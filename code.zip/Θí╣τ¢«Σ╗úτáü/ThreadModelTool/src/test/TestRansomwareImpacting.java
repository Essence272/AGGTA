package test;

import core.AttackStep;
import core.Attacker;
import core.Defense;
import core.GraphViz;
import asset.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TestRansomwareImpacting extends CoreTest {
    private static class RansomwareImpactingModel {

        /*
        attack scenario source: https://us-cert.cisa.gov/ncas/alerts/aa20-049a

                            UserAccount ---  User
                                  |           |
                                  |           |
        Browser ---- Service ---- OS ----- Computer ----- Router
                                                          /    \
                                                         /     \
                                           ExternalNetwork   InternalNetwork
                                            (OT network)      (IT network)

        Attacker's entry point: Service.attemptSpearphishingLink
        */

        public final User user = new User("user");
        public final UserAccount userAccount = new UserAccount("userAccount",false,false);
        public final Browser browser = new Browser("browser");
        public final Service service = new Service("service");
        public final OS os = new OS("os"); // We assume all defenses are disabled for OS. We can enable some of them, then the corresponding attack steps can not be reached.
        public final Computer computer = new Computer("computer");
        public final InternalNetwork itNetwork = new InternalNetwork("ITNetwork");
        public final ExternalNetwork otNetwork = new ExternalNetwork("OTNetwork");
        public final Router router = new Router("router");

        public RansomwareImpactingModel() {
            browser.addService(service);
            os.addService(service);
            os.addComputer(computer);
            os.addUserAccount(userAccount);
            computer.addUser(user);
            computer.addRouter(router);
            router.addInternalNetwork(itNetwork);
            router.addExternalNetwork(otNetwork);
        }
    }

    // Test attack path Spearphishing Link -> User Execution -> Infected Computer -> Encrypt Data for Impact on both OT and IT networks
    public void testPipelineOperationsWithRansomware() {
        var model = new RansomwareImpactingModel();

        model.user.attemptMaliciousLink.assertCompromisedInstantaneously();
        model.user.maliciousLink.assertCompromisedInstantaneously();
        model.os.executeCode.assertCompromisedInstantaneously();
        model.computer.infectedComputer.assertCompromisedInstantaneously();
        model.itNetwork.dataEncryptedForImpact.assertCompromisedInstantaneously();
        model.otNetwork.dataEncryptedForImpact.assertCompromisedInstantaneously();

        // init simulation
        AttackStep target = model.otNetwork.dataEncryptedForImpact;
        List<AttackStep> attackPoints = new ArrayList<AttackStep>();
        attackPoints.add(model.browser.attemptSpearphishingLink);
        int n = 1000;
        int k = 5;

        // set defence
        Defense.setAllDefenses(true);
        model.user.userTraining.setEnabled(false);


        // attack simulate
        Attacker attacker = new Attacker();
        HashMap<Integer, List<Double>> result = new HashMap<Integer, List<Double>>();
        HashMap<Integer, GraphViz> resultGiv = new HashMap<Integer, GraphViz>();
        attacker.simulate(target, attackPoints, n, k, result, resultGiv);

    }

    public void testPipelineAssert() {
        var model = new RansomwareImpactingModel();

        model.user.attemptMaliciousLink.assertCompromisedInstantaneously();
        model.user.maliciousLink.assertCompromisedInstantaneously();
        model.os.executeCode.assertCompromisedInstantaneously();
        model.computer.infectedComputer.assertCompromisedInstantaneously();
        model.itNetwork.dataEncryptedForImpact.assertCompromisedInstantaneously();
        model.otNetwork.dataEncryptedForImpact.assertCompromisedInstantaneously();

    }
    public void drawAttackGraph() {
        var model = new RansomwareImpactingModel();
        AttackStep target = model.otNetwork.dataEncryptedForImpact;
        AttackStep source = model.browser.attemptSpearphishingLink;
        Attacker attacker = new Attacker();
        attacker.drawAttackGraph(source,target);
    }
}