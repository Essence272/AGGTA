package test;

import core.AttackStep;
import core.Attacker;
import core.Defense;
import core.GraphViz;
import asset.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class TestBruteForce extends CoreTest {
    private static class BruteForceAttacksModel {

        /*
        attack scenario source: https://us-cert.cisa.gov/ncas/alerts/TA18-086A

                           Service
                              |
                              |
               UerAccount -- OS -- Computer -- Router -- InternalNetwork
                              |
                              |
                            Windows

        Attacker's entry point: Service.attemptSpearphishingViaService
        */

        public final Service service = new Service("service");
        public final UserAccount userAccount = new UserAccount("userAccount",false,false);
        public final OS os = new OS("os"); // We assume all defenses are disabled for OS. We can enable some of them, then the corresponding attack steps can not be reached.
        public final Windows windows = new Windows("windows");
        public final Computer computer = new Computer("computer");
        public final InternalNetwork victimNetwork = new InternalNetwork("victimNetwork");
        public final Router router = new Router("router");

        public BruteForceAttacksModel() {
            windows.addService(service);
            windows.addUserAccount(userAccount);
            windows.addComputer(computer);
            computer.addRouter(router);
            router.addInternalNetwork(victimNetwork);
        }
    }

    // Test attack path SpearphishingViaService -> SpearphishingViaSocialMedia -> BruteForce -> UserCredentials (RDU) -> EmailCollection -> remoteEmailCollection -> remoteDesktopProtocol -> fileTransferProtocols -> ExfiltrationOverC2Channel
    public void testBruteForceAttacksWithCyberActors() {
        var model = new BruteForceAttacksModel();

        //model.service.spearphishingViaSocialMedia.assertCompromisedInstantaneously();
        //model.os.bruteForce.assertCompromisedInstantaneously();
        //model.userAccount.userCredentials.assertCompromisedInstantaneously();
        //model.os.emailCollection.assertCompromisedInstantaneously();
        //model.victimNetwork.exfiltrationOverC2Channel.assertCompromisedInstantaneously();

        // init simulation
        AttackStep target = model.victimNetwork.exfiltrationOverC2Channel;
        List<AttackStep> attackPoints = new ArrayList<AttackStep>();
        attackPoints.add(model.service.attemptSpearphishingViaService);
        int n = 1000;
        int k = 5;

        // set defence
        Defense.setAllDefenses(false);

        // attack simulate
        Attacker attacker = new Attacker();
        HashMap<Integer, List<Double>> result = new HashMap<Integer, List<Double>>();
        HashMap<Integer, GraphViz> resultGiv = new HashMap<Integer, GraphViz>();
        attacker.simulate(target, attackPoints, n, k, result, resultGiv);
    }

    public void drawAttackGraph() {
        var model = new BruteForceAttacksModel();
        AttackStep target = model.victimNetwork.exfiltrationOverC2Channel;
        AttackStep source = model.service.attemptSpearphishingViaService;
        Attacker attacker = new Attacker();
        attacker.drawAttackGraph(source,target);
    }
}