package test;

import core.AttackStep;
import core.Attacker;
import core.Defense;
import core.GraphViz;
import asset.*;

import java.util.*;

public class TestUkrainePowerGrid extends CoreTest {
    private static class UkrainePowerGridShutdownModel {

        /*
                Browser  ------ Service 
                                  |  
                                  |
                Windows  -------  OS -----  UserAccount
                                  |              |              
                                  |              |
    Firewall ---- Router ----- Computer ------ User
      
        Attacker's entry point: Browser.spearphishingAttachment
        */

        public final User employee = new asset.User("employee",false); // userTraining is set to false; if is set to true, then spearphishingAttachmentDownload.assertUncompromised();
        public final User SCADAUser = new asset.User("SCADAUser",false);
        public final UserAccount employeeAccount = new asset.UserAccount("employeeAccount");
        public final UserAccount SCADAAccount = new asset.UserAccount("SCADAAccount");

        public final Browser browser = new asset.Browser("browser");
        public final Computer officeComputer = new asset.Computer("officeComputer");
        public final Computer SCADAComputer = new asset.Computer("SCADAComputer");
        public final Service remoteService = new asset.Service("remoteService");
        public final Service officeService = new asset.Service("officeService");
        public final OS officeOS = new asset.OS("officeOS");
        public final Windows SCADAEnvironmentWin = new asset.Windows("SCADAEnvironment");

        public final Router router = new asset.Router("router");
        public final Firewall firewall = new asset.Firewall("firewall");

        public UkrainePowerGridShutdownModel() {
            // office area - officeService
            officeService.addBrowser(browser);
            browser.addService(officeService);

            officeService.addOs(officeOS);
            officeOS.addService(officeService);

            // office area - router
            router.addFirewall(firewall);
            //firewall.addRouter(router);

            // office area - employeeAccount
            employeeAccount.addUser(employee);
            employee.addUserAccount(employeeAccount);
            employeeAccount.addOs(officeOS);
            officeOS.addUserAccount(employeeAccount);

            // office area - officeComputer
            officeComputer.addOs(officeOS);
            officeOS.addComputer(officeComputer);

            officeComputer.addUser(employee);
            employee.addComputer(officeComputer);

            officeComputer.addRouter(router);
            router.addComputer(officeComputer);

            officeComputer.addOs(SCADAEnvironmentWin); // link SCADA
            SCADAEnvironmentWin.addComputer(officeComputer);

            // SCADA Environment
            SCADAEnvironmentWin.addService(remoteService);
            remoteService.addOs(SCADAEnvironmentWin);

            //SCADAEnvironmentWin.addUserAccount(SCADAAccount);
            //SCADAAccount.addOs(SCADAEnvironmentWin);

            //SCADAEnvironmentWin.addComputer(SCADAComputer);
            //SCADAComputer.addOs(SCADAEnvironmentWin);

        }
    }

    public void testSystemShutdown(String parm) {
            // init model
            var model = new UkrainePowerGridShutdownModel();

            // init simulation
            AttackStep target = model.SCADAEnvironmentWin.systemShutdownOrReboot;
            List<AttackStep> attackPoints = new ArrayList<AttackStep>();
            attackPoints.add(model.browser.spearphishingAttachment);
            int n = 1000;
            int k = 5;

            // set defence
            Defense.setAllDefenses(true);
            model.employee.userTraining.setEnabled(false);
            model.officeOS.executionPrevention.setEnabled(false);
            //model.service.updateSoftware.setEnabled(false);
            //model.service.multiFactorAuthentication.setEnabled(false);
            //model.os.codeSigning.setEnabled(false);

            // attack simulate
            Attacker attacker = new Attacker();
            HashMap<Integer, List<Double>> result = new HashMap<Integer, List<Double>>();
            HashMap<Integer, GraphViz> resultGiv = new HashMap<Integer, GraphViz>();
            if (parm.equals("Only Zero"))
            {
                attacker.simulate(target, attackPoints, n, k, result, resultGiv, "./src/attackerProfile_0.ttc");
            }
            else if (parm.equals("Only Probability"))
            {
                attacker.simulate(target, attackPoints, n, k, result, resultGiv, "E");
            }
            else
            {
                attacker.simulate(target, attackPoints, n, k, result, resultGiv);
            }

            // assert
    }

    public void drawAttackGraph() {
        var model = new UkrainePowerGridShutdownModel();
        AttackStep target = model.SCADAEnvironmentWin.systemShutdownOrReboot;
        AttackStep source = model.browser.spearphishingAttachment;
        Attacker attacker = new Attacker();
        attacker.drawAttackGraph(source,target);
    }

    private static class UkrainePowerGridServiceStopModel {

        /*
                  OS ------ Service
      
        Attacker's entry point: OS.endpointDenialOfService
        */

        public final asset.Service service = new asset.Service("service");
        public final asset.OS os = new asset.OS("os");
        public final asset.Windows windows = new asset.Windows("windows");

        public UkrainePowerGridServiceStopModel() {
            os.addService(service);
        }
    }

    public void testServiceStop() {
            var model = new UkrainePowerGridServiceStopModel();

            Attacker attacker = new Attacker();
            attacker.addAttackPoint(model.os.endpointDenialOfService);
            attacker.attack();

            model.os.serviceExhaustionFlood.assertCompromisedInstantaneously();
            //model.os.serviceExhaustionFlood.tracePath(0);
    }
}



