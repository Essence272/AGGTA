package test.individualTest.rootkit.src.test.java;

import asset.*;
import core.*;
import test.CoreTest;

public class  TestRootkit extends CoreTest{
    /*
                              OS -----   UserAccount

        Attacker's entry point: userAccount.userRights
    */

    // https://medium.com/chronicle-blog/winnti-more-than-just-windows-and-gates-e4f03436031a
    //  rootkit no defens aktiv.
    private static class rootkit{
        public final UserAccount userAccount = new UserAccount("userAccount");
        public final OS os = new OS("os");
        public final Windows win = new Windows("win");

        public rootkit() {
            userAccount.addOs(os);
        }

    }

    public void persistence(){
        var model = new rootkit();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.userAccount.userRights);
        attacker.attack();

        model.os.rootkit.assertCompromisedInstantaneously();
        model.os.modifyAPICalls.assertCompromisedInstantaneously();
        model.os.bypassAntivirus.assertCompromisedInstantaneously();
        model.os.bypassFileMonitoring.assertCompromisedInstantaneously();
        model.os.bypassProcessWhitelisting.assertCompromisedInstantaneously();
        model.os.bypassSignatureBasedDetection.assertCompromisedInstantaneously();
        model.os.bypassProcessWhitelisting.assertCompromisedInstantaneously();
        model.os.bypassHostIntrusionPrevention.assertCompromisedInstantaneously();
        model.os.bypassSystemAccessControls.assertCompromisedInstantaneously();
    }



}


