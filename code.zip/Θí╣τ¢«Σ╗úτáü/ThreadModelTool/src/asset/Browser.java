package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Browser extends Asset {
  public DriveByCompromise driveByCompromise;

  public Malvertising malvertising;

  public CrossSiteScripting crossSiteScripting;

  public CredentialsFromWebBrowsers credentialsFromWebBrowsers;

  public Phishing phishing;

  public AttemptSpearphishingLink attemptSpearphishingLink;

  public SpearphishingLink spearphishingLink;

  public AttemptSpearphishingAttachment attemptSpearphishingAttachment;

  public SpearphishingAttachment spearphishingAttachment;

  public BrowserBookmarkDiscovery browserBookmarkDiscovery;

  public InstallExtensions installExtensions;

  public BrowserExtensions browserExtensions;

  public StealWebSessionCookie stealWebSessionCookie;

  public AttemptWebSessionCookie attemptWebSessionCookie;

  public WebSessionCookie webSessionCookie;

  public UpdateSoftware updateSoftware;

  public ExploitProtection exploitProtection;

  public Audit audit;

  public PasswordPolicies passwordPolicies;

  public MultiFactorAuthentication multiFactorAuthentication;

  public RestrictWebBasedContent restrictWebBasedContent;

  public Set<Service> service = new HashSet<>();

  public Browser(String name, boolean isUpdateSoftwareEnabled, boolean isExploitProtectionEnabled,
      boolean isAuditEnabled, boolean isPasswordPoliciesEnabled,
      boolean isMultiFactorAuthenticationEnabled, boolean isRestrictWebBasedContentEnabled) {
    super(name);
    assetClassName = "Browser";
    AttackStep.allAttackSteps.remove(driveByCompromise);
    driveByCompromise = new DriveByCompromise(name);
    AttackStep.allAttackSteps.remove(malvertising);
    malvertising = new Malvertising(name);
    AttackStep.allAttackSteps.remove(crossSiteScripting);
    crossSiteScripting = new CrossSiteScripting(name);
    AttackStep.allAttackSteps.remove(credentialsFromWebBrowsers);
    credentialsFromWebBrowsers = new CredentialsFromWebBrowsers(name);
    AttackStep.allAttackSteps.remove(phishing);
    phishing = new Phishing(name);
    AttackStep.allAttackSteps.remove(attemptSpearphishingLink);
    attemptSpearphishingLink = new AttemptSpearphishingLink(name);
    AttackStep.allAttackSteps.remove(spearphishingLink);
    spearphishingLink = new SpearphishingLink(name);
    AttackStep.allAttackSteps.remove(attemptSpearphishingAttachment);
    attemptSpearphishingAttachment = new AttemptSpearphishingAttachment(name);
    AttackStep.allAttackSteps.remove(spearphishingAttachment);
    spearphishingAttachment = new SpearphishingAttachment(name);
    AttackStep.allAttackSteps.remove(browserBookmarkDiscovery);
    browserBookmarkDiscovery = new BrowserBookmarkDiscovery(name);
    AttackStep.allAttackSteps.remove(installExtensions);
    installExtensions = new InstallExtensions(name);
    AttackStep.allAttackSteps.remove(browserExtensions);
    browserExtensions = new BrowserExtensions(name);
    AttackStep.allAttackSteps.remove(stealWebSessionCookie);
    stealWebSessionCookie = new StealWebSessionCookie(name);
    AttackStep.allAttackSteps.remove(attemptWebSessionCookie);
    attemptWebSessionCookie = new AttemptWebSessionCookie(name);
    AttackStep.allAttackSteps.remove(webSessionCookie);
    webSessionCookie = new WebSessionCookie(name);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, isUpdateSoftwareEnabled);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, isExploitProtectionEnabled);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, isAuditEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (restrictWebBasedContent != null) {
      AttackStep.allAttackSteps.remove(restrictWebBasedContent.disable);
    }
    Defense.allDefenses.remove(restrictWebBasedContent);
    restrictWebBasedContent = new RestrictWebBasedContent(name, isRestrictWebBasedContentEnabled);
  }

  public Browser(String name) {
    super(name);
    assetClassName = "Browser";
    AttackStep.allAttackSteps.remove(driveByCompromise);
    driveByCompromise = new DriveByCompromise(name);
    AttackStep.allAttackSteps.remove(malvertising);
    malvertising = new Malvertising(name);
    AttackStep.allAttackSteps.remove(crossSiteScripting);
    crossSiteScripting = new CrossSiteScripting(name);
    AttackStep.allAttackSteps.remove(credentialsFromWebBrowsers);
    credentialsFromWebBrowsers = new CredentialsFromWebBrowsers(name);
    AttackStep.allAttackSteps.remove(phishing);
    phishing = new Phishing(name);
    AttackStep.allAttackSteps.remove(attemptSpearphishingLink);
    attemptSpearphishingLink = new AttemptSpearphishingLink(name);
    AttackStep.allAttackSteps.remove(spearphishingLink);
    spearphishingLink = new SpearphishingLink(name);
    AttackStep.allAttackSteps.remove(attemptSpearphishingAttachment);
    attemptSpearphishingAttachment = new AttemptSpearphishingAttachment(name);
    AttackStep.allAttackSteps.remove(spearphishingAttachment);
    spearphishingAttachment = new SpearphishingAttachment(name);
    AttackStep.allAttackSteps.remove(browserBookmarkDiscovery);
    browserBookmarkDiscovery = new BrowserBookmarkDiscovery(name);
    AttackStep.allAttackSteps.remove(installExtensions);
    installExtensions = new InstallExtensions(name);
    AttackStep.allAttackSteps.remove(browserExtensions);
    browserExtensions = new BrowserExtensions(name);
    AttackStep.allAttackSteps.remove(stealWebSessionCookie);
    stealWebSessionCookie = new StealWebSessionCookie(name);
    AttackStep.allAttackSteps.remove(attemptWebSessionCookie);
    attemptWebSessionCookie = new AttemptWebSessionCookie(name);
    AttackStep.allAttackSteps.remove(webSessionCookie);
    webSessionCookie = new WebSessionCookie(name);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, false);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, false);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (restrictWebBasedContent != null) {
      AttackStep.allAttackSteps.remove(restrictWebBasedContent.disable);
    }
    Defense.allDefenses.remove(restrictWebBasedContent);
    restrictWebBasedContent = new RestrictWebBasedContent(name, false);
  }

  public Browser(boolean isUpdateSoftwareEnabled, boolean isExploitProtectionEnabled,
      boolean isAuditEnabled, boolean isPasswordPoliciesEnabled,
      boolean isMultiFactorAuthenticationEnabled, boolean isRestrictWebBasedContentEnabled) {
    this("Anonymous", isUpdateSoftwareEnabled, isExploitProtectionEnabled, isAuditEnabled, isPasswordPoliciesEnabled, isMultiFactorAuthenticationEnabled, isRestrictWebBasedContentEnabled);
  }

  public Browser() {
    this("Anonymous");
  }

  public void addService(Service service) {
    this.service.add(service);
    service.browser.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("service")) {
      return Service.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("service")) {
      assets.addAll(service);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(service);
    return assets;
  }

  public class DriveByCompromise extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDriveByCompromise;

    private Set<AttackStep> _cacheParentDriveByCompromise;

    public DriveByCompromise(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDriveByCompromise == null) {
        _cacheChildrenDriveByCompromise = new HashSet<>();
        _cacheChildrenDriveByCompromise.add(malvertising);
        _cacheChildrenDriveByCompromise.add(crossSiteScripting);
        for (Service _0 : service) {
          if (_0.os != null) {
            for (Computer _1 : _0.os.computer) {
              for (User _2 : _1.user) {
                _cacheChildrenDriveByCompromise.add(_2.attemptUserExecution);
              }
            }
          }
        }
        for (Service _3 : service) {
          _cacheChildrenDriveByCompromise.add(_3.attemptExploitationForClientExecution);
        }
        for (Service _4 : service) {
          if (_4.os != null) {
            _cacheChildrenDriveByCompromise.add(_4.os.attemptGatekeeperBypass);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDriveByCompromise) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDriveByCompromise == null) {
        _cacheParentDriveByCompromise = new HashSet<>();
        for (Service _5 : service) {
          if (_5.os != null) {
            for (UserAccount _6 : _5.os.userAccount) {
              _cacheParentDriveByCompromise.add(_6.userRights);
            }
          }
        }
        _cacheParentDriveByCompromise.add(updateSoftware.disable);
        _cacheParentDriveByCompromise.add(exploitProtection.disable);
        _cacheParentDriveByCompromise.add(restrictWebBasedContent.disable);
        for (Service _7 : service) {
          if (_7.os != null) {
            _cacheParentDriveByCompromise.add(_7.os.javaScriptOrJScript);
          }
        }
        for (Service _8 : service) {
          if (_8.os != null) {
            _cacheParentDriveByCompromise.add(_8.os.applicationIsolationAndSandboxing.disable);
          }
        }
        for (Service _9 : service) {
          if (_9.os != null) {
            if (_9.os instanceof Windows) {
              _cacheParentDriveByCompromise.add(((asset.Windows) _9.os).manInTheBrowser);
            }
          }
        }
        for (Service _a : service) {
          if (_a.os != null) {
            for (Computer _b : _a.os.computer) {
              for (Router _c : _b.router) {
                for (InternalNetwork _d : _c.internalNetwork) {
                  _cacheParentDriveByCompromise.add(_d.internalDefacement);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDriveByCompromise) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.driveByCompromise");
    }
  }

  public class Malvertising extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenMalvertising;

    private Set<AttackStep> _cacheParentMalvertising;

    public Malvertising(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMalvertising == null) {
        _cacheChildrenMalvertising = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenMalvertising.add(_0.stealApplicationAccessToken);
        }
      }
      for (AttackStep attackStep : _cacheChildrenMalvertising) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMalvertising == null) {
        _cacheParentMalvertising = new HashSet<>();
        _cacheParentMalvertising.add(driveByCompromise);
      }
      for (AttackStep attackStep : _cacheParentMalvertising) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.malvertising");
    }
  }

  public class CrossSiteScripting extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCrossSiteScripting;

    private Set<AttackStep> _cacheParentCrossSiteScripting;

    public CrossSiteScripting(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCrossSiteScripting == null) {
        _cacheChildrenCrossSiteScripting = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenCrossSiteScripting.add(_0.stealApplicationAccessToken);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCrossSiteScripting) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCrossSiteScripting == null) {
        _cacheParentCrossSiteScripting = new HashSet<>();
        _cacheParentCrossSiteScripting.add(driveByCompromise);
      }
      for (AttackStep attackStep : _cacheParentCrossSiteScripting) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.crossSiteScripting");
    }
  }

  public class CredentialsFromWebBrowsers extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCredentialsFromWebBrowsers;

    private Set<AttackStep> _cacheParentCredentialsFromWebBrowsers;

    public CredentialsFromWebBrowsers(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCredentialsFromWebBrowsers == null) {
        _cacheChildrenCredentialsFromWebBrowsers = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            for (UserAccount _1 : _0.os.userAccount) {
              _cacheChildrenCredentialsFromWebBrowsers.add(_1.userCredentials);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCredentialsFromWebBrowsers) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialsFromWebBrowsers == null) {
        _cacheParentCredentialsFromWebBrowsers = new HashSet<>();
        _cacheParentCredentialsFromWebBrowsers.add(passwordPolicies.disable);
        for (Service _2 : service) {
          if (_2.os != null) {
            _cacheParentCredentialsFromWebBrowsers.add(_2.os.credentialsFromPasswordStores);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCredentialsFromWebBrowsers) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.credentialsFromWebBrowsers");
    }
  }

  public class Phishing extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenPhishing;

    private Set<AttackStep> _cacheParentPhishing;

    public Phishing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPhishing == null) {
        _cacheChildrenPhishing = new HashSet<>();
        _cacheChildrenPhishing.add(attemptSpearphishingAttachment);
        _cacheChildrenPhishing.add(attemptSpearphishingLink);
        for (Service _0 : service) {
          _cacheChildrenPhishing.add(_0.attemptSpearphishingViaService);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPhishing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPhishing == null) {
        _cacheParentPhishing = new HashSet<>();
        for (Service _1 : service) {
          if (_1.os != null) {
            _cacheParentPhishing.add(_1.os.compileAfterDelivery);
          }
        }
        for (Service _2 : service) {
          if (_2.os != null) {
            if (_2.os instanceof Windows) {
              _cacheParentPhishing.add(((asset.Windows) _2.os).controlPanel);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentPhishing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.phishing");
    }
  }

  public class AttemptSpearphishingLink extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSpearphishingLink;

    private Set<AttackStep> _cacheParentAttemptSpearphishingLink;

    public AttemptSpearphishingLink(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSpearphishingLink == null) {
        _cacheChildrenAttemptSpearphishingLink = new HashSet<>();
        _cacheChildrenAttemptSpearphishingLink.add(spearphishingLink);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSpearphishingLink) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSpearphishingLink == null) {
        _cacheParentAttemptSpearphishingLink = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentAttemptSpearphishingLink.add(_0.spearphishingViaPersonalEmail);
        }
        for (Service _1 : service) {
          _cacheParentAttemptSpearphishingLink.add(_1.spearphishingViaSocialMedia);
        }
        _cacheParentAttemptSpearphishingLink.add(phishing);
      }
      for (AttackStep attackStep : _cacheParentAttemptSpearphishingLink) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.attemptSpearphishingLink");
    }
  }

  public class SpearphishingLink extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSpearphishingLink;

    private Set<AttackStep> _cacheParentSpearphishingLink;

    public SpearphishingLink(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSpearphishingLink == null) {
        _cacheChildrenSpearphishingLink = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            for (Computer _1 : _0.os.computer) {
              for (User _2 : _1.user) {
                _cacheChildrenSpearphishingLink.add(_2.attemptMaliciousLink);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSpearphishingLink) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSpearphishingLink == null) {
        _cacheParentSpearphishingLink = new HashSet<>();
        for (Service _3 : service) {
          if (_3 instanceof CloudService) {
            _cacheParentSpearphishingLink.add(((asset.CloudService) _3).stealApplicationAccessToken);
          }
        }
        _cacheParentSpearphishingLink.add(attemptSpearphishingLink);
        _cacheParentSpearphishingLink.add(restrictWebBasedContent.disable);
        for (Service _4 : service) {
          if (_4.os != null) {
            _cacheParentSpearphishingLink.add(_4.os.antivirus.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentSpearphishingLink) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.spearphishingLink");
    }
  }

  public class AttemptSpearphishingAttachment extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSpearphishingAttachment;

    private Set<AttackStep> _cacheParentAttemptSpearphishingAttachment;

    public AttemptSpearphishingAttachment(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSpearphishingAttachment == null) {
        _cacheChildrenAttemptSpearphishingAttachment = new HashSet<>();
        _cacheChildrenAttemptSpearphishingAttachment.add(spearphishingAttachment);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSpearphishingAttachment) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSpearphishingAttachment == null) {
        _cacheParentAttemptSpearphishingAttachment = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentAttemptSpearphishingAttachment.add(_0.spearphishingViaPersonalEmail);
        }
        for (Service _1 : service) {
          _cacheParentAttemptSpearphishingAttachment.add(_1.spearphishingViaSocialMedia);
        }
        _cacheParentAttemptSpearphishingAttachment.add(phishing);
        for (Service _2 : service) {
          if (_2.os != null) {
            _cacheParentAttemptSpearphishingAttachment.add(_2.os.visualBasic);
          }
        }
        for (Service _3 : service) {
          if (_3.os != null) {
            _cacheParentAttemptSpearphishingAttachment.add(_3.os.rightToLeftOverride);
          }
        }
        for (Service _4 : service) {
          if (_4.os != null) {
            if (_4.os instanceof Windows) {
              _cacheParentAttemptSpearphishingAttachment.add(((asset.Windows) _4.os).parentPIDSpoofing);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptSpearphishingAttachment) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.attemptSpearphishingAttachment");
    }
  }

  public class SpearphishingAttachment extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSpearphishingAttachment;

    private Set<AttackStep> _cacheParentSpearphishingAttachment;

    public SpearphishingAttachment(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSpearphishingAttachment == null) {
        _cacheChildrenSpearphishingAttachment = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            for (Computer _1 : _0.os.computer) {
              for (User _2 : _1.user) {
                _cacheChildrenSpearphishingAttachment.add(_2.attemptMaliciousFile);
              }
            }
          }
        }
        for (Service _3 : service) {
          if (_3.os != null) {
            _cacheChildrenSpearphishingAttachment.add(_3.os.attemptControlPanel);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSpearphishingAttachment) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSpearphishingAttachment == null) {
        _cacheParentSpearphishingAttachment = new HashSet<>();
        _cacheParentSpearphishingAttachment.add(attemptSpearphishingAttachment);
        _cacheParentSpearphishingAttachment.add(restrictWebBasedContent.disable);
        for (Service _4 : service) {
          if (_4.os != null) {
            _cacheParentSpearphishingAttachment.add(_4.os.antivirus.disable);
          }
        }
        for (Service _5 : service) {
          if (_5.os != null) {
            if (_5.os instanceof Windows) {
              _cacheParentSpearphishingAttachment.add(((asset.Windows) _5.os).templateInjection);
            }
          }
        }
        for (Service _6 : service) {
          if (_6.os != null) {
            for (Computer _7 : _6.os.computer) {
              for (Router _8 : _7.router) {
                for (InternalNetwork _9 : _8.internalNetwork) {
                  _cacheParentSpearphishingAttachment.add(_9.networkIntrusionPrevention.disable);
                }
              }
            }
          }
        }
        for (Service _a : service) {
          if (_a.os != null) {
            for (Computer _b : _a.os.computer) {
              for (Router _c : _b.router) {
                for (ExternalNetwork _d : _c.externalNetwork) {
                  _cacheParentSpearphishingAttachment.add(_d.networkIntrusionPrevention.disable);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentSpearphishingAttachment) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.spearphishingAttachment");
    }
  }

  public class BrowserBookmarkDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenBrowserBookmarkDiscovery;

    private Set<AttackStep> _cacheParentBrowserBookmarkDiscovery;

    public BrowserBookmarkDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBrowserBookmarkDiscovery == null) {
        _cacheChildrenBrowserBookmarkDiscovery = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            for (UserAccount _1 : _0.os.userAccount) {
              _cacheChildrenBrowserBookmarkDiscovery.add(_1.userInformation);
            }
          }
        }
        for (Service _2 : service) {
          if (_2.os != null) {
            for (Computer _3 : _2.os.computer) {
              for (Router _4 : _3.router) {
                for (InternalNetwork _5 : _4.internalNetwork) {
                  _cacheChildrenBrowserBookmarkDiscovery.add(_5.internalNetworkResourcesInformation);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenBrowserBookmarkDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBrowserBookmarkDiscovery == null) {
        _cacheParentBrowserBookmarkDiscovery = new HashSet<>();
        for (Service _6 : service) {
          if (_6.os != null) {
            for (UserAccount _7 : _6.os.userAccount) {
              _cacheParentBrowserBookmarkDiscovery.add(_7.userRights);
            }
          }
        }
        for (Service _8 : service) {
          if (_8.os != null) {
            _cacheParentBrowserBookmarkDiscovery.add(_8.os.credentialsInFiles);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentBrowserBookmarkDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.browserBookmarkDiscovery");
    }
  }

  public class InstallExtensions extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenInstallExtensions;

    private Set<AttackStep> _cacheParentInstallExtensions;

    public InstallExtensions(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInstallExtensions == null) {
        _cacheChildrenInstallExtensions = new HashSet<>();
        _cacheChildrenInstallExtensions.add(browserExtensions);
      }
      for (AttackStep attackStep : _cacheChildrenInstallExtensions) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInstallExtensions == null) {
        _cacheParentInstallExtensions = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            for (UserAccount _1 : _0.os.userAccount) {
              _cacheParentInstallExtensions.add(_1.userRights);
            }
          }
        }
        for (Service _2 : service) {
          if (_2.os != null) {
            _cacheParentInstallExtensions.add(_2.os.compromisedDataOrSystem);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentInstallExtensions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.installExtensions");
    }
  }

  public class BrowserExtensions extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenBrowserExtensions;

    private Set<AttackStep> _cacheParentBrowserExtensions;

    public BrowserExtensions(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBrowserExtensions == null) {
        _cacheChildrenBrowserExtensions = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            for (UserAccount _1 : _0.os.userAccount) {
              _cacheChildrenBrowserExtensions.add(_1.userInformation);
            }
          }
        }
        for (Service _2 : service) {
          if (_2.os != null) {
            for (UserAccount _3 : _2.os.userAccount) {
              _cacheChildrenBrowserExtensions.add(_3.userCredentials);
            }
          }
        }
        for (Service _4 : service) {
          if (_4.os != null) {
            _cacheChildrenBrowserExtensions.add(_4.os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenBrowserExtensions) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBrowserExtensions == null) {
        _cacheParentBrowserExtensions = new HashSet<>();
        for (Service _5 : service) {
          if (_5.os != null) {
            for (UserAccount _6 : _5.os.userAccount) {
              _cacheParentBrowserExtensions.add(_6.userTraining.disable);
            }
          }
        }
        _cacheParentBrowserExtensions.add(installExtensions);
        _cacheParentBrowserExtensions.add(audit.disable);
        for (Service _7 : service) {
          if (_7.os != null) {
            _cacheParentBrowserExtensions.add(_7.os.executionPrevention.disable);
          }
        }
        for (Service _8 : service) {
          if (_8.os != null) {
            _cacheParentBrowserExtensions.add(_8.os.limitSoftwareInstallation.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentBrowserExtensions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.browserExtensions");
    }
  }

  public class StealWebSessionCookie extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenStealWebSessionCookie;

    private Set<AttackStep> _cacheParentStealWebSessionCookie;

    public StealWebSessionCookie(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenStealWebSessionCookie == null) {
        _cacheChildrenStealWebSessionCookie = new HashSet<>();
        _cacheChildrenStealWebSessionCookie.add(attemptWebSessionCookie);
      }
      for (AttackStep attackStep : _cacheChildrenStealWebSessionCookie) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentStealWebSessionCookie == null) {
        _cacheParentStealWebSessionCookie = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            for (UserAccount _1 : _0.os.userAccount) {
              _cacheParentStealWebSessionCookie.add(_1.userRights);
            }
          }
        }
        for (Service _2 : service) {
          if (_2.os != null) {
            for (UserAccount _3 : _2.os.userAccount) {
              _cacheParentStealWebSessionCookie.add(_3.userTraining.disable);
            }
          }
        }
        _cacheParentStealWebSessionCookie.add(multiFactorAuthentication.disable);
        for (Service _4 : service) {
          if (_4.os != null) {
            _cacheParentStealWebSessionCookie.add(_4.os.softwareConfiguration.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentStealWebSessionCookie) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.stealWebSessionCookie");
    }
  }

  public class AttemptWebSessionCookie extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptWebSessionCookie;

    private Set<AttackStep> _cacheParentAttemptWebSessionCookie;

    public AttemptWebSessionCookie(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptWebSessionCookie == null) {
        _cacheChildrenAttemptWebSessionCookie = new HashSet<>();
        _cacheChildrenAttemptWebSessionCookie.add(webSessionCookie);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptWebSessionCookie) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWebSessionCookie == null) {
        _cacheParentAttemptWebSessionCookie = new HashSet<>();
        _cacheParentAttemptWebSessionCookie.add(stealWebSessionCookie);
      }
      for (AttackStep attackStep : _cacheParentAttemptWebSessionCookie) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.attemptWebSessionCookie");
    }
  }

  public class WebSessionCookie extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenWebSessionCookie;

    private Set<AttackStep> _cacheParentWebSessionCookie;

    public WebSessionCookie(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWebSessionCookie == null) {
        _cacheChildrenWebSessionCookie = new HashSet<>();
        for (Service _0 : service) {
          if (_0.os != null) {
            _cacheChildrenWebSessionCookie.add(_0.os.sensitiveDataCollected);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenWebSessionCookie) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWebSessionCookie == null) {
        _cacheParentWebSessionCookie = new HashSet<>();
        _cacheParentWebSessionCookie.add(attemptWebSessionCookie);
        for (Service _1 : service) {
          if (_1.os != null) {
            _cacheParentWebSessionCookie.add(_1.os.softwareConfiguration.disable);
          }
        }
        for (Service _2 : service) {
          if (_2.os != null) {
            if (_2.os instanceof Windows) {
              _cacheParentWebSessionCookie.add(((asset.Windows) _2.os).useAlternateAuthenticationMaterial);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentWebSessionCookie) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Browser.webSessionCookie");
    }
  }

  public class UpdateSoftware extends Defense {
    public UpdateSoftware(String name) {
      this(name, false);
    }

    public UpdateSoftware(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenUpdateSoftware;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenUpdateSoftware == null) {
          _cacheChildrenUpdateSoftware = new HashSet<>();
          _cacheChildrenUpdateSoftware.add(driveByCompromise);
        }
        for (AttackStep attackStep : _cacheChildrenUpdateSoftware) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Browser.updateSoftware";
      }
    }
  }

  public class ExploitProtection extends Defense {
    public ExploitProtection(String name) {
      this(name, false);
    }

    public ExploitProtection(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenExploitProtection;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenExploitProtection == null) {
          _cacheChildrenExploitProtection = new HashSet<>();
          _cacheChildrenExploitProtection.add(driveByCompromise);
        }
        for (AttackStep attackStep : _cacheChildrenExploitProtection) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Browser.exploitProtection";
      }
    }
  }

  public class Audit extends Defense {
    public Audit(String name) {
      this(name, false);
    }

    public Audit(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenAudit;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenAudit == null) {
          _cacheChildrenAudit = new HashSet<>();
          _cacheChildrenAudit.add(browserExtensions);
        }
        for (AttackStep attackStep : _cacheChildrenAudit) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Browser.audit";
      }
    }
  }

  public class PasswordPolicies extends Defense {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenPasswordPolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenPasswordPolicies == null) {
          _cacheChildrenPasswordPolicies = new HashSet<>();
          _cacheChildrenPasswordPolicies.add(credentialsFromWebBrowsers);
        }
        for (AttackStep attackStep : _cacheChildrenPasswordPolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Browser.passwordPolicies";
      }
    }
  }

  public class MultiFactorAuthentication extends Defense {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(stealWebSessionCookie);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Browser.multiFactorAuthentication";
      }
    }
  }

  public class RestrictWebBasedContent extends Defense {
    public RestrictWebBasedContent(String name) {
      this(name, false);
    }

    public RestrictWebBasedContent(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenRestrictWebBasedContent;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenRestrictWebBasedContent == null) {
          _cacheChildrenRestrictWebBasedContent = new HashSet<>();
          _cacheChildrenRestrictWebBasedContent.add(spearphishingAttachment);
          _cacheChildrenRestrictWebBasedContent.add(spearphishingLink);
          for (Service _0 : service) {
            _cacheChildrenRestrictWebBasedContent.add(_0.spearphishingViaService);
          }
          _cacheChildrenRestrictWebBasedContent.add(driveByCompromise);
          for (Service _1 : service) {
            if (_1.os != null) {
              _cacheChildrenRestrictWebBasedContent.add(_1.os.commandAndScriptingInterpreter);
            }
          }
          for (Service _2 : service) {
            if (_2.os != null) {
              _cacheChildrenRestrictWebBasedContent.add(_2.os.domainGenerationAlgorithms);
            }
          }
          for (Service _3 : service) {
            if (_3.os != null) {
              _cacheChildrenRestrictWebBasedContent.add(_3.os.compiledHTMLFile);
            }
          }
          for (Service _4 : service) {
            if (_4.os != null) {
              for (UserAccount _5 : _4.os.userAccount) {
                _cacheChildrenRestrictWebBasedContent.add(_5.userExecution);
              }
            }
          }
          for (Service _6 : service) {
            if (_6.os != null) {
              for (Computer _7 : _6.os.computer) {
                for (User _8 : _7.user) {
                  _cacheChildrenRestrictWebBasedContent.add(_8.maliciousLink);
                }
              }
            }
          }
          for (Service _9 : service) {
            if (_9.os != null) {
              for (Computer _a : _9.os.computer) {
                for (Router _b : _a.router) {
                  for (ExternalNetwork _c : _b.externalNetwork) {
                    _cacheChildrenRestrictWebBasedContent.add(_c.bidirectionaCommunication);
                  }
                }
              }
            }
          }
          for (Service _d : service) {
            if (_d.os != null) {
              for (Computer _e : _d.os.computer) {
                for (Router _f : _e.router) {
                  for (ExternalNetwork _10 : _f.externalNetwork) {
                    _cacheChildrenRestrictWebBasedContent.add(_10.deadDropResolver);
                  }
                }
              }
            }
          }
          for (Service _11 : service) {
            if (_11.os != null) {
              for (Computer _12 : _11.os.computer) {
                for (Router _13 : _12.router) {
                  for (ExternalNetwork _14 : _13.externalNetwork) {
                    _cacheChildrenRestrictWebBasedContent.add(_14.oneWayCommunication);
                  }
                }
              }
            }
          }
          for (Service _15 : service) {
            if (_15.os != null) {
              for (Computer _16 : _15.os.computer) {
                for (Router _17 : _16.router) {
                  for (ExternalNetwork _18 : _17.externalNetwork) {
                    _cacheChildrenRestrictWebBasedContent.add(_18.exfiltrationOverWebService);
                  }
                }
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenRestrictWebBasedContent) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Browser.restrictWebBasedContent";
      }
    }
  }
}
