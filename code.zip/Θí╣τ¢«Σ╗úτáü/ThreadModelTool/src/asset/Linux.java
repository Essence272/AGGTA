package asset;

import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Linux extends OS {
  public AttemptClearCommandHistory attemptClearCommandHistory;

  public ClearLinuxSystemLogs clearLinuxSystemLogs;

  public AttemptBash_profileAndBashrc attemptBash_profileAndBashrc;

  public AttemptBashHistory attemptBashHistory;

  public LinuxFileAndDirectoryPermissionsModification linuxFileAndDirectoryPermissionsModification;

  public LD_PRELOAD lD_PRELOAD;

  public PtraceSystemCalls ptraceSystemCalls;

  public AttemptProcMemory attemptProcMemory;

  public ProcMemory procMemory;

  public SetuidAndSetgid setuidAndSetgid;

  public SSHAuthorizedKeys sSHAuthorizedKeys;

  public AttemptSystemdService attemptSystemdService;

  public UnixShell unixShell;

  public VDSOHijacking vDSOHijacking;

  public EnvironmentVariablePermissions environmentVariablePermissions;

  public Linux(String name, boolean isAntivirusEnabled,
      boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled, boolean isEnvironmentVariablePermissionsEnabled) {
    super(name, isAntivirusEnabled, isRestrictFileAndDirectoryPermissionsEnabled, isRestrictRegistryPermissionsEnabled, isAccountUsePoliciesEnabled, isBehaviorPreventionOnEndpointEnabled, isBootIntegrityEnabled, isDataBackupEnabled, isMultiFactorAuthenticationEnabled, isPasswordPoliciesEnabled, isApplicationIsolationAndSandboxingEnabled, isDoNotMitigateEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isActiveDirectoryConfigurationEnabled, isAuditEnabled, isApplicationDeveloperGuidanceEnabled, isCodeSigningEnabled, isLimitHardwareInstallationEnabled, isOperatingSystemConfigurationEnabled, isSoftwareConfigurationEnabled, isExecutionPreventionEnabled, isPrivilegedAccountManagementEnabled, isEncryptSensitiveInformationEnabled, isRemoteDataStorageEnabled, isLimitSoftwareInstallationEnabled, isUpdateSoftwareEnabled, isUserAccountControlEnabled, isExploitProtectionEnabled);
    assetClassName = "Linux";
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(at);
    at = new At(name);
    AttackStep.allAttackSteps.remove(attemptBootkit);
    attemptBootkit = new AttemptBootkit(name);
    AttackStep.allAttackSteps.remove(bootkit);
    bootkit = new Bootkit(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(attemptClearCommandHistory);
    attemptClearCommandHistory = new AttemptClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(clearCommandHistory);
    clearCommandHistory = new ClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(clearLinuxSystemLogs);
    clearLinuxSystemLogs = new ClearLinuxSystemLogs(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(credentialsFromPasswordStores);
    credentialsFromPasswordStores = new CredentialsFromPasswordStores(name);
    AttackStep.allAttackSteps.remove(cron);
    cron = new Cron(name);
    AttackStep.allAttackSteps.remove(_etc_passwdAND_etc_shadow);
    _etc_passwdAND_etc_shadow = new _etc_passwdAND_etc_shadow(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(spaceAfterFileName);
    spaceAfterFileName = new SpaceAfterFileName(name);
    AttackStep.allAttackSteps.remove(attemptBash_profileAndBashrc);
    attemptBash_profileAndBashrc = new AttemptBash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bash_profileAndBashrc);
    bash_profileAndBashrc = new Bash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(attemptBashHistory);
    attemptBashHistory = new AttemptBashHistory(name);
    AttackStep.allAttackSteps.remove(bashHistory);
    bashHistory = new BashHistory(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(linuxFileAndDirectoryPermissionsModification);
    linuxFileAndDirectoryPermissionsModification = new LinuxFileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(hISTCONTROL);
    hISTCONTROL = new HISTCONTROL(name);
    AttackStep.allAttackSteps.remove(infectedOS);
    infectedOS = new InfectedOS(name);
    AttackStep.allAttackSteps.remove(kernelModulesAndExtensions);
    kernelModulesAndExtensions = new KernelModulesAndExtensions(name);
    AttackStep.allAttackSteps.remove(lD_PRELOAD);
    lD_PRELOAD = new LD_PRELOAD(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(masqueradeTaskOrService);
    masqueradeTaskOrService = new MasqueradeTaskOrService(name);
    AttackStep.allAttackSteps.remove(oSCredentialDumping);
    oSCredentialDumping = new OSCredentialDumping(name);
    AttackStep.allAttackSteps.remove(pluggableAuthenticationModules);
    pluggableAuthenticationModules = new PluggableAuthenticationModules(name);
    AttackStep.allAttackSteps.remove(portKnocking);
    portKnocking = new PortKnocking(name);
    AttackStep.allAttackSteps.remove(procFilesystem);
    procFilesystem = new ProcFilesystem(name);
    AttackStep.allAttackSteps.remove(ptraceSystemCalls);
    ptraceSystemCalls = new PtraceSystemCalls(name);
    AttackStep.allAttackSteps.remove(preOSBoot);
    preOSBoot = new PreOSBoot(name);
    AttackStep.allAttackSteps.remove(attemptProcMemory);
    attemptProcMemory = new AttemptProcMemory(name);
    AttackStep.allAttackSteps.remove(procMemory);
    procMemory = new ProcMemory(name);
    AttackStep.allAttackSteps.remove(processInjection);
    processInjection = new ProcessInjection(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(serverSoftwareComponent);
    serverSoftwareComponent = new ServerSoftwareComponent(name);
    AttackStep.allAttackSteps.remove(attemptSetuidAndSetgid);
    attemptSetuidAndSetgid = new AttemptSetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(setuidAndSetgid);
    setuidAndSetgid = new SetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(securitydMemory);
    securitydMemory = new SecuritydMemory(name);
    AttackStep.allAttackSteps.remove(sSH);
    sSH = new SSH(name);
    AttackStep.allAttackSteps.remove(attemptSSHAuthorizedKeys);
    attemptSSHAuthorizedKeys = new AttemptSSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHAuthorizedKeys);
    sSHAuthorizedKeys = new SSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHHijacking);
    sSHHijacking = new SSHHijacking(name);
    AttackStep.allAttackSteps.remove(attemptSQLStoredProcedures);
    attemptSQLStoredProcedures = new AttemptSQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(sQLStoredProcedures);
    sQLStoredProcedures = new SQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(sudoAndSudoCaching);
    sudoAndSudoCaching = new SudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(attemptSystemdService);
    attemptSystemdService = new AttemptSystemdService(name);
    AttackStep.allAttackSteps.remove(systemdService);
    systemdService = new SystemdService(name);
    AttackStep.allAttackSteps.remove(attemptTransportAgent);
    attemptTransportAgent = new AttemptTransportAgent(name);
    AttackStep.allAttackSteps.remove(transportAgent);
    transportAgent = new TransportAgent(name);
    AttackStep.allAttackSteps.remove(trap);
    trap = new Trap(name);
    AttackStep.allAttackSteps.remove(unixShell);
    unixShell = new UnixShell(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(vDSOHijacking);
    vDSOHijacking = new VDSOHijacking(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, isAntivirusEnabled);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, isAuditEnabled);
    if (behaviorPreventionOnEndpoint != null) {
      AttackStep.allAttackSteps.remove(behaviorPreventionOnEndpoint.disable);
    }
    Defense.allDefenses.remove(behaviorPreventionOnEndpoint);
    behaviorPreventionOnEndpoint = new BehaviorPreventionOnEndpoint(name, isBehaviorPreventionOnEndpointEnabled);
    if (bootIntegrity != null) {
      AttackStep.allAttackSteps.remove(bootIntegrity.disable);
    }
    Defense.allDefenses.remove(bootIntegrity);
    bootIntegrity = new BootIntegrity(name, isBootIntegrityEnabled);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, isCodeSigningEnabled);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, isDisableOrRemoveFeatureOrProgramEnabled);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, isEncryptSensitiveInformationEnabled);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, isExecutionPreventionEnabled);
    if (environmentVariablePermissions != null) {
      AttackStep.allAttackSteps.remove(environmentVariablePermissions.disable);
    }
    Defense.allDefenses.remove(environmentVariablePermissions);
    environmentVariablePermissions = new EnvironmentVariablePermissions(name, isEnvironmentVariablePermissionsEnabled);
    if (limitSoftwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitSoftwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitSoftwareInstallation);
    limitSoftwareInstallation = new LimitSoftwareInstallation(name, isLimitSoftwareInstallationEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, isOperatingSystemConfigurationEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, isPrivilegedAccountManagementEnabled);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, isRestrictFileAndDirectoryPermissionsEnabled);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, isRemoteDataStorageEnabled);
  }

  public Linux(String name) {
    super(name);
    assetClassName = "Linux";
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(at);
    at = new At(name);
    AttackStep.allAttackSteps.remove(attemptBootkit);
    attemptBootkit = new AttemptBootkit(name);
    AttackStep.allAttackSteps.remove(bootkit);
    bootkit = new Bootkit(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(attemptClearCommandHistory);
    attemptClearCommandHistory = new AttemptClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(clearCommandHistory);
    clearCommandHistory = new ClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(clearLinuxSystemLogs);
    clearLinuxSystemLogs = new ClearLinuxSystemLogs(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(credentialsFromPasswordStores);
    credentialsFromPasswordStores = new CredentialsFromPasswordStores(name);
    AttackStep.allAttackSteps.remove(cron);
    cron = new Cron(name);
    AttackStep.allAttackSteps.remove(_etc_passwdAND_etc_shadow);
    _etc_passwdAND_etc_shadow = new _etc_passwdAND_etc_shadow(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(spaceAfterFileName);
    spaceAfterFileName = new SpaceAfterFileName(name);
    AttackStep.allAttackSteps.remove(attemptBash_profileAndBashrc);
    attemptBash_profileAndBashrc = new AttemptBash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bash_profileAndBashrc);
    bash_profileAndBashrc = new Bash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(attemptBashHistory);
    attemptBashHistory = new AttemptBashHistory(name);
    AttackStep.allAttackSteps.remove(bashHistory);
    bashHistory = new BashHistory(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(linuxFileAndDirectoryPermissionsModification);
    linuxFileAndDirectoryPermissionsModification = new LinuxFileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(hISTCONTROL);
    hISTCONTROL = new HISTCONTROL(name);
    AttackStep.allAttackSteps.remove(infectedOS);
    infectedOS = new InfectedOS(name);
    AttackStep.allAttackSteps.remove(kernelModulesAndExtensions);
    kernelModulesAndExtensions = new KernelModulesAndExtensions(name);
    AttackStep.allAttackSteps.remove(lD_PRELOAD);
    lD_PRELOAD = new LD_PRELOAD(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(masqueradeTaskOrService);
    masqueradeTaskOrService = new MasqueradeTaskOrService(name);
    AttackStep.allAttackSteps.remove(oSCredentialDumping);
    oSCredentialDumping = new OSCredentialDumping(name);
    AttackStep.allAttackSteps.remove(pluggableAuthenticationModules);
    pluggableAuthenticationModules = new PluggableAuthenticationModules(name);
    AttackStep.allAttackSteps.remove(portKnocking);
    portKnocking = new PortKnocking(name);
    AttackStep.allAttackSteps.remove(procFilesystem);
    procFilesystem = new ProcFilesystem(name);
    AttackStep.allAttackSteps.remove(ptraceSystemCalls);
    ptraceSystemCalls = new PtraceSystemCalls(name);
    AttackStep.allAttackSteps.remove(preOSBoot);
    preOSBoot = new PreOSBoot(name);
    AttackStep.allAttackSteps.remove(attemptProcMemory);
    attemptProcMemory = new AttemptProcMemory(name);
    AttackStep.allAttackSteps.remove(procMemory);
    procMemory = new ProcMemory(name);
    AttackStep.allAttackSteps.remove(processInjection);
    processInjection = new ProcessInjection(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(serverSoftwareComponent);
    serverSoftwareComponent = new ServerSoftwareComponent(name);
    AttackStep.allAttackSteps.remove(attemptSetuidAndSetgid);
    attemptSetuidAndSetgid = new AttemptSetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(setuidAndSetgid);
    setuidAndSetgid = new SetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(securitydMemory);
    securitydMemory = new SecuritydMemory(name);
    AttackStep.allAttackSteps.remove(sSH);
    sSH = new SSH(name);
    AttackStep.allAttackSteps.remove(attemptSSHAuthorizedKeys);
    attemptSSHAuthorizedKeys = new AttemptSSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHAuthorizedKeys);
    sSHAuthorizedKeys = new SSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHHijacking);
    sSHHijacking = new SSHHijacking(name);
    AttackStep.allAttackSteps.remove(attemptSQLStoredProcedures);
    attemptSQLStoredProcedures = new AttemptSQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(sQLStoredProcedures);
    sQLStoredProcedures = new SQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(sudoAndSudoCaching);
    sudoAndSudoCaching = new SudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(attemptSystemdService);
    attemptSystemdService = new AttemptSystemdService(name);
    AttackStep.allAttackSteps.remove(systemdService);
    systemdService = new SystemdService(name);
    AttackStep.allAttackSteps.remove(attemptTransportAgent);
    attemptTransportAgent = new AttemptTransportAgent(name);
    AttackStep.allAttackSteps.remove(transportAgent);
    transportAgent = new TransportAgent(name);
    AttackStep.allAttackSteps.remove(trap);
    trap = new Trap(name);
    AttackStep.allAttackSteps.remove(unixShell);
    unixShell = new UnixShell(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(vDSOHijacking);
    vDSOHijacking = new VDSOHijacking(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, false);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, false);
    if (behaviorPreventionOnEndpoint != null) {
      AttackStep.allAttackSteps.remove(behaviorPreventionOnEndpoint.disable);
    }
    Defense.allDefenses.remove(behaviorPreventionOnEndpoint);
    behaviorPreventionOnEndpoint = new BehaviorPreventionOnEndpoint(name, false);
    if (bootIntegrity != null) {
      AttackStep.allAttackSteps.remove(bootIntegrity.disable);
    }
    Defense.allDefenses.remove(bootIntegrity);
    bootIntegrity = new BootIntegrity(name, false);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, false);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, false);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, false);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, false);
    if (environmentVariablePermissions != null) {
      AttackStep.allAttackSteps.remove(environmentVariablePermissions.disable);
    }
    Defense.allDefenses.remove(environmentVariablePermissions);
    environmentVariablePermissions = new EnvironmentVariablePermissions(name, false);
    if (limitSoftwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitSoftwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitSoftwareInstallation);
    limitSoftwareInstallation = new LimitSoftwareInstallation(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, false);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, false);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, false);
  }

  public Linux(boolean isAntivirusEnabled, boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled, boolean isEnvironmentVariablePermissionsEnabled) {
    this("Anonymous", isAntivirusEnabled, isRestrictFileAndDirectoryPermissionsEnabled, isRestrictRegistryPermissionsEnabled, isAccountUsePoliciesEnabled, isBehaviorPreventionOnEndpointEnabled, isBootIntegrityEnabled, isDataBackupEnabled, isMultiFactorAuthenticationEnabled, isPasswordPoliciesEnabled, isApplicationIsolationAndSandboxingEnabled, isDoNotMitigateEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isActiveDirectoryConfigurationEnabled, isAuditEnabled, isApplicationDeveloperGuidanceEnabled, isCodeSigningEnabled, isLimitHardwareInstallationEnabled, isOperatingSystemConfigurationEnabled, isSoftwareConfigurationEnabled, isExecutionPreventionEnabled, isPrivilegedAccountManagementEnabled, isEncryptSensitiveInformationEnabled, isRemoteDataStorageEnabled, isLimitSoftwareInstallationEnabled, isUpdateSoftwareEnabled, isUserAccountControlEnabled, isExploitProtectionEnabled, isEnvironmentVariablePermissionsEnabled);
  }

  public Linux() {
    this("Anonymous");
  }

  public class AbuseElevationControlMechanism extends OS.AbuseElevationControlMechanism {
    private Set<AttackStep> _cacheChildrenAbuseElevationControlMechanism;

    public AbuseElevationControlMechanism(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAbuseElevationControlMechanism == null) {
        _cacheChildrenAbuseElevationControlMechanism = new HashSet<>();
        _cacheChildrenAbuseElevationControlMechanism.add(attemptSetuidAndSetgid);
        _cacheChildrenAbuseElevationControlMechanism.add(sudoAndSudoCaching);
      }
      for (AttackStep attackStep : _cacheChildrenAbuseElevationControlMechanism) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.abuseElevationControlMechanism");
    }
  }

  public class AccountManipulation extends OS.AccountManipulation {
    private Set<AttackStep> _cacheChildrenAccountManipulation;

    public AccountManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAccountManipulation == null) {
        _cacheChildrenAccountManipulation = new HashSet<>();
        _cacheChildrenAccountManipulation.add(attemptSSHAuthorizedKeys);
      }
      for (AttackStep attackStep : _cacheChildrenAccountManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.accountManipulation");
    }
  }

  public class At extends OS.At {
    private Set<AttackStep> _cacheChildrenAt;

    private Set<AttackStep> _cacheParentAt;

    public At(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAt == null) {
        _cacheChildrenAt = new HashSet<>();
        _cacheChildrenAt.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenAt) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAt == null) {
        _cacheParentAt = new HashSet<>();
        _cacheParentAt.add(scheduledTaskOrJob);
        _cacheParentAt.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentAt) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.at");
    }
  }

  public class AttemptBootkit extends OS.AttemptBootkit {
    private Set<AttackStep> _cacheChildrenAttemptBootkit;

    public AttemptBootkit(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptBootkit == null) {
        _cacheChildrenAttemptBootkit = new HashSet<>();
        _cacheChildrenAttemptBootkit.add(bootkit);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBootkit) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptBootkit");
    }
  }

  public class Bootkit extends OS.Bootkit {
    private Set<AttackStep> _cacheChildrenBootkit;

    private Set<AttackStep> _cacheParentBootkit;

    public Bootkit(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBootkit == null) {
        _cacheChildrenBootkit = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenBootkit.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenBootkit) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBootkit == null) {
        _cacheParentBootkit = new HashSet<>();
        _cacheParentBootkit.add(attemptBootkit);
        _cacheParentBootkit.add(preOSBoot);
        _cacheParentBootkit.add(bootIntegrity.disable);
        _cacheParentBootkit.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentBootkit) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.bootkit");
    }
  }

  public class BootOrLogonAutostartExecution extends OS.BootOrLogonAutostartExecution {
    private Set<AttackStep> _cacheChildrenBootOrLogonAutostartExecution;

    public BootOrLogonAutostartExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBootOrLogonAutostartExecution == null) {
        _cacheChildrenBootOrLogonAutostartExecution = new HashSet<>();
        _cacheChildrenBootOrLogonAutostartExecution.add(kernelModulesAndExtensions);
      }
      for (AttackStep attackStep : _cacheChildrenBootOrLogonAutostartExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.bootOrLogonAutostartExecution");
    }
  }

  public class AttemptClearCommandHistory extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptClearCommandHistory;

    private Set<AttackStep> _cacheParentAttemptClearCommandHistory;

    public AttemptClearCommandHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptClearCommandHistory == null) {
        _cacheChildrenAttemptClearCommandHistory = new HashSet<>();
        _cacheChildrenAttemptClearCommandHistory.add(clearCommandHistory);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptClearCommandHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptClearCommandHistory == null) {
        _cacheParentAttemptClearCommandHistory = new HashSet<>();
        _cacheParentAttemptClearCommandHistory.add(indicatorRemovalOnHost);
      }
      for (AttackStep attackStep : _cacheParentAttemptClearCommandHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptClearCommandHistory");
    }
  }

  public class ClearCommandHistory extends OS.ClearCommandHistory {
    private Set<AttackStep> _cacheChildrenClearCommandHistory;

    private Set<AttackStep> _cacheParentClearCommandHistory;

    public ClearCommandHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenClearCommandHistory == null) {
        _cacheChildrenClearCommandHistory = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenClearCommandHistory.add(((asset.Linux) Linux.this).bypassLogAnalysis);
        }
        if (Linux.this instanceof Linux) {
          _cacheChildrenClearCommandHistory.add(((asset.Linux) Linux.this).bypassHostForensicAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenClearCommandHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClearCommandHistory == null) {
        _cacheParentClearCommandHistory = new HashSet<>();
        _cacheParentClearCommandHistory.add(attemptClearCommandHistory);
        _cacheParentClearCommandHistory.add(environmentVariablePermissions.disable);
        _cacheParentClearCommandHistory.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentClearCommandHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.clearCommandHistory");
    }
  }

  public class ClearLinuxSystemLogs extends AttackStepMax {
    private Set<AttackStep> _cacheParentClearLinuxSystemLogs;

    public ClearLinuxSystemLogs(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClearLinuxSystemLogs == null) {
        _cacheParentClearLinuxSystemLogs = new HashSet<>();
        _cacheParentClearLinuxSystemLogs.add(indicatorRemovalOnHost);
        _cacheParentClearLinuxSystemLogs.add(encryptSensitiveInformation.disable);
        _cacheParentClearLinuxSystemLogs.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentClearLinuxSystemLogs.add(remoteDataStorage.disable);
      }
      for (AttackStep attackStep : _cacheParentClearLinuxSystemLogs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.clearLinuxSystemLogs");
    }
  }

  public class CommandAndScriptingInterpreter extends OS.CommandAndScriptingInterpreter {
    private Set<AttackStep> _cacheChildrenCommandAndScriptingInterpreter;

    public CommandAndScriptingInterpreter(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCommandAndScriptingInterpreter == null) {
        _cacheChildrenCommandAndScriptingInterpreter = new HashSet<>();
        _cacheChildrenCommandAndScriptingInterpreter.add(unixShell);
      }
      for (AttackStep attackStep : _cacheChildrenCommandAndScriptingInterpreter) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.commandAndScriptingInterpreter");
    }
  }

  public class CreateOrModifySystemProcess extends OS.CreateOrModifySystemProcess {
    private Set<AttackStep> _cacheChildrenCreateOrModifySystemProcess;

    public CreateOrModifySystemProcess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCreateOrModifySystemProcess == null) {
        _cacheChildrenCreateOrModifySystemProcess = new HashSet<>();
        _cacheChildrenCreateOrModifySystemProcess.add(attemptSystemdService);
      }
      for (AttackStep attackStep : _cacheChildrenCreateOrModifySystemProcess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.createOrModifySystemProcess");
    }
  }

  public class CredentialsFromPasswordStores extends OS.CredentialsFromPasswordStores {
    private Set<AttackStep> _cacheChildrenCredentialsFromPasswordStores;

    public CredentialsFromPasswordStores(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCredentialsFromPasswordStores == null) {
        _cacheChildrenCredentialsFromPasswordStores = new HashSet<>();
        _cacheChildrenCredentialsFromPasswordStores.add(securitydMemory);
      }
      for (AttackStep attackStep : _cacheChildrenCredentialsFromPasswordStores) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.credentialsFromPasswordStores");
    }
  }

  public class Cron extends OS.Cron {
    private Set<AttackStep> _cacheChildrenCron;

    private Set<AttackStep> _cacheParentCron;

    public Cron(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCron == null) {
        _cacheChildrenCron = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenCron.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCron) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCron == null) {
        _cacheParentCron = new HashSet<>();
        _cacheParentCron.add(scheduledTaskOrJob);
        _cacheParentCron.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentCron) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.cron");
    }
  }

  public class _etc_passwdAND_etc_shadow extends OS._etc_passwdAND_etc_shadow {
    private Set<AttackStep> _cacheChildren_etc_passwdAND_etc_shadow;

    private Set<AttackStep> _cacheParent_etc_passwdAND_etc_shadow;

    public _etc_passwdAND_etc_shadow(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildren_etc_passwdAND_etc_shadow == null) {
        _cacheChildren_etc_passwdAND_etc_shadow = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildren_etc_passwdAND_etc_shadow.add(((asset.Linux) Linux.this).collectHashInformation);
        }
      }
      for (AttackStep attackStep : _cacheChildren_etc_passwdAND_etc_shadow) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParent_etc_passwdAND_etc_shadow == null) {
        _cacheParent_etc_passwdAND_etc_shadow = new HashSet<>();
        _cacheParent_etc_passwdAND_etc_shadow.add(oSCredentialDumping);
        _cacheParent_etc_passwdAND_etc_shadow.add(passwordPolicies.disable);
        _cacheParent_etc_passwdAND_etc_shadow.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParent_etc_passwdAND_etc_shadow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux._etc_passwdAND_etc_shadow");
    }
  }

  public class EventTriggeredExecution extends OS.EventTriggeredExecution {
    private Set<AttackStep> _cacheChildrenEventTriggeredExecution;

    public EventTriggeredExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenEventTriggeredExecution == null) {
        _cacheChildrenEventTriggeredExecution = new HashSet<>();
        _cacheChildrenEventTriggeredExecution.add(attemptBash_profileAndBashrc);
        _cacheChildrenEventTriggeredExecution.add(trap);
      }
      for (AttackStep attackStep : _cacheChildrenEventTriggeredExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.eventTriggeredExecution");
    }
  }

  public class SpaceAfterFileName extends OS.SpaceAfterFileName {
    private Set<AttackStep> _cacheChildrenSpaceAfterFileName;

    private Set<AttackStep> _cacheParentSpaceAfterFileName;

    public SpaceAfterFileName(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSpaceAfterFileName == null) {
        _cacheChildrenSpaceAfterFileName = new HashSet<>();
        if (Linux.this instanceof Linux) {
          for (Computer _0 : ((asset.Linux) Linux.this).computer) {
            for (User _1 : _0.user) {
              _cacheChildrenSpaceAfterFileName.add(_1.attemptUserExecution);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSpaceAfterFileName) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSpaceAfterFileName == null) {
        _cacheParentSpaceAfterFileName = new HashSet<>();
        _cacheParentSpaceAfterFileName.add(masquerading);
        _cacheParentSpaceAfterFileName.add(masquerading);
      }
      for (AttackStep attackStep : _cacheParentSpaceAfterFileName) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.spaceAfterFileName");
    }
  }

  public class AttemptBash_profileAndBashrc extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBash_profileAndBashrc;

    private Set<AttackStep> _cacheParentAttemptBash_profileAndBashrc;

    public AttemptBash_profileAndBashrc(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBash_profileAndBashrc == null) {
        _cacheChildrenAttemptBash_profileAndBashrc = new HashSet<>();
        _cacheChildrenAttemptBash_profileAndBashrc.add(bash_profileAndBashrc);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBash_profileAndBashrc) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptBash_profileAndBashrc == null) {
        _cacheParentAttemptBash_profileAndBashrc = new HashSet<>();
        _cacheParentAttemptBash_profileAndBashrc.add(eventTriggeredExecution);
        _cacheParentAttemptBash_profileAndBashrc.add(linuxFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheParentAttemptBash_profileAndBashrc) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptBash_profileAndBashrc");
    }
  }

  public class Bash_profileAndBashrc extends OS.Bash_profileAndBashrc {
    private Set<AttackStep> _cacheChildrenBash_profileAndBashrc;

    private Set<AttackStep> _cacheParentBash_profileAndBashrc;

    public Bash_profileAndBashrc(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBash_profileAndBashrc == null) {
        _cacheChildrenBash_profileAndBashrc = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenBash_profileAndBashrc.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenBash_profileAndBashrc) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBash_profileAndBashrc == null) {
        _cacheParentBash_profileAndBashrc = new HashSet<>();
        _cacheParentBash_profileAndBashrc.add(attemptBash_profileAndBashrc);
        _cacheParentBash_profileAndBashrc.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentBash_profileAndBashrc) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.bash_profileAndBashrc");
    }
  }

  public class AttemptBashHistory extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBashHistory;

    private Set<AttackStep> _cacheParentAttemptBashHistory;

    public AttemptBashHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBashHistory == null) {
        _cacheChildrenAttemptBashHistory = new HashSet<>();
        _cacheChildrenAttemptBashHistory.add(bashHistory);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBashHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptBashHistory == null) {
        _cacheParentAttemptBashHistory = new HashSet<>();
        _cacheParentAttemptBashHistory.add(infectedOS);
      }
      for (AttackStep attackStep : _cacheParentAttemptBashHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptBashHistory");
    }
  }

  public class BashHistory extends OS.BashHistory {
    private Set<AttackStep> _cacheChildrenBashHistory;

    private Set<AttackStep> _cacheParentBashHistory;

    public BashHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBashHistory == null) {
        _cacheChildrenBashHistory = new HashSet<>();
        _cacheChildrenBashHistory.add(indicatorRemovalOnHost);
        if (Linux.this instanceof Linux) {
          for (UserAccount _0 : ((asset.Linux) Linux.this).userAccount) {
            _cacheChildrenBashHistory.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenBashHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBashHistory == null) {
        _cacheParentBashHistory = new HashSet<>();
        _cacheParentBashHistory.add(attemptBashHistory);
        _cacheParentBashHistory.add(unsecuredCredentials);
        _cacheParentBashHistory.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentBashHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.bashHistory");
    }
  }

  public class HijackExecutionFlow extends OS.HijackExecutionFlow {
    private Set<AttackStep> _cacheChildrenHijackExecutionFlow;

    private Set<AttackStep> _cacheParentHijackExecutionFlow;

    public HijackExecutionFlow(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHijackExecutionFlow == null) {
        _cacheChildrenHijackExecutionFlow = new HashSet<>();
        _cacheChildrenHijackExecutionFlow.add(lD_PRELOAD);
      }
      for (AttackStep attackStep : _cacheChildrenHijackExecutionFlow) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHijackExecutionFlow == null) {
        _cacheParentHijackExecutionFlow = new HashSet<>();
        _cacheParentHijackExecutionFlow.add(linuxFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheParentHijackExecutionFlow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.hijackExecutionFlow");
    }
  }

  public class FileAndDirectoryPermissionsModification extends OS.FileAndDirectoryPermissionsModification {
    private Set<AttackStep> _cacheChildrenFileAndDirectoryPermissionsModification;

    public FileAndDirectoryPermissionsModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenFileAndDirectoryPermissionsModification == null) {
        _cacheChildrenFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheChildrenFileAndDirectoryPermissionsModification.add(linuxFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheChildrenFileAndDirectoryPermissionsModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.fileAndDirectoryPermissionsModification");
    }
  }

  public class LinuxFileAndDirectoryPermissionsModification extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenLinuxFileAndDirectoryPermissionsModification;

    private Set<AttackStep> _cacheParentLinuxFileAndDirectoryPermissionsModification;

    public LinuxFileAndDirectoryPermissionsModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLinuxFileAndDirectoryPermissionsModification == null) {
        _cacheChildrenLinuxFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheChildrenLinuxFileAndDirectoryPermissionsModification.add(attemptBash_profileAndBashrc);
        _cacheChildrenLinuxFileAndDirectoryPermissionsModification.add(hijackExecutionFlow);
      }
      for (AttackStep attackStep : _cacheChildrenLinuxFileAndDirectoryPermissionsModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLinuxFileAndDirectoryPermissionsModification == null) {
        _cacheParentLinuxFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheParentLinuxFileAndDirectoryPermissionsModification.add(fileAndDirectoryPermissionsModification);
        _cacheParentLinuxFileAndDirectoryPermissionsModification.add(privilegedAccountManagement.disable);
        _cacheParentLinuxFileAndDirectoryPermissionsModification.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentLinuxFileAndDirectoryPermissionsModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.linuxFileAndDirectoryPermissionsModification");
    }
  }

  public class ImpareDefenses extends OS.ImpareDefenses {
    private Set<AttackStep> _cacheChildrenImpareDefenses;

    public ImpareDefenses(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenImpareDefenses == null) {
        _cacheChildrenImpareDefenses = new HashSet<>();
        _cacheChildrenImpareDefenses.add(hISTCONTROL);
      }
      for (AttackStep attackStep : _cacheChildrenImpareDefenses) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.impareDefenses");
    }
  }

  public class IndicatorRemovalOnHost extends OS.IndicatorRemovalOnHost {
    private Set<AttackStep> _cacheChildrenIndicatorRemovalOnHost;

    private Set<AttackStep> _cacheParentIndicatorRemovalOnHost;

    public IndicatorRemovalOnHost(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenIndicatorRemovalOnHost == null) {
        _cacheChildrenIndicatorRemovalOnHost = new HashSet<>();
        _cacheChildrenIndicatorRemovalOnHost.add(clearLinuxSystemLogs);
        _cacheChildrenIndicatorRemovalOnHost.add(attemptClearCommandHistory);
      }
      for (AttackStep attackStep : _cacheChildrenIndicatorRemovalOnHost) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentIndicatorRemovalOnHost == null) {
        _cacheParentIndicatorRemovalOnHost = new HashSet<>();
        _cacheParentIndicatorRemovalOnHost.add(bashHistory);
      }
      for (AttackStep attackStep : _cacheParentIndicatorRemovalOnHost) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.indicatorRemovalOnHost");
    }
  }

  public class HISTCONTROL extends OS.HISTCONTROL {
    private Set<AttackStep> _cacheChildrenHISTCONTROL;

    private Set<AttackStep> _cacheParentHISTCONTROL;

    public HISTCONTROL(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHISTCONTROL == null) {
        _cacheChildrenHISTCONTROL = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenHISTCONTROL.add(((asset.Linux) Linux.this).bypassLogAnalysis);
        }
        if (Linux.this instanceof Linux) {
          _cacheChildrenHISTCONTROL.add(((asset.Linux) Linux.this).bypassHostForensicAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenHISTCONTROL) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHISTCONTROL == null) {
        _cacheParentHISTCONTROL = new HashSet<>();
        _cacheParentHISTCONTROL.add(impareDefenses);
        _cacheParentHISTCONTROL.add(environmentVariablePermissions.disable);
        _cacheParentHISTCONTROL.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentHISTCONTROL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.hISTCONTROL");
    }
  }

  public class InfectedOS extends OS.InfectedOS {
    private Set<AttackStep> _cacheChildrenInfectedOS;

    public InfectedOS(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenInfectedOS == null) {
        _cacheChildrenInfectedOS = new HashSet<>();
        _cacheChildrenInfectedOS.add(attemptBashHistory);
      }
      for (AttackStep attackStep : _cacheChildrenInfectedOS) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.infectedOS");
    }
  }

  public class KernelModulesAndExtensions extends OS.KernelModulesAndExtensions {
    private Set<AttackStep> _cacheChildrenKernelModulesAndExtensions;

    private Set<AttackStep> _cacheParentKernelModulesAndExtensions;

    public KernelModulesAndExtensions(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenKernelModulesAndExtensions == null) {
        _cacheChildrenKernelModulesAndExtensions = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenKernelModulesAndExtensions.add(((asset.Linux) Linux.this).rootkit);
        }
      }
      for (AttackStep attackStep : _cacheChildrenKernelModulesAndExtensions) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentKernelModulesAndExtensions == null) {
        _cacheParentKernelModulesAndExtensions = new HashSet<>();
        _cacheParentKernelModulesAndExtensions.add(bootOrLogonAutostartExecution);
        _cacheParentKernelModulesAndExtensions.add(antivirus.disable);
        _cacheParentKernelModulesAndExtensions.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentKernelModulesAndExtensions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.kernelModulesAndExtensions");
    }
  }

  public class LD_PRELOAD extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenLD_PRELOAD;

    private Set<AttackStep> _cacheParentLD_PRELOAD;

    public LD_PRELOAD(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLD_PRELOAD == null) {
        _cacheChildrenLD_PRELOAD = new HashSet<>();
        if (Linux.this instanceof Linux) {
          for (Service _0 : ((asset.Linux) Linux.this).service) {
            _cacheChildrenLD_PRELOAD.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        _cacheChildrenLD_PRELOAD.add(attemptProcMemory);
      }
      for (AttackStep attackStep : _cacheChildrenLD_PRELOAD) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLD_PRELOAD == null) {
        _cacheParentLD_PRELOAD = new HashSet<>();
        _cacheParentLD_PRELOAD.add(hijackExecutionFlow);
        _cacheParentLD_PRELOAD.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentLD_PRELOAD) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.lD_PRELOAD");
    }
  }

  public class Masquerading extends OS.Masquerading {
    private Set<AttackStep> _cacheChildrenMasquerading;

    public Masquerading(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenMasquerading == null) {
        _cacheChildrenMasquerading = new HashSet<>();
        _cacheChildrenMasquerading.add(masqueradeTaskOrService);
        _cacheChildrenMasquerading.add(spaceAfterFileName);
        _cacheChildrenMasquerading.add(spaceAfterFileName);
      }
      for (AttackStep attackStep : _cacheChildrenMasquerading) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.masquerading");
    }
  }

  public class ModifyAuthenticationProcess extends OS.ModifyAuthenticationProcess {
    private Set<AttackStep> _cacheChildrenModifyAuthenticationProcess;

    public ModifyAuthenticationProcess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenModifyAuthenticationProcess == null) {
        _cacheChildrenModifyAuthenticationProcess = new HashSet<>();
        _cacheChildrenModifyAuthenticationProcess.add(pluggableAuthenticationModules);
      }
      for (AttackStep attackStep : _cacheChildrenModifyAuthenticationProcess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.modifyAuthenticationProcess");
    }
  }

  public class MasqueradeTaskOrService extends OS.MasqueradeTaskOrService {
    private Set<AttackStep> _cacheChildrenMasqueradeTaskOrService;

    private Set<AttackStep> _cacheParentMasqueradeTaskOrService;

    public MasqueradeTaskOrService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenMasqueradeTaskOrService == null) {
        _cacheChildrenMasqueradeTaskOrService = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenMasqueradeTaskOrService.add(((asset.Linux) Linux.this).bypassHostIntrusionPrevention);
        }
      }
      for (AttackStep attackStep : _cacheChildrenMasqueradeTaskOrService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMasqueradeTaskOrService == null) {
        _cacheParentMasqueradeTaskOrService = new HashSet<>();
        _cacheParentMasqueradeTaskOrService.add(masquerading);
      }
      for (AttackStep attackStep : _cacheParentMasqueradeTaskOrService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.masqueradeTaskOrService");
    }
  }

  public class OSCredentialDumping extends OS.OSCredentialDumping {
    private Set<AttackStep> _cacheChildrenOSCredentialDumping;

    public OSCredentialDumping(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOSCredentialDumping == null) {
        _cacheChildrenOSCredentialDumping = new HashSet<>();
        _cacheChildrenOSCredentialDumping.add(procFilesystem);
        _cacheChildrenOSCredentialDumping.add(_etc_passwdAND_etc_shadow);
      }
      for (AttackStep attackStep : _cacheChildrenOSCredentialDumping) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.oSCredentialDumping");
    }
  }

  public class PluggableAuthenticationModules extends OS.PluggableAuthenticationModules {
    private Set<AttackStep> _cacheParentPluggableAuthenticationModules;

    public PluggableAuthenticationModules(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPluggableAuthenticationModules == null) {
        _cacheParentPluggableAuthenticationModules = new HashSet<>();
        _cacheParentPluggableAuthenticationModules.add(modifyAuthenticationProcess);
        _cacheParentPluggableAuthenticationModules.add(multiFactorAuthentication.disable);
        _cacheParentPluggableAuthenticationModules.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentPluggableAuthenticationModules) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.pluggableAuthenticationModules");
    }
  }

  public class PortKnocking extends OS.PortKnocking {
    private Set<AttackStep> _cacheChildrenPortKnocking;

    public PortKnocking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPortKnocking == null) {
        _cacheChildrenPortKnocking = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenPortKnocking.add(((asset.Linux) Linux.this).bypassDefensiveNetworkServiceScanning);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPortKnocking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.portKnocking");
    }
  }

  public class ProcFilesystem extends OS.ProcFilesystem {
    private Set<AttackStep> _cacheChildrenProcFilesystem;

    private Set<AttackStep> _cacheParentProcFilesystem;

    public ProcFilesystem(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenProcFilesystem == null) {
        _cacheChildrenProcFilesystem = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenProcFilesystem.add(((asset.Linux) Linux.this).collectHashInformation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenProcFilesystem) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcFilesystem == null) {
        _cacheParentProcFilesystem = new HashSet<>();
        _cacheParentProcFilesystem.add(oSCredentialDumping);
        _cacheParentProcFilesystem.add(passwordPolicies.disable);
        _cacheParentProcFilesystem.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentProcFilesystem) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.procFilesystem");
    }
  }

  public class PtraceSystemCalls extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenPtraceSystemCalls;

    private Set<AttackStep> _cacheParentPtraceSystemCalls;

    public PtraceSystemCalls(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPtraceSystemCalls == null) {
        _cacheChildrenPtraceSystemCalls = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenPtraceSystemCalls.add(((asset.Linux) Linux.this).bypassAntivirus);
        }
        if (Linux.this instanceof Linux) {
          _cacheChildrenPtraceSystemCalls.add(((asset.Linux) Linux.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPtraceSystemCalls) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPtraceSystemCalls == null) {
        _cacheParentPtraceSystemCalls = new HashSet<>();
        _cacheParentPtraceSystemCalls.add(processInjection);
        _cacheParentPtraceSystemCalls.add(behaviorPreventionOnEndpoint.disable);
        _cacheParentPtraceSystemCalls.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentPtraceSystemCalls) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.ptraceSystemCalls");
    }
  }

  public class PreOSBoot extends OS.PreOSBoot {
    private Set<AttackStep> _cacheChildrenPreOSBoot;

    public PreOSBoot(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPreOSBoot == null) {
        _cacheChildrenPreOSBoot = new HashSet<>();
        _cacheChildrenPreOSBoot.add(bootkit);
      }
      for (AttackStep attackStep : _cacheChildrenPreOSBoot) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.preOSBoot");
    }
  }

  public class AttemptProcMemory extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptProcMemory;

    private Set<AttackStep> _cacheParentAttemptProcMemory;

    public AttemptProcMemory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptProcMemory == null) {
        _cacheChildrenAttemptProcMemory = new HashSet<>();
        _cacheChildrenAttemptProcMemory.add(procMemory);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptProcMemory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptProcMemory == null) {
        _cacheParentAttemptProcMemory = new HashSet<>();
        _cacheParentAttemptProcMemory.add(lD_PRELOAD);
        _cacheParentAttemptProcMemory.add(processInjection);
      }
      for (AttackStep attackStep : _cacheParentAttemptProcMemory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptProcMemory");
    }
  }

  public class ProcMemory extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenProcMemory;

    private Set<AttackStep> _cacheParentProcMemory;

    public ProcMemory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenProcMemory == null) {
        _cacheChildrenProcMemory = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenProcMemory.add(((asset.Linux) Linux.this).bypassAntivirus);
        }
        if (Linux.this instanceof Linux) {
          _cacheChildrenProcMemory.add(((asset.Linux) Linux.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenProcMemory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcMemory == null) {
        _cacheParentProcMemory = new HashSet<>();
        _cacheParentProcMemory.add(attemptProcMemory);
        _cacheParentProcMemory.add(behaviorPreventionOnEndpoint.disable);
        _cacheParentProcMemory.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentProcMemory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.procMemory");
    }
  }

  public class ProcessInjection extends OS.ProcessInjection {
    private Set<AttackStep> _cacheChildrenProcessInjection;

    public ProcessInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenProcessInjection == null) {
        _cacheChildrenProcessInjection = new HashSet<>();
        _cacheChildrenProcessInjection.add(ptraceSystemCalls);
        _cacheChildrenProcessInjection.add(attemptProcMemory);
        _cacheChildrenProcessInjection.add(vDSOHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenProcessInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.processInjection");
    }
  }

  public class ScheduledTaskOrJob extends OS.ScheduledTaskOrJob {
    private Set<AttackStep> _cacheChildrenScheduledTaskOrJob;

    public ScheduledTaskOrJob(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenScheduledTaskOrJob == null) {
        _cacheChildrenScheduledTaskOrJob = new HashSet<>();
        _cacheChildrenScheduledTaskOrJob.add(at);
        _cacheChildrenScheduledTaskOrJob.add(cron);
      }
      for (AttackStep attackStep : _cacheChildrenScheduledTaskOrJob) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.scheduledTaskOrJob");
    }
  }

  public class ServerSoftwareComponent extends OS.ServerSoftwareComponent {
    private Set<AttackStep> _cacheChildrenServerSoftwareComponent;

    public ServerSoftwareComponent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServerSoftwareComponent == null) {
        _cacheChildrenServerSoftwareComponent = new HashSet<>();
        _cacheChildrenServerSoftwareComponent.add(attemptSQLStoredProcedures);
        _cacheChildrenServerSoftwareComponent.add(attemptTransportAgent);
      }
      for (AttackStep attackStep : _cacheChildrenServerSoftwareComponent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.serverSoftwareComponent");
    }
  }

  public class AttemptSetuidAndSetgid extends OS.AttemptSetuidAndSetgid {
    private Set<AttackStep> _cacheChildrenAttemptSetuidAndSetgid;

    private Set<AttackStep> _cacheParentAttemptSetuidAndSetgid;

    public AttemptSetuidAndSetgid(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSetuidAndSetgid == null) {
        _cacheChildrenAttemptSetuidAndSetgid = new HashSet<>();
        _cacheChildrenAttemptSetuidAndSetgid.add(setuidAndSetgid);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSetuidAndSetgid) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSetuidAndSetgid == null) {
        _cacheParentAttemptSetuidAndSetgid = new HashSet<>();
        _cacheParentAttemptSetuidAndSetgid.add(abuseElevationControlMechanism);
      }
      for (AttackStep attackStep : _cacheParentAttemptSetuidAndSetgid) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptSetuidAndSetgid");
    }
  }

  public class SetuidAndSetgid extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSetuidAndSetgid;

    private Set<AttackStep> _cacheParentSetuidAndSetgid;

    public SetuidAndSetgid(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSetuidAndSetgid == null) {
        _cacheChildrenSetuidAndSetgid = new HashSet<>();
        if (Linux.this instanceof Linux) {
          for (Service _0 : ((asset.Linux) Linux.this).service) {
            _cacheChildrenSetuidAndSetgid.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Linux.this instanceof Linux) {
          _cacheChildrenSetuidAndSetgid.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSetuidAndSetgid) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSetuidAndSetgid == null) {
        _cacheParentSetuidAndSetgid = new HashSet<>();
        _cacheParentSetuidAndSetgid.add(attemptSetuidAndSetgid);
        _cacheParentSetuidAndSetgid.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentSetuidAndSetgid) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.setuidAndSetgid");
    }
  }

  public class SecuritydMemory extends OS.SecuritydMemory {
    private Set<AttackStep> _cacheChildrenSecuritydMemory;

    private Set<AttackStep> _cacheParentSecuritydMemory;

    public SecuritydMemory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSecuritydMemory == null) {
        _cacheChildrenSecuritydMemory = new HashSet<>();
        if (Linux.this instanceof Linux) {
          for (UserAccount _0 : ((asset.Linux) Linux.this).userAccount) {
            _cacheChildrenSecuritydMemory.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSecuritydMemory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSecuritydMemory == null) {
        _cacheParentSecuritydMemory = new HashSet<>();
        _cacheParentSecuritydMemory.add(credentialsFromPasswordStores);
      }
      for (AttackStep attackStep : _cacheParentSecuritydMemory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.securitydMemory");
    }
  }

  public class SSH extends OS.SSH {
    private Set<AttackStep> _cacheChildrenSSH;

    private Set<AttackStep> _cacheParentSSH;

    public SSH(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSSH == null) {
        _cacheChildrenSSH = new HashSet<>();
        if (Linux.this instanceof Linux) {
          for (Computer _0 : ((asset.Linux) Linux.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenSSH.add(_2.c2Connected);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSSH) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSH == null) {
        _cacheParentSSH = new HashSet<>();
        _cacheParentSSH.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentSSH.add(multiFactorAuthentication.disable);
      }
      for (AttackStep attackStep : _cacheParentSSH) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.sSH");
    }
  }

  public class AttemptSSHAuthorizedKeys extends OS.AttemptSSHAuthorizedKeys {
    private Set<AttackStep> _cacheChildrenAttemptSSHAuthorizedKeys;

    private Set<AttackStep> _cacheParentAttemptSSHAuthorizedKeys;

    public AttemptSSHAuthorizedKeys(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSSHAuthorizedKeys == null) {
        _cacheChildrenAttemptSSHAuthorizedKeys = new HashSet<>();
        _cacheChildrenAttemptSSHAuthorizedKeys.add(sSHAuthorizedKeys);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSSHAuthorizedKeys) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSSHAuthorizedKeys == null) {
        _cacheParentAttemptSSHAuthorizedKeys = new HashSet<>();
        _cacheParentAttemptSSHAuthorizedKeys.add(accountManipulation);
      }
      for (AttackStep attackStep : _cacheParentAttemptSSHAuthorizedKeys) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptSSHAuthorizedKeys");
    }
  }

  public class SSHAuthorizedKeys extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSSHAuthorizedKeys;

    private Set<AttackStep> _cacheParentSSHAuthorizedKeys;

    public SSHAuthorizedKeys(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSSHAuthorizedKeys == null) {
        _cacheChildrenSSHAuthorizedKeys = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenSSHAuthorizedKeys.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSSHAuthorizedKeys) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSHAuthorizedKeys == null) {
        _cacheParentSSHAuthorizedKeys = new HashSet<>();
        _cacheParentSSHAuthorizedKeys.add(attemptSSHAuthorizedKeys);
        _cacheParentSSHAuthorizedKeys.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentSSHAuthorizedKeys.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSSHAuthorizedKeys) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.sSHAuthorizedKeys");
    }
  }

  public class SSHHijacking extends OS.SSHHijacking {
    private Set<AttackStep> _cacheChildrenSSHHijacking;

    private Set<AttackStep> _cacheParentSSHHijacking;

    public SSHHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSSHHijacking == null) {
        _cacheChildrenSSHHijacking = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenSSHHijacking.add(((asset.Linux) Linux.this).sSHCredentialInterception);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSSHHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSHHijacking == null) {
        _cacheParentSSHHijacking = new HashSet<>();
        _cacheParentSSHHijacking.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentSSHHijacking.add(passwordPolicies.disable);
        _cacheParentSSHHijacking.add(privilegedAccountManagement.disable);
        _cacheParentSSHHijacking.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSSHHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.sSHHijacking");
    }
  }

  public class AttemptSQLStoredProcedures extends OS.AttemptSQLStoredProcedures {
    private Set<AttackStep> _cacheChildrenAttemptSQLStoredProcedures;

    private Set<AttackStep> _cacheParentAttemptSQLStoredProcedures;

    public AttemptSQLStoredProcedures(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSQLStoredProcedures == null) {
        _cacheChildrenAttemptSQLStoredProcedures = new HashSet<>();
        _cacheChildrenAttemptSQLStoredProcedures.add(sQLStoredProcedures);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSQLStoredProcedures) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSQLStoredProcedures == null) {
        _cacheParentAttemptSQLStoredProcedures = new HashSet<>();
        _cacheParentAttemptSQLStoredProcedures.add(serverSoftwareComponent);
      }
      for (AttackStep attackStep : _cacheParentAttemptSQLStoredProcedures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptSQLStoredProcedures");
    }
  }

  public class SQLStoredProcedures extends OS.SQLStoredProcedures {
    private Set<AttackStep> _cacheChildrenSQLStoredProcedures;

    private Set<AttackStep> _cacheParentSQLStoredProcedures;

    public SQLStoredProcedures(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSQLStoredProcedures == null) {
        _cacheChildrenSQLStoredProcedures = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenSQLStoredProcedures.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSQLStoredProcedures) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSQLStoredProcedures == null) {
        _cacheParentSQLStoredProcedures = new HashSet<>();
        _cacheParentSQLStoredProcedures.add(attemptSQLStoredProcedures);
        _cacheParentSQLStoredProcedures.add(audit.disable);
        _cacheParentSQLStoredProcedures.add(codeSigning.disable);
        _cacheParentSQLStoredProcedures.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentSQLStoredProcedures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.sQLStoredProcedures");
    }
  }

  public class SudoAndSudoCaching extends OS.SudoAndSudoCaching {
    private Set<AttackStep> _cacheChildrenSudoAndSudoCaching;

    private Set<AttackStep> _cacheParentSudoAndSudoCaching;

    public SudoAndSudoCaching(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSudoAndSudoCaching == null) {
        _cacheChildrenSudoAndSudoCaching = new HashSet<>();
        if (Linux.this instanceof Linux) {
          for (Service _0 : ((asset.Linux) Linux.this).service) {
            _cacheChildrenSudoAndSudoCaching.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSudoAndSudoCaching) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSudoAndSudoCaching == null) {
        _cacheParentSudoAndSudoCaching = new HashSet<>();
        _cacheParentSudoAndSudoCaching.add(abuseElevationControlMechanism);
        _cacheParentSudoAndSudoCaching.add(operatingSystemConfiguration.disable);
        _cacheParentSudoAndSudoCaching.add(privilegedAccountManagement.disable);
        _cacheParentSudoAndSudoCaching.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSudoAndSudoCaching) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.sudoAndSudoCaching");
    }
  }

  public class AttemptSystemdService extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSystemdService;

    private Set<AttackStep> _cacheParentAttemptSystemdService;

    public AttemptSystemdService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSystemdService == null) {
        _cacheChildrenAttemptSystemdService = new HashSet<>();
        _cacheChildrenAttemptSystemdService.add(systemdService);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSystemdService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSystemdService == null) {
        _cacheParentAttemptSystemdService = new HashSet<>();
        _cacheParentAttemptSystemdService.add(createOrModifySystemProcess);
      }
      for (AttackStep attackStep : _cacheParentAttemptSystemdService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptSystemdService");
    }
  }

  public class SystemdService extends OS.SystemdService {
    private Set<AttackStep> _cacheChildrenSystemdService;

    private Set<AttackStep> _cacheParentSystemdService;

    public SystemdService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSystemdService == null) {
        _cacheChildrenSystemdService = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenSystemdService.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSystemdService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemdService == null) {
        _cacheParentSystemdService = new HashSet<>();
        _cacheParentSystemdService.add(attemptSystemdService);
        _cacheParentSystemdService.add(limitSoftwareInstallation.disable);
        _cacheParentSystemdService.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSystemdService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.systemdService");
    }
  }

  public class AttemptTransportAgent extends OS.AttemptTransportAgent {
    private Set<AttackStep> _cacheChildrenAttemptTransportAgent;

    private Set<AttackStep> _cacheParentAttemptTransportAgent;

    public AttemptTransportAgent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptTransportAgent == null) {
        _cacheChildrenAttemptTransportAgent = new HashSet<>();
        _cacheChildrenAttemptTransportAgent.add(transportAgent);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptTransportAgent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTransportAgent == null) {
        _cacheParentAttemptTransportAgent = new HashSet<>();
        _cacheParentAttemptTransportAgent.add(serverSoftwareComponent);
      }
      for (AttackStep attackStep : _cacheParentAttemptTransportAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.attemptTransportAgent");
    }
  }

  public class TransportAgent extends OS.TransportAgent {
    private Set<AttackStep> _cacheChildrenTransportAgent;

    private Set<AttackStep> _cacheParentTransportAgent;

    public TransportAgent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTransportAgent == null) {
        _cacheChildrenTransportAgent = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenTransportAgent.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenTransportAgent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTransportAgent == null) {
        _cacheParentTransportAgent = new HashSet<>();
        _cacheParentTransportAgent.add(attemptTransportAgent);
        _cacheParentTransportAgent.add(audit.disable);
        _cacheParentTransportAgent.add(codeSigning.disable);
        _cacheParentTransportAgent.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentTransportAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.transportAgent");
    }
  }

  public class Trap extends OS.Trap {
    private Set<AttackStep> _cacheChildrenTrap;

    private Set<AttackStep> _cacheParentTrap;

    public Trap(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTrap == null) {
        _cacheChildrenTrap = new HashSet<>();
        _cacheChildrenTrap.add(executeCode);
        if (Linux.this instanceof Linux) {
          _cacheChildrenTrap.add(((asset.Linux) Linux.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenTrap) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTrap == null) {
        _cacheParentTrap = new HashSet<>();
        _cacheParentTrap.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentTrap) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.trap");
    }
  }

  public class UnixShell extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenUnixShell;

    private Set<AttackStep> _cacheParentUnixShell;

    public UnixShell(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUnixShell == null) {
        _cacheChildrenUnixShell = new HashSet<>();
        _cacheChildrenUnixShell.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenUnixShell) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUnixShell == null) {
        _cacheParentUnixShell = new HashSet<>();
        _cacheParentUnixShell.add(commandAndScriptingInterpreter);
        _cacheParentUnixShell.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentUnixShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.unixShell");
    }
  }

  public class UnsecuredCredentials extends OS.UnsecuredCredentials {
    private Set<AttackStep> _cacheChildrenUnsecuredCredentials;

    public UnsecuredCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenUnsecuredCredentials == null) {
        _cacheChildrenUnsecuredCredentials = new HashSet<>();
        _cacheChildrenUnsecuredCredentials.add(bashHistory);
      }
      for (AttackStep attackStep : _cacheChildrenUnsecuredCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.unsecuredCredentials");
    }
  }

  public class VDSOHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenVDSOHijacking;

    private Set<AttackStep> _cacheParentVDSOHijacking;

    public VDSOHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenVDSOHijacking == null) {
        _cacheChildrenVDSOHijacking = new HashSet<>();
        if (Linux.this instanceof Linux) {
          _cacheChildrenVDSOHijacking.add(((asset.Linux) Linux.this).bypassAntivirus);
        }
        if (Linux.this instanceof Linux) {
          _cacheChildrenVDSOHijacking.add(((asset.Linux) Linux.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenVDSOHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentVDSOHijacking == null) {
        _cacheParentVDSOHijacking = new HashSet<>();
        _cacheParentVDSOHijacking.add(processInjection);
        _cacheParentVDSOHijacking.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentVDSOHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.vDSOHijacking");
    }
  }

  public class ExecuteCode extends OS.ExecuteCode {
    private Set<AttackStep> _cacheChildrenExecuteCode;

    private Set<AttackStep> _cacheParentExecuteCode;

    public ExecuteCode(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenExecuteCode == null) {
        _cacheChildrenExecuteCode = new HashSet<>();
        if (Linux.this instanceof Linux) {
          for (Computer _0 : ((asset.Linux) Linux.this).computer) {
            _cacheChildrenExecuteCode.add(_0.infectedLinuxComputer);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExecuteCode) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecuteCode == null) {
        _cacheParentExecuteCode = new HashSet<>();
        _cacheParentExecuteCode.add(at);
        _cacheParentExecuteCode.add(trap);
        _cacheParentExecuteCode.add(unixShell);
      }
      for (AttackStep attackStep : _cacheParentExecuteCode) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Linux.executeCode");
    }
  }

  public class Antivirus extends OS.Antivirus {
    public Antivirus(String name) {
      this(name, false);
    }

    public Antivirus(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.Antivirus.Disable {
      private Set<AttackStep> _cacheChildrenAntivirus;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenAntivirus == null) {
          _cacheChildrenAntivirus = new HashSet<>();
          _cacheChildrenAntivirus.add(kernelModulesAndExtensions);
        }
        for (AttackStep attackStep : _cacheChildrenAntivirus) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.antivirus";
      }
    }
  }

  public class Audit extends OS.Audit {
    public Audit(String name) {
      this(name, false);
    }

    public Audit(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.Audit.Disable {
      private Set<AttackStep> _cacheChildrenAudit;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenAudit == null) {
          _cacheChildrenAudit = new HashSet<>();
          _cacheChildrenAudit.add(at);
          _cacheChildrenAudit.add(cron);
          _cacheChildrenAudit.add(sQLStoredProcedures);
          _cacheChildrenAudit.add(transportAgent);
        }
        for (AttackStep attackStep : _cacheChildrenAudit) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.audit";
      }
    }
  }

  public class BehaviorPreventionOnEndpoint extends OS.BehaviorPreventionOnEndpoint {
    public BehaviorPreventionOnEndpoint(String name) {
      this(name, false);
    }

    public BehaviorPreventionOnEndpoint(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.BehaviorPreventionOnEndpoint.Disable {
      private Set<AttackStep> _cacheChildrenBehaviorPreventionOnEndpoint;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenBehaviorPreventionOnEndpoint == null) {
          _cacheChildrenBehaviorPreventionOnEndpoint = new HashSet<>();
          _cacheChildrenBehaviorPreventionOnEndpoint.add(ptraceSystemCalls);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(procMemory);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(vDSOHijacking);
        }
        for (AttackStep attackStep : _cacheChildrenBehaviorPreventionOnEndpoint) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.behaviorPreventionOnEndpoint";
      }
    }
  }

  public class BootIntegrity extends OS.BootIntegrity {
    public BootIntegrity(String name) {
      this(name, false);
    }

    public BootIntegrity(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.BootIntegrity.Disable {
      private Set<AttackStep> _cacheChildrenBootIntegrity;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenBootIntegrity == null) {
          _cacheChildrenBootIntegrity = new HashSet<>();
          _cacheChildrenBootIntegrity.add(bootkit);
        }
        for (AttackStep attackStep : _cacheChildrenBootIntegrity) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.bootIntegrity";
      }
    }
  }

  public class CodeSigning extends OS.CodeSigning {
    public CodeSigning(String name) {
      this(name, false);
    }

    public CodeSigning(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.CodeSigning.Disable {
      private Set<AttackStep> _cacheChildrenCodeSigning;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenCodeSigning == null) {
          _cacheChildrenCodeSigning = new HashSet<>();
          _cacheChildrenCodeSigning.add(sQLStoredProcedures);
          _cacheChildrenCodeSigning.add(transportAgent);
        }
        for (AttackStep attackStep : _cacheChildrenCodeSigning) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.codeSigning";
      }
    }
  }

  public class DisableOrRemoveFeatureOrProgram extends OS.DisableOrRemoveFeatureOrProgram {
    public DisableOrRemoveFeatureOrProgram(String name) {
      this(name, false);
    }

    public DisableOrRemoveFeatureOrProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.DisableOrRemoveFeatureOrProgram.Disable {
      private Set<AttackStep> _cacheChildrenDisableOrRemoveFeatureOrProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenDisableOrRemoveFeatureOrProgram == null) {
          _cacheChildrenDisableOrRemoveFeatureOrProgram = new HashSet<>();
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(sSH);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(sSHAuthorizedKeys);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(sSHHijacking);
        }
        for (AttackStep attackStep : _cacheChildrenDisableOrRemoveFeatureOrProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.disableOrRemoveFeatureOrProgram";
      }
    }
  }

  public class EncryptSensitiveInformation extends OS.EncryptSensitiveInformation {
    public EncryptSensitiveInformation(String name) {
      this(name, false);
    }

    public EncryptSensitiveInformation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.EncryptSensitiveInformation.Disable {
      private Set<AttackStep> _cacheChildrenEncryptSensitiveInformation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenEncryptSensitiveInformation == null) {
          _cacheChildrenEncryptSensitiveInformation = new HashSet<>();
          _cacheChildrenEncryptSensitiveInformation.add(clearLinuxSystemLogs);
        }
        for (AttackStep attackStep : _cacheChildrenEncryptSensitiveInformation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.encryptSensitiveInformation";
      }
    }
  }

  public class ExecutionPrevention extends OS.ExecutionPrevention {
    public ExecutionPrevention(String name) {
      this(name, false);
    }

    public ExecutionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.ExecutionPrevention.Disable {
      private Set<AttackStep> _cacheChildrenExecutionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenExecutionPrevention == null) {
          _cacheChildrenExecutionPrevention = new HashSet<>();
          _cacheChildrenExecutionPrevention.add(kernelModulesAndExtensions);
          _cacheChildrenExecutionPrevention.add(unixShell);
          _cacheChildrenExecutionPrevention.add(lD_PRELOAD);
        }
        for (AttackStep attackStep : _cacheChildrenExecutionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.executionPrevention";
      }
    }
  }

  public class EnvironmentVariablePermissions extends Defense {
    public EnvironmentVariablePermissions(String name) {
      this(name, false);
    }

    public EnvironmentVariablePermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenEnvironmentVariablePermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenEnvironmentVariablePermissions == null) {
          _cacheChildrenEnvironmentVariablePermissions = new HashSet<>();
          _cacheChildrenEnvironmentVariablePermissions.add(clearCommandHistory);
          _cacheChildrenEnvironmentVariablePermissions.add(hISTCONTROL);
        }
        for (AttackStep attackStep : _cacheChildrenEnvironmentVariablePermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.environmentVariablePermissions";
      }
    }
  }

  public class LimitSoftwareInstallation extends OS.LimitSoftwareInstallation {
    public LimitSoftwareInstallation(String name) {
      this(name, false);
    }

    public LimitSoftwareInstallation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.LimitSoftwareInstallation.Disable {
      private Set<AttackStep> _cacheChildrenLimitSoftwareInstallation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenLimitSoftwareInstallation == null) {
          _cacheChildrenLimitSoftwareInstallation = new HashSet<>();
          _cacheChildrenLimitSoftwareInstallation.add(systemdService);
        }
        for (AttackStep attackStep : _cacheChildrenLimitSoftwareInstallation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.limitSoftwareInstallation";
      }
    }
  }

  public class MultiFactorAuthentication extends OS.MultiFactorAuthentication {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.MultiFactorAuthentication.Disable {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(pluggableAuthenticationModules);
          _cacheChildrenMultiFactorAuthentication.add(sSH);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.multiFactorAuthentication";
      }
    }
  }

  public class OperatingSystemConfiguration extends OS.OperatingSystemConfiguration {
    public OperatingSystemConfiguration(String name) {
      this(name, false);
    }

    public OperatingSystemConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.OperatingSystemConfiguration.Disable {
      private Set<AttackStep> _cacheChildrenOperatingSystemConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenOperatingSystemConfiguration == null) {
          _cacheChildrenOperatingSystemConfiguration = new HashSet<>();
          _cacheChildrenOperatingSystemConfiguration.add(bashHistory);
          _cacheChildrenOperatingSystemConfiguration.add(hISTCONTROL);
          _cacheChildrenOperatingSystemConfiguration.add(setuidAndSetgid);
          _cacheChildrenOperatingSystemConfiguration.add(sudoAndSudoCaching);
        }
        for (AttackStep attackStep : _cacheChildrenOperatingSystemConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.operatingSystemConfiguration";
      }
    }
  }

  public class PasswordPolicies extends OS.PasswordPolicies {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.PasswordPolicies.Disable {
      private Set<AttackStep> _cacheChildrenPasswordPolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPasswordPolicies == null) {
          _cacheChildrenPasswordPolicies = new HashSet<>();
          _cacheChildrenPasswordPolicies.add(sSHHijacking);
          _cacheChildrenPasswordPolicies.add(procFilesystem);
          _cacheChildrenPasswordPolicies.add(_etc_passwdAND_etc_shadow);
        }
        for (AttackStep attackStep : _cacheChildrenPasswordPolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.passwordPolicies";
      }
    }
  }

  public class PrivilegedAccountManagement extends OS.PrivilegedAccountManagement {
    public PrivilegedAccountManagement(String name) {
      this(name, false);
    }

    public PrivilegedAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.PrivilegedAccountManagement.Disable {
      private Set<AttackStep> _cacheChildrenPrivilegedAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPrivilegedAccountManagement == null) {
          _cacheChildrenPrivilegedAccountManagement = new HashSet<>();
          _cacheChildrenPrivilegedAccountManagement.add(bootkit);
          _cacheChildrenPrivilegedAccountManagement.add(_etc_passwdAND_etc_shadow);
          _cacheChildrenPrivilegedAccountManagement.add(sSHHijacking);
          _cacheChildrenPrivilegedAccountManagement.add(sQLStoredProcedures);
          _cacheChildrenPrivilegedAccountManagement.add(sudoAndSudoCaching);
          _cacheChildrenPrivilegedAccountManagement.add(pluggableAuthenticationModules);
          _cacheChildrenPrivilegedAccountManagement.add(procFilesystem);
          _cacheChildrenPrivilegedAccountManagement.add(ptraceSystemCalls);
          _cacheChildrenPrivilegedAccountManagement.add(transportAgent);
          _cacheChildrenPrivilegedAccountManagement.add(linuxFileAndDirectoryPermissionsModification);
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.privilegedAccountManagement";
      }
    }
  }

  public class RestrictFileAndDirectoryPermissions extends OS.RestrictFileAndDirectoryPermissions {
    public RestrictFileAndDirectoryPermissions(String name) {
      this(name, false);
    }

    public RestrictFileAndDirectoryPermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.RestrictFileAndDirectoryPermissions.Disable {
      private Set<AttackStep> _cacheChildrenRestrictFileAndDirectoryPermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenRestrictFileAndDirectoryPermissions == null) {
          _cacheChildrenRestrictFileAndDirectoryPermissions = new HashSet<>();
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(bash_profileAndBashrc);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(clearCommandHistory);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(clearLinuxSystemLogs);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(sSHAuthorizedKeys);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(sSHHijacking);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(sudoAndSudoCaching);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(systemdService);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(procMemory);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(linuxFileAndDirectoryPermissionsModification);
        }
        for (AttackStep attackStep : _cacheChildrenRestrictFileAndDirectoryPermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.restrictFileAndDirectoryPermissions";
      }
    }
  }

  public class RemoteDataStorage extends OS.RemoteDataStorage {
    public RemoteDataStorage(String name) {
      this(name, false);
    }

    public RemoteDataStorage(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.RemoteDataStorage.Disable {
      private Set<AttackStep> _cacheChildrenRemoteDataStorage;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenRemoteDataStorage == null) {
          _cacheChildrenRemoteDataStorage = new HashSet<>();
          _cacheChildrenRemoteDataStorage.add(clearLinuxSystemLogs);
        }
        for (AttackStep attackStep : _cacheChildrenRemoteDataStorage) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Linux.remoteDataStorage";
      }
    }
  }
}
