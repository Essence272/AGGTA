package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class AdminAccount extends Asset {
  public AdminRights adminRights;

  public AdminCredentials adminCredentials;

  public AttemptCreateAccount attemptCreateAccount;

  public CreateAccount createAccount;

  public PrivilegedAccountManagement privilegedAccountManagement;

  public Set<UserAccount> userAccount = new HashSet<>();

  public OS os = null;

  public AdminAccount(String name, boolean isPrivilegedAccountManagementEnabled) {
    super(name);
    assetClassName = "AdminAccount";
    AttackStep.allAttackSteps.remove(adminRights);
    adminRights = new AdminRights(name);
    AttackStep.allAttackSteps.remove(adminCredentials);
    adminCredentials = new AdminCredentials(name);
    AttackStep.allAttackSteps.remove(attemptCreateAccount);
    attemptCreateAccount = new AttemptCreateAccount(name);
    AttackStep.allAttackSteps.remove(createAccount);
    createAccount = new CreateAccount(name);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, isPrivilegedAccountManagementEnabled);
  }

  public AdminAccount(String name) {
    super(name);
    assetClassName = "AdminAccount";
    AttackStep.allAttackSteps.remove(adminRights);
    adminRights = new AdminRights(name);
    AttackStep.allAttackSteps.remove(adminCredentials);
    adminCredentials = new AdminCredentials(name);
    AttackStep.allAttackSteps.remove(attemptCreateAccount);
    attemptCreateAccount = new AttemptCreateAccount(name);
    AttackStep.allAttackSteps.remove(createAccount);
    createAccount = new CreateAccount(name);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, false);
  }

  public AdminAccount(boolean isPrivilegedAccountManagementEnabled) {
    this("Anonymous", isPrivilegedAccountManagementEnabled);
  }

  public AdminAccount() {
    this("Anonymous");
  }

  public void addUserAccount(UserAccount userAccount) {
    this.userAccount.add(userAccount);
    userAccount.adminAccount.add(this);
  }

  public void addOs(OS os) {
    this.os = os;
    os.adminAccount.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("userAccount")) {
      return UserAccount.class.getName();
    } else if (field.equals("os")) {
      return OS.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("userAccount")) {
      assets.addAll(userAccount);
    } else if (field.equals("os")) {
      if (os != null) {
        assets.add(os);
      }
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(userAccount);
    if (os != null) {
      assets.add(os);
    }
    return assets;
  }

  public class AdminRights extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAdminRights;

    private Set<AttackStep> _cacheParentAdminRights;

    public AdminRights(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAdminRights == null) {
        _cacheChildrenAdminRights = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenAdminRights.add(_0.userRights);
        }
        _cacheChildrenAdminRights.add(createAccount);
        if (os != null) {
          _cacheChildrenAdminRights.add(os.abuseElevationControlMechanism);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.accessibilityFeatures);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.accountAccessRemoval);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.appCertDLLs);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.appInitDLLs);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.applicationShimming);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.at);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptAccessTokenManipulation);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptAutomatedCollection);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptBITSJobs);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptCredentialsInFiles);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptDataDestruction);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptDataEncryptedForImpact);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptExecutionThroughAPI);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptServiceRegistryPermissionsWeakness);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptServicesFilePermissionsWeakness);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptServiceStop);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptShortcutModification);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptSIDHistoryInjection);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptTimeProviders);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptWindowsAdminShares);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptWindowsManagementInstrumentationEventSubscription);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.attemptWinlogonHelperDLL);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.authenticationPackage);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.bootkit);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.clearWindowsEventLogs);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.credentialAPIHooking);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.credentialsFromPasswordStores);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.dCShadow);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.dCSync);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.detailedRemoteSystemDiscovery);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.disableWindowsEventLogging);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.distributedComponentObjectModel);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.domainControllerAuthentication);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.exchangeEmailDelegatePermissions);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.fileAndDirectoryDiscovery);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.fileSystemLogicalOffsets);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.firmwareCorruption);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.groupPolicyModification);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.imageFileExecutionOptionsInjection);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.inhibitSystemRecovery);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.lSASSDriver);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.lSASSMemory);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.manInTheBrowser);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.masqueradeTaskOrService);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.modifyRegistry);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.netshHelperDLL);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.networkServiceScan);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.networkShareConnectionRemoval);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.networkSniffing);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.oSCredentialDumping);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.parentPIDSpoofing);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.passwordFilterDLL);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.portMonitors);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.powerShell);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.powerShellAdminProfile);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.processDiscovery);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.queryRegistry);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.registryRunKeysOrStartupFolder);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.remoteScheduledTask);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.resourceHijacking);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.scheduledTask);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.securitySupportProvider);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.serviceExecution);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.sQLStoredProcedures);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.systemFirmware);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.systemNetworkConnectionsDiscovery);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.systemOwnerOrUserDiscovery);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.systemServiceDiscovery);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.systemShutdownOrReboot);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.transportAgent);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.twoFactorAuthenticationInterception);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.windowsManagementInstrumentation);
        }
        if (os != null) {
          _cacheChildrenAdminRights.add(os.windowsRemoteManagement);
        }
        if (os != null) {
          for (Service _1 : os.service) {
            _cacheChildrenAdminRights.add(_1.applicationDeploymentSoftware);
          }
        }
        if (os != null) {
          for (Service _2 : os.service) {
            _cacheChildrenAdminRights.add(_2.attemptUseThirdpartySoftware);
          }
        }
        if (os != null) {
          for (Service _3 : os.service) {
            _cacheChildrenAdminRights.add(_3.additionalAzureServicePrincipalCredentials);
          }
        }
        if (os != null) {
          for (Service _4 : os.service) {
            _cacheChildrenAdminRights.add(_4.exchangeEmailDelegatePermissions);
          }
        }
        if (os != null) {
          for (Service _5 : os.service) {
            _cacheChildrenAdminRights.add(_5.addOffice365GlobalAdministratorRole);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenAdminRights) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAdminRights == null) {
        _cacheParentAdminRights = new HashSet<>();
        _cacheParentAdminRights.add(adminCredentials);
        if (os != null) {
          for (Service _6 : os.service) {
            _cacheParentAdminRights.add(_6.exploitationForPrivilegeEscalation);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAdminRights.add(((asset.Windows) os).logonScripts);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAdminRights.add(((asset.MacOS) os).logonScripts);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAdminRights) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("AdminAccount.adminRights");
    }
  }

  public class AdminCredentials extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAdminCredentials;

    private Set<AttackStep> _cacheParentAdminCredentials;

    public AdminCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAdminCredentials == null) {
        _cacheChildrenAdminCredentials = new HashSet<>();
        _cacheChildrenAdminCredentials.add(adminRights);
        if (os != null) {
          _cacheChildrenAdminCredentials.add(os.validAccounts);
        }
        if (os != null) {
          for (Service _0 : os.service) {
            _cacheChildrenAdminCredentials.add(_0.remoteServices);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenAdminCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAdminCredentials == null) {
        _cacheParentAdminCredentials = new HashSet<>();
        if (os != null) {
          _cacheParentAdminCredentials.add(os.clipboardData);
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAdminCredentials.add(((asset.Windows) os).passwordFilterDLL);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAdminCredentials.add(((asset.MacOS) os).bashHistory);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAdminCredentials) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("AdminAccount.adminCredentials");
    }
  }

  public class AttemptCreateAccount extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptCreateAccount;

    private Set<AttackStep> _cacheParentAttemptCreateAccount;

    public AttemptCreateAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptCreateAccount == null) {
        _cacheChildrenAttemptCreateAccount = new HashSet<>();
        _cacheChildrenAttemptCreateAccount.add(createAccount);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptCreateAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptCreateAccount == null) {
        _cacheParentAttemptCreateAccount = new HashSet<>();
        if (os != null) {
          for (Service _0 : os.service) {
            if (_0 instanceof CloudService) {
              _cacheParentAttemptCreateAccount.add(((asset.CloudService) _0).addOffice365GlobalAdministratorRole);
            }
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptCreateAccount.add(((asset.Windows) os).groupPolicyModification);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptCreateAccount.add(((asset.MacOS) os).hiddenUsers);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptCreateAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("AdminAccount.attemptCreateAccount");
    }
  }

  public class CreateAccount extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCreateAccount;

    private Set<AttackStep> _cacheParentCreateAccount;

    public CreateAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCreateAccount == null) {
        _cacheChildrenCreateAccount = new HashSet<>();
        if (os != null) {
          for (Service _0 : os.service) {
            _cacheChildrenCreateAccount.add(_0.cloudAccount);
          }
        }
        if (os != null) {
          _cacheChildrenCreateAccount.add(os.domainAccount);
        }
        if (os != null) {
          _cacheChildrenCreateAccount.add(os.localAccount);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCreateAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCreateAccount == null) {
        _cacheParentCreateAccount = new HashSet<>();
        _cacheParentCreateAccount.add(adminRights);
        _cacheParentCreateAccount.add(attemptCreateAccount);
      }
      for (AttackStep attackStep : _cacheParentCreateAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("AdminAccount.createAccount");
    }
  }

  public class PrivilegedAccountManagement extends Defense {
    public PrivilegedAccountManagement(String name) {
      this(name, false);
    }

    public PrivilegedAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenPrivilegedAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenPrivilegedAccountManagement == null) {
          _cacheChildrenPrivilegedAccountManagement = new HashSet<>();
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.accessTokenManipulation);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.domainAccount);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.firmwareCorruption);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.kernelModulesAndExtensions);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.localAccount);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.modifyRegistry);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.passTheTicket);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.powerShell);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.remoteDesktopProtocol);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.serviceExecution);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.sudoAndSudoCaching);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.systemdService);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.systemFirmware);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.windowsAdminShares);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.windowsManagementInstrumentation);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.windowsManagementInstrumentationEventSubscription);
          }
          if (os != null) {
            _cacheChildrenPrivilegedAccountManagement.add(os.windowsRemoteManagement);
          }
          if (os != null) {
            for (Service _0 : os.service) {
              _cacheChildrenPrivilegedAccountManagement.add(_0.applicationDeploymentSoftware);
            }
          }
          if (os != null) {
            for (Service _1 : os.service) {
              _cacheChildrenPrivilegedAccountManagement.add(_1.exploitationOfRemoteServices);
            }
          }
          if (os != null) {
            for (Service _2 : os.service) {
              _cacheChildrenPrivilegedAccountManagement.add(_2.cloudAccount);
            }
          }
          if (os != null) {
            for (Service _3 : os.service) {
              _cacheChildrenPrivilegedAccountManagement.add(_3.useThirdpartySoftware);
            }
          }
          if (os != null) {
            for (Service _4 : os.service) {
              _cacheChildrenPrivilegedAccountManagement.add(_4.exploitHighVulnerabilityPublicFacingApplication);
            }
          }
          if (os != null) {
            for (Service _5 : os.service) {
              _cacheChildrenPrivilegedAccountManagement.add(_5.exploitMediumVulnerabilityPublicFacingApplication);
            }
          }
          if (os != null) {
            for (Service _6 : os.service) {
              _cacheChildrenPrivilegedAccountManagement.add(_6.exploitLowVulnerabilityPublicFacingApplication);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "AdminAccount.privilegedAccountManagement";
      }
    }
  }
}
