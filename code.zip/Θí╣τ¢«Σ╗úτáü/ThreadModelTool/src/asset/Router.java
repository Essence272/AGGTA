package asset;

import core.Asset;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Router extends Asset {
  public Set<Computer> computer = new HashSet<>();

  public Firewall firewall = null;

  public Set<InternalNetwork> internalNetwork = new HashSet<>();

  public Set<ExternalNetwork> externalNetwork = new HashSet<>();

  public Router(String name) {
    super(name);
    assetClassName = "Router";
  }

  public Router() {
    this("Anonymous");
  }

  public void addComputer(Computer computer) {
    this.computer.add(computer);
    computer.router.add(this);
  }

  public void addFirewall(Firewall firewall) {
    this.firewall = firewall;
    firewall.router = this;
  }

  public void addInternalNetwork(InternalNetwork internalNetwork) {
    this.internalNetwork.add(internalNetwork);
    internalNetwork.router.add(this);
  }

  public void addExternalNetwork(ExternalNetwork externalNetwork) {
    this.externalNetwork.add(externalNetwork);
    externalNetwork.router.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("computer")) {
      return Computer.class.getName();
    } else if (field.equals("firewall")) {
      return Firewall.class.getName();
    } else if (field.equals("internalNetwork")) {
      return InternalNetwork.class.getName();
    } else if (field.equals("externalNetwork")) {
      return ExternalNetwork.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("computer")) {
      assets.addAll(computer);
    } else if (field.equals("firewall")) {
      if (firewall != null) {
        assets.add(firewall);
      }
    } else if (field.equals("internalNetwork")) {
      assets.addAll(internalNetwork);
    } else if (field.equals("externalNetwork")) {
      assets.addAll(externalNetwork);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(computer);
    if (firewall != null) {
      assets.add(firewall);
    }
    assets.addAll(internalNetwork);
    assets.addAll(externalNetwork);
    return assets;
  }
}
