package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class User extends Asset {
  public AttemptMaliciousLink attemptMaliciousLink;

  public MaliciousLink maliciousLink;

  public AttemptMaliciousFile attemptMaliciousFile;

  public MaliciousFile maliciousFile;

  public AttemptUserExecution attemptUserExecution;

  public MediaInserted mediaInserted;

  public UserTraining userTraining;

  public Set<Computer> computer = new HashSet<>();

  public Set<UserAccount> userAccount = new HashSet<>();

  public User(String name, boolean isUserTrainingEnabled) {
    super(name);
    assetClassName = "User";
    AttackStep.allAttackSteps.remove(attemptMaliciousLink);
    attemptMaliciousLink = new AttemptMaliciousLink(name);
    AttackStep.allAttackSteps.remove(maliciousLink);
    maliciousLink = new MaliciousLink(name);
    AttackStep.allAttackSteps.remove(attemptMaliciousFile);
    attemptMaliciousFile = new AttemptMaliciousFile(name);
    AttackStep.allAttackSteps.remove(maliciousFile);
    maliciousFile = new MaliciousFile(name);
    AttackStep.allAttackSteps.remove(attemptUserExecution);
    attemptUserExecution = new AttemptUserExecution(name);
    AttackStep.allAttackSteps.remove(mediaInserted);
    mediaInserted = new MediaInserted(name);
    if (userTraining != null) {
      AttackStep.allAttackSteps.remove(userTraining.disable);
    }
    Defense.allDefenses.remove(userTraining);
    userTraining = new UserTraining(name, isUserTrainingEnabled);
  }

  public User(String name) {
    super(name);
    assetClassName = "User";
    AttackStep.allAttackSteps.remove(attemptMaliciousLink);
    attemptMaliciousLink = new AttemptMaliciousLink(name);
    AttackStep.allAttackSteps.remove(maliciousLink);
    maliciousLink = new MaliciousLink(name);
    AttackStep.allAttackSteps.remove(attemptMaliciousFile);
    attemptMaliciousFile = new AttemptMaliciousFile(name);
    AttackStep.allAttackSteps.remove(maliciousFile);
    maliciousFile = new MaliciousFile(name);
    AttackStep.allAttackSteps.remove(attemptUserExecution);
    attemptUserExecution = new AttemptUserExecution(name);
    AttackStep.allAttackSteps.remove(mediaInserted);
    mediaInserted = new MediaInserted(name);
    if (userTraining != null) {
      AttackStep.allAttackSteps.remove(userTraining.disable);
    }
    Defense.allDefenses.remove(userTraining);
    userTraining = new UserTraining(name, false);
  }

  public User(boolean isUserTrainingEnabled) {
    this("Anonymous", isUserTrainingEnabled);
  }

  public User() {
    this("Anonymous");
  }

  public void addComputer(Computer computer) {
    this.computer.add(computer);
    computer.user.add(this);
  }

  public void addUserAccount(UserAccount userAccount) {
    this.userAccount.add(userAccount);
    userAccount.user = this;
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("computer")) {
      return Computer.class.getName();
    } else if (field.equals("userAccount")) {
      return UserAccount.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("computer")) {
      assets.addAll(computer);
    } else if (field.equals("userAccount")) {
      assets.addAll(userAccount);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(computer);
    assets.addAll(userAccount);
    return assets;
  }

  public class AttemptMaliciousLink extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptMaliciousLink;

    private Set<AttackStep> _cacheParentAttemptMaliciousLink;

    public AttemptMaliciousLink(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptMaliciousLink == null) {
        _cacheChildrenAttemptMaliciousLink = new HashSet<>();
        _cacheChildrenAttemptMaliciousLink.add(maliciousLink);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptMaliciousLink) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptMaliciousLink == null) {
        _cacheParentAttemptMaliciousLink = new HashSet<>();
        for (Computer _0 : computer) {
          for (OS _1 : _0.os) {
            for (Service _2 : _1.service) {
              for (Browser _3 : _2.browser) {
                _cacheParentAttemptMaliciousLink.add(_3.spearphishingLink);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptMaliciousLink) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("User.attemptMaliciousLink");
    }
  }

  public class MaliciousLink extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenMaliciousLink;

    private Set<AttackStep> _cacheParentMaliciousLink;

    public MaliciousLink(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMaliciousLink == null) {
        _cacheChildrenMaliciousLink = new HashSet<>();
        for (Computer _0 : computer) {
          for (OS _1 : _0.os) {
            for (Service _2 : _1.service) {
              _cacheChildrenMaliciousLink.add(_2.attemptExploitationForClientExecution);
            }
          }
        }
        _cacheChildrenMaliciousLink.add(attemptMaliciousFile);
        for (Computer _3 : computer) {
          for (OS _4 : _3.os) {
            _cacheChildrenMaliciousLink.add(_4.executeCode);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenMaliciousLink) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMaliciousLink == null) {
        _cacheParentMaliciousLink = new HashSet<>();
        _cacheParentMaliciousLink.add(attemptMaliciousLink);
        _cacheParentMaliciousLink.add(userTraining.disable);
        for (UserAccount _5 : userAccount) {
          _cacheParentMaliciousLink.add(_5.userExecution);
        }
        for (Computer _6 : computer) {
          for (OS _7 : _6.os) {
            for (Service _8 : _7.service) {
              for (Browser _9 : _8.browser) {
                _cacheParentMaliciousLink.add(_9.restrictWebBasedContent.disable);
              }
            }
          }
        }
        for (Computer _a : computer) {
          for (Router _b : _a.router) {
            for (InternalNetwork _c : _b.internalNetwork) {
              _cacheParentMaliciousLink.add(_c.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentMaliciousLink) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("User.maliciousLink");
    }
  }

  public class AttemptMaliciousFile extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptMaliciousFile;

    private Set<AttackStep> _cacheParentAttemptMaliciousFile;

    public AttemptMaliciousFile(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptMaliciousFile == null) {
        _cacheChildrenAttemptMaliciousFile = new HashSet<>();
        _cacheChildrenAttemptMaliciousFile.add(maliciousFile);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptMaliciousFile) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptMaliciousFile == null) {
        _cacheParentAttemptMaliciousFile = new HashSet<>();
        _cacheParentAttemptMaliciousFile.add(maliciousLink);
        for (Computer _0 : computer) {
          for (OS _1 : _0.os) {
            for (Service _2 : _1.service) {
              for (Browser _3 : _2.browser) {
                _cacheParentAttemptMaliciousFile.add(_3.spearphishingAttachment);
              }
            }
          }
        }
        for (Computer _4 : computer) {
          for (OS _5 : _4.os) {
            _cacheParentAttemptMaliciousFile.add(_5.internalSpearphishing);
          }
        }
        for (Computer _6 : computer) {
          for (OS _7 : _6.os) {
            _cacheParentAttemptMaliciousFile.add(_7.rightToLeftOverride);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptMaliciousFile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("User.attemptMaliciousFile");
    }
  }

  public class MaliciousFile extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenMaliciousFile;

    private Set<AttackStep> _cacheParentMaliciousFile;

    public MaliciousFile(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMaliciousFile == null) {
        _cacheChildrenMaliciousFile = new HashSet<>();
        for (Computer _0 : computer) {
          for (OS _1 : _0.os) {
            _cacheChildrenMaliciousFile.add(_1.attemptDynamicDataExchange);
          }
        }
        for (Computer _2 : computer) {
          for (OS _3 : _2.os) {
            _cacheChildrenMaliciousFile.add(_3.executeCode);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenMaliciousFile) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMaliciousFile == null) {
        _cacheParentMaliciousFile = new HashSet<>();
        _cacheParentMaliciousFile.add(attemptMaliciousFile);
        _cacheParentMaliciousFile.add(userTraining.disable);
        for (UserAccount _4 : userAccount) {
          _cacheParentMaliciousFile.add(_4.userExecution);
        }
        for (UserAccount _5 : userAccount) {
          if (_5.os != null) {
            _cacheParentMaliciousFile.add(_5.os.executionPrevention.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentMaliciousFile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("User.maliciousFile");
    }
  }

  public class AttemptUserExecution extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptUserExecution;

    private Set<AttackStep> _cacheParentAttemptUserExecution;

    public AttemptUserExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptUserExecution == null) {
        _cacheChildrenAttemptUserExecution = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenAttemptUserExecution.add(_0.userExecution);
        }
      }
      for (AttackStep attackStep : _cacheChildrenAttemptUserExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptUserExecution == null) {
        _cacheParentAttemptUserExecution = new HashSet<>();
        for (Computer _1 : computer) {
          for (OS _2 : _1.os) {
            for (Service _3 : _2.service) {
              _cacheParentAttemptUserExecution.add(_3.exploitationForClientExecution);
            }
          }
        }
        for (Computer _4 : computer) {
          for (OS _5 : _4.os) {
            for (Service _6 : _5.service) {
              for (Browser _7 : _6.browser) {
                _cacheParentAttemptUserExecution.add(_7.driveByCompromise);
              }
            }
          }
        }
        for (Computer _8 : computer) {
          for (OS _9 : _8.os) {
            _cacheParentAttemptUserExecution.add(_9.remoteFileCopy);
          }
        }
        for (Computer _a : computer) {
          for (OS _b : _a.os) {
            if (_b instanceof Windows) {
              _cacheParentAttemptUserExecution.add(((asset.Windows) _b).compiledHTMLFile);
            }
          }
        }
        for (Computer _c : computer) {
          for (OS _d : _c.os) {
            if (_d instanceof Windows) {
              _cacheParentAttemptUserExecution.add(((asset.Windows) _d).attemptPowerShell);
            }
          }
        }
        for (Computer _e : computer) {
          for (OS _f : _e.os) {
            if (_f instanceof Linux) {
              _cacheParentAttemptUserExecution.add(((asset.Linux) _f).spaceAfterFileName);
            }
          }
        }
        for (Computer _10 : computer) {
          for (OS _11 : _10.os) {
            if (_11 instanceof MacOS) {
              _cacheParentAttemptUserExecution.add(((asset.MacOS) _11).spaceAfterFileName);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptUserExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("User.attemptUserExecution");
    }
  }

  public class MediaInserted extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenMediaInserted;

    public MediaInserted(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMediaInserted == null) {
        _cacheChildrenMediaInserted = new HashSet<>();
        for (Computer _0 : computer) {
          for (OS _1 : _0.os) {
            _cacheChildrenMediaInserted.add(_1.replicationThroughRemovableMedia);
          }
        }
        for (Computer _2 : computer) {
          for (PeripheralDevice _3 : _2.peripheralDevice) {
            _cacheChildrenMediaInserted.add(_3.dataExfiltration);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenMediaInserted) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("User.mediaInserted");
    }
  }

  public class UserTraining extends Defense {
    public UserTraining(String name) {
      this(name, false);
    }

    public UserTraining(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenUserTraining;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenUserTraining == null) {
          _cacheChildrenUserTraining = new HashSet<>();
          _cacheChildrenUserTraining.add(maliciousFile);
          _cacheChildrenUserTraining.add(maliciousLink);
          for (UserAccount _0 : userAccount) {
            _cacheChildrenUserTraining.add(_0.userExecution);
          }
        }
        for (AttackStep attackStep : _cacheChildrenUserTraining) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "User.userTraining";
      }
    }
  }
}
