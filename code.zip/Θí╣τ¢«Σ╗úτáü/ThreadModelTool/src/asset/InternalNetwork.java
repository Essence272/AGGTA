package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class InternalNetwork extends Asset {
  public ObfuscateNetworkTraffic obfuscateNetworkTraffic;

  public ApplicationLayerConnexion applicationLayerConnexion;

  public AttemptDataEncryptedForImpact attemptDataEncryptedForImpact;

  public DataEncryptedForImpact dataEncryptedForImpact;

  public DataExfiltration dataExfiltration;

  public InternalDefacement internalDefacement;

  public AttemptExfiltrationOverC2Channel attemptExfiltrationOverC2Channel;

  public ExfiltrationOverC2Channel exfiltrationOverC2Channel;

  public FirewallExists firewallExists;

  public BypassNetworkIntrusionDetection bypassNetworkIntrusionDetection;

  public BypassProxies bypassProxies;

  public AttemptTransmittedDataManipulation attemptTransmittedDataManipulation;

  public TransmittedDataManipulation transmittedDataManipulation;

  public C2Connexion c2Connexion;

  public ExchangeServerCollection exchangeServerCollection;

  public NetworkShareDiscovery networkShareDiscovery;

  public InternalNetworkResourcesInformation internalNetworkResourcesInformation;

  public RemoteSystemsConnection remoteSystemsConnection;

  public WebShell webShell;

  public Persistence persistence;

  public RemoteAccess remoteAccess;

  public RemoteCOMExecution remoteCOMExecution;

  public RemoteExecution remoteExecution;

  public C2Connected c2Connected;

  public Communicate communicate;

  public GenerateDomainNames generateDomainNames;

  public DataObfuscation dataObfuscation;

  public JunkData junkData;

  public AttemptProtocolImpersonation attemptProtocolImpersonation;

  public ProtocolImpersonation protocolImpersonation;

  public PacketCapture packetCapture;

  public TaintSharedContent taintSharedContent;

  public DataFromNetworkSharedDrive dataFromNetworkSharedDrive;

  public EncryptSensitiveInformation encryptSensitiveInformation;

  public ExecutionPrevention executionPrevention;

  public FilterNetworkTraffic filterNetworkTraffic;

  public LimitAccessToResourceOverNetwork limitAccessToResourceOverNetwork;

  public MultiFactorAuthentication multiFactorAuthentication;

  public NetworkIntrusionPrevention networkIntrusionPrevention;

  public NetworkSegmentation networkSegmentation;

  public SSLOrTLSInspection sSLOrTLSInspection;

  public Set<Router> router = new HashSet<>();

  public InternalNetwork(String name, boolean isEncryptSensitiveInformationEnabled,
      boolean isExecutionPreventionEnabled, boolean isFilterNetworkTrafficEnabled,
      boolean isLimitAccessToResourceOverNetworkEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isNetworkIntrusionPreventionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isSSLOrTLSInspectionEnabled) {
    super(name);
    assetClassName = "InternalNetwork";
    AttackStep.allAttackSteps.remove(obfuscateNetworkTraffic);
    obfuscateNetworkTraffic = new ObfuscateNetworkTraffic(name);
    AttackStep.allAttackSteps.remove(applicationLayerConnexion);
    applicationLayerConnexion = new ApplicationLayerConnexion(name);
    AttackStep.allAttackSteps.remove(attemptDataEncryptedForImpact);
    attemptDataEncryptedForImpact = new AttemptDataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataExfiltration);
    dataExfiltration = new DataExfiltration(name);
    AttackStep.allAttackSteps.remove(internalDefacement);
    internalDefacement = new InternalDefacement(name);
    AttackStep.allAttackSteps.remove(attemptExfiltrationOverC2Channel);
    attemptExfiltrationOverC2Channel = new AttemptExfiltrationOverC2Channel(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverC2Channel);
    exfiltrationOverC2Channel = new ExfiltrationOverC2Channel(name);
    if (firewallExists != null) {
      AttackStep.allAttackSteps.remove(firewallExists.disable);
    }
    Defense.allDefenses.remove(firewallExists);
    firewallExists = new FirewallExists(name);
    AttackStep.allAttackSteps.remove(bypassNetworkIntrusionDetection);
    bypassNetworkIntrusionDetection = new BypassNetworkIntrusionDetection(name);
    AttackStep.allAttackSteps.remove(bypassProxies);
    bypassProxies = new BypassProxies(name);
    AttackStep.allAttackSteps.remove(attemptTransmittedDataManipulation);
    attemptTransmittedDataManipulation = new AttemptTransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(transmittedDataManipulation);
    transmittedDataManipulation = new TransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(c2Connexion);
    c2Connexion = new C2Connexion(name);
    AttackStep.allAttackSteps.remove(exchangeServerCollection);
    exchangeServerCollection = new ExchangeServerCollection(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(internalNetworkResourcesInformation);
    internalNetworkResourcesInformation = new InternalNetworkResourcesInformation(name);
    AttackStep.allAttackSteps.remove(remoteSystemsConnection);
    remoteSystemsConnection = new RemoteSystemsConnection(name);
    AttackStep.allAttackSteps.remove(webShell);
    webShell = new WebShell(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(remoteAccess);
    remoteAccess = new RemoteAccess(name);
    AttackStep.allAttackSteps.remove(remoteCOMExecution);
    remoteCOMExecution = new RemoteCOMExecution(name);
    AttackStep.allAttackSteps.remove(remoteExecution);
    remoteExecution = new RemoteExecution(name);
    AttackStep.allAttackSteps.remove(c2Connected);
    c2Connected = new C2Connected(name);
    AttackStep.allAttackSteps.remove(communicate);
    communicate = new Communicate(name);
    AttackStep.allAttackSteps.remove(generateDomainNames);
    generateDomainNames = new GenerateDomainNames(name);
    AttackStep.allAttackSteps.remove(dataObfuscation);
    dataObfuscation = new DataObfuscation(name);
    AttackStep.allAttackSteps.remove(junkData);
    junkData = new JunkData(name);
    AttackStep.allAttackSteps.remove(attemptProtocolImpersonation);
    attemptProtocolImpersonation = new AttemptProtocolImpersonation(name);
    AttackStep.allAttackSteps.remove(protocolImpersonation);
    protocolImpersonation = new ProtocolImpersonation(name);
    AttackStep.allAttackSteps.remove(packetCapture);
    packetCapture = new PacketCapture(name);
    AttackStep.allAttackSteps.remove(taintSharedContent);
    taintSharedContent = new TaintSharedContent(name);
    AttackStep.allAttackSteps.remove(dataFromNetworkSharedDrive);
    dataFromNetworkSharedDrive = new DataFromNetworkSharedDrive(name);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, isEncryptSensitiveInformationEnabled);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, isExecutionPreventionEnabled);
    if (filterNetworkTraffic != null) {
      AttackStep.allAttackSteps.remove(filterNetworkTraffic.disable);
    }
    Defense.allDefenses.remove(filterNetworkTraffic);
    filterNetworkTraffic = new FilterNetworkTraffic(name, isFilterNetworkTrafficEnabled);
    if (limitAccessToResourceOverNetwork != null) {
      AttackStep.allAttackSteps.remove(limitAccessToResourceOverNetwork.disable);
    }
    Defense.allDefenses.remove(limitAccessToResourceOverNetwork);
    limitAccessToResourceOverNetwork = new LimitAccessToResourceOverNetwork(name, isLimitAccessToResourceOverNetworkEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (networkIntrusionPrevention != null) {
      AttackStep.allAttackSteps.remove(networkIntrusionPrevention.disable);
    }
    Defense.allDefenses.remove(networkIntrusionPrevention);
    networkIntrusionPrevention = new NetworkIntrusionPrevention(name, isNetworkIntrusionPreventionEnabled);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, isNetworkSegmentationEnabled);
    if (sSLOrTLSInspection != null) {
      AttackStep.allAttackSteps.remove(sSLOrTLSInspection.disable);
    }
    Defense.allDefenses.remove(sSLOrTLSInspection);
    sSLOrTLSInspection = new SSLOrTLSInspection(name, isSSLOrTLSInspectionEnabled);
  }

  public InternalNetwork(String name) {
    super(name);
    assetClassName = "InternalNetwork";
    AttackStep.allAttackSteps.remove(obfuscateNetworkTraffic);
    obfuscateNetworkTraffic = new ObfuscateNetworkTraffic(name);
    AttackStep.allAttackSteps.remove(applicationLayerConnexion);
    applicationLayerConnexion = new ApplicationLayerConnexion(name);
    AttackStep.allAttackSteps.remove(attemptDataEncryptedForImpact);
    attemptDataEncryptedForImpact = new AttemptDataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataExfiltration);
    dataExfiltration = new DataExfiltration(name);
    AttackStep.allAttackSteps.remove(internalDefacement);
    internalDefacement = new InternalDefacement(name);
    AttackStep.allAttackSteps.remove(attemptExfiltrationOverC2Channel);
    attemptExfiltrationOverC2Channel = new AttemptExfiltrationOverC2Channel(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverC2Channel);
    exfiltrationOverC2Channel = new ExfiltrationOverC2Channel(name);
    if (firewallExists != null) {
      AttackStep.allAttackSteps.remove(firewallExists.disable);
    }
    Defense.allDefenses.remove(firewallExists);
    firewallExists = new FirewallExists(name);
    AttackStep.allAttackSteps.remove(bypassNetworkIntrusionDetection);
    bypassNetworkIntrusionDetection = new BypassNetworkIntrusionDetection(name);
    AttackStep.allAttackSteps.remove(bypassProxies);
    bypassProxies = new BypassProxies(name);
    AttackStep.allAttackSteps.remove(attemptTransmittedDataManipulation);
    attemptTransmittedDataManipulation = new AttemptTransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(transmittedDataManipulation);
    transmittedDataManipulation = new TransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(c2Connexion);
    c2Connexion = new C2Connexion(name);
    AttackStep.allAttackSteps.remove(exchangeServerCollection);
    exchangeServerCollection = new ExchangeServerCollection(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(internalNetworkResourcesInformation);
    internalNetworkResourcesInformation = new InternalNetworkResourcesInformation(name);
    AttackStep.allAttackSteps.remove(remoteSystemsConnection);
    remoteSystemsConnection = new RemoteSystemsConnection(name);
    AttackStep.allAttackSteps.remove(webShell);
    webShell = new WebShell(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(remoteAccess);
    remoteAccess = new RemoteAccess(name);
    AttackStep.allAttackSteps.remove(remoteCOMExecution);
    remoteCOMExecution = new RemoteCOMExecution(name);
    AttackStep.allAttackSteps.remove(remoteExecution);
    remoteExecution = new RemoteExecution(name);
    AttackStep.allAttackSteps.remove(c2Connected);
    c2Connected = new C2Connected(name);
    AttackStep.allAttackSteps.remove(communicate);
    communicate = new Communicate(name);
    AttackStep.allAttackSteps.remove(generateDomainNames);
    generateDomainNames = new GenerateDomainNames(name);
    AttackStep.allAttackSteps.remove(dataObfuscation);
    dataObfuscation = new DataObfuscation(name);
    AttackStep.allAttackSteps.remove(junkData);
    junkData = new JunkData(name);
    AttackStep.allAttackSteps.remove(attemptProtocolImpersonation);
    attemptProtocolImpersonation = new AttemptProtocolImpersonation(name);
    AttackStep.allAttackSteps.remove(protocolImpersonation);
    protocolImpersonation = new ProtocolImpersonation(name);
    AttackStep.allAttackSteps.remove(packetCapture);
    packetCapture = new PacketCapture(name);
    AttackStep.allAttackSteps.remove(taintSharedContent);
    taintSharedContent = new TaintSharedContent(name);
    AttackStep.allAttackSteps.remove(dataFromNetworkSharedDrive);
    dataFromNetworkSharedDrive = new DataFromNetworkSharedDrive(name);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, false);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, false);
    if (filterNetworkTraffic != null) {
      AttackStep.allAttackSteps.remove(filterNetworkTraffic.disable);
    }
    Defense.allDefenses.remove(filterNetworkTraffic);
    filterNetworkTraffic = new FilterNetworkTraffic(name, false);
    if (limitAccessToResourceOverNetwork != null) {
      AttackStep.allAttackSteps.remove(limitAccessToResourceOverNetwork.disable);
    }
    Defense.allDefenses.remove(limitAccessToResourceOverNetwork);
    limitAccessToResourceOverNetwork = new LimitAccessToResourceOverNetwork(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (networkIntrusionPrevention != null) {
      AttackStep.allAttackSteps.remove(networkIntrusionPrevention.disable);
    }
    Defense.allDefenses.remove(networkIntrusionPrevention);
    networkIntrusionPrevention = new NetworkIntrusionPrevention(name, false);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, false);
    if (sSLOrTLSInspection != null) {
      AttackStep.allAttackSteps.remove(sSLOrTLSInspection.disable);
    }
    Defense.allDefenses.remove(sSLOrTLSInspection);
    sSLOrTLSInspection = new SSLOrTLSInspection(name, false);
  }

  public InternalNetwork(boolean isEncryptSensitiveInformationEnabled,
      boolean isExecutionPreventionEnabled, boolean isFilterNetworkTrafficEnabled,
      boolean isLimitAccessToResourceOverNetworkEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isNetworkIntrusionPreventionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isSSLOrTLSInspectionEnabled) {
    this("Anonymous", isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isFilterNetworkTrafficEnabled, isLimitAccessToResourceOverNetworkEnabled, isMultiFactorAuthenticationEnabled, isNetworkIntrusionPreventionEnabled, isNetworkSegmentationEnabled, isSSLOrTLSInspectionEnabled);
  }

  public InternalNetwork() {
    this("Anonymous");
  }

  public void addRouter(Router router) {
    this.router.add(router);
    router.internalNetwork.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("router")) {
      return Router.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("router")) {
      assets.addAll(router);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(router);
    return assets;
  }

  public class ObfuscateNetworkTraffic extends AttackStepMin {
    private Set<AttackStep> _cacheParentObfuscateNetworkTraffic;

    public ObfuscateNetworkTraffic(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentObfuscateNetworkTraffic == null) {
        _cacheParentObfuscateNetworkTraffic = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentObfuscateNetworkTraffic.add(_2.domainFronting);
            }
          }
        }
        _cacheParentObfuscateNetworkTraffic.add(sSLOrTLSInspection.disable);
      }
      for (AttackStep attackStep : _cacheParentObfuscateNetworkTraffic) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.obfuscateNetworkTraffic");
    }
  }

  public class ApplicationLayerConnexion extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenApplicationLayerConnexion;

    private Set<AttackStep> _cacheParentApplicationLayerConnexion;

    public ApplicationLayerConnexion(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenApplicationLayerConnexion == null) {
        _cacheChildrenApplicationLayerConnexion = new HashSet<>();
        _cacheChildrenApplicationLayerConnexion.add(c2Connexion);
        _cacheChildrenApplicationLayerConnexion.add(bypassNetworkIntrusionDetection);
        for (Router _0 : router) {
          for (ExternalNetwork _1 : _0.externalNetwork) {
            _cacheChildrenApplicationLayerConnexion.add(_1.bypassNetworkIntrusionDetection);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenApplicationLayerConnexion) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationLayerConnexion == null) {
        _cacheParentApplicationLayerConnexion = new HashSet<>();
        _cacheParentApplicationLayerConnexion.add(networkIntrusionPrevention.disable);
        for (Router _2 : router) {
          for (Computer _3 : _2.computer) {
            _cacheParentApplicationLayerConnexion.add(_3.infectedComputer);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentApplicationLayerConnexion) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.applicationLayerConnexion");
    }
  }

  public class AttemptDataEncryptedForImpact extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDataEncryptedForImpact;

    private Set<AttackStep> _cacheParentAttemptDataEncryptedForImpact;

    public AttemptDataEncryptedForImpact(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDataEncryptedForImpact == null) {
        _cacheChildrenAttemptDataEncryptedForImpact = new HashSet<>();
        _cacheChildrenAttemptDataEncryptedForImpact.add(dataEncryptedForImpact);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDataEncryptedForImpact) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDataEncryptedForImpact == null) {
        _cacheParentAttemptDataEncryptedForImpact = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            _cacheParentAttemptDataEncryptedForImpact.add(_1.infectedComputer);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptDataEncryptedForImpact) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.attemptDataEncryptedForImpact");
    }
  }

  public class DataEncryptedForImpact extends AttackStepMax {
    private Set<AttackStep> _cacheParentDataEncryptedForImpact;

    public DataEncryptedForImpact(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataEncryptedForImpact == null) {
        _cacheParentDataEncryptedForImpact = new HashSet<>();
        _cacheParentDataEncryptedForImpact.add(attemptDataEncryptedForImpact);
        _cacheParentDataEncryptedForImpact.add(c2Connected);
      }
      for (AttackStep attackStep : _cacheParentDataEncryptedForImpact) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.dataEncryptedForImpact");
    }
  }

  public class DataExfiltration extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDataExfiltration;

    private Set<AttackStep> _cacheParentDataExfiltration;

    public DataExfiltration(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataExfiltration == null) {
        _cacheChildrenDataExfiltration = new HashSet<>();
        for (Router _0 : router) {
          for (ExternalNetwork _1 : _0.externalNetwork) {
            _cacheChildrenDataExfiltration.add(_1.dataExfiltration);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDataExfiltration) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataExfiltration == null) {
        _cacheParentDataExfiltration = new HashSet<>();
        for (Router _2 : router) {
          for (Computer _3 : _2.computer) {
            for (OS _4 : _3.os) {
              _cacheParentDataExfiltration.add(_4.exfiltrationOverOtherNetworkMedium);
            }
          }
        }
        for (Router _5 : router) {
          for (Computer _6 : _5.computer) {
            for (OS _7 : _6.os) {
              _cacheParentDataExfiltration.add(_7.exfiltrationOverBluetooth);
            }
          }
        }
        for (Router _8 : router) {
          for (Computer _9 : _8.computer) {
            for (OS _a : _9.os) {
              _cacheParentDataExfiltration.add(_a.dataSizedTransfer);
            }
          }
        }
        for (Router _b : router) {
          for (Computer _c : _b.computer) {
            for (OS _d : _c.os) {
              _cacheParentDataExfiltration.add(_d.scheduledExfiltration);
            }
          }
        }
        for (Router _e : router) {
          for (Computer _f : _e.computer) {
            for (OS _10 : _f.os) {
              _cacheParentDataExfiltration.add(_10.exfiltrationOverAsymmetricEncryptedNonC2Protocol);
            }
          }
        }
        for (Router _11 : router) {
          for (Computer _12 : _11.computer) {
            for (OS _13 : _12.os) {
              _cacheParentDataExfiltration.add(_13.exfiltrationOverSymmetricEncryptedNonC2Protocol);
            }
          }
        }
        for (Router _14 : router) {
          for (Computer _15 : _14.computer) {
            for (OS _16 : _15.os) {
              _cacheParentDataExfiltration.add(_16.exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol);
            }
          }
        }
        _cacheParentDataExfiltration.add(exfiltrationOverC2Channel);
        _cacheParentDataExfiltration.add(networkIntrusionPrevention.disable);
        for (Router _17 : router) {
          if (_17.firewall != null) {
            _cacheParentDataExfiltration.add(_17.firewall.bypassFirewall);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDataExfiltration) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.dataExfiltration");
    }
  }

  public class InternalDefacement extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenInternalDefacement;

    private Set<AttackStep> _cacheParentInternalDefacement;

    public InternalDefacement(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInternalDefacement == null) {
        _cacheChildrenInternalDefacement = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                for (Browser _4 : _3.browser) {
                  _cacheChildrenInternalDefacement.add(_4.driveByCompromise);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenInternalDefacement) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInternalDefacement == null) {
        _cacheParentInternalDefacement = new HashSet<>();
        for (Router _5 : router) {
          for (Computer _6 : _5.computer) {
            for (OS _7 : _6.os) {
              _cacheParentInternalDefacement.add(_7.defacement);
            }
          }
        }
        for (Router _8 : router) {
          for (Computer _9 : _8.computer) {
            for (OS _a : _9.os) {
              _cacheParentInternalDefacement.add(_a.dataBackup.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentInternalDefacement) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.internalDefacement");
    }
  }

  public class AttemptExfiltrationOverC2Channel extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExfiltrationOverC2Channel;

    private Set<AttackStep> _cacheParentAttemptExfiltrationOverC2Channel;

    public AttemptExfiltrationOverC2Channel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExfiltrationOverC2Channel == null) {
        _cacheChildrenAttemptExfiltrationOverC2Channel = new HashSet<>();
        _cacheChildrenAttemptExfiltrationOverC2Channel.add(exfiltrationOverC2Channel);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExfiltrationOverC2Channel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExfiltrationOverC2Channel == null) {
        _cacheParentAttemptExfiltrationOverC2Channel = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentAttemptExfiltrationOverC2Channel.add(_2.sensitiveDataCollected);
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              _cacheParentAttemptExfiltrationOverC2Channel.add(_5.dataCollected);
            }
          }
        }
        for (Router _6 : router) {
          for (Computer _7 : _6.computer) {
            for (OS _8 : _7.os) {
              _cacheParentAttemptExfiltrationOverC2Channel.add(_8.dataEncrypted);
            }
          }
        }
        for (Router _9 : router) {
          for (Computer _a : _9.computer) {
            for (OS _b : _a.os) {
              _cacheParentAttemptExfiltrationOverC2Channel.add(_b.localDataStaging);
            }
          }
        }
        for (Router _c : router) {
          for (Computer _d : _c.computer) {
            for (OS _e : _d.os) {
              _cacheParentAttemptExfiltrationOverC2Channel.add(_e.remoteDataStaging);
            }
          }
        }
        for (Router _f : router) {
          for (Computer _10 : _f.computer) {
            for (OS _11 : _10.os) {
              _cacheParentAttemptExfiltrationOverC2Channel.add(_11.dataCompressed);
            }
          }
        }
        for (Router _12 : router) {
          for (Computer _13 : _12.computer) {
            for (OS _14 : _13.os) {
              _cacheParentAttemptExfiltrationOverC2Channel.add(_14.automatedExfiltration);
            }
          }
        }
        for (Router _15 : router) {
          for (Computer _16 : _15.computer) {
            for (OS _17 : _16.os) {
              if (_17 instanceof Windows) {
                _cacheParentAttemptExfiltrationOverC2Channel.add(((asset.Windows) _17).remoteDesktopProtocol);
              }
            }
          }
        }
        _cacheParentAttemptExfiltrationOverC2Channel.add(c2Connected);
      }
      for (AttackStep attackStep : _cacheParentAttemptExfiltrationOverC2Channel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.attemptExfiltrationOverC2Channel");
    }
  }

  public class ExfiltrationOverC2Channel extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExfiltrationOverC2Channel;

    private Set<AttackStep> _cacheParentExfiltrationOverC2Channel;

    public ExfiltrationOverC2Channel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverC2Channel == null) {
        _cacheChildrenExfiltrationOverC2Channel = new HashSet<>();
        _cacheChildrenExfiltrationOverC2Channel.add(dataExfiltration);
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverC2Channel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverC2Channel == null) {
        _cacheParentExfiltrationOverC2Channel = new HashSet<>();
        _cacheParentExfiltrationOverC2Channel.add(attemptExfiltrationOverC2Channel);
        _cacheParentExfiltrationOverC2Channel.add(networkIntrusionPrevention.disable);
        for (Router _0 : router) {
          for (ExternalNetwork _1 : _0.externalNetwork) {
            _cacheParentExfiltrationOverC2Channel.add(_1.networkIntrusionPrevention.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverC2Channel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.exfiltrationOverC2Channel");
    }
  }

  public class FirewallExists extends Defense {
    public FirewallExists(String name) {
      super(name);
      disable = new Disable(name);
    }

    @Override
    public boolean isEnabled() {
      for (Router _0 : router) {
        if (_0.firewall != null) {
          return false;
        }
      }
      return true;
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenFirewallExists;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenFirewallExists == null) {
          _cacheChildrenFirewallExists = new HashSet<>();
          for (Router _1 : router) {
            if (_1.firewall != null) {
              _cacheChildrenFirewallExists.add(_1.firewall.bypassFirewall);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenFirewallExists) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.firewallExists";
      }
    }
  }

  public class BypassNetworkIntrusionDetection extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassNetworkIntrusionDetection;

    public BypassNetworkIntrusionDetection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassNetworkIntrusionDetection == null) {
        _cacheParentBypassNetworkIntrusionDetection = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                if (_3 instanceof CloudService) {
                  _cacheParentBypassNetworkIntrusionDetection.add(((asset.CloudService) _3).cloudAccounts);
                }
              }
            }
          }
        }
        for (Router _4 : router) {
          for (Computer _5 : _4.computer) {
            for (OS _6 : _5.os) {
              for (Service _7 : _6.service) {
                if (_7 instanceof CloudService) {
                  _cacheParentBypassNetworkIntrusionDetection.add(((asset.CloudService) _7).createSnapshot);
                }
              }
            }
          }
        }
        for (Router _8 : router) {
          for (Computer _9 : _8.computer) {
            for (OS _a : _9.os) {
              for (Service _b : _a.service) {
                if (_b instanceof CloudService) {
                  _cacheParentBypassNetworkIntrusionDetection.add(((asset.CloudService) _b).deleteCloudInstance);
                }
              }
            }
          }
        }
        for (Router _c : router) {
          for (Computer _d : _c.computer) {
            for (OS _e : _d.os) {
              for (Service _f : _e.service) {
                if (_f instanceof CloudService) {
                  _cacheParentBypassNetworkIntrusionDetection.add(((asset.CloudService) _f).revertCloudInstance);
                }
              }
            }
          }
        }
        for (Router _10 : router) {
          for (Computer _11 : _10.computer) {
            for (OS _12 : _11.os) {
              _cacheParentBypassNetworkIntrusionDetection.add(_12.steganography);
            }
          }
        }
        for (Router _13 : router) {
          for (Computer _14 : _13.computer) {
            for (OS _15 : _14.os) {
              _cacheParentBypassNetworkIntrusionDetection.add(_15.defaultAccounts);
            }
          }
        }
        for (Router _16 : router) {
          for (Computer _17 : _16.computer) {
            for (OS _18 : _17.os) {
              _cacheParentBypassNetworkIntrusionDetection.add(_18.domainAccounts);
            }
          }
        }
        for (Router _19 : router) {
          for (Computer _1a : _19.computer) {
            for (OS _1b : _1a.os) {
              _cacheParentBypassNetworkIntrusionDetection.add(_1b.localAccounts);
            }
          }
        }
        for (Router _1c : router) {
          for (Computer _1d : _1c.computer) {
            for (OS _1e : _1d.os) {
              if (_1e instanceof Windows) {
                _cacheParentBypassNetworkIntrusionDetection.add(((asset.Windows) _1e).deobfuscateOrDecodeFilesOrInformation);
              }
            }
          }
        }
        _cacheParentBypassNetworkIntrusionDetection.add(applicationLayerConnexion);
        _cacheParentBypassNetworkIntrusionDetection.add(junkData);
      }
      for (AttackStep attackStep : _cacheParentBypassNetworkIntrusionDetection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.bypassNetworkIntrusionDetection");
    }
  }

  public class BypassProxies extends AttackStepMin {
    public BypassProxies(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.bypassProxies");
    }
  }

  public class AttemptTransmittedDataManipulation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptTransmittedDataManipulation;

    private Set<AttackStep> _cacheParentAttemptTransmittedDataManipulation;

    public AttemptTransmittedDataManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptTransmittedDataManipulation == null) {
        _cacheChildrenAttemptTransmittedDataManipulation = new HashSet<>();
        _cacheChildrenAttemptTransmittedDataManipulation.add(transmittedDataManipulation);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptTransmittedDataManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTransmittedDataManipulation == null) {
        _cacheParentAttemptTransmittedDataManipulation = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentAttemptTransmittedDataManipulation.add(_2.dataManipulation);
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              _cacheParentAttemptTransmittedDataManipulation.add(_5.manInTheMiddle);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptTransmittedDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.attemptTransmittedDataManipulation");
    }
  }

  public class TransmittedDataManipulation extends AttackStepMax {
    private Set<AttackStep> _cacheParentTransmittedDataManipulation;

    public TransmittedDataManipulation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTransmittedDataManipulation == null) {
        _cacheParentTransmittedDataManipulation = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (UserAccount _3 : _2.userAccount) {
                _cacheParentTransmittedDataManipulation.add(_3.userRights);
              }
            }
          }
        }
        _cacheParentTransmittedDataManipulation.add(attemptTransmittedDataManipulation);
        _cacheParentTransmittedDataManipulation.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentTransmittedDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.transmittedDataManipulation");
    }
  }

  public class C2Connexion extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenC2Connexion;

    private Set<AttackStep> _cacheParentC2Connexion;

    public C2Connexion(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenC2Connexion == null) {
        _cacheChildrenC2Connexion = new HashSet<>();
        _cacheChildrenC2Connexion.add(c2Connected);
      }
      for (AttackStep attackStep : _cacheChildrenC2Connexion) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentC2Connexion == null) {
        _cacheParentC2Connexion = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                _cacheParentC2Connexion.add(_3.remoteAccessSoftware);
              }
            }
          }
        }
        for (Router _4 : router) {
          for (Computer _5 : _4.computer) {
            for (OS _6 : _5.os) {
              _cacheParentC2Connexion.add(_6.webProtocols);
            }
          }
        }
        for (Router _7 : router) {
          for (Computer _8 : _7.computer) {
            for (OS _9 : _8.os) {
              _cacheParentC2Connexion.add(_9.fileTransferProtocols);
            }
          }
        }
        for (Router _a : router) {
          for (Computer _b : _a.computer) {
            for (OS _c : _b.os) {
              _cacheParentC2Connexion.add(_c.mailProtocols);
            }
          }
        }
        for (Router _d : router) {
          for (Computer _e : _d.computer) {
            for (OS _f : _e.os) {
              _cacheParentC2Connexion.add(_f.dNS);
            }
          }
        }
        _cacheParentC2Connexion.add(applicationLayerConnexion);
        _cacheParentC2Connexion.add(networkIntrusionPrevention.disable);
        for (Router _10 : router) {
          if (_10.firewall != null) {
            _cacheParentC2Connexion.add(_10.firewall.bypassFirewall);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentC2Connexion) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.c2Connexion");
    }
  }

  public class ExchangeServerCollection extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExchangeServerCollection;

    private Set<AttackStep> _cacheParentExchangeServerCollection;

    public ExchangeServerCollection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExchangeServerCollection == null) {
        _cacheChildrenExchangeServerCollection = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheChildrenExchangeServerCollection.add(_2.dataCollected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExchangeServerCollection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExchangeServerCollection == null) {
        _cacheParentExchangeServerCollection = new HashSet<>();
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              for (UserAccount _6 : _5.userAccount) {
                _cacheParentExchangeServerCollection.add(_6.userCredentials);
              }
            }
          }
        }
        _cacheParentExchangeServerCollection.add(encryptSensitiveInformation.disable);
        _cacheParentExchangeServerCollection.add(multiFactorAuthentication.disable);
      }
      for (AttackStep attackStep : _cacheParentExchangeServerCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.exchangeServerCollection");
    }
  }

  public class NetworkShareDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentNetworkShareDiscovery;

    public NetworkShareDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkShareDiscovery == null) {
        _cacheParentNetworkShareDiscovery = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              if (_2 instanceof Windows) {
                _cacheParentNetworkShareDiscovery.add(((asset.Windows) _2).networkShareDiscovery);
              }
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              if (_5 instanceof MacOS) {
                _cacheParentNetworkShareDiscovery.add(((asset.MacOS) _5).networkShareDiscovery);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentNetworkShareDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.networkShareDiscovery");
    }
  }

  public class InternalNetworkResourcesInformation extends AttackStepMin {
    private Set<AttackStep> _cacheParentInternalNetworkResourcesInformation;

    public InternalNetworkResourcesInformation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInternalNetworkResourcesInformation == null) {
        _cacheParentInternalNetworkResourcesInformation = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                for (Browser _4 : _3.browser) {
                  _cacheParentInternalNetworkResourcesInformation.add(_4.browserBookmarkDiscovery);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentInternalNetworkResourcesInformation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.internalNetworkResourcesInformation");
    }
  }

  public class RemoteSystemsConnection extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenRemoteSystemsConnection;

    private Set<AttackStep> _cacheParentRemoteSystemsConnection;

    public RemoteSystemsConnection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRemoteSystemsConnection == null) {
        _cacheChildrenRemoteSystemsConnection = new HashSet<>();
        for (Router _0 : router) {
          for (InternalNetwork _1 : _0.internalNetwork) {
            _cacheChildrenRemoteSystemsConnection.add(_1.dataFromNetworkSharedDrive);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenRemoteSystemsConnection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteSystemsConnection == null) {
        _cacheParentRemoteSystemsConnection = new HashSet<>();
        for (Router _2 : router) {
          for (Computer _3 : _2.computer) {
            for (OS _4 : _3.os) {
              if (_4 instanceof Windows) {
                _cacheParentRemoteSystemsConnection.add(((asset.Windows) _4).passTheHash);
              }
            }
          }
        }
        for (Router _5 : router) {
          for (Computer _6 : _5.computer) {
            for (OS _7 : _6.os) {
              if (_7 instanceof Windows) {
                _cacheParentRemoteSystemsConnection.add(((asset.Windows) _7).powerShell);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteSystemsConnection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.remoteSystemsConnection");
    }
  }

  public class WebShell extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenWebShell;

    private Set<AttackStep> _cacheParentWebShell;

    public WebShell(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWebShell == null) {
        _cacheChildrenWebShell = new HashSet<>();
        _cacheChildrenWebShell.add(persistence);
      }
      for (AttackStep attackStep : _cacheChildrenWebShell) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWebShell == null) {
        _cacheParentWebShell = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentWebShell.add(_2.serverSoftwareComponent);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentWebShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.webShell");
    }
  }

  public class Persistence extends AttackStepMin {
    private Set<AttackStep> _cacheParentPersistence;

    public Persistence(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPersistence == null) {
        _cacheParentPersistence = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                _cacheParentPersistence.add(_3.externalRemoteServices);
              }
            }
          }
        }
        for (Router _4 : router) {
          for (Computer _5 : _4.computer) {
            for (OS _6 : _5.os) {
              if (_6 instanceof Windows) {
                _cacheParentPersistence.add(((asset.Windows) _6).networkLogonScripts);
              }
            }
          }
        }
        _cacheParentPersistence.add(webShell);
      }
      for (AttackStep attackStep : _cacheParentPersistence) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.persistence");
    }
  }

  public class RemoteAccess extends AttackStepMin {
    private Set<AttackStep> _cacheParentRemoteAccess;

    public RemoteAccess(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteAccess == null) {
        _cacheParentRemoteAccess = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                _cacheParentRemoteAccess.add(_3.externalRemoteServices);
              }
            }
          }
        }
        for (Router _4 : router) {
          for (Computer _5 : _4.computer) {
            for (OS _6 : _5.os) {
              for (Service _7 : _6.service) {
                _cacheParentRemoteAccess.add(_7.updateSoftware.disable);
              }
            }
          }
        }
        for (Router _8 : router) {
          for (Computer _9 : _8.computer) {
            for (OS _a : _9.os) {
              _cacheParentRemoteAccess.add(_a.executeCode);
            }
          }
        }
        for (Router _b : router) {
          for (Computer _c : _b.computer) {
            for (OS _d : _c.os) {
              if (_d instanceof Windows) {
                _cacheParentRemoteAccess.add(((asset.Windows) _d).passTheTicket);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteAccess) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.remoteAccess");
    }
  }

  public class RemoteCOMExecution extends AttackStepMin {
    private Set<AttackStep> _cacheParentRemoteCOMExecution;

    public RemoteCOMExecution(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteCOMExecution == null) {
        _cacheParentRemoteCOMExecution = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              if (_2 instanceof Windows) {
                _cacheParentRemoteCOMExecution.add(((asset.Windows) _2).distributedComponentObjectModel);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteCOMExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.remoteCOMExecution");
    }
  }

  public class RemoteExecution extends AttackStepMin {
    private Set<AttackStep> _cacheParentRemoteExecution;

    public RemoteExecution(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteExecution == null) {
        _cacheParentRemoteExecution = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              if (_2 instanceof Windows) {
                _cacheParentRemoteExecution.add(((asset.Windows) _2).remoteScheduledTask);
              }
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              if (_5 instanceof Windows) {
                _cacheParentRemoteExecution.add(((asset.Windows) _5).windowsRemoteManagement);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.remoteExecution");
    }
  }

  public class C2Connected extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenC2Connected;

    private Set<AttackStep> _cacheParentC2Connected;

    public C2Connected(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenC2Connected == null) {
        _cacheChildrenC2Connected = new HashSet<>();
        _cacheChildrenC2Connected.add(communicate);
        _cacheChildrenC2Connected.add(dataObfuscation);
        _cacheChildrenC2Connected.add(packetCapture);
        _cacheChildrenC2Connected.add(dataEncryptedForImpact);
        _cacheChildrenC2Connected.add(attemptExfiltrationOverC2Channel);
      }
      for (AttackStep attackStep : _cacheChildrenC2Connected) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentC2Connected == null) {
        _cacheParentC2Connected = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                if (_3 instanceof CloudService) {
                  _cacheParentC2Connected.add(((asset.CloudService) _3).disableOrModifyCloudFirewall);
                }
              }
            }
          }
        }
        for (Router _4 : router) {
          for (Computer _5 : _4.computer) {
            for (OS _6 : _5.os) {
              _cacheParentC2Connected.add(_6.encryptedChannel);
            }
          }
        }
        for (Router _7 : router) {
          for (Computer _8 : _7.computer) {
            for (OS _9 : _8.os) {
              _cacheParentC2Connected.add(_9.internalProxy);
            }
          }
        }
        for (Router _a : router) {
          for (Computer _b : _a.computer) {
            for (OS _c : _b.os) {
              _cacheParentC2Connected.add(_c.externalProxy);
            }
          }
        }
        for (Router _d : router) {
          for (Computer _e : _d.computer) {
            for (OS _f : _e.os) {
              _cacheParentC2Connected.add(_f.multiHopProxy);
            }
          }
        }
        for (Router _10 : router) {
          for (Computer _11 : _10.computer) {
            for (OS _12 : _11.os) {
              _cacheParentC2Connected.add(_12.multiStageChannels);
            }
          }
        }
        for (Router _13 : router) {
          for (Computer _14 : _13.computer) {
            for (OS _15 : _14.os) {
              _cacheParentC2Connected.add(_15.disableOrModifySystemFirewall);
            }
          }
        }
        for (Router _16 : router) {
          for (Computer _17 : _16.computer) {
            for (OS _18 : _17.os) {
              _cacheParentC2Connected.add(_18.nonApplicationLayerProtocol);
            }
          }
        }
        for (Router _19 : router) {
          for (Computer _1a : _19.computer) {
            for (OS _1b : _1a.os) {
              _cacheParentC2Connected.add(_1b.nonStandardPort);
            }
          }
        }
        for (Router _1c : router) {
          for (Computer _1d : _1c.computer) {
            for (OS _1e : _1d.os) {
              if (_1e instanceof Linux) {
                _cacheParentC2Connected.add(((asset.Linux) _1e).sSH);
              }
            }
          }
        }
        for (Router _1f : router) {
          for (Computer _20 : _1f.computer) {
            for (OS _21 : _20.os) {
              if (_21 instanceof MacOS) {
                _cacheParentC2Connected.add(((asset.MacOS) _21).sSH);
              }
            }
          }
        }
        _cacheParentC2Connected.add(c2Connexion);
        for (Router _22 : router) {
          for (ExternalNetwork _23 : _22.externalNetwork) {
            _cacheParentC2Connected.add(_23.deadDropResolver);
          }
        }
        for (Router _24 : router) {
          for (ExternalNetwork _25 : _24.externalNetwork) {
            _cacheParentC2Connected.add(_25.bidirectionaCommunication);
          }
        }
        for (Router _26 : router) {
          for (ExternalNetwork _27 : _26.externalNetwork) {
            _cacheParentC2Connected.add(_27.oneWayCommunication);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentC2Connected) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.c2Connected");
    }
  }

  public class Communicate extends AttackStepMin {
    private Set<AttackStep> _cacheParentCommunicate;

    public Communicate(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCommunicate == null) {
        _cacheParentCommunicate = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentCommunicate.add(_2.domainGenerationAlgorithms);
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              _cacheParentCommunicate.add(_5.standardEncoding);
            }
          }
        }
        for (Router _6 : router) {
          for (Computer _7 : _6.computer) {
            for (OS _8 : _7.os) {
              _cacheParentCommunicate.add(_8.nonStandardEncoding);
            }
          }
        }
        for (Router _9 : router) {
          for (Computer _a : _9.computer) {
            for (OS _b : _a.os) {
              _cacheParentCommunicate.add(_b.fallbackChannels);
            }
          }
        }
        _cacheParentCommunicate.add(c2Connected);
        _cacheParentCommunicate.add(protocolImpersonation);
      }
      for (AttackStep attackStep : _cacheParentCommunicate) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.communicate");
    }
  }

  public class GenerateDomainNames extends AttackStepMin {
    private Set<AttackStep> _cacheParentGenerateDomainNames;

    public GenerateDomainNames(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGenerateDomainNames == null) {
        _cacheParentGenerateDomainNames = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentGenerateDomainNames.add(_2.domainGenerationAlgorithms);
            }
          }
        }
        _cacheParentGenerateDomainNames.add(networkIntrusionPrevention.disable);
        for (Router _3 : router) {
          for (ExternalNetwork _4 : _3.externalNetwork) {
            _cacheParentGenerateDomainNames.add(_4.networkIntrusionPrevention.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentGenerateDomainNames) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.generateDomainNames");
    }
  }

  public class DataObfuscation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataObfuscation;

    private Set<AttackStep> _cacheParentDataObfuscation;

    public DataObfuscation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataObfuscation == null) {
        _cacheChildrenDataObfuscation = new HashSet<>();
        _cacheChildrenDataObfuscation.add(junkData);
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheChildrenDataObfuscation.add(_2.steganography);
            }
          }
        }
        _cacheChildrenDataObfuscation.add(attemptProtocolImpersonation);
      }
      for (AttackStep attackStep : _cacheChildrenDataObfuscation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataObfuscation == null) {
        _cacheParentDataObfuscation = new HashSet<>();
        _cacheParentDataObfuscation.add(c2Connected);
        for (Router _3 : router) {
          for (ExternalNetwork _4 : _3.externalNetwork) {
            _cacheParentDataObfuscation.add(_4.networkIntrusionPrevention.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDataObfuscation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.dataObfuscation");
    }
  }

  public class JunkData extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenJunkData;

    private Set<AttackStep> _cacheParentJunkData;

    public JunkData(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenJunkData == null) {
        _cacheChildrenJunkData = new HashSet<>();
        _cacheChildrenJunkData.add(bypassNetworkIntrusionDetection);
      }
      for (AttackStep attackStep : _cacheChildrenJunkData) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentJunkData == null) {
        _cacheParentJunkData = new HashSet<>();
        _cacheParentJunkData.add(dataObfuscation);
        _cacheParentJunkData.add(networkIntrusionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentJunkData) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.junkData");
    }
  }

  public class AttemptProtocolImpersonation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptProtocolImpersonation;

    private Set<AttackStep> _cacheParentAttemptProtocolImpersonation;

    public AttemptProtocolImpersonation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptProtocolImpersonation == null) {
        _cacheChildrenAttemptProtocolImpersonation = new HashSet<>();
        _cacheChildrenAttemptProtocolImpersonation.add(protocolImpersonation);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptProtocolImpersonation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptProtocolImpersonation == null) {
        _cacheParentAttemptProtocolImpersonation = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentAttemptProtocolImpersonation.add(_2.protocolTunneling);
            }
          }
        }
        _cacheParentAttemptProtocolImpersonation.add(dataObfuscation);
      }
      for (AttackStep attackStep : _cacheParentAttemptProtocolImpersonation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.attemptProtocolImpersonation");
    }
  }

  public class ProtocolImpersonation extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenProtocolImpersonation;

    private Set<AttackStep> _cacheParentProtocolImpersonation;

    public ProtocolImpersonation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenProtocolImpersonation == null) {
        _cacheChildrenProtocolImpersonation = new HashSet<>();
        _cacheChildrenProtocolImpersonation.add(communicate);
      }
      for (AttackStep attackStep : _cacheChildrenProtocolImpersonation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProtocolImpersonation == null) {
        _cacheParentProtocolImpersonation = new HashSet<>();
        _cacheParentProtocolImpersonation.add(attemptProtocolImpersonation);
        _cacheParentProtocolImpersonation.add(networkIntrusionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentProtocolImpersonation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.protocolImpersonation");
    }
  }

  public class PacketCapture extends AttackStepMin {
    private Set<AttackStep> _cacheParentPacketCapture;

    public PacketCapture(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPacketCapture == null) {
        _cacheParentPacketCapture = new HashSet<>();
        _cacheParentPacketCapture.add(c2Connected);
      }
      for (AttackStep attackStep : _cacheParentPacketCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.packetCapture");
    }
  }

  public class TaintSharedContent extends AttackStepMax {
    private Set<AttackStep> _cacheParentTaintSharedContent;

    public TaintSharedContent(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTaintSharedContent == null) {
        _cacheParentTaintSharedContent = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentTaintSharedContent.add(_2.restrictFileAndDirectoryPermissions.disable);
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              if (_5 instanceof Windows) {
                _cacheParentTaintSharedContent.add(((asset.Windows) _5).attemptTaintSharedContent);
              }
            }
          }
        }
        for (Router _6 : router) {
          for (Computer _7 : _6.computer) {
            for (OS _8 : _7.os) {
              if (_8 instanceof Windows) {
                _cacheParentTaintSharedContent.add(((asset.Windows) _8).executionPrevention.disable);
              }
            }
          }
        }
        for (Router _9 : router) {
          for (Computer _a : _9.computer) {
            for (OS _b : _a.os) {
              if (_b instanceof Windows) {
                _cacheParentTaintSharedContent.add(((asset.Windows) _b).exploitProtection.disable);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentTaintSharedContent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.taintSharedContent");
    }
  }

  public class DataFromNetworkSharedDrive extends AttackStepMin {
    private Set<AttackStep> _cacheParentDataFromNetworkSharedDrive;

    public DataFromNetworkSharedDrive(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataFromNetworkSharedDrive == null) {
        _cacheParentDataFromNetworkSharedDrive = new HashSet<>();
        for (Router _0 : router) {
          for (InternalNetwork _1 : _0.internalNetwork) {
            _cacheParentDataFromNetworkSharedDrive.add(_1.remoteSystemsConnection);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDataFromNetworkSharedDrive) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("InternalNetwork.dataFromNetworkSharedDrive");
    }
  }

  public class EncryptSensitiveInformation extends Defense {
    public EncryptSensitiveInformation(String name) {
      this(name, false);
    }

    public EncryptSensitiveInformation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenEncryptSensitiveInformation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenEncryptSensitiveInformation == null) {
          _cacheChildrenEncryptSensitiveInformation = new HashSet<>();
          _cacheChildrenEncryptSensitiveInformation.add(transmittedDataManipulation);
          _cacheChildrenEncryptSensitiveInformation.add(exchangeServerCollection);
        }
        for (AttackStep attackStep : _cacheChildrenEncryptSensitiveInformation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.encryptSensitiveInformation";
      }
    }
  }

  public class ExecutionPrevention extends Defense {
    public ExecutionPrevention(String name) {
      this(name, false);
    }

    public ExecutionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenExecutionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenExecutionPrevention == null) {
          _cacheChildrenExecutionPrevention = new HashSet<>();
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenExecutionPrevention.add(_2.networkServiceScan);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenExecutionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.executionPrevention";
      }
    }
  }

  public class FilterNetworkTraffic extends Defense {
    public FilterNetworkTraffic(String name) {
      this(name, false);
    }

    public FilterNetworkTraffic(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenFilterNetworkTraffic;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenFilterNetworkTraffic == null) {
          _cacheChildrenFilterNetworkTraffic = new HashSet<>();
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenFilterNetworkTraffic.add(_2.nonApplicationLayerProtocol);
              }
            }
          }
          for (Router _3 : router) {
            for (Computer _4 : _3.computer) {
              for (OS _5 : _4.os) {
                _cacheChildrenFilterNetworkTraffic.add(_5.directNetworkFlood);
              }
            }
          }
          for (Router _6 : router) {
            for (Computer _7 : _6.computer) {
              for (OS _8 : _7.os) {
                _cacheChildrenFilterNetworkTraffic.add(_8.endpointDenialOfService);
              }
            }
          }
          for (Router _9 : router) {
            for (Computer _a : _9.computer) {
              for (OS _b : _a.os) {
                _cacheChildrenFilterNetworkTraffic.add(_b.lateralToolTransfer);
              }
            }
          }
          for (Router _c : router) {
            for (Computer _d : _c.computer) {
              for (OS _e : _d.os) {
                _cacheChildrenFilterNetworkTraffic.add(_e.manInTheMiddle);
              }
            }
          }
          for (Router _f : router) {
            for (Computer _10 : _f.computer) {
              for (OS _11 : _10.os) {
                _cacheChildrenFilterNetworkTraffic.add(_11.dNS);
              }
            }
          }
          for (Router _12 : router) {
            for (Computer _13 : _12.computer) {
              for (OS _14 : _13.os) {
                _cacheChildrenFilterNetworkTraffic.add(_14.vNC);
              }
            }
          }
          for (Router _15 : router) {
            for (Computer _16 : _15.computer) {
              for (OS _17 : _16.os) {
                _cacheChildrenFilterNetworkTraffic.add(_17.protocolTunneling);
              }
            }
          }
          for (Router _18 : router) {
            for (Computer _19 : _18.computer) {
              for (OS _1a : _19.os) {
                _cacheChildrenFilterNetworkTraffic.add(_1a.multiHopProxy);
              }
            }
          }
          for (Router _1b : router) {
            for (Computer _1c : _1b.computer) {
              for (OS _1d : _1c.os) {
                _cacheChildrenFilterNetworkTraffic.add(_1d.reflectionAmplification);
              }
            }
          }
          for (Router _1e : router) {
            for (Computer _1f : _1e.computer) {
              for (OS _20 : _1f.os) {
                _cacheChildrenFilterNetworkTraffic.add(_20.exfiltrationOverAternativeProtocol);
              }
            }
          }
          for (Router _21 : router) {
            for (Computer _22 : _21.computer) {
              for (OS _23 : _22.os) {
                _cacheChildrenFilterNetworkTraffic.add(_23.bITSJobs);
              }
            }
          }
          for (Router _24 : router) {
            for (Computer _25 : _24.computer) {
              for (OS _26 : _25.os) {
                _cacheChildrenFilterNetworkTraffic.add(_26.lLMNR_NBT_NS_PoisoningAndSMBRelay);
              }
            }
          }
          for (Router _27 : router) {
            for (Computer _28 : _27.computer) {
              for (OS _29 : _28.os) {
                _cacheChildrenFilterNetworkTraffic.add(_29.forcedAuthentication);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenFilterNetworkTraffic) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.filterNetworkTraffic";
      }
    }
  }

  public class LimitAccessToResourceOverNetwork extends Defense {
    public LimitAccessToResourceOverNetwork(String name) {
      this(name, false);
    }

    public LimitAccessToResourceOverNetwork(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenLimitAccessToResourceOverNetwork;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenLimitAccessToResourceOverNetwork == null) {
          _cacheChildrenLimitAccessToResourceOverNetwork = new HashSet<>();
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenLimitAccessToResourceOverNetwork.add(_2.manInTheMiddle);
              }
            }
          }
          for (Router _3 : router) {
            for (Computer _4 : _3.computer) {
              for (OS _5 : _4.os) {
                _cacheChildrenLimitAccessToResourceOverNetwork.add(_5.remoteDesktopProtocol);
              }
            }
          }
          for (Router _6 : router) {
            for (Computer _7 : _6.computer) {
              for (OS _8 : _7.os) {
                _cacheChildrenLimitAccessToResourceOverNetwork.add(_8.windowsAdminShares);
              }
            }
          }
          for (Router _9 : router) {
            for (Computer _a : _9.computer) {
              for (OS _b : _a.os) {
                _cacheChildrenLimitAccessToResourceOverNetwork.add(_b.rDPHijacking);
              }
            }
          }
          for (Router _c : router) {
            for (Computer _d : _c.computer) {
              _cacheChildrenLimitAccessToResourceOverNetwork.add(_d.hardwareAdditions);
            }
          }
          for (Router _e : router) {
            for (Computer _f : _e.computer) {
              for (OS _10 : _f.os) {
                for (Service _11 : _10.service) {
                  _cacheChildrenLimitAccessToResourceOverNetwork.add(_11.externalRemoteServices);
                }
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenLimitAccessToResourceOverNetwork) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.limitAccessToResourceOverNetwork";
      }
    }
  }

  public class MultiFactorAuthentication extends Defense {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(exchangeServerCollection);
          for (Router _0 : router) {
            for (ExternalNetwork _1 : _0.externalNetwork) {
              _cacheChildrenMultiFactorAuthentication.add(_1.dataFromCloudStorageObject);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.multiFactorAuthentication";
      }
    }
  }

  public class NetworkIntrusionPrevention extends Defense {
    public NetworkIntrusionPrevention(String name) {
      this(name, false);
    }

    public NetworkIntrusionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenNetworkIntrusionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenNetworkIntrusionPrevention == null) {
          _cacheChildrenNetworkIntrusionPrevention = new HashSet<>();
          _cacheChildrenNetworkIntrusionPrevention.add(applicationLayerConnexion);
          _cacheChildrenNetworkIntrusionPrevention.add(c2Connexion);
          _cacheChildrenNetworkIntrusionPrevention.add(dataExfiltration);
          _cacheChildrenNetworkIntrusionPrevention.add(exfiltrationOverC2Channel);
          _cacheChildrenNetworkIntrusionPrevention.add(generateDomainNames);
          _cacheChildrenNetworkIntrusionPrevention.add(junkData);
          _cacheChildrenNetworkIntrusionPrevention.add(protocolImpersonation);
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                for (UserAccount _3 : _2.userAccount) {
                  _cacheChildrenNetworkIntrusionPrevention.add(_3.userExecution);
                }
              }
            }
          }
          for (Router _4 : router) {
            for (Computer _5 : _4.computer) {
              for (User _6 : _5.user) {
                _cacheChildrenNetworkIntrusionPrevention.add(_6.maliciousLink);
              }
            }
          }
          for (Router _7 : router) {
            for (Computer _8 : _7.computer) {
              for (OS _9 : _8.os) {
                for (Service _a : _9.service) {
                  for (Browser _b : _a.browser) {
                    _cacheChildrenNetworkIntrusionPrevention.add(_b.spearphishingAttachment);
                  }
                }
              }
            }
          }
          for (Router _c : router) {
            for (Computer _d : _c.computer) {
              for (OS _e : _d.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_e.nonApplicationLayerProtocol);
              }
            }
          }
          for (Router _f : router) {
            for (Computer _10 : _f.computer) {
              for (OS _11 : _10.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_11.encryptedChannel);
              }
            }
          }
          for (Router _12 : router) {
            for (Computer _13 : _12.computer) {
              for (OS _14 : _13.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_14.dataCompressed);
              }
            }
          }
          for (Router _15 : router) {
            for (Computer _16 : _15.computer) {
              for (OS _17 : _16.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_17.domainGenerationAlgorithms);
              }
            }
          }
          for (Router _18 : router) {
            for (Computer _19 : _18.computer) {
              for (OS _1a : _19.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_1a.internalProxy);
              }
            }
          }
          for (Router _1b : router) {
            for (Computer _1c : _1b.computer) {
              for (OS _1d : _1c.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_1d.externalProxy);
              }
            }
          }
          for (Router _1e : router) {
            for (Computer _1f : _1e.computer) {
              for (OS _20 : _1f.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_20.exfiltrationOverAternativeProtocol);
              }
            }
          }
          for (Router _21 : router) {
            for (Computer _22 : _21.computer) {
              for (OS _23 : _22.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_23.standardEncoding);
              }
            }
          }
          for (Router _24 : router) {
            for (Computer _25 : _24.computer) {
              for (OS _26 : _25.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_26.nonStandardEncoding);
              }
            }
          }
          for (Router _27 : router) {
            for (Computer _28 : _27.computer) {
              for (OS _29 : _28.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_29.fallbackChannels);
              }
            }
          }
          for (Router _2a : router) {
            for (Computer _2b : _2a.computer) {
              for (OS _2c : _2b.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_2c.lateralToolTransfer);
              }
            }
          }
          for (Router _2d : router) {
            for (Computer _2e : _2d.computer) {
              for (OS _2f : _2e.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_2f.manInTheMiddle);
              }
            }
          }
          for (Router _30 : router) {
            for (Computer _31 : _30.computer) {
              for (OS _32 : _31.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_32.multiStageChannels);
              }
            }
          }
          for (Router _33 : router) {
            for (Computer _34 : _33.computer) {
              for (OS _35 : _34.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_35.networkServiceScan);
              }
            }
          }
          for (Router _36 : router) {
            for (Computer _37 : _36.computer) {
              for (OS _38 : _37.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_38.protocolTunneling);
              }
            }
          }
          for (Router _39 : router) {
            for (Computer _3a : _39.computer) {
              for (OS _3b : _3a.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_3b.remoteFileCopy);
              }
            }
          }
          for (Router _3c : router) {
            for (Computer _3d : _3c.computer) {
              for (OS _3e : _3d.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_3e.applicationLayerProtocol);
              }
            }
          }
          for (Router _3f : router) {
            for (Computer _40 : _3f.computer) {
              for (OS _41 : _40.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_41.nonStandardPort);
              }
            }
          }
          for (Router _42 : router) {
            for (Computer _43 : _42.computer) {
              for (OS _44 : _43.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_44.templateInjection);
              }
            }
          }
          for (Router _45 : router) {
            for (Computer _46 : _45.computer) {
              for (OS _47 : _46.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_47.lLMNR_NBT_NS_PoisoningAndSMBRelay);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenNetworkIntrusionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.networkIntrusionPrevention";
      }
    }
  }

  public class NetworkSegmentation extends Defense {
    public NetworkSegmentation(String name) {
      this(name, false);
    }

    public NetworkSegmentation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenNetworkSegmentation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenNetworkSegmentation == null) {
          _cacheChildrenNetworkSegmentation = new HashSet<>();
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                for (Service _3 : _2.service) {
                  _cacheChildrenNetworkSegmentation.add(_3.applicationDeploymentSoftware);
                }
              }
            }
          }
          for (Router _4 : router) {
            for (Computer _5 : _4.computer) {
              for (OS _6 : _5.os) {
                _cacheChildrenNetworkSegmentation.add(_6.manInTheMiddle);
              }
            }
          }
          for (Router _7 : router) {
            for (Computer _8 : _7.computer) {
              for (OS _9 : _8.os) {
                _cacheChildrenNetworkSegmentation.add(_9.nonStandardPort);
              }
            }
          }
          for (Router _a : router) {
            for (Computer _b : _a.computer) {
              for (OS _c : _b.os) {
                _cacheChildrenNetworkSegmentation.add(_c.nonApplicationLayerProtocol);
              }
            }
          }
          for (Router _d : router) {
            for (Computer _e : _d.computer) {
              for (OS _f : _e.os) {
                _cacheChildrenNetworkSegmentation.add(_f.domainAccount);
              }
            }
          }
          for (Router _10 : router) {
            for (Computer _11 : _10.computer) {
              for (OS _12 : _11.os) {
                _cacheChildrenNetworkSegmentation.add(_12.exfiltrationOverAternativeProtocol);
              }
            }
          }
          for (Router _13 : router) {
            for (Computer _14 : _13.computer) {
              for (OS _15 : _14.os) {
                _cacheChildrenNetworkSegmentation.add(_15.privateKeys);
              }
            }
          }
          for (Router _16 : router) {
            for (Computer _17 : _16.computer) {
              for (OS _18 : _17.os) {
                _cacheChildrenNetworkSegmentation.add(_18.runtimeDataManipulation);
              }
            }
          }
          for (Router _19 : router) {
            for (Computer _1a : _19.computer) {
              for (OS _1b : _1a.os) {
                _cacheChildrenNetworkSegmentation.add(_1b.domainTrustDiscovery);
              }
            }
          }
          for (Router _1c : router) {
            for (Computer _1d : _1c.computer) {
              for (OS _1e : _1d.os) {
                _cacheChildrenNetworkSegmentation.add(_1e.lLMNR_NBT_NS_PoisoningAndSMBRelay);
              }
            }
          }
          for (Router _1f : router) {
            for (Computer _20 : _1f.computer) {
              for (OS _21 : _20.os) {
                _cacheChildrenNetworkSegmentation.add(_21.rDPHijacking);
              }
            }
          }
          for (Router _22 : router) {
            for (Computer _23 : _22.computer) {
              for (OS _24 : _23.os) {
                _cacheChildrenNetworkSegmentation.add(_24.serviceStop);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenNetworkSegmentation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.networkSegmentation";
      }
    }
  }

  public class SSLOrTLSInspection extends Defense {
    public SSLOrTLSInspection(String name) {
      this(name, false);
    }

    public SSLOrTLSInspection(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenSSLOrTLSInspection;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenSSLOrTLSInspection == null) {
          _cacheChildrenSSLOrTLSInspection = new HashSet<>();
          _cacheChildrenSSLOrTLSInspection.add(obfuscateNetworkTraffic);
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenSSLOrTLSInspection.add(_2.encryptedChannel);
              }
            }
          }
          for (Router _3 : router) {
            for (Computer _4 : _3.computer) {
              for (OS _5 : _4.os) {
                _cacheChildrenSSLOrTLSInspection.add(_5.domainFronting);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenSSLOrTLSInspection) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "InternalNetwork.sSLOrTLSInspection";
      }
    }
  }
}
