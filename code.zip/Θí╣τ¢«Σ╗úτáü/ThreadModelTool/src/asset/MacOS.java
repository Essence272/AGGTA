package asset;

import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class MacOS extends OS {
  public AttemptBashHistory attemptBashHistory;

  public AttemptBash_profileAndBashrc attemptBash_profileAndBashrc;

  public AttemptBootOrLogonInitializationScripts attemptBootOrLogonInitializationScripts;

  public BootOrLogonInitializationScripts bootOrLogonInitializationScripts;

  public ClearMacSystemLogs clearMacSystemLogs;

  public CodeSigningCertificate codeSigningCertificate;

  public AttemptClearCommandHistory attemptClearCommandHistory;

  public DylibHijacking dylibHijacking;

  public AttemptEmond attemptEmond;

  public MacFileAndDirectoryPermissionsModification macFileAndDirectoryPermissionsModification;

  public AttemptGUIInputCapture attemptGUIInputCapture;

  public AttemptHiddenWindow attemptHiddenWindow;

  public InvalidCodeSignature invalidCodeSignature;

  public AttemptLaunchDaemon attemptLaunchDaemon;

  public LogonScripts logonScripts;

  public SetuidAndSetgid setuidAndSetgid;

  public AttemptSoftwarePacking attemptSoftwarePacking;

  public SoftwarePacking softwarePacking;

  public SSHAuthorizedKeys sSHAuthorizedKeys;

  public AttemptSudoAndSudoCaching attemptSudoAndSudoCaching;

  public UnixShell unixShell;

  public AttemptKeychain attemptKeychain;

  public AppleScript appleScript;

  public StartupItems startupItems;

  public EnvironmentVariablePermissions environmentVariablePermissions;

  public MacOS(String name, boolean isAntivirusEnabled,
      boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled, boolean isEnvironmentVariablePermissionsEnabled) {
    super(name, isAntivirusEnabled, isRestrictFileAndDirectoryPermissionsEnabled, isRestrictRegistryPermissionsEnabled, isAccountUsePoliciesEnabled, isBehaviorPreventionOnEndpointEnabled, isBootIntegrityEnabled, isDataBackupEnabled, isMultiFactorAuthenticationEnabled, isPasswordPoliciesEnabled, isApplicationIsolationAndSandboxingEnabled, isDoNotMitigateEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isActiveDirectoryConfigurationEnabled, isAuditEnabled, isApplicationDeveloperGuidanceEnabled, isCodeSigningEnabled, isLimitHardwareInstallationEnabled, isOperatingSystemConfigurationEnabled, isSoftwareConfigurationEnabled, isExecutionPreventionEnabled, isPrivilegedAccountManagementEnabled, isEncryptSensitiveInformationEnabled, isRemoteDataStorageEnabled, isLimitSoftwareInstallationEnabled, isUpdateSoftwareEnabled, isUserAccountControlEnabled, isExploitProtectionEnabled);
    assetClassName = "MacOS";
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(attemptBashHistory);
    attemptBashHistory = new AttemptBashHistory(name);
    AttackStep.allAttackSteps.remove(bashHistory);
    bashHistory = new BashHistory(name);
    AttackStep.allAttackSteps.remove(attemptBash_profileAndBashrc);
    attemptBash_profileAndBashrc = new AttemptBash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bash_profileAndBashrc);
    bash_profileAndBashrc = new Bash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(attemptBootOrLogonInitializationScripts);
    attemptBootOrLogonInitializationScripts = new AttemptBootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(bootOrLogonInitializationScripts);
    bootOrLogonInitializationScripts = new BootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(clearMacSystemLogs);
    clearMacSystemLogs = new ClearMacSystemLogs(name);
    AttackStep.allAttackSteps.remove(codeSigningCertificate);
    codeSigningCertificate = new CodeSigningCertificate(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(visualBasic);
    visualBasic = new VisualBasic(name);
    AttackStep.allAttackSteps.remove(javaScriptOrJScript);
    javaScriptOrJScript = new JavaScriptOrJScript(name);
    AttackStep.allAttackSteps.remove(attemptClearCommandHistory);
    attemptClearCommandHistory = new AttemptClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(clearCommandHistory);
    clearCommandHistory = new ClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(credentialsFromPasswordStores);
    credentialsFromPasswordStores = new CredentialsFromPasswordStores(name);
    AttackStep.allAttackSteps.remove(cron);
    cron = new Cron(name);
    AttackStep.allAttackSteps.remove(dylibHijacking);
    dylibHijacking = new DylibHijacking(name);
    AttackStep.allAttackSteps.remove(attemptElevatedExecutionWithPrompt);
    attemptElevatedExecutionWithPrompt = new AttemptElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(elevatedExecutionWithPrompt);
    elevatedExecutionWithPrompt = new ElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(attemptEmond);
    attemptEmond = new AttemptEmond(name);
    AttackStep.allAttackSteps.remove(emond);
    emond = new Emond(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(macFileAndDirectoryPermissionsModification);
    macFileAndDirectoryPermissionsModification = new MacFileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    AttackStep.allAttackSteps.remove(attemptGatekeeperBypass);
    attemptGatekeeperBypass = new AttemptGatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(gatekeeperBypass);
    gatekeeperBypass = new GatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(attemptGUIInputCapture);
    attemptGUIInputCapture = new AttemptGUIInputCapture(name);
    AttackStep.allAttackSteps.remove(gUIInputCapture);
    gUIInputCapture = new GUIInputCapture(name);
    AttackStep.allAttackSteps.remove(hideArtifacts);
    hideArtifacts = new HideArtifacts(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(inputCapture);
    inputCapture = new InputCapture(name);
    AttackStep.allAttackSteps.remove(hiddenUsers);
    hiddenUsers = new HiddenUsers(name);
    AttackStep.allAttackSteps.remove(attemptHiddenWindow);
    attemptHiddenWindow = new AttemptHiddenWindow(name);
    AttackStep.allAttackSteps.remove(hiddenWindow);
    hiddenWindow = new HiddenWindow(name);
    AttackStep.allAttackSteps.remove(hISTCONTROL);
    hISTCONTROL = new HISTCONTROL(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(infectedOS);
    infectedOS = new InfectedOS(name);
    AttackStep.allAttackSteps.remove(invalidCodeSignature);
    invalidCodeSignature = new InvalidCodeSignature(name);
    AttackStep.allAttackSteps.remove(kernelModulesAndExtensions);
    kernelModulesAndExtensions = new KernelModulesAndExtensions(name);
    AttackStep.allAttackSteps.remove(attemptLaunchAgent);
    attemptLaunchAgent = new AttemptLaunchAgent(name);
    AttackStep.allAttackSteps.remove(launchAgent);
    launchAgent = new LaunchAgent(name);
    AttackStep.allAttackSteps.remove(launchctl);
    launchctl = new Launchctl(name);
    AttackStep.allAttackSteps.remove(launchd);
    launchd = new Launchd(name);
    AttackStep.allAttackSteps.remove(attemptLaunchDaemon);
    attemptLaunchDaemon = new AttemptLaunchDaemon(name);
    AttackStep.allAttackSteps.remove(launchDaemon);
    launchDaemon = new LaunchDaemon(name);
    AttackStep.allAttackSteps.remove(lC_LOAD_DYLIB_Addition);
    lC_LOAD_DYLIB_Addition = new LC_LOAD_DYLIB_Addition(name);
    AttackStep.allAttackSteps.remove(attemptLogonScripts);
    attemptLogonScripts = new AttemptLogonScripts(name);
    AttackStep.allAttackSteps.remove(logonScripts);
    logonScripts = new LogonScripts(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(obfuscatedFilesOrInformation);
    obfuscatedFilesOrInformation = new ObfuscatedFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(attemptPlistModification);
    attemptPlistModification = new AttemptPlistModification(name);
    AttackStep.allAttackSteps.remove(plistModification);
    plistModification = new PlistModification(name);
    AttackStep.allAttackSteps.remove(pluggableAuthenticationModules);
    pluggableAuthenticationModules = new PluggableAuthenticationModules(name);
    AttackStep.allAttackSteps.remove(portKnocking);
    portKnocking = new PortKnocking(name);
    AttackStep.allAttackSteps.remove(rc_common);
    rc_common = new Rc_common(name);
    AttackStep.allAttackSteps.remove(reopenedApplications);
    reopenedApplications = new ReopenedApplications(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(securitydMemory);
    securitydMemory = new SecuritydMemory(name);
    AttackStep.allAttackSteps.remove(attemptSetuidAndSetgid);
    attemptSetuidAndSetgid = new AttemptSetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(setuidAndSetgid);
    setuidAndSetgid = new SetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(attemptSoftwarePacking);
    attemptSoftwarePacking = new AttemptSoftwarePacking(name);
    AttackStep.allAttackSteps.remove(softwarePacking);
    softwarePacking = new SoftwarePacking(name);
    AttackStep.allAttackSteps.remove(source);
    source = new Source(name);
    AttackStep.allAttackSteps.remove(systemServices);
    systemServices = new SystemServices(name);
    AttackStep.allAttackSteps.remove(sSH);
    sSH = new SSH(name);
    AttackStep.allAttackSteps.remove(attemptSSHAuthorizedKeys);
    attemptSSHAuthorizedKeys = new AttemptSSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHAuthorizedKeys);
    sSHAuthorizedKeys = new SSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHHijacking);
    sSHHijacking = new SSHHijacking(name);
    AttackStep.allAttackSteps.remove(subvertTrustControls);
    subvertTrustControls = new SubvertTrustControls(name);
    AttackStep.allAttackSteps.remove(attemptSudoAndSudoCaching);
    attemptSudoAndSudoCaching = new AttemptSudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(sudoAndSudoCaching);
    sudoAndSudoCaching = new SudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(trap);
    trap = new Trap(name);
    AttackStep.allAttackSteps.remove(videoCapture);
    videoCapture = new VideoCapture(name);
    AttackStep.allAttackSteps.remove(spaceAfterFileName);
    spaceAfterFileName = new SpaceAfterFileName(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(unixShell);
    unixShell = new UnixShell(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentation);
    windowsManagementInstrumentation = new WindowsManagementInstrumentation(name);
    AttackStep.allAttackSteps.remove(attemptKeychain);
    attemptKeychain = new AttemptKeychain(name);
    AttackStep.allAttackSteps.remove(keychain);
    keychain = new Keychain(name);
    AttackStep.allAttackSteps.remove(appleScript);
    appleScript = new AppleScript(name);
    AttackStep.allAttackSteps.remove(attemptStartupItems);
    attemptStartupItems = new AttemptStartupItems(name);
    AttackStep.allAttackSteps.remove(startupItems);
    startupItems = new StartupItems(name);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, isAntivirusEnabled);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, isAuditEnabled);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, isCodeSigningEnabled);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, isDisableOrRemoveFeatureOrProgramEnabled);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, isExecutionPreventionEnabled);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, isEncryptSensitiveInformationEnabled);
    if (environmentVariablePermissions != null) {
      AttackStep.allAttackSteps.remove(environmentVariablePermissions.disable);
    }
    Defense.allDefenses.remove(environmentVariablePermissions);
    environmentVariablePermissions = new EnvironmentVariablePermissions(name, isEnvironmentVariablePermissionsEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, isOperatingSystemConfigurationEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, isPrivilegedAccountManagementEnabled);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, isRestrictFileAndDirectoryPermissionsEnabled);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, isRemoteDataStorageEnabled);
  }

  public MacOS(String name) {
    super(name);
    assetClassName = "MacOS";
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(attemptBashHistory);
    attemptBashHistory = new AttemptBashHistory(name);
    AttackStep.allAttackSteps.remove(bashHistory);
    bashHistory = new BashHistory(name);
    AttackStep.allAttackSteps.remove(attemptBash_profileAndBashrc);
    attemptBash_profileAndBashrc = new AttemptBash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bash_profileAndBashrc);
    bash_profileAndBashrc = new Bash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(attemptBootOrLogonInitializationScripts);
    attemptBootOrLogonInitializationScripts = new AttemptBootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(bootOrLogonInitializationScripts);
    bootOrLogonInitializationScripts = new BootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(clearMacSystemLogs);
    clearMacSystemLogs = new ClearMacSystemLogs(name);
    AttackStep.allAttackSteps.remove(codeSigningCertificate);
    codeSigningCertificate = new CodeSigningCertificate(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(visualBasic);
    visualBasic = new VisualBasic(name);
    AttackStep.allAttackSteps.remove(javaScriptOrJScript);
    javaScriptOrJScript = new JavaScriptOrJScript(name);
    AttackStep.allAttackSteps.remove(attemptClearCommandHistory);
    attemptClearCommandHistory = new AttemptClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(clearCommandHistory);
    clearCommandHistory = new ClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(credentialsFromPasswordStores);
    credentialsFromPasswordStores = new CredentialsFromPasswordStores(name);
    AttackStep.allAttackSteps.remove(cron);
    cron = new Cron(name);
    AttackStep.allAttackSteps.remove(dylibHijacking);
    dylibHijacking = new DylibHijacking(name);
    AttackStep.allAttackSteps.remove(attemptElevatedExecutionWithPrompt);
    attemptElevatedExecutionWithPrompt = new AttemptElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(elevatedExecutionWithPrompt);
    elevatedExecutionWithPrompt = new ElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(attemptEmond);
    attemptEmond = new AttemptEmond(name);
    AttackStep.allAttackSteps.remove(emond);
    emond = new Emond(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(macFileAndDirectoryPermissionsModification);
    macFileAndDirectoryPermissionsModification = new MacFileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    AttackStep.allAttackSteps.remove(attemptGatekeeperBypass);
    attemptGatekeeperBypass = new AttemptGatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(gatekeeperBypass);
    gatekeeperBypass = new GatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(attemptGUIInputCapture);
    attemptGUIInputCapture = new AttemptGUIInputCapture(name);
    AttackStep.allAttackSteps.remove(gUIInputCapture);
    gUIInputCapture = new GUIInputCapture(name);
    AttackStep.allAttackSteps.remove(hideArtifacts);
    hideArtifacts = new HideArtifacts(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(inputCapture);
    inputCapture = new InputCapture(name);
    AttackStep.allAttackSteps.remove(hiddenUsers);
    hiddenUsers = new HiddenUsers(name);
    AttackStep.allAttackSteps.remove(attemptHiddenWindow);
    attemptHiddenWindow = new AttemptHiddenWindow(name);
    AttackStep.allAttackSteps.remove(hiddenWindow);
    hiddenWindow = new HiddenWindow(name);
    AttackStep.allAttackSteps.remove(hISTCONTROL);
    hISTCONTROL = new HISTCONTROL(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(infectedOS);
    infectedOS = new InfectedOS(name);
    AttackStep.allAttackSteps.remove(invalidCodeSignature);
    invalidCodeSignature = new InvalidCodeSignature(name);
    AttackStep.allAttackSteps.remove(kernelModulesAndExtensions);
    kernelModulesAndExtensions = new KernelModulesAndExtensions(name);
    AttackStep.allAttackSteps.remove(attemptLaunchAgent);
    attemptLaunchAgent = new AttemptLaunchAgent(name);
    AttackStep.allAttackSteps.remove(launchAgent);
    launchAgent = new LaunchAgent(name);
    AttackStep.allAttackSteps.remove(launchctl);
    launchctl = new Launchctl(name);
    AttackStep.allAttackSteps.remove(launchd);
    launchd = new Launchd(name);
    AttackStep.allAttackSteps.remove(attemptLaunchDaemon);
    attemptLaunchDaemon = new AttemptLaunchDaemon(name);
    AttackStep.allAttackSteps.remove(launchDaemon);
    launchDaemon = new LaunchDaemon(name);
    AttackStep.allAttackSteps.remove(lC_LOAD_DYLIB_Addition);
    lC_LOAD_DYLIB_Addition = new LC_LOAD_DYLIB_Addition(name);
    AttackStep.allAttackSteps.remove(attemptLogonScripts);
    attemptLogonScripts = new AttemptLogonScripts(name);
    AttackStep.allAttackSteps.remove(logonScripts);
    logonScripts = new LogonScripts(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(obfuscatedFilesOrInformation);
    obfuscatedFilesOrInformation = new ObfuscatedFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(attemptPlistModification);
    attemptPlistModification = new AttemptPlistModification(name);
    AttackStep.allAttackSteps.remove(plistModification);
    plistModification = new PlistModification(name);
    AttackStep.allAttackSteps.remove(pluggableAuthenticationModules);
    pluggableAuthenticationModules = new PluggableAuthenticationModules(name);
    AttackStep.allAttackSteps.remove(portKnocking);
    portKnocking = new PortKnocking(name);
    AttackStep.allAttackSteps.remove(rc_common);
    rc_common = new Rc_common(name);
    AttackStep.allAttackSteps.remove(reopenedApplications);
    reopenedApplications = new ReopenedApplications(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(securitydMemory);
    securitydMemory = new SecuritydMemory(name);
    AttackStep.allAttackSteps.remove(attemptSetuidAndSetgid);
    attemptSetuidAndSetgid = new AttemptSetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(setuidAndSetgid);
    setuidAndSetgid = new SetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(attemptSoftwarePacking);
    attemptSoftwarePacking = new AttemptSoftwarePacking(name);
    AttackStep.allAttackSteps.remove(softwarePacking);
    softwarePacking = new SoftwarePacking(name);
    AttackStep.allAttackSteps.remove(source);
    source = new Source(name);
    AttackStep.allAttackSteps.remove(systemServices);
    systemServices = new SystemServices(name);
    AttackStep.allAttackSteps.remove(sSH);
    sSH = new SSH(name);
    AttackStep.allAttackSteps.remove(attemptSSHAuthorizedKeys);
    attemptSSHAuthorizedKeys = new AttemptSSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHAuthorizedKeys);
    sSHAuthorizedKeys = new SSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(sSHHijacking);
    sSHHijacking = new SSHHijacking(name);
    AttackStep.allAttackSteps.remove(subvertTrustControls);
    subvertTrustControls = new SubvertTrustControls(name);
    AttackStep.allAttackSteps.remove(attemptSudoAndSudoCaching);
    attemptSudoAndSudoCaching = new AttemptSudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(sudoAndSudoCaching);
    sudoAndSudoCaching = new SudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(trap);
    trap = new Trap(name);
    AttackStep.allAttackSteps.remove(videoCapture);
    videoCapture = new VideoCapture(name);
    AttackStep.allAttackSteps.remove(spaceAfterFileName);
    spaceAfterFileName = new SpaceAfterFileName(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(unixShell);
    unixShell = new UnixShell(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentation);
    windowsManagementInstrumentation = new WindowsManagementInstrumentation(name);
    AttackStep.allAttackSteps.remove(attemptKeychain);
    attemptKeychain = new AttemptKeychain(name);
    AttackStep.allAttackSteps.remove(keychain);
    keychain = new Keychain(name);
    AttackStep.allAttackSteps.remove(appleScript);
    appleScript = new AppleScript(name);
    AttackStep.allAttackSteps.remove(attemptStartupItems);
    attemptStartupItems = new AttemptStartupItems(name);
    AttackStep.allAttackSteps.remove(startupItems);
    startupItems = new StartupItems(name);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, false);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, false);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, false);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, false);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, false);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, false);
    if (environmentVariablePermissions != null) {
      AttackStep.allAttackSteps.remove(environmentVariablePermissions.disable);
    }
    Defense.allDefenses.remove(environmentVariablePermissions);
    environmentVariablePermissions = new EnvironmentVariablePermissions(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, false);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, false);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, false);
  }

  public MacOS(boolean isAntivirusEnabled, boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled, boolean isEnvironmentVariablePermissionsEnabled) {
    this("Anonymous", isAntivirusEnabled, isRestrictFileAndDirectoryPermissionsEnabled, isRestrictRegistryPermissionsEnabled, isAccountUsePoliciesEnabled, isBehaviorPreventionOnEndpointEnabled, isBootIntegrityEnabled, isDataBackupEnabled, isMultiFactorAuthenticationEnabled, isPasswordPoliciesEnabled, isApplicationIsolationAndSandboxingEnabled, isDoNotMitigateEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isActiveDirectoryConfigurationEnabled, isAuditEnabled, isApplicationDeveloperGuidanceEnabled, isCodeSigningEnabled, isLimitHardwareInstallationEnabled, isOperatingSystemConfigurationEnabled, isSoftwareConfigurationEnabled, isExecutionPreventionEnabled, isPrivilegedAccountManagementEnabled, isEncryptSensitiveInformationEnabled, isRemoteDataStorageEnabled, isLimitSoftwareInstallationEnabled, isUpdateSoftwareEnabled, isUserAccountControlEnabled, isExploitProtectionEnabled, isEnvironmentVariablePermissionsEnabled);
  }

  public MacOS() {
    this("Anonymous");
  }

  public class AbuseElevationControlMechanism extends OS.AbuseElevationControlMechanism {
    private Set<AttackStep> _cacheChildrenAbuseElevationControlMechanism;

    public AbuseElevationControlMechanism(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAbuseElevationControlMechanism == null) {
        _cacheChildrenAbuseElevationControlMechanism = new HashSet<>();
        _cacheChildrenAbuseElevationControlMechanism.add(attemptSetuidAndSetgid);
        _cacheChildrenAbuseElevationControlMechanism.add(sudoAndSudoCaching);
        _cacheChildrenAbuseElevationControlMechanism.add(attemptElevatedExecutionWithPrompt);
      }
      for (AttackStep attackStep : _cacheChildrenAbuseElevationControlMechanism) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.abuseElevationControlMechanism");
    }
  }

  public class AccountManipulation extends OS.AccountManipulation {
    private Set<AttackStep> _cacheChildrenAccountManipulation;

    public AccountManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAccountManipulation == null) {
        _cacheChildrenAccountManipulation = new HashSet<>();
        _cacheChildrenAccountManipulation.add(attemptSSHAuthorizedKeys);
      }
      for (AttackStep attackStep : _cacheChildrenAccountManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.accountManipulation");
    }
  }

  public class AttemptBashHistory extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBashHistory;

    private Set<AttackStep> _cacheParentAttemptBashHistory;

    public AttemptBashHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBashHistory == null) {
        _cacheChildrenAttemptBashHistory = new HashSet<>();
        _cacheChildrenAttemptBashHistory.add(bashHistory);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBashHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptBashHistory == null) {
        _cacheParentAttemptBashHistory = new HashSet<>();
        _cacheParentAttemptBashHistory.add(infectedOS);
      }
      for (AttackStep attackStep : _cacheParentAttemptBashHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptBashHistory");
    }
  }

  public class BashHistory extends OS.BashHistory {
    private Set<AttackStep> _cacheChildrenBashHistory;

    private Set<AttackStep> _cacheParentBashHistory;

    public BashHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBashHistory == null) {
        _cacheChildrenBashHistory = new HashSet<>();
        _cacheChildrenBashHistory.add(indicatorRemovalOnHost);
        if (MacOS.this instanceof MacOS) {
          for (AdminAccount _0 : ((asset.MacOS) MacOS.this).adminAccount) {
            _cacheChildrenBashHistory.add(_0.adminCredentials);
          }
        }
        if (MacOS.this instanceof MacOS) {
          for (UserAccount _1 : ((asset.MacOS) MacOS.this).userAccount) {
            _cacheChildrenBashHistory.add(_1.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenBashHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBashHistory == null) {
        _cacheParentBashHistory = new HashSet<>();
        _cacheParentBashHistory.add(attemptBashHistory);
        _cacheParentBashHistory.add(unsecuredCredentials);
        _cacheParentBashHistory.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentBashHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.bashHistory");
    }
  }

  public class AttemptBash_profileAndBashrc extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBash_profileAndBashrc;

    private Set<AttackStep> _cacheParentAttemptBash_profileAndBashrc;

    public AttemptBash_profileAndBashrc(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBash_profileAndBashrc == null) {
        _cacheChildrenAttemptBash_profileAndBashrc = new HashSet<>();
        _cacheChildrenAttemptBash_profileAndBashrc.add(bash_profileAndBashrc);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBash_profileAndBashrc) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptBash_profileAndBashrc == null) {
        _cacheParentAttemptBash_profileAndBashrc = new HashSet<>();
        _cacheParentAttemptBash_profileAndBashrc.add(eventTriggeredExecution);
        _cacheParentAttemptBash_profileAndBashrc.add(macFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheParentAttemptBash_profileAndBashrc) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptBash_profileAndBashrc");
    }
  }

  public class Bash_profileAndBashrc extends OS.Bash_profileAndBashrc {
    private Set<AttackStep> _cacheChildrenBash_profileAndBashrc;

    private Set<AttackStep> _cacheParentBash_profileAndBashrc;

    public Bash_profileAndBashrc(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBash_profileAndBashrc == null) {
        _cacheChildrenBash_profileAndBashrc = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenBash_profileAndBashrc.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenBash_profileAndBashrc) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBash_profileAndBashrc == null) {
        _cacheParentBash_profileAndBashrc = new HashSet<>();
        _cacheParentBash_profileAndBashrc.add(attemptBash_profileAndBashrc);
        _cacheParentBash_profileAndBashrc.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentBash_profileAndBashrc) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.bash_profileAndBashrc");
    }
  }

  public class BootOrLogonAutostartExecution extends OS.BootOrLogonAutostartExecution {
    private Set<AttackStep> _cacheChildrenBootOrLogonAutostartExecution;

    public BootOrLogonAutostartExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBootOrLogonAutostartExecution == null) {
        _cacheChildrenBootOrLogonAutostartExecution = new HashSet<>();
        _cacheChildrenBootOrLogonAutostartExecution.add(kernelModulesAndExtensions);
        _cacheChildrenBootOrLogonAutostartExecution.add(reopenedApplications);
        _cacheChildrenBootOrLogonAutostartExecution.add(attemptPlistModification);
      }
      for (AttackStep attackStep : _cacheChildrenBootOrLogonAutostartExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.bootOrLogonAutostartExecution");
    }
  }

  public class AttemptBootOrLogonInitializationScripts extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBootOrLogonInitializationScripts;

    public AttemptBootOrLogonInitializationScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBootOrLogonInitializationScripts == null) {
        _cacheChildrenAttemptBootOrLogonInitializationScripts = new HashSet<>();
        _cacheChildrenAttemptBootOrLogonInitializationScripts.add(bootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBootOrLogonInitializationScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptBootOrLogonInitializationScripts");
    }
  }

  public class BootOrLogonInitializationScripts extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenBootOrLogonInitializationScripts;

    private Set<AttackStep> _cacheParentBootOrLogonInitializationScripts;

    public BootOrLogonInitializationScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBootOrLogonInitializationScripts == null) {
        _cacheChildrenBootOrLogonInitializationScripts = new HashSet<>();
        _cacheChildrenBootOrLogonInitializationScripts.add(attemptLogonScripts);
        _cacheChildrenBootOrLogonInitializationScripts.add(rc_common);
        _cacheChildrenBootOrLogonInitializationScripts.add(attemptStartupItems);
      }
      for (AttackStep attackStep : _cacheChildrenBootOrLogonInitializationScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBootOrLogonInitializationScripts == null) {
        _cacheParentBootOrLogonInitializationScripts = new HashSet<>();
        _cacheParentBootOrLogonInitializationScripts.add(attemptBootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheParentBootOrLogonInitializationScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.bootOrLogonInitializationScripts");
    }
  }

  public class ClearMacSystemLogs extends AttackStepMax {
    private Set<AttackStep> _cacheParentClearMacSystemLogs;

    public ClearMacSystemLogs(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClearMacSystemLogs == null) {
        _cacheParentClearMacSystemLogs = new HashSet<>();
        _cacheParentClearMacSystemLogs.add(indicatorRemovalOnHost);
        _cacheParentClearMacSystemLogs.add(encryptSensitiveInformation.disable);
        _cacheParentClearMacSystemLogs.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentClearMacSystemLogs.add(remoteDataStorage.disable);
      }
      for (AttackStep attackStep : _cacheParentClearMacSystemLogs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.clearMacSystemLogs");
    }
  }

  public class CodeSigningCertificate extends AttackStepMin {
    private Set<AttackStep> _cacheParentCodeSigningCertificate;

    public CodeSigningCertificate(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCodeSigningCertificate == null) {
        _cacheParentCodeSigningCertificate = new HashSet<>();
        _cacheParentCodeSigningCertificate.add(subvertTrustControls);
      }
      for (AttackStep attackStep : _cacheParentCodeSigningCertificate) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.codeSigningCertificate");
    }
  }

  public class CommandAndScriptingInterpreter extends OS.CommandAndScriptingInterpreter {
    private Set<AttackStep> _cacheChildrenCommandAndScriptingInterpreter;

    private Set<AttackStep> _cacheParentCommandAndScriptingInterpreter;

    public CommandAndScriptingInterpreter(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCommandAndScriptingInterpreter == null) {
        _cacheChildrenCommandAndScriptingInterpreter = new HashSet<>();
        _cacheChildrenCommandAndScriptingInterpreter.add(unixShell);
        _cacheChildrenCommandAndScriptingInterpreter.add(appleScript);
      }
      for (AttackStep attackStep : _cacheChildrenCommandAndScriptingInterpreter) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCommandAndScriptingInterpreter == null) {
        _cacheParentCommandAndScriptingInterpreter = new HashSet<>();
        _cacheParentCommandAndScriptingInterpreter.add(windowsManagementInstrumentation);
      }
      for (AttackStep attackStep : _cacheParentCommandAndScriptingInterpreter) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.commandAndScriptingInterpreter");
    }
  }

  public class EventTriggeredExecution extends OS.EventTriggeredExecution {
    private Set<AttackStep> _cacheChildrenEventTriggeredExecution;

    public EventTriggeredExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenEventTriggeredExecution == null) {
        _cacheChildrenEventTriggeredExecution = new HashSet<>();
        _cacheChildrenEventTriggeredExecution.add(attemptEmond);
        _cacheChildrenEventTriggeredExecution.add(attemptBash_profileAndBashrc);
        _cacheChildrenEventTriggeredExecution.add(trap);
        _cacheChildrenEventTriggeredExecution.add(lC_LOAD_DYLIB_Addition);
      }
      for (AttackStep attackStep : _cacheChildrenEventTriggeredExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.eventTriggeredExecution");
    }
  }

  public class VisualBasic extends OS.VisualBasic {
    private Set<AttackStep> _cacheChildrenVisualBasic;

    public VisualBasic(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenVisualBasic == null) {
        _cacheChildrenVisualBasic = new HashSet<>();
        _cacheChildrenVisualBasic.add(attemptHiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenVisualBasic) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.visualBasic");
    }
  }

  public class JavaScriptOrJScript extends OS.JavaScriptOrJScript {
    private Set<AttackStep> _cacheChildrenJavaScriptOrJScript;

    public JavaScriptOrJScript(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenJavaScriptOrJScript == null) {
        _cacheChildrenJavaScriptOrJScript = new HashSet<>();
        _cacheChildrenJavaScriptOrJScript.add(attemptHiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenJavaScriptOrJScript) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.javaScriptOrJScript");
    }
  }

  public class AttemptClearCommandHistory extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptClearCommandHistory;

    private Set<AttackStep> _cacheParentAttemptClearCommandHistory;

    public AttemptClearCommandHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptClearCommandHistory == null) {
        _cacheChildrenAttemptClearCommandHistory = new HashSet<>();
        _cacheChildrenAttemptClearCommandHistory.add(clearCommandHistory);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptClearCommandHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptClearCommandHistory == null) {
        _cacheParentAttemptClearCommandHistory = new HashSet<>();
        _cacheParentAttemptClearCommandHistory.add(indicatorRemovalOnHost);
      }
      for (AttackStep attackStep : _cacheParentAttemptClearCommandHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptClearCommandHistory");
    }
  }

  public class ClearCommandHistory extends OS.ClearCommandHistory {
    private Set<AttackStep> _cacheChildrenClearCommandHistory;

    private Set<AttackStep> _cacheParentClearCommandHistory;

    public ClearCommandHistory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenClearCommandHistory == null) {
        _cacheChildrenClearCommandHistory = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenClearCommandHistory.add(((asset.MacOS) MacOS.this).bypassLogAnalysis);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenClearCommandHistory.add(((asset.MacOS) MacOS.this).bypassHostForensicAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenClearCommandHistory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClearCommandHistory == null) {
        _cacheParentClearCommandHistory = new HashSet<>();
        _cacheParentClearCommandHistory.add(attemptClearCommandHistory);
        _cacheParentClearCommandHistory.add(environmentVariablePermissions.disable);
        _cacheParentClearCommandHistory.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentClearCommandHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.clearCommandHistory");
    }
  }

  public class CreateOrModifySystemProcess extends OS.CreateOrModifySystemProcess {
    private Set<AttackStep> _cacheChildrenCreateOrModifySystemProcess;

    public CreateOrModifySystemProcess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCreateOrModifySystemProcess == null) {
        _cacheChildrenCreateOrModifySystemProcess = new HashSet<>();
        _cacheChildrenCreateOrModifySystemProcess.add(attemptLaunchAgent);
        _cacheChildrenCreateOrModifySystemProcess.add(attemptLaunchDaemon);
      }
      for (AttackStep attackStep : _cacheChildrenCreateOrModifySystemProcess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.createOrModifySystemProcess");
    }
  }

  public class CredentialsFromPasswordStores extends OS.CredentialsFromPasswordStores {
    private Set<AttackStep> _cacheChildrenCredentialsFromPasswordStores;

    public CredentialsFromPasswordStores(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCredentialsFromPasswordStores == null) {
        _cacheChildrenCredentialsFromPasswordStores = new HashSet<>();
        _cacheChildrenCredentialsFromPasswordStores.add(attemptKeychain);
        _cacheChildrenCredentialsFromPasswordStores.add(securitydMemory);
      }
      for (AttackStep attackStep : _cacheChildrenCredentialsFromPasswordStores) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.credentialsFromPasswordStores");
    }
  }

  public class Cron extends OS.Cron {
    private Set<AttackStep> _cacheChildrenCron;

    private Set<AttackStep> _cacheParentCron;

    public Cron(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCron == null) {
        _cacheChildrenCron = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenCron.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCron) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCron == null) {
        _cacheParentCron = new HashSet<>();
        _cacheParentCron.add(scheduledTaskOrJob);
        _cacheParentCron.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentCron) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.cron");
    }
  }

  public class DylibHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDylibHijacking;

    private Set<AttackStep> _cacheParentDylibHijacking;

    public DylibHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDylibHijacking == null) {
        _cacheChildrenDylibHijacking = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenDylibHijacking.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDylibHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDylibHijacking == null) {
        _cacheParentDylibHijacking = new HashSet<>();
        _cacheParentDylibHijacking.add(hijackExecutionFlow);
        _cacheParentDylibHijacking.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentDylibHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.dylibHijacking");
    }
  }

  public class AttemptElevatedExecutionWithPrompt extends OS.AttemptElevatedExecutionWithPrompt {
    private Set<AttackStep> _cacheChildrenAttemptElevatedExecutionWithPrompt;

    private Set<AttackStep> _cacheParentAttemptElevatedExecutionWithPrompt;

    public AttemptElevatedExecutionWithPrompt(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptElevatedExecutionWithPrompt == null) {
        _cacheChildrenAttemptElevatedExecutionWithPrompt = new HashSet<>();
        _cacheChildrenAttemptElevatedExecutionWithPrompt.add(elevatedExecutionWithPrompt);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptElevatedExecutionWithPrompt) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptElevatedExecutionWithPrompt == null) {
        _cacheParentAttemptElevatedExecutionWithPrompt = new HashSet<>();
        _cacheParentAttemptElevatedExecutionWithPrompt.add(abuseElevationControlMechanism);
        _cacheParentAttemptElevatedExecutionWithPrompt.add(masquerading);
      }
      for (AttackStep attackStep : _cacheParentAttemptElevatedExecutionWithPrompt) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptElevatedExecutionWithPrompt");
    }
  }

  public class ElevatedExecutionWithPrompt extends OS.ElevatedExecutionWithPrompt {
    private Set<AttackStep> _cacheChildrenElevatedExecutionWithPrompt;

    private Set<AttackStep> _cacheParentElevatedExecutionWithPrompt;

    public ElevatedExecutionWithPrompt(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenElevatedExecutionWithPrompt == null) {
        _cacheChildrenElevatedExecutionWithPrompt = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenElevatedExecutionWithPrompt.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenElevatedExecutionWithPrompt.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenElevatedExecutionWithPrompt) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentElevatedExecutionWithPrompt == null) {
        _cacheParentElevatedExecutionWithPrompt = new HashSet<>();
        _cacheParentElevatedExecutionWithPrompt.add(attemptElevatedExecutionWithPrompt);
        _cacheParentElevatedExecutionWithPrompt.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentElevatedExecutionWithPrompt) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.elevatedExecutionWithPrompt");
    }
  }

  public class AttemptEmond extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptEmond;

    private Set<AttackStep> _cacheParentAttemptEmond;

    public AttemptEmond(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptEmond == null) {
        _cacheChildrenAttemptEmond = new HashSet<>();
        _cacheChildrenAttemptEmond.add(emond);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptEmond) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptEmond == null) {
        _cacheParentAttemptEmond = new HashSet<>();
        _cacheParentAttemptEmond.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptEmond) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptEmond");
    }
  }

  public class Emond extends OS.Emond {
    private Set<AttackStep> _cacheChildrenEmond;

    private Set<AttackStep> _cacheParentEmond;

    public Emond(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenEmond == null) {
        _cacheChildrenEmond = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenEmond.add(((asset.MacOS) MacOS.this).persistence);
        }
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenEmond.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenEmond) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEmond == null) {
        _cacheParentEmond = new HashSet<>();
        _cacheParentEmond.add(attemptEmond);
        _cacheParentEmond.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentEmond) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.emond");
    }
  }

  public class FileAndDirectoryPermissionsModification extends OS.FileAndDirectoryPermissionsModification {
    private Set<AttackStep> _cacheChildrenFileAndDirectoryPermissionsModification;

    public FileAndDirectoryPermissionsModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenFileAndDirectoryPermissionsModification == null) {
        _cacheChildrenFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheChildrenFileAndDirectoryPermissionsModification.add(macFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheChildrenFileAndDirectoryPermissionsModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.fileAndDirectoryPermissionsModification");
    }
  }

  public class MacFileAndDirectoryPermissionsModification extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenMacFileAndDirectoryPermissionsModification;

    private Set<AttackStep> _cacheParentMacFileAndDirectoryPermissionsModification;

    public MacFileAndDirectoryPermissionsModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMacFileAndDirectoryPermissionsModification == null) {
        _cacheChildrenMacFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheChildrenMacFileAndDirectoryPermissionsModification.add(attemptBash_profileAndBashrc);
        _cacheChildrenMacFileAndDirectoryPermissionsModification.add(hijackExecutionFlow);
      }
      for (AttackStep attackStep : _cacheChildrenMacFileAndDirectoryPermissionsModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMacFileAndDirectoryPermissionsModification == null) {
        _cacheParentMacFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheParentMacFileAndDirectoryPermissionsModification.add(fileAndDirectoryPermissionsModification);
        _cacheParentMacFileAndDirectoryPermissionsModification.add(privilegedAccountManagement.disable);
        _cacheParentMacFileAndDirectoryPermissionsModification.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentMacFileAndDirectoryPermissionsModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.macFileAndDirectoryPermissionsModification");
    }
  }

  public class ExecuteCode extends OS.ExecuteCode {
    private Set<AttackStep> _cacheChildrenExecuteCode;

    private Set<AttackStep> _cacheParentExecuteCode;

    public ExecuteCode(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenExecuteCode == null) {
        _cacheChildrenExecuteCode = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Computer _0 : ((asset.MacOS) MacOS.this).computer) {
            _cacheChildrenExecuteCode.add(_0.infectedMacOSComputer);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExecuteCode) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecuteCode == null) {
        _cacheParentExecuteCode = new HashSet<>();
        _cacheParentExecuteCode.add(launchd);
        _cacheParentExecuteCode.add(plistModification);
        _cacheParentExecuteCode.add(source);
        _cacheParentExecuteCode.add(trap);
        _cacheParentExecuteCode.add(unixShell);
        _cacheParentExecuteCode.add(appleScript);
      }
      for (AttackStep attackStep : _cacheParentExecuteCode) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.executeCode");
    }
  }

  public class AttemptGatekeeperBypass extends OS.AttemptGatekeeperBypass {
    private Set<AttackStep> _cacheChildrenAttemptGatekeeperBypass;

    public AttemptGatekeeperBypass(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptGatekeeperBypass == null) {
        _cacheChildrenAttemptGatekeeperBypass = new HashSet<>();
        _cacheChildrenAttemptGatekeeperBypass.add(gatekeeperBypass);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptGatekeeperBypass) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptGatekeeperBypass");
    }
  }

  public class GatekeeperBypass extends OS.GatekeeperBypass {
    private Set<AttackStep> _cacheChildrenGatekeeperBypass;

    private Set<AttackStep> _cacheParentGatekeeperBypass;

    public GatekeeperBypass(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenGatekeeperBypass == null) {
        _cacheChildrenGatekeeperBypass = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenGatekeeperBypass.add(((asset.MacOS) MacOS.this).bypassApplicationControl);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenGatekeeperBypass.add(((asset.MacOS) MacOS.this).bypassAntivirus);
        }
      }
      for (AttackStep attackStep : _cacheChildrenGatekeeperBypass) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGatekeeperBypass == null) {
        _cacheParentGatekeeperBypass = new HashSet<>();
        _cacheParentGatekeeperBypass.add(attemptGatekeeperBypass);
        _cacheParentGatekeeperBypass.add(subvertTrustControls);
        _cacheParentGatekeeperBypass.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentGatekeeperBypass) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.gatekeeperBypass");
    }
  }

  public class AttemptGUIInputCapture extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptGUIInputCapture;

    private Set<AttackStep> _cacheParentAttemptGUIInputCapture;

    public AttemptGUIInputCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptGUIInputCapture == null) {
        _cacheChildrenAttemptGUIInputCapture = new HashSet<>();
        _cacheChildrenAttemptGUIInputCapture.add(gUIInputCapture);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptGUIInputCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptGUIInputCapture == null) {
        _cacheParentAttemptGUIInputCapture = new HashSet<>();
        _cacheParentAttemptGUIInputCapture.add(inputCapture);
        _cacheParentAttemptGUIInputCapture.add(appleScript);
      }
      for (AttackStep attackStep : _cacheParentAttemptGUIInputCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptGUIInputCapture");
    }
  }

  public class GUIInputCapture extends OS.GUIInputCapture {
    private Set<AttackStep> _cacheChildrenGUIInputCapture;

    private Set<AttackStep> _cacheParentGUIInputCapture;

    public GUIInputCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenGUIInputCapture == null) {
        _cacheChildrenGUIInputCapture = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (UserAccount _0 : ((asset.MacOS) MacOS.this).userAccount) {
            _cacheChildrenGUIInputCapture.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenGUIInputCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGUIInputCapture == null) {
        _cacheParentGUIInputCapture = new HashSet<>();
        _cacheParentGUIInputCapture.add(attemptGUIInputCapture);
      }
      for (AttackStep attackStep : _cacheParentGUIInputCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.gUIInputCapture");
    }
  }

  public class HideArtifacts extends OS.HideArtifacts {
    private Set<AttackStep> _cacheChildrenHideArtifacts;

    public HideArtifacts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHideArtifacts == null) {
        _cacheChildrenHideArtifacts = new HashSet<>();
        _cacheChildrenHideArtifacts.add(attemptHiddenWindow);
        _cacheChildrenHideArtifacts.add(hiddenUsers);
      }
      for (AttackStep attackStep : _cacheChildrenHideArtifacts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.hideArtifacts");
    }
  }

  public class HijackExecutionFlow extends OS.HijackExecutionFlow {
    private Set<AttackStep> _cacheChildrenHijackExecutionFlow;

    private Set<AttackStep> _cacheParentHijackExecutionFlow;

    public HijackExecutionFlow(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHijackExecutionFlow == null) {
        _cacheChildrenHijackExecutionFlow = new HashSet<>();
        _cacheChildrenHijackExecutionFlow.add(dylibHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenHijackExecutionFlow) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHijackExecutionFlow == null) {
        _cacheParentHijackExecutionFlow = new HashSet<>();
        _cacheParentHijackExecutionFlow.add(macFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheParentHijackExecutionFlow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.hijackExecutionFlow");
    }
  }

  public class IndicatorRemovalOnHost extends OS.IndicatorRemovalOnHost {
    private Set<AttackStep> _cacheChildrenIndicatorRemovalOnHost;

    private Set<AttackStep> _cacheParentIndicatorRemovalOnHost;

    public IndicatorRemovalOnHost(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenIndicatorRemovalOnHost == null) {
        _cacheChildrenIndicatorRemovalOnHost = new HashSet<>();
        _cacheChildrenIndicatorRemovalOnHost.add(clearMacSystemLogs);
        _cacheChildrenIndicatorRemovalOnHost.add(attemptClearCommandHistory);
      }
      for (AttackStep attackStep : _cacheChildrenIndicatorRemovalOnHost) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentIndicatorRemovalOnHost == null) {
        _cacheParentIndicatorRemovalOnHost = new HashSet<>();
        _cacheParentIndicatorRemovalOnHost.add(bashHistory);
      }
      for (AttackStep attackStep : _cacheParentIndicatorRemovalOnHost) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.indicatorRemovalOnHost");
    }
  }

  public class InputCapture extends OS.InputCapture {
    private Set<AttackStep> _cacheChildrenInputCapture;

    public InputCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenInputCapture == null) {
        _cacheChildrenInputCapture = new HashSet<>();
        _cacheChildrenInputCapture.add(attemptGUIInputCapture);
      }
      for (AttackStep attackStep : _cacheChildrenInputCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.inputCapture");
    }
  }

  public class HiddenUsers extends OS.HiddenUsers {
    private Set<AttackStep> _cacheChildrenHiddenUsers;

    private Set<AttackStep> _cacheParentHiddenUsers;

    public HiddenUsers(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHiddenUsers == null) {
        _cacheChildrenHiddenUsers = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (AdminAccount _0 : ((asset.MacOS) MacOS.this).adminAccount) {
            _cacheChildrenHiddenUsers.add(_0.attemptCreateAccount);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenHiddenUsers) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHiddenUsers == null) {
        _cacheParentHiddenUsers = new HashSet<>();
        _cacheParentHiddenUsers.add(hideArtifacts);
        _cacheParentHiddenUsers.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentHiddenUsers) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.hiddenUsers");
    }
  }

  public class AttemptHiddenWindow extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptHiddenWindow;

    private Set<AttackStep> _cacheParentAttemptHiddenWindow;

    public AttemptHiddenWindow(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptHiddenWindow == null) {
        _cacheChildrenAttemptHiddenWindow = new HashSet<>();
        _cacheChildrenAttemptHiddenWindow.add(hiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptHiddenWindow) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptHiddenWindow == null) {
        _cacheParentAttemptHiddenWindow = new HashSet<>();
        _cacheParentAttemptHiddenWindow.add(visualBasic);
        _cacheParentAttemptHiddenWindow.add(javaScriptOrJScript);
        _cacheParentAttemptHiddenWindow.add(hideArtifacts);
      }
      for (AttackStep attackStep : _cacheParentAttemptHiddenWindow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptHiddenWindow");
    }
  }

  public class HiddenWindow extends OS.HiddenWindow {
    private Set<AttackStep> _cacheParentHiddenWindow;

    public HiddenWindow(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHiddenWindow == null) {
        _cacheParentHiddenWindow = new HashSet<>();
        _cacheParentHiddenWindow.add(attemptHiddenWindow);
        _cacheParentHiddenWindow.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentHiddenWindow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.hiddenWindow");
    }
  }

  public class HISTCONTROL extends OS.HISTCONTROL {
    private Set<AttackStep> _cacheChildrenHISTCONTROL;

    private Set<AttackStep> _cacheParentHISTCONTROL;

    public HISTCONTROL(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHISTCONTROL == null) {
        _cacheChildrenHISTCONTROL = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenHISTCONTROL.add(((asset.MacOS) MacOS.this).bypassLogAnalysis);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenHISTCONTROL.add(((asset.MacOS) MacOS.this).bypassHostForensicAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenHISTCONTROL) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHISTCONTROL == null) {
        _cacheParentHISTCONTROL = new HashSet<>();
        _cacheParentHISTCONTROL.add(impareDefenses);
        _cacheParentHISTCONTROL.add(environmentVariablePermissions.disable);
        _cacheParentHISTCONTROL.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentHISTCONTROL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.hISTCONTROL");
    }
  }

  public class ImpareDefenses extends OS.ImpareDefenses {
    private Set<AttackStep> _cacheChildrenImpareDefenses;

    public ImpareDefenses(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenImpareDefenses == null) {
        _cacheChildrenImpareDefenses = new HashSet<>();
        _cacheChildrenImpareDefenses.add(hISTCONTROL);
      }
      for (AttackStep attackStep : _cacheChildrenImpareDefenses) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.impareDefenses");
    }
  }

  public class InfectedOS extends OS.InfectedOS {
    private Set<AttackStep> _cacheChildrenInfectedOS;

    public InfectedOS(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenInfectedOS == null) {
        _cacheChildrenInfectedOS = new HashSet<>();
        _cacheChildrenInfectedOS.add(attemptBashHistory);
      }
      for (AttackStep attackStep : _cacheChildrenInfectedOS) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.infectedOS");
    }
  }

  public class InvalidCodeSignature extends AttackStepMax {
    private Set<AttackStep> _cacheParentInvalidCodeSignature;

    public InvalidCodeSignature(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInvalidCodeSignature == null) {
        _cacheParentInvalidCodeSignature = new HashSet<>();
        _cacheParentInvalidCodeSignature.add(masquerading);
        _cacheParentInvalidCodeSignature.add(codeSigning.disable);
      }
      for (AttackStep attackStep : _cacheParentInvalidCodeSignature) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.invalidCodeSignature");
    }
  }

  public class KernelModulesAndExtensions extends OS.KernelModulesAndExtensions {
    private Set<AttackStep> _cacheChildrenKernelModulesAndExtensions;

    private Set<AttackStep> _cacheParentKernelModulesAndExtensions;

    public KernelModulesAndExtensions(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenKernelModulesAndExtensions == null) {
        _cacheChildrenKernelModulesAndExtensions = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenKernelModulesAndExtensions.add(((asset.MacOS) MacOS.this).rootkit);
        }
      }
      for (AttackStep attackStep : _cacheChildrenKernelModulesAndExtensions) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentKernelModulesAndExtensions == null) {
        _cacheParentKernelModulesAndExtensions = new HashSet<>();
        _cacheParentKernelModulesAndExtensions.add(bootOrLogonAutostartExecution);
        _cacheParentKernelModulesAndExtensions.add(antivirus.disable);
        _cacheParentKernelModulesAndExtensions.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentKernelModulesAndExtensions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.kernelModulesAndExtensions");
    }
  }

  public class AttemptLaunchAgent extends OS.AttemptLaunchAgent {
    private Set<AttackStep> _cacheChildrenAttemptLaunchAgent;

    private Set<AttackStep> _cacheParentAttemptLaunchAgent;

    public AttemptLaunchAgent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptLaunchAgent == null) {
        _cacheChildrenAttemptLaunchAgent = new HashSet<>();
        _cacheChildrenAttemptLaunchAgent.add(launchAgent);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLaunchAgent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLaunchAgent == null) {
        _cacheParentAttemptLaunchAgent = new HashSet<>();
        _cacheParentAttemptLaunchAgent.add(createOrModifySystemProcess);
        _cacheParentAttemptLaunchAgent.add(launchctl);
        _cacheParentAttemptLaunchAgent.add(launchDaemon);
      }
      for (AttackStep attackStep : _cacheParentAttemptLaunchAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptLaunchAgent");
    }
  }

  public class LaunchAgent extends OS.LaunchAgent {
    private Set<AttackStep> _cacheChildrenLaunchAgent;

    private Set<AttackStep> _cacheParentLaunchAgent;

    public LaunchAgent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLaunchAgent == null) {
        _cacheChildrenLaunchAgent = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenLaunchAgent.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenLaunchAgent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchAgent == null) {
        _cacheParentLaunchAgent = new HashSet<>();
        _cacheParentLaunchAgent.add(attemptLaunchAgent);
      }
      for (AttackStep attackStep : _cacheParentLaunchAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.launchAgent");
    }
  }

  public class Launchctl extends OS.Launchctl {
    private Set<AttackStep> _cacheChildrenLaunchctl;

    private Set<AttackStep> _cacheParentLaunchctl;

    public Launchctl(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLaunchctl == null) {
        _cacheChildrenLaunchctl = new HashSet<>();
        _cacheChildrenLaunchctl.add(attemptLaunchAgent);
        _cacheChildrenLaunchctl.add(attemptLaunchDaemon);
      }
      for (AttackStep attackStep : _cacheChildrenLaunchctl) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchctl == null) {
        _cacheParentLaunchctl = new HashSet<>();
        _cacheParentLaunchctl.add(systemServices);
      }
      for (AttackStep attackStep : _cacheParentLaunchctl) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.launchctl");
    }
  }

  public class Launchd extends OS.Launchd {
    private Set<AttackStep> _cacheChildrenLaunchd;

    private Set<AttackStep> _cacheParentLaunchd;

    public Launchd(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLaunchd == null) {
        _cacheChildrenLaunchd = new HashSet<>();
        _cacheChildrenLaunchd.add(executeCode);
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenLaunchd.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenLaunchd) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchd == null) {
        _cacheParentLaunchd = new HashSet<>();
        _cacheParentLaunchd.add(scheduledTaskOrJob);
        _cacheParentLaunchd.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentLaunchd) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.launchd");
    }
  }

  public class AttemptLaunchDaemon extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptLaunchDaemon;

    private Set<AttackStep> _cacheParentAttemptLaunchDaemon;

    public AttemptLaunchDaemon(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptLaunchDaemon == null) {
        _cacheChildrenAttemptLaunchDaemon = new HashSet<>();
        _cacheChildrenAttemptLaunchDaemon.add(launchDaemon);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLaunchDaemon) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLaunchDaemon == null) {
        _cacheParentAttemptLaunchDaemon = new HashSet<>();
        _cacheParentAttemptLaunchDaemon.add(createOrModifySystemProcess);
        _cacheParentAttemptLaunchDaemon.add(launchctl);
      }
      for (AttackStep attackStep : _cacheParentAttemptLaunchDaemon) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptLaunchDaemon");
    }
  }

  public class LaunchDaemon extends OS.LaunchDaemon {
    private Set<AttackStep> _cacheChildrenLaunchDaemon;

    private Set<AttackStep> _cacheParentLaunchDaemon;

    public LaunchDaemon(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLaunchDaemon == null) {
        _cacheChildrenLaunchDaemon = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenLaunchDaemon.add(((asset.MacOS) MacOS.this).persistence);
        }
        _cacheChildrenLaunchDaemon.add(attemptLaunchAgent);
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenLaunchDaemon.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenLaunchDaemon) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchDaemon == null) {
        _cacheParentLaunchDaemon = new HashSet<>();
        _cacheParentLaunchDaemon.add(attemptLaunchDaemon);
      }
      for (AttackStep attackStep : _cacheParentLaunchDaemon) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.launchDaemon");
    }
  }

  public class LC_LOAD_DYLIB_Addition extends OS.LC_LOAD_DYLIB_Addition {
    private Set<AttackStep> _cacheChildrenLC_LOAD_DYLIB_Addition;

    private Set<AttackStep> _cacheParentLC_LOAD_DYLIB_Addition;

    public LC_LOAD_DYLIB_Addition(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLC_LOAD_DYLIB_Addition == null) {
        _cacheChildrenLC_LOAD_DYLIB_Addition = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenLC_LOAD_DYLIB_Addition.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenLC_LOAD_DYLIB_Addition) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLC_LOAD_DYLIB_Addition == null) {
        _cacheParentLC_LOAD_DYLIB_Addition = new HashSet<>();
        _cacheParentLC_LOAD_DYLIB_Addition.add(eventTriggeredExecution);
        _cacheParentLC_LOAD_DYLIB_Addition.add(audit.disable);
        _cacheParentLC_LOAD_DYLIB_Addition.add(codeSigning.disable);
        _cacheParentLC_LOAD_DYLIB_Addition.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentLC_LOAD_DYLIB_Addition) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.lC_LOAD_DYLIB_Addition");
    }
  }

  public class AttemptLogonScripts extends OS.AttemptLogonScripts {
    private Set<AttackStep> _cacheChildrenAttemptLogonScripts;

    private Set<AttackStep> _cacheParentAttemptLogonScripts;

    public AttemptLogonScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptLogonScripts == null) {
        _cacheChildrenAttemptLogonScripts = new HashSet<>();
        _cacheChildrenAttemptLogonScripts.add(logonScripts);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLogonScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLogonScripts == null) {
        _cacheParentAttemptLogonScripts = new HashSet<>();
        _cacheParentAttemptLogonScripts.add(bootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheParentAttemptLogonScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptLogonScripts");
    }
  }

  public class LogonScripts extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenLogonScripts;

    private Set<AttackStep> _cacheParentLogonScripts;

    public LogonScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLogonScripts == null) {
        _cacheChildrenLogonScripts = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (AdminAccount _0 : ((asset.MacOS) MacOS.this).adminAccount) {
            _cacheChildrenLogonScripts.add(_0.adminRights);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenLogonScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLogonScripts == null) {
        _cacheParentLogonScripts = new HashSet<>();
        _cacheParentLogonScripts.add(attemptLogonScripts);
        _cacheParentLogonScripts.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentLogonScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.logonScripts");
    }
  }

  public class Masquerading extends OS.Masquerading {
    private Set<AttackStep> _cacheChildrenMasquerading;

    public Masquerading(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenMasquerading == null) {
        _cacheChildrenMasquerading = new HashSet<>();
        _cacheChildrenMasquerading.add(invalidCodeSignature);
        _cacheChildrenMasquerading.add(attemptElevatedExecutionWithPrompt);
      }
      for (AttackStep attackStep : _cacheChildrenMasquerading) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.masquerading");
    }
  }

  public class ModifyAuthenticationProcess extends OS.ModifyAuthenticationProcess {
    private Set<AttackStep> _cacheChildrenModifyAuthenticationProcess;

    public ModifyAuthenticationProcess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenModifyAuthenticationProcess == null) {
        _cacheChildrenModifyAuthenticationProcess = new HashSet<>();
        _cacheChildrenModifyAuthenticationProcess.add(pluggableAuthenticationModules);
      }
      for (AttackStep attackStep : _cacheChildrenModifyAuthenticationProcess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.modifyAuthenticationProcess");
    }
  }

  public class ObfuscatedFilesOrInformation extends OS.ObfuscatedFilesOrInformation {
    private Set<AttackStep> _cacheChildrenObfuscatedFilesOrInformation;

    public ObfuscatedFilesOrInformation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenObfuscatedFilesOrInformation == null) {
        _cacheChildrenObfuscatedFilesOrInformation = new HashSet<>();
        _cacheChildrenObfuscatedFilesOrInformation.add(attemptSoftwarePacking);
      }
      for (AttackStep attackStep : _cacheChildrenObfuscatedFilesOrInformation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.obfuscatedFilesOrInformation");
    }
  }

  public class AttemptPlistModification extends OS.AttemptPlistModification {
    private Set<AttackStep> _cacheChildrenAttemptPlistModification;

    private Set<AttackStep> _cacheParentAttemptPlistModification;

    public AttemptPlistModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptPlistModification == null) {
        _cacheChildrenAttemptPlistModification = new HashSet<>();
        _cacheChildrenAttemptPlistModification.add(plistModification);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPlistModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPlistModification == null) {
        _cacheParentAttemptPlistModification = new HashSet<>();
        _cacheParentAttemptPlistModification.add(bootOrLogonAutostartExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptPlistModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptPlistModification");
    }
  }

  public class PlistModification extends OS.PlistModification {
    private Set<AttackStep> _cacheChildrenPlistModification;

    private Set<AttackStep> _cacheParentPlistModification;

    public PlistModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPlistModification == null) {
        _cacheChildrenPlistModification = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenPlistModification.add(((asset.MacOS) MacOS.this).bypassApplicationWhitelisting);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenPlistModification.add(((asset.MacOS) MacOS.this).bypassProcessWhitelisting);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenPlistModification.add(((asset.MacOS) MacOS.this).bypassFileOrPathWhitelisting);
        }
        _cacheChildrenPlistModification.add(executeCode);
        _cacheChildrenPlistModification.add(reopenedApplications);
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenPlistModification.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenPlistModification.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPlistModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPlistModification == null) {
        _cacheParentPlistModification = new HashSet<>();
        _cacheParentPlistModification.add(attemptPlistModification);
        _cacheParentPlistModification.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentPlistModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.plistModification");
    }
  }

  public class PluggableAuthenticationModules extends OS.PluggableAuthenticationModules {
    private Set<AttackStep> _cacheParentPluggableAuthenticationModules;

    public PluggableAuthenticationModules(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPluggableAuthenticationModules == null) {
        _cacheParentPluggableAuthenticationModules = new HashSet<>();
        _cacheParentPluggableAuthenticationModules.add(modifyAuthenticationProcess);
        _cacheParentPluggableAuthenticationModules.add(multiFactorAuthentication.disable);
        _cacheParentPluggableAuthenticationModules.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentPluggableAuthenticationModules) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.pluggableAuthenticationModules");
    }
  }

  public class PortKnocking extends OS.PortKnocking {
    private Set<AttackStep> _cacheChildrenPortKnocking;

    public PortKnocking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPortKnocking == null) {
        _cacheChildrenPortKnocking = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenPortKnocking.add(((asset.MacOS) MacOS.this).bypassDefensiveNetworkServiceScanning);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPortKnocking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.portKnocking");
    }
  }

  public class Rc_common extends OS.Rc_common {
    private Set<AttackStep> _cacheChildrenRc_common;

    private Set<AttackStep> _cacheParentRc_common;

    public Rc_common(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRc_common == null) {
        _cacheChildrenRc_common = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenRc_common.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenRc_common) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRc_common == null) {
        _cacheParentRc_common = new HashSet<>();
        _cacheParentRc_common.add(bootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheParentRc_common) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.rc_common");
    }
  }

  public class ReopenedApplications extends OS.ReopenedApplications {
    private Set<AttackStep> _cacheChildrenReopenedApplications;

    private Set<AttackStep> _cacheParentReopenedApplications;

    public ReopenedApplications(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenReopenedApplications == null) {
        _cacheChildrenReopenedApplications = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenReopenedApplications.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenReopenedApplications) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentReopenedApplications == null) {
        _cacheParentReopenedApplications = new HashSet<>();
        _cacheParentReopenedApplications.add(bootOrLogonAutostartExecution);
        _cacheParentReopenedApplications.add(plistModification);
        _cacheParentReopenedApplications.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentReopenedApplications) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.reopenedApplications");
    }
  }

  public class ScheduledTaskOrJob extends OS.ScheduledTaskOrJob {
    private Set<AttackStep> _cacheChildrenScheduledTaskOrJob;

    public ScheduledTaskOrJob(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenScheduledTaskOrJob == null) {
        _cacheChildrenScheduledTaskOrJob = new HashSet<>();
        _cacheChildrenScheduledTaskOrJob.add(cron);
        _cacheChildrenScheduledTaskOrJob.add(launchd);
      }
      for (AttackStep attackStep : _cacheChildrenScheduledTaskOrJob) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.scheduledTaskOrJob");
    }
  }

  public class SecuritydMemory extends OS.SecuritydMemory {
    private Set<AttackStep> _cacheChildrenSecuritydMemory;

    private Set<AttackStep> _cacheParentSecuritydMemory;

    public SecuritydMemory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSecuritydMemory == null) {
        _cacheChildrenSecuritydMemory = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (UserAccount _0 : ((asset.MacOS) MacOS.this).userAccount) {
            _cacheChildrenSecuritydMemory.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSecuritydMemory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSecuritydMemory == null) {
        _cacheParentSecuritydMemory = new HashSet<>();
        _cacheParentSecuritydMemory.add(credentialsFromPasswordStores);
      }
      for (AttackStep attackStep : _cacheParentSecuritydMemory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.securitydMemory");
    }
  }

  public class AttemptSetuidAndSetgid extends OS.AttemptSetuidAndSetgid {
    private Set<AttackStep> _cacheChildrenAttemptSetuidAndSetgid;

    private Set<AttackStep> _cacheParentAttemptSetuidAndSetgid;

    public AttemptSetuidAndSetgid(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSetuidAndSetgid == null) {
        _cacheChildrenAttemptSetuidAndSetgid = new HashSet<>();
        _cacheChildrenAttemptSetuidAndSetgid.add(setuidAndSetgid);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSetuidAndSetgid) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSetuidAndSetgid == null) {
        _cacheParentAttemptSetuidAndSetgid = new HashSet<>();
        _cacheParentAttemptSetuidAndSetgid.add(abuseElevationControlMechanism);
      }
      for (AttackStep attackStep : _cacheParentAttemptSetuidAndSetgid) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptSetuidAndSetgid");
    }
  }

  public class SetuidAndSetgid extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSetuidAndSetgid;

    private Set<AttackStep> _cacheParentSetuidAndSetgid;

    public SetuidAndSetgid(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSetuidAndSetgid == null) {
        _cacheChildrenSetuidAndSetgid = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenSetuidAndSetgid.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenSetuidAndSetgid.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSetuidAndSetgid) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSetuidAndSetgid == null) {
        _cacheParentSetuidAndSetgid = new HashSet<>();
        _cacheParentSetuidAndSetgid.add(attemptSetuidAndSetgid);
        _cacheParentSetuidAndSetgid.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentSetuidAndSetgid) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.setuidAndSetgid");
    }
  }

  public class AttemptSoftwarePacking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSoftwarePacking;

    private Set<AttackStep> _cacheParentAttemptSoftwarePacking;

    public AttemptSoftwarePacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSoftwarePacking == null) {
        _cacheChildrenAttemptSoftwarePacking = new HashSet<>();
        _cacheChildrenAttemptSoftwarePacking.add(softwarePacking);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSoftwarePacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSoftwarePacking == null) {
        _cacheParentAttemptSoftwarePacking = new HashSet<>();
        _cacheParentAttemptSoftwarePacking.add(obfuscatedFilesOrInformation);
      }
      for (AttackStep attackStep : _cacheParentAttemptSoftwarePacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptSoftwarePacking");
    }
  }

  public class SoftwarePacking extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSoftwarePacking;

    private Set<AttackStep> _cacheParentSoftwarePacking;

    public SoftwarePacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSoftwarePacking == null) {
        _cacheChildrenSoftwarePacking = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenSoftwarePacking.add(((asset.MacOS) MacOS.this).indicatorRemovalFromTools);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenSoftwarePacking.add(((asset.MacOS) MacOS.this).bypassSignatureBasedDetection);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenSoftwarePacking.add(((asset.MacOS) MacOS.this).bypassAntivirus);
        }
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenSoftwarePacking.add(((asset.MacOS) MacOS.this).bypassHeuristicDetection);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSoftwarePacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSoftwarePacking == null) {
        _cacheParentSoftwarePacking = new HashSet<>();
        _cacheParentSoftwarePacking.add(attemptSoftwarePacking);
        _cacheParentSoftwarePacking.add(antivirus.disable);
      }
      for (AttackStep attackStep : _cacheParentSoftwarePacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.softwarePacking");
    }
  }

  public class Source extends OS.Source {
    private Set<AttackStep> _cacheChildrenSource;

    public Source(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSource == null) {
        _cacheChildrenSource = new HashSet<>();
        _cacheChildrenSource.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenSource) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.source");
    }
  }

  public class SystemServices extends OS.SystemServices {
    private Set<AttackStep> _cacheChildrenSystemServices;

    public SystemServices(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSystemServices == null) {
        _cacheChildrenSystemServices = new HashSet<>();
        _cacheChildrenSystemServices.add(launchctl);
      }
      for (AttackStep attackStep : _cacheChildrenSystemServices) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.systemServices");
    }
  }

  public class SSH extends OS.SSH {
    private Set<AttackStep> _cacheChildrenSSH;

    private Set<AttackStep> _cacheParentSSH;

    public SSH(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSSH == null) {
        _cacheChildrenSSH = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Computer _0 : ((asset.MacOS) MacOS.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenSSH.add(_2.c2Connected);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSSH) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSH == null) {
        _cacheParentSSH = new HashSet<>();
        _cacheParentSSH.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentSSH.add(multiFactorAuthentication.disable);
      }
      for (AttackStep attackStep : _cacheParentSSH) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.sSH");
    }
  }

  public class AttemptSSHAuthorizedKeys extends OS.AttemptSSHAuthorizedKeys {
    private Set<AttackStep> _cacheChildrenAttemptSSHAuthorizedKeys;

    private Set<AttackStep> _cacheParentAttemptSSHAuthorizedKeys;

    public AttemptSSHAuthorizedKeys(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSSHAuthorizedKeys == null) {
        _cacheChildrenAttemptSSHAuthorizedKeys = new HashSet<>();
        _cacheChildrenAttemptSSHAuthorizedKeys.add(sSHAuthorizedKeys);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSSHAuthorizedKeys) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSSHAuthorizedKeys == null) {
        _cacheParentAttemptSSHAuthorizedKeys = new HashSet<>();
        _cacheParentAttemptSSHAuthorizedKeys.add(accountManipulation);
      }
      for (AttackStep attackStep : _cacheParentAttemptSSHAuthorizedKeys) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptSSHAuthorizedKeys");
    }
  }

  public class SSHAuthorizedKeys extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSSHAuthorizedKeys;

    private Set<AttackStep> _cacheParentSSHAuthorizedKeys;

    public SSHAuthorizedKeys(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSSHAuthorizedKeys == null) {
        _cacheChildrenSSHAuthorizedKeys = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenSSHAuthorizedKeys.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSSHAuthorizedKeys) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSHAuthorizedKeys == null) {
        _cacheParentSSHAuthorizedKeys = new HashSet<>();
        _cacheParentSSHAuthorizedKeys.add(attemptSSHAuthorizedKeys);
        _cacheParentSSHAuthorizedKeys.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentSSHAuthorizedKeys.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSSHAuthorizedKeys) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.sSHAuthorizedKeys");
    }
  }

  public class SSHHijacking extends OS.SSHHijacking {
    private Set<AttackStep> _cacheChildrenSSHHijacking;

    private Set<AttackStep> _cacheParentSSHHijacking;

    public SSHHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSSHHijacking == null) {
        _cacheChildrenSSHHijacking = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenSSHHijacking.add(((asset.MacOS) MacOS.this).sSHCredentialInterception);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSSHHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSHHijacking == null) {
        _cacheParentSSHHijacking = new HashSet<>();
        _cacheParentSSHHijacking.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentSSHHijacking.add(passwordPolicies.disable);
        _cacheParentSSHHijacking.add(privilegedAccountManagement.disable);
        _cacheParentSSHHijacking.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSSHHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.sSHHijacking");
    }
  }

  public class SubvertTrustControls extends OS.SubvertTrustControls {
    private Set<AttackStep> _cacheChildrenSubvertTrustControls;

    public SubvertTrustControls(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSubvertTrustControls == null) {
        _cacheChildrenSubvertTrustControls = new HashSet<>();
        _cacheChildrenSubvertTrustControls.add(codeSigningCertificate);
        _cacheChildrenSubvertTrustControls.add(gatekeeperBypass);
      }
      for (AttackStep attackStep : _cacheChildrenSubvertTrustControls) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.subvertTrustControls");
    }
  }

  public class AttemptSudoAndSudoCaching extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSudoAndSudoCaching;

    public AttemptSudoAndSudoCaching(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSudoAndSudoCaching == null) {
        _cacheChildrenAttemptSudoAndSudoCaching = new HashSet<>();
        _cacheChildrenAttemptSudoAndSudoCaching.add(sudoAndSudoCaching);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSudoAndSudoCaching) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptSudoAndSudoCaching");
    }
  }

  public class SudoAndSudoCaching extends OS.SudoAndSudoCaching {
    private Set<AttackStep> _cacheChildrenSudoAndSudoCaching;

    private Set<AttackStep> _cacheParentSudoAndSudoCaching;

    public SudoAndSudoCaching(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSudoAndSudoCaching == null) {
        _cacheChildrenSudoAndSudoCaching = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenSudoAndSudoCaching.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSudoAndSudoCaching) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSudoAndSudoCaching == null) {
        _cacheParentSudoAndSudoCaching = new HashSet<>();
        _cacheParentSudoAndSudoCaching.add(abuseElevationControlMechanism);
        _cacheParentSudoAndSudoCaching.add(attemptSudoAndSudoCaching);
        _cacheParentSudoAndSudoCaching.add(operatingSystemConfiguration.disable);
        _cacheParentSudoAndSudoCaching.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSudoAndSudoCaching) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.sudoAndSudoCaching");
    }
  }

  public class Trap extends OS.Trap {
    private Set<AttackStep> _cacheChildrenTrap;

    private Set<AttackStep> _cacheParentTrap;

    public Trap(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTrap == null) {
        _cacheChildrenTrap = new HashSet<>();
        _cacheChildrenTrap.add(executeCode);
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenTrap.add(((asset.MacOS) MacOS.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenTrap) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTrap == null) {
        _cacheParentTrap = new HashSet<>();
        _cacheParentTrap.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentTrap) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.trap");
    }
  }

  public class VideoCapture extends OS.VideoCapture {
    private Set<AttackStep> _cacheChildrenVideoCapture;

    public VideoCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenVideoCapture == null) {
        _cacheChildrenVideoCapture = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Computer _0 : ((asset.MacOS) MacOS.this).computer) {
            _cacheChildrenVideoCapture.add(_0.collectVideo);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenVideoCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.videoCapture");
    }
  }

  public class SpaceAfterFileName extends OS.SpaceAfterFileName {
    private Set<AttackStep> _cacheChildrenSpaceAfterFileName;

    public SpaceAfterFileName(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSpaceAfterFileName == null) {
        _cacheChildrenSpaceAfterFileName = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Computer _0 : ((asset.MacOS) MacOS.this).computer) {
            for (User _1 : _0.user) {
              _cacheChildrenSpaceAfterFileName.add(_1.attemptUserExecution);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSpaceAfterFileName) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.spaceAfterFileName");
    }
  }

  public class NetworkShareDiscovery extends OS.NetworkShareDiscovery {
    private Set<AttackStep> _cacheChildrenNetworkShareDiscovery;

    private Set<AttackStep> _cacheParentNetworkShareDiscovery;

    public NetworkShareDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenNetworkShareDiscovery == null) {
        _cacheChildrenNetworkShareDiscovery = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (Computer _0 : ((asset.MacOS) MacOS.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenNetworkShareDiscovery.add(_2.networkShareDiscovery);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenNetworkShareDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkShareDiscovery == null) {
        _cacheParentNetworkShareDiscovery = new HashSet<>();
        _cacheParentNetworkShareDiscovery.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentNetworkShareDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.networkShareDiscovery");
    }
  }

  public class UnixShell extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenUnixShell;

    private Set<AttackStep> _cacheParentUnixShell;

    public UnixShell(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUnixShell == null) {
        _cacheChildrenUnixShell = new HashSet<>();
        _cacheChildrenUnixShell.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenUnixShell) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUnixShell == null) {
        _cacheParentUnixShell = new HashSet<>();
        _cacheParentUnixShell.add(commandAndScriptingInterpreter);
        _cacheParentUnixShell.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentUnixShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.unixShell");
    }
  }

  public class UnsecuredCredentials extends OS.UnsecuredCredentials {
    private Set<AttackStep> _cacheChildrenUnsecuredCredentials;

    public UnsecuredCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenUnsecuredCredentials == null) {
        _cacheChildrenUnsecuredCredentials = new HashSet<>();
        _cacheChildrenUnsecuredCredentials.add(bashHistory);
      }
      for (AttackStep attackStep : _cacheChildrenUnsecuredCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.unsecuredCredentials");
    }
  }

  public class WindowsManagementInstrumentation extends OS.WindowsManagementInstrumentation {
    private Set<AttackStep> _cacheChildrenWindowsManagementInstrumentation;

    public WindowsManagementInstrumentation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWindowsManagementInstrumentation == null) {
        _cacheChildrenWindowsManagementInstrumentation = new HashSet<>();
        _cacheChildrenWindowsManagementInstrumentation.add(commandAndScriptingInterpreter);
      }
      for (AttackStep attackStep : _cacheChildrenWindowsManagementInstrumentation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.windowsManagementInstrumentation");
    }
  }

  public class AttemptKeychain extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptKeychain;

    private Set<AttackStep> _cacheParentAttemptKeychain;

    public AttemptKeychain(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptKeychain == null) {
        _cacheChildrenAttemptKeychain = new HashSet<>();
        _cacheChildrenAttemptKeychain.add(keychain);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptKeychain) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptKeychain == null) {
        _cacheParentAttemptKeychain = new HashSet<>();
        _cacheParentAttemptKeychain.add(credentialsFromPasswordStores);
      }
      for (AttackStep attackStep : _cacheParentAttemptKeychain) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptKeychain");
    }
  }

  public class Keychain extends OS.Keychain {
    private Set<AttackStep> _cacheChildrenKeychain;

    private Set<AttackStep> _cacheParentKeychain;

    public Keychain(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenKeychain == null) {
        _cacheChildrenKeychain = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          for (UserAccount _0 : ((asset.MacOS) MacOS.this).userAccount) {
            _cacheChildrenKeychain.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenKeychain) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentKeychain == null) {
        _cacheParentKeychain = new HashSet<>();
        _cacheParentKeychain.add(attemptKeychain);
        _cacheParentKeychain.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentKeychain) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.keychain");
    }
  }

  public class AppleScript extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenAppleScript;

    private Set<AttackStep> _cacheParentAppleScript;

    public AppleScript(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAppleScript == null) {
        _cacheChildrenAppleScript = new HashSet<>();
        _cacheChildrenAppleScript.add(executeCode);
        _cacheChildrenAppleScript.add(attemptGUIInputCapture);
      }
      for (AttackStep attackStep : _cacheChildrenAppleScript) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAppleScript == null) {
        _cacheParentAppleScript = new HashSet<>();
        _cacheParentAppleScript.add(commandAndScriptingInterpreter);
        _cacheParentAppleScript.add(codeSigning.disable);
        _cacheParentAppleScript.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentAppleScript) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.appleScript");
    }
  }

  public class AttemptStartupItems extends OS.AttemptStartupItems {
    private Set<AttackStep> _cacheChildrenAttemptStartupItems;

    private Set<AttackStep> _cacheParentAttemptStartupItems;

    public AttemptStartupItems(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptStartupItems == null) {
        _cacheChildrenAttemptStartupItems = new HashSet<>();
        _cacheChildrenAttemptStartupItems.add(startupItems);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptStartupItems) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptStartupItems == null) {
        _cacheParentAttemptStartupItems = new HashSet<>();
        _cacheParentAttemptStartupItems.add(bootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheParentAttemptStartupItems) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.attemptStartupItems");
    }
  }

  public class StartupItems extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenStartupItems;

    private Set<AttackStep> _cacheParentStartupItems;

    public StartupItems(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenStartupItems == null) {
        _cacheChildrenStartupItems = new HashSet<>();
        if (MacOS.this instanceof MacOS) {
          _cacheChildrenStartupItems.add(((asset.MacOS) MacOS.this).persistence);
        }
        if (MacOS.this instanceof MacOS) {
          for (Service _0 : ((asset.MacOS) MacOS.this).service) {
            _cacheChildrenStartupItems.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenStartupItems) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentStartupItems == null) {
        _cacheParentStartupItems = new HashSet<>();
        _cacheParentStartupItems.add(attemptStartupItems);
        _cacheParentStartupItems.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentStartupItems) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("MacOS.startupItems");
    }
  }

  public class Antivirus extends OS.Antivirus {
    public Antivirus(String name) {
      this(name, false);
    }

    public Antivirus(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.Antivirus.Disable {
      private Set<AttackStep> _cacheChildrenAntivirus;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenAntivirus == null) {
          _cacheChildrenAntivirus = new HashSet<>();
          _cacheChildrenAntivirus.add(kernelModulesAndExtensions);
          _cacheChildrenAntivirus.add(softwarePacking);
        }
        for (AttackStep attackStep : _cacheChildrenAntivirus) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.antivirus";
      }
    }
  }

  public class Audit extends OS.Audit {
    public Audit(String name) {
      this(name, false);
    }

    public Audit(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.Audit.Disable {
      private Set<AttackStep> _cacheChildrenAudit;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenAudit == null) {
          _cacheChildrenAudit = new HashSet<>();
          _cacheChildrenAudit.add(lC_LOAD_DYLIB_Addition);
          _cacheChildrenAudit.add(cron);
          _cacheChildrenAudit.add(launchd);
        }
        for (AttackStep attackStep : _cacheChildrenAudit) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.audit";
      }
    }
  }

  public class CodeSigning extends OS.CodeSigning {
    public CodeSigning(String name) {
      this(name, false);
    }

    public CodeSigning(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.CodeSigning.Disable {
      private Set<AttackStep> _cacheChildrenCodeSigning;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenCodeSigning == null) {
          _cacheChildrenCodeSigning = new HashSet<>();
          _cacheChildrenCodeSigning.add(appleScript);
          _cacheChildrenCodeSigning.add(invalidCodeSignature);
          _cacheChildrenCodeSigning.add(lC_LOAD_DYLIB_Addition);
        }
        for (AttackStep attackStep : _cacheChildrenCodeSigning) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.codeSigning";
      }
    }
  }

  public class DisableOrRemoveFeatureOrProgram extends OS.DisableOrRemoveFeatureOrProgram {
    public DisableOrRemoveFeatureOrProgram(String name) {
      this(name, false);
    }

    public DisableOrRemoveFeatureOrProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.DisableOrRemoveFeatureOrProgram.Disable {
      private Set<AttackStep> _cacheChildrenDisableOrRemoveFeatureOrProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenDisableOrRemoveFeatureOrProgram == null) {
          _cacheChildrenDisableOrRemoveFeatureOrProgram = new HashSet<>();
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(emond);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(reopenedApplications);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(sSH);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(sSHAuthorizedKeys);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(sSHHijacking);
        }
        for (AttackStep attackStep : _cacheChildrenDisableOrRemoveFeatureOrProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.disableOrRemoveFeatureOrProgram";
      }
    }
  }

  public class ExecutionPrevention extends OS.ExecutionPrevention {
    public ExecutionPrevention(String name) {
      this(name, false);
    }

    public ExecutionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.ExecutionPrevention.Disable {
      private Set<AttackStep> _cacheChildrenExecutionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenExecutionPrevention == null) {
          _cacheChildrenExecutionPrevention = new HashSet<>();
          _cacheChildrenExecutionPrevention.add(appleScript);
          _cacheChildrenExecutionPrevention.add(elevatedExecutionWithPrompt);
          _cacheChildrenExecutionPrevention.add(gatekeeperBypass);
          _cacheChildrenExecutionPrevention.add(hiddenWindow);
          _cacheChildrenExecutionPrevention.add(kernelModulesAndExtensions);
          _cacheChildrenExecutionPrevention.add(lC_LOAD_DYLIB_Addition);
          _cacheChildrenExecutionPrevention.add(networkShareDiscovery);
          _cacheChildrenExecutionPrevention.add(unixShell);
        }
        for (AttackStep attackStep : _cacheChildrenExecutionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.executionPrevention";
      }
    }
  }

  public class EncryptSensitiveInformation extends OS.EncryptSensitiveInformation {
    public EncryptSensitiveInformation(String name) {
      this(name, false);
    }

    public EncryptSensitiveInformation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.EncryptSensitiveInformation.Disable {
      private Set<AttackStep> _cacheChildrenEncryptSensitiveInformation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenEncryptSensitiveInformation == null) {
          _cacheChildrenEncryptSensitiveInformation = new HashSet<>();
          _cacheChildrenEncryptSensitiveInformation.add(clearMacSystemLogs);
        }
        for (AttackStep attackStep : _cacheChildrenEncryptSensitiveInformation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.encryptSensitiveInformation";
      }
    }
  }

  public class EnvironmentVariablePermissions extends Defense {
    public EnvironmentVariablePermissions(String name) {
      this(name, false);
    }

    public EnvironmentVariablePermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenEnvironmentVariablePermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenEnvironmentVariablePermissions == null) {
          _cacheChildrenEnvironmentVariablePermissions = new HashSet<>();
          _cacheChildrenEnvironmentVariablePermissions.add(clearCommandHistory);
          _cacheChildrenEnvironmentVariablePermissions.add(hISTCONTROL);
        }
        for (AttackStep attackStep : _cacheChildrenEnvironmentVariablePermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.environmentVariablePermissions";
      }
    }
  }

  public class MultiFactorAuthentication extends OS.MultiFactorAuthentication {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.MultiFactorAuthentication.Disable {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(pluggableAuthenticationModules);
          _cacheChildrenMultiFactorAuthentication.add(sSH);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.multiFactorAuthentication";
      }
    }
  }

  public class OperatingSystemConfiguration extends OS.OperatingSystemConfiguration {
    public OperatingSystemConfiguration(String name) {
      this(name, false);
    }

    public OperatingSystemConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.OperatingSystemConfiguration.Disable {
      private Set<AttackStep> _cacheChildrenOperatingSystemConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenOperatingSystemConfiguration == null) {
          _cacheChildrenOperatingSystemConfiguration = new HashSet<>();
          _cacheChildrenOperatingSystemConfiguration.add(bashHistory);
          _cacheChildrenOperatingSystemConfiguration.add(hiddenUsers);
          _cacheChildrenOperatingSystemConfiguration.add(hISTCONTROL);
          _cacheChildrenOperatingSystemConfiguration.add(setuidAndSetgid);
          _cacheChildrenOperatingSystemConfiguration.add(sudoAndSudoCaching);
        }
        for (AttackStep attackStep : _cacheChildrenOperatingSystemConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.operatingSystemConfiguration";
      }
    }
  }

  public class PasswordPolicies extends OS.PasswordPolicies {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.PasswordPolicies.Disable {
      private Set<AttackStep> _cacheChildrenPasswordPolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPasswordPolicies == null) {
          _cacheChildrenPasswordPolicies = new HashSet<>();
          _cacheChildrenPasswordPolicies.add(keychain);
          _cacheChildrenPasswordPolicies.add(sSHHijacking);
        }
        for (AttackStep attackStep : _cacheChildrenPasswordPolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.passwordPolicies";
      }
    }
  }

  public class PrivilegedAccountManagement extends OS.PrivilegedAccountManagement {
    public PrivilegedAccountManagement(String name) {
      this(name, false);
    }

    public PrivilegedAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.PrivilegedAccountManagement.Disable {
      private Set<AttackStep> _cacheChildrenPrivilegedAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPrivilegedAccountManagement == null) {
          _cacheChildrenPrivilegedAccountManagement = new HashSet<>();
          _cacheChildrenPrivilegedAccountManagement.add(sSHHijacking);
          _cacheChildrenPrivilegedAccountManagement.add(macFileAndDirectoryPermissionsModification);
          _cacheChildrenPrivilegedAccountManagement.add(pluggableAuthenticationModules);
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.privilegedAccountManagement";
      }
    }
  }

  public class RestrictFileAndDirectoryPermissions extends OS.RestrictFileAndDirectoryPermissions {
    public RestrictFileAndDirectoryPermissions(String name) {
      this(name, false);
    }

    public RestrictFileAndDirectoryPermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.RestrictFileAndDirectoryPermissions.Disable {
      private Set<AttackStep> _cacheChildrenRestrictFileAndDirectoryPermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenRestrictFileAndDirectoryPermissions == null) {
          _cacheChildrenRestrictFileAndDirectoryPermissions = new HashSet<>();
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(bash_profileAndBashrc);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(clearCommandHistory);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(clearMacSystemLogs);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(dylibHijacking);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(logonScripts);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(plistModification);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(sSHAuthorizedKeys);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(sSHHijacking);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(startupItems);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(sudoAndSudoCaching);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(macFileAndDirectoryPermissionsModification);
        }
        for (AttackStep attackStep : _cacheChildrenRestrictFileAndDirectoryPermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.restrictFileAndDirectoryPermissions";
      }
    }
  }

  public class RemoteDataStorage extends OS.RemoteDataStorage {
    public RemoteDataStorage(String name) {
      this(name, false);
    }

    public RemoteDataStorage(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.RemoteDataStorage.Disable {
      private Set<AttackStep> _cacheChildrenRemoteDataStorage;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenRemoteDataStorage == null) {
          _cacheChildrenRemoteDataStorage = new HashSet<>();
          _cacheChildrenRemoteDataStorage.add(clearMacSystemLogs);
        }
        for (AttackStep attackStep : _cacheChildrenRemoteDataStorage) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "MacOS.remoteDataStorage";
      }
    }
  }
}
