package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class OS extends Asset {
  public AttemptBITSJobs attemptBITSJobs;

  public AttemptAppCertDLLs attemptAppCertDLLs;

  public AppCertDLLs appCertDLLs;

  public BypassUserAccessControl bypassUserAccessControl;

  public ChangeDefaultFileAssociation changeDefaultFileAssociation;

  public AttemptGatekeeperBypass attemptGatekeeperBypass;

  public GatekeeperBypass gatekeeperBypass;

  public Cmstp cmstp;

  public CompiledHTMLFile compiledHTMLFile;

  public COR_PROFILER cOR_PROFILER;

  public ComponentObjectModelHijacking componentObjectModelHijacking;

  public ControlPanel controlPanel;

  public CredentialsInRegistry credentialsInRegistry;

  public DeobfuscateOrDecodeFilesOrInformation deobfuscateOrDecodeFilesOrInformation;

  public DLLSearchOrderHijacking dLLSearchOrderHijacking;

  public DomainTrustDiscovery domainTrustDiscovery;

  public DynamicDataExchange dynamicDataExchange;

  public Mshta mshta;

  public WindowsRemoteManagement windowsRemoteManagement;

  public _etc_passwdAND_etc_shadow _etc_passwdAND_etc_shadow;

  public AccessibilityFeatures accessibilityFeatures;

  public AppInitDLLs appInitDLLs;

  public ApplicationShimming applicationShimming;

  public At at;

  public AttemptBootkit attemptBootkit;

  public AttemptElevatedExecutionWithPrompt attemptElevatedExecutionWithPrompt;

  public AttemptLSASSDriver attemptLSASSDriver;

  public AttemptLSASSMemory attemptLSASSMemory;

  public AttemptPasswordFilterDLL attemptPasswordFilterDLL;

  public AttemptServiceExecution attemptServiceExecution;

  public AttemptServiceRegistryPermissionsWeakness attemptServiceRegistryPermissionsWeakness;

  public AttemptServicesFilePermissionsWeakness attemptServicesFilePermissionsWeakness;

  public AttemptSIDHistoryInjection attemptSIDHistoryInjection;

  public AttemptSIPAndTrustProviderHijacking attemptSIPAndTrustProviderHijacking;

  public AttemptSQLStoredProcedures attemptSQLStoredProcedures;

  public AttemptStartupItems attemptStartupItems;

  public AttemptSystemFirmware attemptSystemFirmware;

  public AttemptTimeProviders attemptTimeProviders;

  public AttemptTransportAgent attemptTransportAgent;

  public AttemptWinlogonHelperDLL attemptWinlogonHelperDLL;

  public AttemptWindowsRemoteManagement attemptWindowsRemoteManagement;

  public WinlogonHelperDLL winlogonHelperDLL;

  public AuthenticationPackage authenticationPackage;

  public Bootkit bootkit;

  public ClearWindowsEventLogs clearWindowsEventLogs;

  public ComponentFirmware componentFirmware;

  public CredentialAPIHooking credentialAPIHooking;

  public DCShadow dCShadow;

  public DCSync dCSync;

  public DisableWindowsEventLogging disableWindowsEventLogging;

  public DomainControllerAuthentication domainControllerAuthentication;

  public Emond emond;

  public ExchangeEmailDelegatePermissions exchangeEmailDelegatePermissions;

  public FileSystemLogicalOffsets fileSystemLogicalOffsets;

  public HiddenUsers hiddenUsers;

  public ImageFileExecutionOptionsInjection imageFileExecutionOptionsInjection;

  public KernelModulesAndExtensions kernelModulesAndExtensions;

  public Keychain keychain;

  public Launchd launchd;

  public LaunchDaemon launchDaemon;

  public LSASSDriver lSASSDriver;

  public NetshHelperDLL netshHelperDLL;

  public PasswordFilterDLL passwordFilterDLL;

  public PluggableAuthenticationModules pluggableAuthenticationModules;

  public PortMonitors portMonitors;

  public AttemptPowerShell attemptPowerShell;

  public PowerShell powerShell;

  public AttemptPowerShellAdminProfile attemptPowerShellAdminProfile;

  public PowerShellAdminProfile powerShellAdminProfile;

  public ProcFilesystem procFilesystem;

  public QueryRegistry queryRegistry;

  public Rc_common rc_common;

  public RemoteScheduledTask remoteScheduledTask;

  public ScheduledTask scheduledTask;

  public SecuritydMemory securitydMemory;

  public SecuritySupportProvider securitySupportProvider;

  public ServiceExecution serviceExecution;

  public SQLStoredProcedures sQLStoredProcedures;

  public SystemFirmware systemFirmware;

  public TransportAgent transportAgent;

  public AttemptWindowsAdminShares attemptWindowsAdminShares;

  public AttemptExecutionThroughAPI attemptExecutionThroughAPI;

  public AttemptAccessTokenManipulation attemptAccessTokenManipulation;

  public AccessTokenManipulation accessTokenManipulation;

  public AttemptControlPanel attemptControlPanel;

  public AttemptDistributedComponentObjectModel attemptDistributedComponentObjectModel;

  public AttemptLaunchAgent attemptLaunchAgent;

  public LaunchAgent launchAgent;

  public AttemptAccessibilityFeatures attemptAccessibilityFeatures;

  public AttemptLogonScripts attemptLogonScripts;

  public AttemptPlistModification attemptPlistModification;

  public AttemptRemoteDesktopProtocol attemptRemoteDesktopProtocol;

  public AttemptServiceStop attemptServiceStop;

  public AttemptSetuidAndSetgid attemptSetuidAndSetgid;

  public AttemptShortcutModification attemptShortcutModification;

  public ShortcutModification shortcutModification;

  public AttemptSSHAuthorizedKeys attemptSSHAuthorizedKeys;

  public AttemptTaintSharedContent attemptTaintSharedContent;

  public Bash_profileAndBashrc bash_profileAndBashrc;

  public BashHistory bashHistory;

  public BITSJobs bITSJobs;

  public CachedDomainCredentials cachedDomainCredentials;

  public ClearCommandHistory clearCommandHistory;

  public Cron cron;

  public DistributedComponentObjectModel distributedComponentObjectModel;

  public ElevatedExecutionWithPrompt elevatedExecutionWithPrompt;

  public EmailCollection emailCollection;

  public ExecutableInstallerFilePermissionsWeakness executableInstallerFilePermissionsWeakness;

  public ExecutionThroughModuleLoad executionThroughModuleLoad;

  public ForcedAuthentication forcedAuthentication;

  public GoldenTicket goldenTicket;

  public GroupPolicyModification groupPolicyModification;

  public GroupPolicyPreferences groupPolicyPreferences;

  public GUIInputCapture gUIInputCapture;

  public HiddenWindow hiddenWindow;

  public HISTCONTROL hISTCONTROL;

  public IndirectCommandExecution indirectCommandExecution;

  public InstallUtil installUtil;

  public Launchctl launchctl;

  public LC_LOAD_DYLIB_Addition lC_LOAD_DYLIB_Addition;

  public LLMNR_NBT_NS_PoisoningAndSMBRelay lLMNR_NBT_NS_PoisoningAndSMBRelay;

  public LSASecrets lSASecrets;

  public LSASSMemory lSASSMemory;

  public ManInTheBrowser manInTheBrowser;

  public MasqueradeTaskOrService masqueradeTaskOrService;

  public ModifyRegistry modifyRegistry;

  public Msiexec msiexec;

  public NetworkShareConnectionRemoval networkShareConnectionRemoval;

  public NetworkShareDiscovery networkShareDiscovery;

  public NTDS nTDS;

  public Odbcconf odbcconf;

  public ParentPIDSpoofing parentPIDSpoofing;

  public PathInterceptionBySearchOrderHijacking pathInterceptionBySearchOrderHijacking;

  public PeripheralDeviceDiscovery peripheralDeviceDiscovery;

  public PlistModification plistModification;

  public PortableExecutableInjection portableExecutableInjection;

  public PortKnocking portKnocking;

  public PowerShellUserProfile powerShellUserProfile;

  public ProcessDoppelganging processDoppelganging;

  public ProcessHollowing processHollowing;

  public PubPrn pubPrn;

  public RDPHijacking rDPHijacking;

  public RegistryRunKeysOrStartupFolder registryRunKeysOrStartupFolder;

  public RegsvcsOrRegasm regsvcsOrRegasm;

  public Regsvr32 regsvr32;

  public RemoteDesktopProtocol remoteDesktopProtocol;

  public ReopenedApplications reopenedApplications;

  public Rundll32 rundll32;

  public Screensaver screensaver;

  public SecurityAccountManager securityAccountManager;

  public ServicesFilePermissionsWeakness servicesFilePermissionsWeakness;

  public ServicesRegistryPermissionsWeakness servicesRegistryPermissionsWeakness;

  public ServiceStop serviceStop;

  public SignedScriptProxyExecution signedScriptProxyExecution;

  public SilverTicket silverTicket;

  public SIPAndTrustProviderHijacking sIPAndTrustProviderHijacking;

  public Source source;

  public SpaceAfterFileName spaceAfterFileName;

  public SSH sSH;

  public SSHHijacking sSHHijacking;

  public SudoAndSudoCaching sudoAndSudoCaching;

  public SystemdService systemdService;

  public SystemServiceDiscovery systemServiceDiscovery;

  public TemplateInjection templateInjection;

  public ThreadExecutionHijacking threadExecutionHijacking;

  public Trap trap;

  public TrustedDeveloperUtilities trustedDeveloperUtilities;

  public VideoCapture videoCapture;

  public WindowsAdminShares windowsAdminShares;

  public WindowsManagementInstrumentation windowsManagementInstrumentation;

  public AttemptWindowsManagementInstrumentationEventSubscription attemptWindowsManagementInstrumentationEventSubscription;

  public WindowsManagementInstrumentationEventSubscription windowsManagementInstrumentationEventSubscription;

  public XslScriptProcessing xslScriptProcessing;

  public AccountManipulation accountManipulation;

  public ArchiveCollectedData archiveCollectedData;

  public ArchiveViaUtility archiveViaUtility;

  public ArchiveViaLibrary archiveViaLibrary;

  public ArchiveViaCustomMethod archiveViaCustomMethod;

  public AbuseElevationControlMechanism abuseElevationControlMechanism;

  public AccountAccessRemoval accountAccessRemoval;

  public BootOrLogonAutostartExecution bootOrLogonAutostartExecution;

  public InfectedOS infectedOS;

  public ClipboardData clipboardData;

  public AccountDiscovery accountDiscovery;

  public AttemptDomainAccount attemptDomainAccount;

  public DomainAccount domainAccount;

  public AttemptLocalAccount attemptLocalAccount;

  public LocalAccount localAccount;

  public CommandAndScriptingInterpreter commandAndScriptingInterpreter;

  public VisualBasic visualBasic;

  public Python python;

  public JavaScriptOrJScript javaScriptOrJScript;

  public CreateOrModifySystemProcess createOrModifySystemProcess;

  public CredentialsFromPasswordStores credentialsFromPasswordStores;

  public DataManipulation dataManipulation;

  public DataFromLocalSystem dataFromLocalSystem;

  public Defacement defacement;

  public DomainDiscovery domainDiscovery;

  public DomainGenerationAlgorithms domainGenerationAlgorithms;

  public CompromisedDataOrSystem compromisedDataOrSystem;

  public AttemptBinaryPadding attemptBinaryPadding;

  public BinaryPadding binaryPadding;

  public ApplicationWindowDiscovery applicationWindowDiscovery;

  public ProcessDiscovery processDiscovery;

  public CollectHashInformation collectHashInformation;

  public CompileAfterDelivery compileAfterDelivery;

  public OSCredentialDumping oSCredentialDumping;

  public AttemptEncryptedChannel attemptEncryptedChannel;

  public EncryptedChannel encryptedChannel;

  public DataEncoding dataEncoding;

  public StandardEncoding standardEncoding;

  public NonStandardEncoding nonStandardEncoding;

  public DynamicResolution dynamicResolution;

  public FastFluxDNS fastFluxDNS;

  public DNSCalculation dNSCalculation;

  public ExecuteCode executeCode;

  public AttemptEndpointDenialOfService attemptEndpointDenialOfService;

  public EndpointDenialOfService endpointDenialOfService;

  public ApplicationExhaustionFlood applicationExhaustionFlood;

  public OSExhaustionFlood oSExhaustionFlood;

  public ServiceExhaustionFlood serviceExhaustionFlood;

  public ApplicationOrSystemExploitation applicationOrSystemExploitation;

  public EventTriggeredExecution eventTriggeredExecution;

  public ExecutionGuardrails executionGuardrails;

  public EnvironmentalKeying environmentalKeying;

  public PayloadDelivery payloadDelivery;

  public ExfiltrationOverOtherNetworkMedium exfiltrationOverOtherNetworkMedium;

  public ExfiltrationOverBluetooth exfiltrationOverBluetooth;

  public FallbackChannels fallbackChannels;

  public FirmwareCorruption firmwareCorruption;

  public HideArtifacts hideArtifacts;

  public HiddenFileSystem hiddenFileSystem;

  public RunVirtualInstance runVirtualInstance;

  public HiddenFilesAndDirectories hiddenFilesAndDirectories;

  public HijackExecutionFlow hijackExecutionFlow;

  public IndicatorRemovalFromTools indicatorRemovalFromTools;

  public IndicatorRemovalOnHost indicatorRemovalOnHost;

  public Timestomp timestomp;

  public InputCapture inputCapture;

  public Keylogging keylogging;

  public LateralToolTransfer lateralToolTransfer;

  public WebPortalCapture webPortalCapture;

  public InternalSpearphishing internalSpearphishing;

  public AttemptDynamicDataExchange attemptDynamicDataExchange;

  public ManInTheMiddle manInTheMiddle;

  public Masquerading masquerading;

  public ModifyAuthenticationProcess modifyAuthenticationProcess;

  public RightToLeftOverride rightToLeftOverride;

  public RenameSystemUtilities renameSystemUtilities;

  public MatchLegitimateNameOrLocation matchLegitimateNameOrLocation;

  public Proxy proxy;

  public InternalProxy internalProxy;

  public ExternalProxy externalProxy;

  public AttemptMultiHopProxy attemptMultiHopProxy;

  public MultiHopProxy multiHopProxy;

  public DomainFronting domainFronting;

  public AttemptMultiStageChannels attemptMultiStageChannels;

  public MultiStageChannels multiStageChannels;

  public NetworkDenialOfService networkDenialOfService;

  public DirectNetworkFlood directNetworkFlood;

  public ReflectionAmplification reflectionAmplification;

  public NetworkSniffing networkSniffing;

  public ObfuscatedFilesOrInformation obfuscatedFilesOrInformation;

  public Steganography steganography;

  public AttemptPrivateKeys attemptPrivateKeys;

  public PrivateKeys privateKeys;

  public PrivateKeysWithPassphrase privateKeysWithPassphrase;

  public ResourceHijacking resourceHijacking;

  public CommunicationThroughRemovableMedia communicationThroughRemovableMedia;

  public RemoteSystemDiscovery remoteSystemDiscovery;

  public DetailedRemoteSystemDiscovery detailedRemoteSystemDiscovery;

  public FileAndDirectoryPermissionsModification fileAndDirectoryPermissionsModification;

  public ImpareDefenses impareDefenses;

  public AttemptDisableOrModifyTools attemptDisableOrModifyTools;

  public DisableOrModifyTools disableOrModifyTools;

  public DisableOrModifySystemFirewall disableOrModifySystemFirewall;

  public AttemptIndicatorBlocking attemptIndicatorBlocking;

  public IndicatorBlocking indicatorBlocking;

  public ScheduledTaskOrJob scheduledTaskOrJob;

  public ServerSoftwareComponent serverSoftwareComponent;

  public SoftwareDiscovery softwareDiscovery;

  public SecuritySoftwareDiscovery securitySoftwareDiscovery;

  public SystemAccess systemAccess;

  public SystemInformationDiscovery systemInformationDiscovery;

  public SystemNetworkConnectionsDiscovery systemNetworkConnectionsDiscovery;

  public SystemOwnerOrUserDiscovery systemOwnerOrUserDiscovery;

  public SystemServices systemServices;

  public SystemShutdownOrReboot systemShutdownOrReboot;

  public ProcessInjection processInjection;

  public AttemptProtocolTunneling attemptProtocolTunneling;

  public ProtocolTunneling protocolTunneling;

  public Rootkit rootkit;

  public RuntimeDataManipulation runtimeDataManipulation;

  public AttemptApplicationLayerProtocol attemptApplicationLayerProtocol;

  public ApplicationLayerProtocol applicationLayerProtocol;

  public AttemptNonApplicationLayerProtocol attemptNonApplicationLayerProtocol;

  public NonApplicationLayerProtocol nonApplicationLayerProtocol;

  public WebProtocols webProtocols;

  public FileTransferProtocols fileTransferProtocols;

  public MailProtocols mailProtocols;

  public DNS dNS;

  public SystemNetworkConfigurationDiscovery systemNetworkConfigurationDiscovery;

  public TwoFactorAuthenticationInterception twoFactorAuthenticationInterception;

  public ModifyAPICalls modifyAPICalls;

  public BypassAntivirus bypassAntivirus;

  public BypassAutorunsAnalysis bypassAutorunsAnalysis;

  public BypassApplicationControl bypassApplicationControl;

  public BypassApplicationWhitelisting bypassApplicationWhitelisting;

  public BypassBinaryAnalysis bypassBinaryAnalysis;

  public BypassDefensiveNetworkServiceScanning bypassDefensiveNetworkServiceScanning;

  public BypassDigitalCertificateValidation bypassDigitalCertificateValidation;

  public BypassEgressFiltering bypassEgressFiltering;

  public BypassFileMonitoring bypassFileMonitoring;

  public BypassFileOrPathWhitelisting bypassFileOrPathWhitelisting;

  public BypassFileSystemAccessControls bypassFileSystemAccessControls;

  public BypassHeuristicDetection bypassHeuristicDetection;

  public BypassHostForensicAnalysis bypassHostForensicAnalysis;

  public BypassHostIntrusionPrevention bypassHostIntrusionPrevention;

  public BypassProcessWhitelisting bypassProcessWhitelisting;

  public BypassSystemAccessControls bypassSystemAccessControls;

  public BypassLogAnalysis bypassLogAnalysis;

  public BypassSignatureBasedDetection bypassSignatureBasedDetection;

  public BypassStaticFileAnalysis bypassStaticFileAnalysis;

  public BypassUserModeSignatureValidation bypassUserModeSignatureValidation;

  public PasswordPolicyDiscovery passwordPolicyDiscovery;

  public BruteForceWithPasswordPolicy bruteForceWithPasswordPolicy;

  public BruteForce bruteForce;

  public PassTheHash passTheHash;

  public PassTheTicket passTheTicket;

  public PasswordGuessing passwordGuessing;

  public AttemptPasswordCracking attemptPasswordCracking;

  public PasswordCracking passwordCracking;

  public PasswordSpraying passwordSpraying;

  public CredentialStuffing credentialStuffing;

  public PermissionGroupsDiscovery permissionGroupsDiscovery;

  public LocalGroups localGroups;

  public DomainGroups domainGroups;

  public PreOSBoot preOSBoot;

  public AttemptAntivirusCheck attemptAntivirusCheck;

  public AntivirusCheck antivirusCheck;

  public Persistence persistence;

  public SSHCredentialInterception sSHCredentialInterception;

  public StoredDataManipulation storedDataManipulation;

  public NonStandardPort nonStandardPort;

  public SubvertTrustControls subvertTrustControls;

  public InstallRootCertificate installRootCertificate;

  public UnsecuredCredentials unsecuredCredentials;

  public AttemptCredentialsInFiles attemptCredentialsInFiles;

  public CredentialsInFiles credentialsInFiles;

  public ValidAccounts validAccounts;

  public DefaultAccounts defaultAccounts;

  public AttemptDomainAccounts attemptDomainAccounts;

  public DomainAccounts domainAccounts;

  public AttemptLocalAccounts attemptLocalAccounts;

  public LocalAccounts localAccounts;

  public VirtualizationOrSandboxEvasion virtualizationOrSandboxEvasion;

  public SystemChecks systemChecks;

  public UserActivityBasedChecks userActivityBasedChecks;

  public TimeBasedEvasion timeBasedEvasion;

  public VNC vNC;

  public FileDeletion fileDeletion;

  public FileAndDirectoryDiscovery fileAndDirectoryDiscovery;

  public DiskWipe diskWipe;

  public DiskContentWipe diskContentWipe;

  public DiskStructureWipe diskStructureWipe;

  public RemoteFileCopy remoteFileCopy;

  public SensitiveDataCollected sensitiveDataCollected;

  public DataCollected dataCollected;

  public DataEncrypted dataEncrypted;

  public DataSizedTransfer dataSizedTransfer;

  public DataStaged dataStaged;

  public LocalDataStaging localDataStaging;

  public ReplicationThroughRemovableMedia replicationThroughRemovableMedia;

  public RemoteDataStaging remoteDataStaging;

  public AttemptDataDestruction attemptDataDestruction;

  public DataDestruction dataDestruction;

  public AttemptDataEncryptedForImpact attemptDataEncryptedForImpact;

  public DataEncryptedForImpact dataEncryptedForImpact;

  public DataCompressed dataCompressed;

  public InhibitSystemRecovery inhibitSystemRecovery;

  public ScreenCapture screenCapture;

  public ScheduledExfiltration scheduledExfiltration;

  public AttemptExfiltrationOverAternativeProtocol attemptExfiltrationOverAternativeProtocol;

  public ExfiltrationOverAternativeProtocol exfiltrationOverAternativeProtocol;

  public ExfiltrationOverAsymmetricEncryptedNonC2Protocol exfiltrationOverAsymmetricEncryptedNonC2Protocol;

  public ExfiltrationOverSymmetricEncryptedNonC2Protocol exfiltrationOverSymmetricEncryptedNonC2Protocol;

  public ExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol;

  public DataFromInformationRepositories dataFromInformationRepositories;

  public Confluence confluence;

  public Sharepoint sharepoint;

  public WindowsService windowsService;

  public AttemptAutomatedCollection attemptAutomatedCollection;

  public AutomatedCollection automatedCollection;

  public AutomatedExfiltration automatedExfiltration;

  public NetworkServiceScan networkServiceScan;

  public Antivirus antivirus;

  public RestrictFileAndDirectoryPermissions restrictFileAndDirectoryPermissions;

  public RestrictRegistryPermissions restrictRegistryPermissions;

  public AccountUsePolicies accountUsePolicies;

  public BehaviorPreventionOnEndpoint behaviorPreventionOnEndpoint;

  public BootIntegrity bootIntegrity;

  public DataBackup dataBackup;

  public MultiFactorAuthentication multiFactorAuthentication;

  public PasswordPolicies passwordPolicies;

  public ApplicationIsolationAndSandboxing applicationIsolationAndSandboxing;

  public DoNotMitigate doNotMitigate;

  public DisableOrRemoveFeatureOrProgram disableOrRemoveFeatureOrProgram;

  public ActiveDirectoryConfiguration activeDirectoryConfiguration;

  public Audit audit;

  public ApplicationDeveloperGuidance applicationDeveloperGuidance;

  public CodeSigning codeSigning;

  public LimitHardwareInstallation limitHardwareInstallation;

  public OperatingSystemConfiguration operatingSystemConfiguration;

  public SoftwareConfiguration softwareConfiguration;

  public ExecutionPrevention executionPrevention;

  public PrivilegedAccountManagement privilegedAccountManagement;

  public EncryptSensitiveInformation encryptSensitiveInformation;

  public RemoteDataStorage remoteDataStorage;

  public LimitSoftwareInstallation limitSoftwareInstallation;

  public UpdateSoftware updateSoftware;

  public UserAccountControl userAccountControl;

  public ExploitProtection exploitProtection;

  public Set<UserAccount> userAccount = new HashSet<>();

  public Set<AdminAccount> adminAccount = new HashSet<>();

  public Set<Service> service = new HashSet<>();

  public Set<Computer> computer = new HashSet<>();

  public OS(String name, boolean isAntivirusEnabled,
      boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled) {
    super(name);
    assetClassName = "OS";
    AttackStep.allAttackSteps.remove(attemptBITSJobs);
    attemptBITSJobs = new AttemptBITSJobs(name);
    AttackStep.allAttackSteps.remove(attemptAppCertDLLs);
    attemptAppCertDLLs = new AttemptAppCertDLLs(name);
    AttackStep.allAttackSteps.remove(appCertDLLs);
    appCertDLLs = new AppCertDLLs(name);
    AttackStep.allAttackSteps.remove(bypassUserAccessControl);
    bypassUserAccessControl = new BypassUserAccessControl(name);
    AttackStep.allAttackSteps.remove(changeDefaultFileAssociation);
    changeDefaultFileAssociation = new ChangeDefaultFileAssociation(name);
    AttackStep.allAttackSteps.remove(attemptGatekeeperBypass);
    attemptGatekeeperBypass = new AttemptGatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(gatekeeperBypass);
    gatekeeperBypass = new GatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(cmstp);
    cmstp = new Cmstp(name);
    AttackStep.allAttackSteps.remove(compiledHTMLFile);
    compiledHTMLFile = new CompiledHTMLFile(name);
    AttackStep.allAttackSteps.remove(cOR_PROFILER);
    cOR_PROFILER = new COR_PROFILER(name);
    AttackStep.allAttackSteps.remove(componentObjectModelHijacking);
    componentObjectModelHijacking = new ComponentObjectModelHijacking(name);
    AttackStep.allAttackSteps.remove(controlPanel);
    controlPanel = new ControlPanel(name);
    AttackStep.allAttackSteps.remove(credentialsInRegistry);
    credentialsInRegistry = new CredentialsInRegistry(name);
    AttackStep.allAttackSteps.remove(deobfuscateOrDecodeFilesOrInformation);
    deobfuscateOrDecodeFilesOrInformation = new DeobfuscateOrDecodeFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(dLLSearchOrderHijacking);
    dLLSearchOrderHijacking = new DLLSearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(domainTrustDiscovery);
    domainTrustDiscovery = new DomainTrustDiscovery(name);
    AttackStep.allAttackSteps.remove(dynamicDataExchange);
    dynamicDataExchange = new DynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(mshta);
    mshta = new Mshta(name);
    AttackStep.allAttackSteps.remove(windowsRemoteManagement);
    windowsRemoteManagement = new WindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(_etc_passwdAND_etc_shadow);
    _etc_passwdAND_etc_shadow = new _etc_passwdAND_etc_shadow(name);
    AttackStep.allAttackSteps.remove(accessibilityFeatures);
    accessibilityFeatures = new AccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(appInitDLLs);
    appInitDLLs = new AppInitDLLs(name);
    AttackStep.allAttackSteps.remove(applicationShimming);
    applicationShimming = new ApplicationShimming(name);
    AttackStep.allAttackSteps.remove(at);
    at = new At(name);
    AttackStep.allAttackSteps.remove(attemptBootkit);
    attemptBootkit = new AttemptBootkit(name);
    AttackStep.allAttackSteps.remove(attemptElevatedExecutionWithPrompt);
    attemptElevatedExecutionWithPrompt = new AttemptElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(attemptLSASSDriver);
    attemptLSASSDriver = new AttemptLSASSDriver(name);
    AttackStep.allAttackSteps.remove(attemptLSASSMemory);
    attemptLSASSMemory = new AttemptLSASSMemory(name);
    AttackStep.allAttackSteps.remove(attemptPasswordFilterDLL);
    attemptPasswordFilterDLL = new AttemptPasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(attemptServiceExecution);
    attemptServiceExecution = new AttemptServiceExecution(name);
    AttackStep.allAttackSteps.remove(attemptServiceRegistryPermissionsWeakness);
    attemptServiceRegistryPermissionsWeakness = new AttemptServiceRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptServicesFilePermissionsWeakness);
    attemptServicesFilePermissionsWeakness = new AttemptServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptSIDHistoryInjection);
    attemptSIDHistoryInjection = new AttemptSIDHistoryInjection(name);
    AttackStep.allAttackSteps.remove(attemptSIPAndTrustProviderHijacking);
    attemptSIPAndTrustProviderHijacking = new AttemptSIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(attemptSQLStoredProcedures);
    attemptSQLStoredProcedures = new AttemptSQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(attemptStartupItems);
    attemptStartupItems = new AttemptStartupItems(name);
    AttackStep.allAttackSteps.remove(attemptSystemFirmware);
    attemptSystemFirmware = new AttemptSystemFirmware(name);
    AttackStep.allAttackSteps.remove(attemptTimeProviders);
    attemptTimeProviders = new AttemptTimeProviders(name);
    AttackStep.allAttackSteps.remove(attemptTransportAgent);
    attemptTransportAgent = new AttemptTransportAgent(name);
    AttackStep.allAttackSteps.remove(attemptWinlogonHelperDLL);
    attemptWinlogonHelperDLL = new AttemptWinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(attemptWindowsRemoteManagement);
    attemptWindowsRemoteManagement = new AttemptWindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(winlogonHelperDLL);
    winlogonHelperDLL = new WinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(authenticationPackage);
    authenticationPackage = new AuthenticationPackage(name);
    AttackStep.allAttackSteps.remove(bootkit);
    bootkit = new Bootkit(name);
    AttackStep.allAttackSteps.remove(clearWindowsEventLogs);
    clearWindowsEventLogs = new ClearWindowsEventLogs(name);
    AttackStep.allAttackSteps.remove(componentFirmware);
    componentFirmware = new ComponentFirmware(name);
    AttackStep.allAttackSteps.remove(credentialAPIHooking);
    credentialAPIHooking = new CredentialAPIHooking(name);
    AttackStep.allAttackSteps.remove(dCShadow);
    dCShadow = new DCShadow(name);
    AttackStep.allAttackSteps.remove(dCSync);
    dCSync = new DCSync(name);
    AttackStep.allAttackSteps.remove(disableWindowsEventLogging);
    disableWindowsEventLogging = new DisableWindowsEventLogging(name);
    AttackStep.allAttackSteps.remove(domainControllerAuthentication);
    domainControllerAuthentication = new DomainControllerAuthentication(name);
    AttackStep.allAttackSteps.remove(emond);
    emond = new Emond(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(fileSystemLogicalOffsets);
    fileSystemLogicalOffsets = new FileSystemLogicalOffsets(name);
    AttackStep.allAttackSteps.remove(hiddenUsers);
    hiddenUsers = new HiddenUsers(name);
    AttackStep.allAttackSteps.remove(imageFileExecutionOptionsInjection);
    imageFileExecutionOptionsInjection = new ImageFileExecutionOptionsInjection(name);
    AttackStep.allAttackSteps.remove(kernelModulesAndExtensions);
    kernelModulesAndExtensions = new KernelModulesAndExtensions(name);
    AttackStep.allAttackSteps.remove(keychain);
    keychain = new Keychain(name);
    AttackStep.allAttackSteps.remove(launchd);
    launchd = new Launchd(name);
    AttackStep.allAttackSteps.remove(launchDaemon);
    launchDaemon = new LaunchDaemon(name);
    AttackStep.allAttackSteps.remove(lSASSDriver);
    lSASSDriver = new LSASSDriver(name);
    AttackStep.allAttackSteps.remove(netshHelperDLL);
    netshHelperDLL = new NetshHelperDLL(name);
    AttackStep.allAttackSteps.remove(passwordFilterDLL);
    passwordFilterDLL = new PasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(pluggableAuthenticationModules);
    pluggableAuthenticationModules = new PluggableAuthenticationModules(name);
    AttackStep.allAttackSteps.remove(portMonitors);
    portMonitors = new PortMonitors(name);
    AttackStep.allAttackSteps.remove(attemptPowerShell);
    attemptPowerShell = new AttemptPowerShell(name);
    AttackStep.allAttackSteps.remove(powerShell);
    powerShell = new PowerShell(name);
    AttackStep.allAttackSteps.remove(attemptPowerShellAdminProfile);
    attemptPowerShellAdminProfile = new AttemptPowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(powerShellAdminProfile);
    powerShellAdminProfile = new PowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(procFilesystem);
    procFilesystem = new ProcFilesystem(name);
    AttackStep.allAttackSteps.remove(queryRegistry);
    queryRegistry = new QueryRegistry(name);
    AttackStep.allAttackSteps.remove(rc_common);
    rc_common = new Rc_common(name);
    AttackStep.allAttackSteps.remove(remoteScheduledTask);
    remoteScheduledTask = new RemoteScheduledTask(name);
    AttackStep.allAttackSteps.remove(scheduledTask);
    scheduledTask = new ScheduledTask(name);
    AttackStep.allAttackSteps.remove(securitydMemory);
    securitydMemory = new SecuritydMemory(name);
    AttackStep.allAttackSteps.remove(securitySupportProvider);
    securitySupportProvider = new SecuritySupportProvider(name);
    AttackStep.allAttackSteps.remove(serviceExecution);
    serviceExecution = new ServiceExecution(name);
    AttackStep.allAttackSteps.remove(sQLStoredProcedures);
    sQLStoredProcedures = new SQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(systemFirmware);
    systemFirmware = new SystemFirmware(name);
    AttackStep.allAttackSteps.remove(transportAgent);
    transportAgent = new TransportAgent(name);
    AttackStep.allAttackSteps.remove(attemptWindowsAdminShares);
    attemptWindowsAdminShares = new AttemptWindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(attemptExecutionThroughAPI);
    attemptExecutionThroughAPI = new AttemptExecutionThroughAPI(name);
    AttackStep.allAttackSteps.remove(attemptAccessTokenManipulation);
    attemptAccessTokenManipulation = new AttemptAccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(accessTokenManipulation);
    accessTokenManipulation = new AccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(attemptControlPanel);
    attemptControlPanel = new AttemptControlPanel(name);
    AttackStep.allAttackSteps.remove(attemptDistributedComponentObjectModel);
    attemptDistributedComponentObjectModel = new AttemptDistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(attemptLaunchAgent);
    attemptLaunchAgent = new AttemptLaunchAgent(name);
    AttackStep.allAttackSteps.remove(launchAgent);
    launchAgent = new LaunchAgent(name);
    AttackStep.allAttackSteps.remove(attemptAccessibilityFeatures);
    attemptAccessibilityFeatures = new AttemptAccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(attemptLogonScripts);
    attemptLogonScripts = new AttemptLogonScripts(name);
    AttackStep.allAttackSteps.remove(attemptPlistModification);
    attemptPlistModification = new AttemptPlistModification(name);
    AttackStep.allAttackSteps.remove(attemptRemoteDesktopProtocol);
    attemptRemoteDesktopProtocol = new AttemptRemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(attemptServiceStop);
    attemptServiceStop = new AttemptServiceStop(name);
    AttackStep.allAttackSteps.remove(attemptSetuidAndSetgid);
    attemptSetuidAndSetgid = new AttemptSetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(attemptShortcutModification);
    attemptShortcutModification = new AttemptShortcutModification(name);
    AttackStep.allAttackSteps.remove(shortcutModification);
    shortcutModification = new ShortcutModification(name);
    AttackStep.allAttackSteps.remove(attemptSSHAuthorizedKeys);
    attemptSSHAuthorizedKeys = new AttemptSSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(attemptTaintSharedContent);
    attemptTaintSharedContent = new AttemptTaintSharedContent(name);
    AttackStep.allAttackSteps.remove(bash_profileAndBashrc);
    bash_profileAndBashrc = new Bash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bashHistory);
    bashHistory = new BashHistory(name);
    AttackStep.allAttackSteps.remove(bITSJobs);
    bITSJobs = new BITSJobs(name);
    AttackStep.allAttackSteps.remove(cachedDomainCredentials);
    cachedDomainCredentials = new CachedDomainCredentials(name);
    AttackStep.allAttackSteps.remove(clearCommandHistory);
    clearCommandHistory = new ClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(cron);
    cron = new Cron(name);
    AttackStep.allAttackSteps.remove(distributedComponentObjectModel);
    distributedComponentObjectModel = new DistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(elevatedExecutionWithPrompt);
    elevatedExecutionWithPrompt = new ElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(emailCollection);
    emailCollection = new EmailCollection(name);
    AttackStep.allAttackSteps.remove(executableInstallerFilePermissionsWeakness);
    executableInstallerFilePermissionsWeakness = new ExecutableInstallerFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(executionThroughModuleLoad);
    executionThroughModuleLoad = new ExecutionThroughModuleLoad(name);
    AttackStep.allAttackSteps.remove(forcedAuthentication);
    forcedAuthentication = new ForcedAuthentication(name);
    AttackStep.allAttackSteps.remove(goldenTicket);
    goldenTicket = new GoldenTicket(name);
    AttackStep.allAttackSteps.remove(groupPolicyModification);
    groupPolicyModification = new GroupPolicyModification(name);
    AttackStep.allAttackSteps.remove(groupPolicyPreferences);
    groupPolicyPreferences = new GroupPolicyPreferences(name);
    AttackStep.allAttackSteps.remove(gUIInputCapture);
    gUIInputCapture = new GUIInputCapture(name);
    AttackStep.allAttackSteps.remove(hiddenWindow);
    hiddenWindow = new HiddenWindow(name);
    AttackStep.allAttackSteps.remove(hISTCONTROL);
    hISTCONTROL = new HISTCONTROL(name);
    AttackStep.allAttackSteps.remove(indirectCommandExecution);
    indirectCommandExecution = new IndirectCommandExecution(name);
    AttackStep.allAttackSteps.remove(installUtil);
    installUtil = new InstallUtil(name);
    AttackStep.allAttackSteps.remove(launchctl);
    launchctl = new Launchctl(name);
    AttackStep.allAttackSteps.remove(lC_LOAD_DYLIB_Addition);
    lC_LOAD_DYLIB_Addition = new LC_LOAD_DYLIB_Addition(name);
    AttackStep.allAttackSteps.remove(lLMNR_NBT_NS_PoisoningAndSMBRelay);
    lLMNR_NBT_NS_PoisoningAndSMBRelay = new LLMNR_NBT_NS_PoisoningAndSMBRelay(name);
    AttackStep.allAttackSteps.remove(lSASecrets);
    lSASecrets = new LSASecrets(name);
    AttackStep.allAttackSteps.remove(lSASSMemory);
    lSASSMemory = new LSASSMemory(name);
    AttackStep.allAttackSteps.remove(manInTheBrowser);
    manInTheBrowser = new ManInTheBrowser(name);
    AttackStep.allAttackSteps.remove(masqueradeTaskOrService);
    masqueradeTaskOrService = new MasqueradeTaskOrService(name);
    AttackStep.allAttackSteps.remove(modifyRegistry);
    modifyRegistry = new ModifyRegistry(name);
    AttackStep.allAttackSteps.remove(msiexec);
    msiexec = new Msiexec(name);
    AttackStep.allAttackSteps.remove(networkShareConnectionRemoval);
    networkShareConnectionRemoval = new NetworkShareConnectionRemoval(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(nTDS);
    nTDS = new NTDS(name);
    AttackStep.allAttackSteps.remove(odbcconf);
    odbcconf = new Odbcconf(name);
    AttackStep.allAttackSteps.remove(parentPIDSpoofing);
    parentPIDSpoofing = new ParentPIDSpoofing(name);
    AttackStep.allAttackSteps.remove(pathInterceptionBySearchOrderHijacking);
    pathInterceptionBySearchOrderHijacking = new PathInterceptionBySearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(peripheralDeviceDiscovery);
    peripheralDeviceDiscovery = new PeripheralDeviceDiscovery(name);
    AttackStep.allAttackSteps.remove(plistModification);
    plistModification = new PlistModification(name);
    AttackStep.allAttackSteps.remove(portableExecutableInjection);
    portableExecutableInjection = new PortableExecutableInjection(name);
    AttackStep.allAttackSteps.remove(portKnocking);
    portKnocking = new PortKnocking(name);
    AttackStep.allAttackSteps.remove(powerShellUserProfile);
    powerShellUserProfile = new PowerShellUserProfile(name);
    AttackStep.allAttackSteps.remove(processDoppelganging);
    processDoppelganging = new ProcessDoppelganging(name);
    AttackStep.allAttackSteps.remove(processHollowing);
    processHollowing = new ProcessHollowing(name);
    AttackStep.allAttackSteps.remove(pubPrn);
    pubPrn = new PubPrn(name);
    AttackStep.allAttackSteps.remove(rDPHijacking);
    rDPHijacking = new RDPHijacking(name);
    AttackStep.allAttackSteps.remove(registryRunKeysOrStartupFolder);
    registryRunKeysOrStartupFolder = new RegistryRunKeysOrStartupFolder(name);
    AttackStep.allAttackSteps.remove(regsvcsOrRegasm);
    regsvcsOrRegasm = new RegsvcsOrRegasm(name);
    AttackStep.allAttackSteps.remove(regsvr32);
    regsvr32 = new Regsvr32(name);
    AttackStep.allAttackSteps.remove(remoteDesktopProtocol);
    remoteDesktopProtocol = new RemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(reopenedApplications);
    reopenedApplications = new ReopenedApplications(name);
    AttackStep.allAttackSteps.remove(rundll32);
    rundll32 = new Rundll32(name);
    AttackStep.allAttackSteps.remove(screensaver);
    screensaver = new Screensaver(name);
    AttackStep.allAttackSteps.remove(securityAccountManager);
    securityAccountManager = new SecurityAccountManager(name);
    AttackStep.allAttackSteps.remove(servicesFilePermissionsWeakness);
    servicesFilePermissionsWeakness = new ServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(servicesRegistryPermissionsWeakness);
    servicesRegistryPermissionsWeakness = new ServicesRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(serviceStop);
    serviceStop = new ServiceStop(name);
    AttackStep.allAttackSteps.remove(signedScriptProxyExecution);
    signedScriptProxyExecution = new SignedScriptProxyExecution(name);
    AttackStep.allAttackSteps.remove(silverTicket);
    silverTicket = new SilverTicket(name);
    AttackStep.allAttackSteps.remove(sIPAndTrustProviderHijacking);
    sIPAndTrustProviderHijacking = new SIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(source);
    source = new Source(name);
    AttackStep.allAttackSteps.remove(spaceAfterFileName);
    spaceAfterFileName = new SpaceAfterFileName(name);
    AttackStep.allAttackSteps.remove(sSH);
    sSH = new SSH(name);
    AttackStep.allAttackSteps.remove(sSHHijacking);
    sSHHijacking = new SSHHijacking(name);
    AttackStep.allAttackSteps.remove(sudoAndSudoCaching);
    sudoAndSudoCaching = new SudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(systemdService);
    systemdService = new SystemdService(name);
    AttackStep.allAttackSteps.remove(systemServiceDiscovery);
    systemServiceDiscovery = new SystemServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(templateInjection);
    templateInjection = new TemplateInjection(name);
    AttackStep.allAttackSteps.remove(threadExecutionHijacking);
    threadExecutionHijacking = new ThreadExecutionHijacking(name);
    AttackStep.allAttackSteps.remove(trap);
    trap = new Trap(name);
    AttackStep.allAttackSteps.remove(trustedDeveloperUtilities);
    trustedDeveloperUtilities = new TrustedDeveloperUtilities(name);
    AttackStep.allAttackSteps.remove(videoCapture);
    videoCapture = new VideoCapture(name);
    AttackStep.allAttackSteps.remove(windowsAdminShares);
    windowsAdminShares = new WindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentation);
    windowsManagementInstrumentation = new WindowsManagementInstrumentation(name);
    AttackStep.allAttackSteps.remove(attemptWindowsManagementInstrumentationEventSubscription);
    attemptWindowsManagementInstrumentationEventSubscription = new AttemptWindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentationEventSubscription);
    windowsManagementInstrumentationEventSubscription = new WindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(xslScriptProcessing);
    xslScriptProcessing = new XslScriptProcessing(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(archiveCollectedData);
    archiveCollectedData = new ArchiveCollectedData(name);
    AttackStep.allAttackSteps.remove(archiveViaUtility);
    archiveViaUtility = new ArchiveViaUtility(name);
    AttackStep.allAttackSteps.remove(archiveViaLibrary);
    archiveViaLibrary = new ArchiveViaLibrary(name);
    AttackStep.allAttackSteps.remove(archiveViaCustomMethod);
    archiveViaCustomMethod = new ArchiveViaCustomMethod(name);
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountAccessRemoval);
    accountAccessRemoval = new AccountAccessRemoval(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(infectedOS);
    infectedOS = new InfectedOS(name);
    AttackStep.allAttackSteps.remove(clipboardData);
    clipboardData = new ClipboardData(name);
    AttackStep.allAttackSteps.remove(accountDiscovery);
    accountDiscovery = new AccountDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptDomainAccount);
    attemptDomainAccount = new AttemptDomainAccount(name);
    AttackStep.allAttackSteps.remove(domainAccount);
    domainAccount = new DomainAccount(name);
    AttackStep.allAttackSteps.remove(attemptLocalAccount);
    attemptLocalAccount = new AttemptLocalAccount(name);
    AttackStep.allAttackSteps.remove(localAccount);
    localAccount = new LocalAccount(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(visualBasic);
    visualBasic = new VisualBasic(name);
    AttackStep.allAttackSteps.remove(python);
    python = new Python(name);
    AttackStep.allAttackSteps.remove(javaScriptOrJScript);
    javaScriptOrJScript = new JavaScriptOrJScript(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(credentialsFromPasswordStores);
    credentialsFromPasswordStores = new CredentialsFromPasswordStores(name);
    AttackStep.allAttackSteps.remove(dataManipulation);
    dataManipulation = new DataManipulation(name);
    AttackStep.allAttackSteps.remove(dataFromLocalSystem);
    dataFromLocalSystem = new DataFromLocalSystem(name);
    AttackStep.allAttackSteps.remove(defacement);
    defacement = new Defacement(name);
    AttackStep.allAttackSteps.remove(domainDiscovery);
    domainDiscovery = new DomainDiscovery(name);
    AttackStep.allAttackSteps.remove(domainGenerationAlgorithms);
    domainGenerationAlgorithms = new DomainGenerationAlgorithms(name);
    AttackStep.allAttackSteps.remove(compromisedDataOrSystem);
    compromisedDataOrSystem = new CompromisedDataOrSystem(name);
    AttackStep.allAttackSteps.remove(attemptBinaryPadding);
    attemptBinaryPadding = new AttemptBinaryPadding(name);
    AttackStep.allAttackSteps.remove(binaryPadding);
    binaryPadding = new BinaryPadding(name);
    AttackStep.allAttackSteps.remove(applicationWindowDiscovery);
    applicationWindowDiscovery = new ApplicationWindowDiscovery(name);
    AttackStep.allAttackSteps.remove(processDiscovery);
    processDiscovery = new ProcessDiscovery(name);
    AttackStep.allAttackSteps.remove(collectHashInformation);
    collectHashInformation = new CollectHashInformation(name);
    AttackStep.allAttackSteps.remove(compileAfterDelivery);
    compileAfterDelivery = new CompileAfterDelivery(name);
    AttackStep.allAttackSteps.remove(oSCredentialDumping);
    oSCredentialDumping = new OSCredentialDumping(name);
    AttackStep.allAttackSteps.remove(attemptEncryptedChannel);
    attemptEncryptedChannel = new AttemptEncryptedChannel(name);
    AttackStep.allAttackSteps.remove(encryptedChannel);
    encryptedChannel = new EncryptedChannel(name);
    AttackStep.allAttackSteps.remove(dataEncoding);
    dataEncoding = new DataEncoding(name);
    AttackStep.allAttackSteps.remove(standardEncoding);
    standardEncoding = new StandardEncoding(name);
    AttackStep.allAttackSteps.remove(nonStandardEncoding);
    nonStandardEncoding = new NonStandardEncoding(name);
    AttackStep.allAttackSteps.remove(dynamicResolution);
    dynamicResolution = new DynamicResolution(name);
    AttackStep.allAttackSteps.remove(fastFluxDNS);
    fastFluxDNS = new FastFluxDNS(name);
    AttackStep.allAttackSteps.remove(dNSCalculation);
    dNSCalculation = new DNSCalculation(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    AttackStep.allAttackSteps.remove(attemptEndpointDenialOfService);
    attemptEndpointDenialOfService = new AttemptEndpointDenialOfService(name);
    AttackStep.allAttackSteps.remove(endpointDenialOfService);
    endpointDenialOfService = new EndpointDenialOfService(name);
    AttackStep.allAttackSteps.remove(applicationExhaustionFlood);
    applicationExhaustionFlood = new ApplicationExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(oSExhaustionFlood);
    oSExhaustionFlood = new OSExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(applicationOrSystemExploitation);
    applicationOrSystemExploitation = new ApplicationOrSystemExploitation(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(executionGuardrails);
    executionGuardrails = new ExecutionGuardrails(name);
    AttackStep.allAttackSteps.remove(environmentalKeying);
    environmentalKeying = new EnvironmentalKeying(name);
    AttackStep.allAttackSteps.remove(payloadDelivery);
    payloadDelivery = new PayloadDelivery(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverOtherNetworkMedium);
    exfiltrationOverOtherNetworkMedium = new ExfiltrationOverOtherNetworkMedium(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverBluetooth);
    exfiltrationOverBluetooth = new ExfiltrationOverBluetooth(name);
    AttackStep.allAttackSteps.remove(fallbackChannels);
    fallbackChannels = new FallbackChannels(name);
    AttackStep.allAttackSteps.remove(firmwareCorruption);
    firmwareCorruption = new FirmwareCorruption(name);
    AttackStep.allAttackSteps.remove(hideArtifacts);
    hideArtifacts = new HideArtifacts(name);
    AttackStep.allAttackSteps.remove(hiddenFileSystem);
    hiddenFileSystem = new HiddenFileSystem(name);
    AttackStep.allAttackSteps.remove(runVirtualInstance);
    runVirtualInstance = new RunVirtualInstance(name);
    AttackStep.allAttackSteps.remove(hiddenFilesAndDirectories);
    hiddenFilesAndDirectories = new HiddenFilesAndDirectories(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalFromTools);
    indicatorRemovalFromTools = new IndicatorRemovalFromTools(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(timestomp);
    timestomp = new Timestomp(name);
    AttackStep.allAttackSteps.remove(inputCapture);
    inputCapture = new InputCapture(name);
    AttackStep.allAttackSteps.remove(keylogging);
    keylogging = new Keylogging(name);
    AttackStep.allAttackSteps.remove(lateralToolTransfer);
    lateralToolTransfer = new LateralToolTransfer(name);
    AttackStep.allAttackSteps.remove(webPortalCapture);
    webPortalCapture = new WebPortalCapture(name);
    AttackStep.allAttackSteps.remove(internalSpearphishing);
    internalSpearphishing = new InternalSpearphishing(name);
    AttackStep.allAttackSteps.remove(attemptDynamicDataExchange);
    attemptDynamicDataExchange = new AttemptDynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(manInTheMiddle);
    manInTheMiddle = new ManInTheMiddle(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(rightToLeftOverride);
    rightToLeftOverride = new RightToLeftOverride(name);
    AttackStep.allAttackSteps.remove(renameSystemUtilities);
    renameSystemUtilities = new RenameSystemUtilities(name);
    AttackStep.allAttackSteps.remove(matchLegitimateNameOrLocation);
    matchLegitimateNameOrLocation = new MatchLegitimateNameOrLocation(name);
    AttackStep.allAttackSteps.remove(proxy);
    proxy = new Proxy(name);
    AttackStep.allAttackSteps.remove(internalProxy);
    internalProxy = new InternalProxy(name);
    AttackStep.allAttackSteps.remove(externalProxy);
    externalProxy = new ExternalProxy(name);
    AttackStep.allAttackSteps.remove(attemptMultiHopProxy);
    attemptMultiHopProxy = new AttemptMultiHopProxy(name);
    AttackStep.allAttackSteps.remove(multiHopProxy);
    multiHopProxy = new MultiHopProxy(name);
    AttackStep.allAttackSteps.remove(domainFronting);
    domainFronting = new DomainFronting(name);
    AttackStep.allAttackSteps.remove(attemptMultiStageChannels);
    attemptMultiStageChannels = new AttemptMultiStageChannels(name);
    AttackStep.allAttackSteps.remove(multiStageChannels);
    multiStageChannels = new MultiStageChannels(name);
    AttackStep.allAttackSteps.remove(networkDenialOfService);
    networkDenialOfService = new NetworkDenialOfService(name);
    AttackStep.allAttackSteps.remove(directNetworkFlood);
    directNetworkFlood = new DirectNetworkFlood(name);
    AttackStep.allAttackSteps.remove(reflectionAmplification);
    reflectionAmplification = new ReflectionAmplification(name);
    AttackStep.allAttackSteps.remove(networkSniffing);
    networkSniffing = new NetworkSniffing(name);
    AttackStep.allAttackSteps.remove(obfuscatedFilesOrInformation);
    obfuscatedFilesOrInformation = new ObfuscatedFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(steganography);
    steganography = new Steganography(name);
    AttackStep.allAttackSteps.remove(attemptPrivateKeys);
    attemptPrivateKeys = new AttemptPrivateKeys(name);
    AttackStep.allAttackSteps.remove(privateKeys);
    privateKeys = new PrivateKeys(name);
    AttackStep.allAttackSteps.remove(privateKeysWithPassphrase);
    privateKeysWithPassphrase = new PrivateKeysWithPassphrase(name);
    AttackStep.allAttackSteps.remove(resourceHijacking);
    resourceHijacking = new ResourceHijacking(name);
    AttackStep.allAttackSteps.remove(communicationThroughRemovableMedia);
    communicationThroughRemovableMedia = new CommunicationThroughRemovableMedia(name);
    AttackStep.allAttackSteps.remove(remoteSystemDiscovery);
    remoteSystemDiscovery = new RemoteSystemDiscovery(name);
    AttackStep.allAttackSteps.remove(detailedRemoteSystemDiscovery);
    detailedRemoteSystemDiscovery = new DetailedRemoteSystemDiscovery(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(attemptDisableOrModifyTools);
    attemptDisableOrModifyTools = new AttemptDisableOrModifyTools(name);
    AttackStep.allAttackSteps.remove(disableOrModifyTools);
    disableOrModifyTools = new DisableOrModifyTools(name);
    AttackStep.allAttackSteps.remove(disableOrModifySystemFirewall);
    disableOrModifySystemFirewall = new DisableOrModifySystemFirewall(name);
    AttackStep.allAttackSteps.remove(attemptIndicatorBlocking);
    attemptIndicatorBlocking = new AttemptIndicatorBlocking(name);
    AttackStep.allAttackSteps.remove(indicatorBlocking);
    indicatorBlocking = new IndicatorBlocking(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(serverSoftwareComponent);
    serverSoftwareComponent = new ServerSoftwareComponent(name);
    AttackStep.allAttackSteps.remove(softwareDiscovery);
    softwareDiscovery = new SoftwareDiscovery(name);
    AttackStep.allAttackSteps.remove(securitySoftwareDiscovery);
    securitySoftwareDiscovery = new SecuritySoftwareDiscovery(name);
    AttackStep.allAttackSteps.remove(systemAccess);
    systemAccess = new SystemAccess(name);
    AttackStep.allAttackSteps.remove(systemInformationDiscovery);
    systemInformationDiscovery = new SystemInformationDiscovery(name);
    AttackStep.allAttackSteps.remove(systemNetworkConnectionsDiscovery);
    systemNetworkConnectionsDiscovery = new SystemNetworkConnectionsDiscovery(name);
    AttackStep.allAttackSteps.remove(systemOwnerOrUserDiscovery);
    systemOwnerOrUserDiscovery = new SystemOwnerOrUserDiscovery(name);
    AttackStep.allAttackSteps.remove(systemServices);
    systemServices = new SystemServices(name);
    AttackStep.allAttackSteps.remove(systemShutdownOrReboot);
    systemShutdownOrReboot = new SystemShutdownOrReboot(name);
    AttackStep.allAttackSteps.remove(processInjection);
    processInjection = new ProcessInjection(name);
    AttackStep.allAttackSteps.remove(attemptProtocolTunneling);
    attemptProtocolTunneling = new AttemptProtocolTunneling(name);
    AttackStep.allAttackSteps.remove(protocolTunneling);
    protocolTunneling = new ProtocolTunneling(name);
    AttackStep.allAttackSteps.remove(rootkit);
    rootkit = new Rootkit(name);
    AttackStep.allAttackSteps.remove(runtimeDataManipulation);
    runtimeDataManipulation = new RuntimeDataManipulation(name);
    AttackStep.allAttackSteps.remove(attemptApplicationLayerProtocol);
    attemptApplicationLayerProtocol = new AttemptApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(applicationLayerProtocol);
    applicationLayerProtocol = new ApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(attemptNonApplicationLayerProtocol);
    attemptNonApplicationLayerProtocol = new AttemptNonApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(nonApplicationLayerProtocol);
    nonApplicationLayerProtocol = new NonApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(webProtocols);
    webProtocols = new WebProtocols(name);
    AttackStep.allAttackSteps.remove(fileTransferProtocols);
    fileTransferProtocols = new FileTransferProtocols(name);
    AttackStep.allAttackSteps.remove(mailProtocols);
    mailProtocols = new MailProtocols(name);
    AttackStep.allAttackSteps.remove(dNS);
    dNS = new DNS(name);
    AttackStep.allAttackSteps.remove(systemNetworkConfigurationDiscovery);
    systemNetworkConfigurationDiscovery = new SystemNetworkConfigurationDiscovery(name);
    AttackStep.allAttackSteps.remove(twoFactorAuthenticationInterception);
    twoFactorAuthenticationInterception = new TwoFactorAuthenticationInterception(name);
    AttackStep.allAttackSteps.remove(modifyAPICalls);
    modifyAPICalls = new ModifyAPICalls(name);
    AttackStep.allAttackSteps.remove(bypassAntivirus);
    bypassAntivirus = new BypassAntivirus(name);
    AttackStep.allAttackSteps.remove(bypassAutorunsAnalysis);
    bypassAutorunsAnalysis = new BypassAutorunsAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassApplicationControl);
    bypassApplicationControl = new BypassApplicationControl(name);
    AttackStep.allAttackSteps.remove(bypassApplicationWhitelisting);
    bypassApplicationWhitelisting = new BypassApplicationWhitelisting(name);
    AttackStep.allAttackSteps.remove(bypassBinaryAnalysis);
    bypassBinaryAnalysis = new BypassBinaryAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassDefensiveNetworkServiceScanning);
    bypassDefensiveNetworkServiceScanning = new BypassDefensiveNetworkServiceScanning(name);
    AttackStep.allAttackSteps.remove(bypassDigitalCertificateValidation);
    bypassDigitalCertificateValidation = new BypassDigitalCertificateValidation(name);
    AttackStep.allAttackSteps.remove(bypassEgressFiltering);
    bypassEgressFiltering = new BypassEgressFiltering(name);
    AttackStep.allAttackSteps.remove(bypassFileMonitoring);
    bypassFileMonitoring = new BypassFileMonitoring(name);
    AttackStep.allAttackSteps.remove(bypassFileOrPathWhitelisting);
    bypassFileOrPathWhitelisting = new BypassFileOrPathWhitelisting(name);
    AttackStep.allAttackSteps.remove(bypassFileSystemAccessControls);
    bypassFileSystemAccessControls = new BypassFileSystemAccessControls(name);
    AttackStep.allAttackSteps.remove(bypassHeuristicDetection);
    bypassHeuristicDetection = new BypassHeuristicDetection(name);
    AttackStep.allAttackSteps.remove(bypassHostForensicAnalysis);
    bypassHostForensicAnalysis = new BypassHostForensicAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassHostIntrusionPrevention);
    bypassHostIntrusionPrevention = new BypassHostIntrusionPrevention(name);
    AttackStep.allAttackSteps.remove(bypassProcessWhitelisting);
    bypassProcessWhitelisting = new BypassProcessWhitelisting(name);
    AttackStep.allAttackSteps.remove(bypassSystemAccessControls);
    bypassSystemAccessControls = new BypassSystemAccessControls(name);
    AttackStep.allAttackSteps.remove(bypassLogAnalysis);
    bypassLogAnalysis = new BypassLogAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassSignatureBasedDetection);
    bypassSignatureBasedDetection = new BypassSignatureBasedDetection(name);
    AttackStep.allAttackSteps.remove(bypassStaticFileAnalysis);
    bypassStaticFileAnalysis = new BypassStaticFileAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassUserModeSignatureValidation);
    bypassUserModeSignatureValidation = new BypassUserModeSignatureValidation(name);
    AttackStep.allAttackSteps.remove(passwordPolicyDiscovery);
    passwordPolicyDiscovery = new PasswordPolicyDiscovery(name);
    AttackStep.allAttackSteps.remove(bruteForceWithPasswordPolicy);
    bruteForceWithPasswordPolicy = new BruteForceWithPasswordPolicy(name);
    AttackStep.allAttackSteps.remove(bruteForce);
    bruteForce = new BruteForce(name);
    AttackStep.allAttackSteps.remove(passTheHash);
    passTheHash = new PassTheHash(name);
    AttackStep.allAttackSteps.remove(passTheTicket);
    passTheTicket = new PassTheTicket(name);
    AttackStep.allAttackSteps.remove(passwordGuessing);
    passwordGuessing = new PasswordGuessing(name);
    AttackStep.allAttackSteps.remove(attemptPasswordCracking);
    attemptPasswordCracking = new AttemptPasswordCracking(name);
    AttackStep.allAttackSteps.remove(passwordCracking);
    passwordCracking = new PasswordCracking(name);
    AttackStep.allAttackSteps.remove(passwordSpraying);
    passwordSpraying = new PasswordSpraying(name);
    AttackStep.allAttackSteps.remove(credentialStuffing);
    credentialStuffing = new CredentialStuffing(name);
    AttackStep.allAttackSteps.remove(permissionGroupsDiscovery);
    permissionGroupsDiscovery = new PermissionGroupsDiscovery(name);
    AttackStep.allAttackSteps.remove(localGroups);
    localGroups = new LocalGroups(name);
    AttackStep.allAttackSteps.remove(domainGroups);
    domainGroups = new DomainGroups(name);
    AttackStep.allAttackSteps.remove(preOSBoot);
    preOSBoot = new PreOSBoot(name);
    AttackStep.allAttackSteps.remove(attemptAntivirusCheck);
    attemptAntivirusCheck = new AttemptAntivirusCheck(name);
    AttackStep.allAttackSteps.remove(antivirusCheck);
    antivirusCheck = new AntivirusCheck(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(sSHCredentialInterception);
    sSHCredentialInterception = new SSHCredentialInterception(name);
    AttackStep.allAttackSteps.remove(storedDataManipulation);
    storedDataManipulation = new StoredDataManipulation(name);
    AttackStep.allAttackSteps.remove(nonStandardPort);
    nonStandardPort = new NonStandardPort(name);
    AttackStep.allAttackSteps.remove(subvertTrustControls);
    subvertTrustControls = new SubvertTrustControls(name);
    AttackStep.allAttackSteps.remove(installRootCertificate);
    installRootCertificate = new InstallRootCertificate(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(attemptCredentialsInFiles);
    attemptCredentialsInFiles = new AttemptCredentialsInFiles(name);
    AttackStep.allAttackSteps.remove(credentialsInFiles);
    credentialsInFiles = new CredentialsInFiles(name);
    AttackStep.allAttackSteps.remove(validAccounts);
    validAccounts = new ValidAccounts(name);
    AttackStep.allAttackSteps.remove(defaultAccounts);
    defaultAccounts = new DefaultAccounts(name);
    AttackStep.allAttackSteps.remove(attemptDomainAccounts);
    attemptDomainAccounts = new AttemptDomainAccounts(name);
    AttackStep.allAttackSteps.remove(domainAccounts);
    domainAccounts = new DomainAccounts(name);
    AttackStep.allAttackSteps.remove(attemptLocalAccounts);
    attemptLocalAccounts = new AttemptLocalAccounts(name);
    AttackStep.allAttackSteps.remove(localAccounts);
    localAccounts = new LocalAccounts(name);
    AttackStep.allAttackSteps.remove(virtualizationOrSandboxEvasion);
    virtualizationOrSandboxEvasion = new VirtualizationOrSandboxEvasion(name);
    AttackStep.allAttackSteps.remove(systemChecks);
    systemChecks = new SystemChecks(name);
    AttackStep.allAttackSteps.remove(userActivityBasedChecks);
    userActivityBasedChecks = new UserActivityBasedChecks(name);
    AttackStep.allAttackSteps.remove(timeBasedEvasion);
    timeBasedEvasion = new TimeBasedEvasion(name);
    AttackStep.allAttackSteps.remove(vNC);
    vNC = new VNC(name);
    AttackStep.allAttackSteps.remove(fileDeletion);
    fileDeletion = new FileDeletion(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryDiscovery);
    fileAndDirectoryDiscovery = new FileAndDirectoryDiscovery(name);
    AttackStep.allAttackSteps.remove(diskWipe);
    diskWipe = new DiskWipe(name);
    AttackStep.allAttackSteps.remove(diskContentWipe);
    diskContentWipe = new DiskContentWipe(name);
    AttackStep.allAttackSteps.remove(diskStructureWipe);
    diskStructureWipe = new DiskStructureWipe(name);
    AttackStep.allAttackSteps.remove(remoteFileCopy);
    remoteFileCopy = new RemoteFileCopy(name);
    AttackStep.allAttackSteps.remove(sensitiveDataCollected);
    sensitiveDataCollected = new SensitiveDataCollected(name);
    AttackStep.allAttackSteps.remove(dataCollected);
    dataCollected = new DataCollected(name);
    AttackStep.allAttackSteps.remove(dataEncrypted);
    dataEncrypted = new DataEncrypted(name);
    AttackStep.allAttackSteps.remove(dataSizedTransfer);
    dataSizedTransfer = new DataSizedTransfer(name);
    AttackStep.allAttackSteps.remove(dataStaged);
    dataStaged = new DataStaged(name);
    AttackStep.allAttackSteps.remove(localDataStaging);
    localDataStaging = new LocalDataStaging(name);
    AttackStep.allAttackSteps.remove(replicationThroughRemovableMedia);
    replicationThroughRemovableMedia = new ReplicationThroughRemovableMedia(name);
    AttackStep.allAttackSteps.remove(remoteDataStaging);
    remoteDataStaging = new RemoteDataStaging(name);
    AttackStep.allAttackSteps.remove(attemptDataDestruction);
    attemptDataDestruction = new AttemptDataDestruction(name);
    AttackStep.allAttackSteps.remove(dataDestruction);
    dataDestruction = new DataDestruction(name);
    AttackStep.allAttackSteps.remove(attemptDataEncryptedForImpact);
    attemptDataEncryptedForImpact = new AttemptDataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataCompressed);
    dataCompressed = new DataCompressed(name);
    AttackStep.allAttackSteps.remove(inhibitSystemRecovery);
    inhibitSystemRecovery = new InhibitSystemRecovery(name);
    AttackStep.allAttackSteps.remove(screenCapture);
    screenCapture = new ScreenCapture(name);
    AttackStep.allAttackSteps.remove(scheduledExfiltration);
    scheduledExfiltration = new ScheduledExfiltration(name);
    AttackStep.allAttackSteps.remove(attemptExfiltrationOverAternativeProtocol);
    attemptExfiltrationOverAternativeProtocol = new AttemptExfiltrationOverAternativeProtocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverAternativeProtocol);
    exfiltrationOverAternativeProtocol = new ExfiltrationOverAternativeProtocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverAsymmetricEncryptedNonC2Protocol);
    exfiltrationOverAsymmetricEncryptedNonC2Protocol = new ExfiltrationOverAsymmetricEncryptedNonC2Protocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverSymmetricEncryptedNonC2Protocol);
    exfiltrationOverSymmetricEncryptedNonC2Protocol = new ExfiltrationOverSymmetricEncryptedNonC2Protocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol);
    exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol = new ExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol(name);
    AttackStep.allAttackSteps.remove(dataFromInformationRepositories);
    dataFromInformationRepositories = new DataFromInformationRepositories(name);
    AttackStep.allAttackSteps.remove(confluence);
    confluence = new Confluence(name);
    AttackStep.allAttackSteps.remove(sharepoint);
    sharepoint = new Sharepoint(name);
    AttackStep.allAttackSteps.remove(windowsService);
    windowsService = new WindowsService(name);
    AttackStep.allAttackSteps.remove(attemptAutomatedCollection);
    attemptAutomatedCollection = new AttemptAutomatedCollection(name);
    AttackStep.allAttackSteps.remove(automatedCollection);
    automatedCollection = new AutomatedCollection(name);
    AttackStep.allAttackSteps.remove(automatedExfiltration);
    automatedExfiltration = new AutomatedExfiltration(name);
    AttackStep.allAttackSteps.remove(networkServiceScan);
    networkServiceScan = new NetworkServiceScan(name);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, isAntivirusEnabled);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, isRestrictFileAndDirectoryPermissionsEnabled);
    if (restrictRegistryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictRegistryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictRegistryPermissions);
    restrictRegistryPermissions = new RestrictRegistryPermissions(name, isRestrictRegistryPermissionsEnabled);
    if (accountUsePolicies != null) {
      AttackStep.allAttackSteps.remove(accountUsePolicies.disable);
    }
    Defense.allDefenses.remove(accountUsePolicies);
    accountUsePolicies = new AccountUsePolicies(name, isAccountUsePoliciesEnabled);
    if (behaviorPreventionOnEndpoint != null) {
      AttackStep.allAttackSteps.remove(behaviorPreventionOnEndpoint.disable);
    }
    Defense.allDefenses.remove(behaviorPreventionOnEndpoint);
    behaviorPreventionOnEndpoint = new BehaviorPreventionOnEndpoint(name, isBehaviorPreventionOnEndpointEnabled);
    if (bootIntegrity != null) {
      AttackStep.allAttackSteps.remove(bootIntegrity.disable);
    }
    Defense.allDefenses.remove(bootIntegrity);
    bootIntegrity = new BootIntegrity(name, isBootIntegrityEnabled);
    if (dataBackup != null) {
      AttackStep.allAttackSteps.remove(dataBackup.disable);
    }
    Defense.allDefenses.remove(dataBackup);
    dataBackup = new DataBackup(name, isDataBackupEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
    if (applicationIsolationAndSandboxing != null) {
      AttackStep.allAttackSteps.remove(applicationIsolationAndSandboxing.disable);
    }
    Defense.allDefenses.remove(applicationIsolationAndSandboxing);
    applicationIsolationAndSandboxing = new ApplicationIsolationAndSandboxing(name, isApplicationIsolationAndSandboxingEnabled);
    if (doNotMitigate != null) {
      AttackStep.allAttackSteps.remove(doNotMitigate.disable);
    }
    Defense.allDefenses.remove(doNotMitigate);
    doNotMitigate = new DoNotMitigate(name, isDoNotMitigateEnabled);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, isDisableOrRemoveFeatureOrProgramEnabled);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, isActiveDirectoryConfigurationEnabled);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, isAuditEnabled);
    if (applicationDeveloperGuidance != null) {
      AttackStep.allAttackSteps.remove(applicationDeveloperGuidance.disable);
    }
    Defense.allDefenses.remove(applicationDeveloperGuidance);
    applicationDeveloperGuidance = new ApplicationDeveloperGuidance(name, isApplicationDeveloperGuidanceEnabled);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, isCodeSigningEnabled);
    if (limitHardwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitHardwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitHardwareInstallation);
    limitHardwareInstallation = new LimitHardwareInstallation(name, isLimitHardwareInstallationEnabled);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, isOperatingSystemConfigurationEnabled);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, isSoftwareConfigurationEnabled);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, isExecutionPreventionEnabled);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, isPrivilegedAccountManagementEnabled);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, isEncryptSensitiveInformationEnabled);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, isRemoteDataStorageEnabled);
    if (limitSoftwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitSoftwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitSoftwareInstallation);
    limitSoftwareInstallation = new LimitSoftwareInstallation(name, isLimitSoftwareInstallationEnabled);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, isUpdateSoftwareEnabled);
    if (userAccountControl != null) {
      AttackStep.allAttackSteps.remove(userAccountControl.disable);
    }
    Defense.allDefenses.remove(userAccountControl);
    userAccountControl = new UserAccountControl(name, isUserAccountControlEnabled);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, isExploitProtectionEnabled);
  }

  public OS(String name) {
    super(name);
    assetClassName = "OS";
    AttackStep.allAttackSteps.remove(attemptBITSJobs);
    attemptBITSJobs = new AttemptBITSJobs(name);
    AttackStep.allAttackSteps.remove(attemptAppCertDLLs);
    attemptAppCertDLLs = new AttemptAppCertDLLs(name);
    AttackStep.allAttackSteps.remove(appCertDLLs);
    appCertDLLs = new AppCertDLLs(name);
    AttackStep.allAttackSteps.remove(bypassUserAccessControl);
    bypassUserAccessControl = new BypassUserAccessControl(name);
    AttackStep.allAttackSteps.remove(changeDefaultFileAssociation);
    changeDefaultFileAssociation = new ChangeDefaultFileAssociation(name);
    AttackStep.allAttackSteps.remove(attemptGatekeeperBypass);
    attemptGatekeeperBypass = new AttemptGatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(gatekeeperBypass);
    gatekeeperBypass = new GatekeeperBypass(name);
    AttackStep.allAttackSteps.remove(cmstp);
    cmstp = new Cmstp(name);
    AttackStep.allAttackSteps.remove(compiledHTMLFile);
    compiledHTMLFile = new CompiledHTMLFile(name);
    AttackStep.allAttackSteps.remove(cOR_PROFILER);
    cOR_PROFILER = new COR_PROFILER(name);
    AttackStep.allAttackSteps.remove(componentObjectModelHijacking);
    componentObjectModelHijacking = new ComponentObjectModelHijacking(name);
    AttackStep.allAttackSteps.remove(controlPanel);
    controlPanel = new ControlPanel(name);
    AttackStep.allAttackSteps.remove(credentialsInRegistry);
    credentialsInRegistry = new CredentialsInRegistry(name);
    AttackStep.allAttackSteps.remove(deobfuscateOrDecodeFilesOrInformation);
    deobfuscateOrDecodeFilesOrInformation = new DeobfuscateOrDecodeFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(dLLSearchOrderHijacking);
    dLLSearchOrderHijacking = new DLLSearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(domainTrustDiscovery);
    domainTrustDiscovery = new DomainTrustDiscovery(name);
    AttackStep.allAttackSteps.remove(dynamicDataExchange);
    dynamicDataExchange = new DynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(mshta);
    mshta = new Mshta(name);
    AttackStep.allAttackSteps.remove(windowsRemoteManagement);
    windowsRemoteManagement = new WindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(_etc_passwdAND_etc_shadow);
    _etc_passwdAND_etc_shadow = new _etc_passwdAND_etc_shadow(name);
    AttackStep.allAttackSteps.remove(accessibilityFeatures);
    accessibilityFeatures = new AccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(appInitDLLs);
    appInitDLLs = new AppInitDLLs(name);
    AttackStep.allAttackSteps.remove(applicationShimming);
    applicationShimming = new ApplicationShimming(name);
    AttackStep.allAttackSteps.remove(at);
    at = new At(name);
    AttackStep.allAttackSteps.remove(attemptBootkit);
    attemptBootkit = new AttemptBootkit(name);
    AttackStep.allAttackSteps.remove(attemptElevatedExecutionWithPrompt);
    attemptElevatedExecutionWithPrompt = new AttemptElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(attemptLSASSDriver);
    attemptLSASSDriver = new AttemptLSASSDriver(name);
    AttackStep.allAttackSteps.remove(attemptLSASSMemory);
    attemptLSASSMemory = new AttemptLSASSMemory(name);
    AttackStep.allAttackSteps.remove(attemptPasswordFilterDLL);
    attemptPasswordFilterDLL = new AttemptPasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(attemptServiceExecution);
    attemptServiceExecution = new AttemptServiceExecution(name);
    AttackStep.allAttackSteps.remove(attemptServiceRegistryPermissionsWeakness);
    attemptServiceRegistryPermissionsWeakness = new AttemptServiceRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptServicesFilePermissionsWeakness);
    attemptServicesFilePermissionsWeakness = new AttemptServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptSIDHistoryInjection);
    attemptSIDHistoryInjection = new AttemptSIDHistoryInjection(name);
    AttackStep.allAttackSteps.remove(attemptSIPAndTrustProviderHijacking);
    attemptSIPAndTrustProviderHijacking = new AttemptSIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(attemptSQLStoredProcedures);
    attemptSQLStoredProcedures = new AttemptSQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(attemptStartupItems);
    attemptStartupItems = new AttemptStartupItems(name);
    AttackStep.allAttackSteps.remove(attemptSystemFirmware);
    attemptSystemFirmware = new AttemptSystemFirmware(name);
    AttackStep.allAttackSteps.remove(attemptTimeProviders);
    attemptTimeProviders = new AttemptTimeProviders(name);
    AttackStep.allAttackSteps.remove(attemptTransportAgent);
    attemptTransportAgent = new AttemptTransportAgent(name);
    AttackStep.allAttackSteps.remove(attemptWinlogonHelperDLL);
    attemptWinlogonHelperDLL = new AttemptWinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(attemptWindowsRemoteManagement);
    attemptWindowsRemoteManagement = new AttemptWindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(winlogonHelperDLL);
    winlogonHelperDLL = new WinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(authenticationPackage);
    authenticationPackage = new AuthenticationPackage(name);
    AttackStep.allAttackSteps.remove(bootkit);
    bootkit = new Bootkit(name);
    AttackStep.allAttackSteps.remove(clearWindowsEventLogs);
    clearWindowsEventLogs = new ClearWindowsEventLogs(name);
    AttackStep.allAttackSteps.remove(componentFirmware);
    componentFirmware = new ComponentFirmware(name);
    AttackStep.allAttackSteps.remove(credentialAPIHooking);
    credentialAPIHooking = new CredentialAPIHooking(name);
    AttackStep.allAttackSteps.remove(dCShadow);
    dCShadow = new DCShadow(name);
    AttackStep.allAttackSteps.remove(dCSync);
    dCSync = new DCSync(name);
    AttackStep.allAttackSteps.remove(disableWindowsEventLogging);
    disableWindowsEventLogging = new DisableWindowsEventLogging(name);
    AttackStep.allAttackSteps.remove(domainControllerAuthentication);
    domainControllerAuthentication = new DomainControllerAuthentication(name);
    AttackStep.allAttackSteps.remove(emond);
    emond = new Emond(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(fileSystemLogicalOffsets);
    fileSystemLogicalOffsets = new FileSystemLogicalOffsets(name);
    AttackStep.allAttackSteps.remove(hiddenUsers);
    hiddenUsers = new HiddenUsers(name);
    AttackStep.allAttackSteps.remove(imageFileExecutionOptionsInjection);
    imageFileExecutionOptionsInjection = new ImageFileExecutionOptionsInjection(name);
    AttackStep.allAttackSteps.remove(kernelModulesAndExtensions);
    kernelModulesAndExtensions = new KernelModulesAndExtensions(name);
    AttackStep.allAttackSteps.remove(keychain);
    keychain = new Keychain(name);
    AttackStep.allAttackSteps.remove(launchd);
    launchd = new Launchd(name);
    AttackStep.allAttackSteps.remove(launchDaemon);
    launchDaemon = new LaunchDaemon(name);
    AttackStep.allAttackSteps.remove(lSASSDriver);
    lSASSDriver = new LSASSDriver(name);
    AttackStep.allAttackSteps.remove(netshHelperDLL);
    netshHelperDLL = new NetshHelperDLL(name);
    AttackStep.allAttackSteps.remove(passwordFilterDLL);
    passwordFilterDLL = new PasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(pluggableAuthenticationModules);
    pluggableAuthenticationModules = new PluggableAuthenticationModules(name);
    AttackStep.allAttackSteps.remove(portMonitors);
    portMonitors = new PortMonitors(name);
    AttackStep.allAttackSteps.remove(attemptPowerShell);
    attemptPowerShell = new AttemptPowerShell(name);
    AttackStep.allAttackSteps.remove(powerShell);
    powerShell = new PowerShell(name);
    AttackStep.allAttackSteps.remove(attemptPowerShellAdminProfile);
    attemptPowerShellAdminProfile = new AttemptPowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(powerShellAdminProfile);
    powerShellAdminProfile = new PowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(procFilesystem);
    procFilesystem = new ProcFilesystem(name);
    AttackStep.allAttackSteps.remove(queryRegistry);
    queryRegistry = new QueryRegistry(name);
    AttackStep.allAttackSteps.remove(rc_common);
    rc_common = new Rc_common(name);
    AttackStep.allAttackSteps.remove(remoteScheduledTask);
    remoteScheduledTask = new RemoteScheduledTask(name);
    AttackStep.allAttackSteps.remove(scheduledTask);
    scheduledTask = new ScheduledTask(name);
    AttackStep.allAttackSteps.remove(securitydMemory);
    securitydMemory = new SecuritydMemory(name);
    AttackStep.allAttackSteps.remove(securitySupportProvider);
    securitySupportProvider = new SecuritySupportProvider(name);
    AttackStep.allAttackSteps.remove(serviceExecution);
    serviceExecution = new ServiceExecution(name);
    AttackStep.allAttackSteps.remove(sQLStoredProcedures);
    sQLStoredProcedures = new SQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(systemFirmware);
    systemFirmware = new SystemFirmware(name);
    AttackStep.allAttackSteps.remove(transportAgent);
    transportAgent = new TransportAgent(name);
    AttackStep.allAttackSteps.remove(attemptWindowsAdminShares);
    attemptWindowsAdminShares = new AttemptWindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(attemptExecutionThroughAPI);
    attemptExecutionThroughAPI = new AttemptExecutionThroughAPI(name);
    AttackStep.allAttackSteps.remove(attemptAccessTokenManipulation);
    attemptAccessTokenManipulation = new AttemptAccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(accessTokenManipulation);
    accessTokenManipulation = new AccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(attemptControlPanel);
    attemptControlPanel = new AttemptControlPanel(name);
    AttackStep.allAttackSteps.remove(attemptDistributedComponentObjectModel);
    attemptDistributedComponentObjectModel = new AttemptDistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(attemptLaunchAgent);
    attemptLaunchAgent = new AttemptLaunchAgent(name);
    AttackStep.allAttackSteps.remove(launchAgent);
    launchAgent = new LaunchAgent(name);
    AttackStep.allAttackSteps.remove(attemptAccessibilityFeatures);
    attemptAccessibilityFeatures = new AttemptAccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(attemptLogonScripts);
    attemptLogonScripts = new AttemptLogonScripts(name);
    AttackStep.allAttackSteps.remove(attemptPlistModification);
    attemptPlistModification = new AttemptPlistModification(name);
    AttackStep.allAttackSteps.remove(attemptRemoteDesktopProtocol);
    attemptRemoteDesktopProtocol = new AttemptRemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(attemptServiceStop);
    attemptServiceStop = new AttemptServiceStop(name);
    AttackStep.allAttackSteps.remove(attemptSetuidAndSetgid);
    attemptSetuidAndSetgid = new AttemptSetuidAndSetgid(name);
    AttackStep.allAttackSteps.remove(attemptShortcutModification);
    attemptShortcutModification = new AttemptShortcutModification(name);
    AttackStep.allAttackSteps.remove(shortcutModification);
    shortcutModification = new ShortcutModification(name);
    AttackStep.allAttackSteps.remove(attemptSSHAuthorizedKeys);
    attemptSSHAuthorizedKeys = new AttemptSSHAuthorizedKeys(name);
    AttackStep.allAttackSteps.remove(attemptTaintSharedContent);
    attemptTaintSharedContent = new AttemptTaintSharedContent(name);
    AttackStep.allAttackSteps.remove(bash_profileAndBashrc);
    bash_profileAndBashrc = new Bash_profileAndBashrc(name);
    AttackStep.allAttackSteps.remove(bashHistory);
    bashHistory = new BashHistory(name);
    AttackStep.allAttackSteps.remove(bITSJobs);
    bITSJobs = new BITSJobs(name);
    AttackStep.allAttackSteps.remove(cachedDomainCredentials);
    cachedDomainCredentials = new CachedDomainCredentials(name);
    AttackStep.allAttackSteps.remove(clearCommandHistory);
    clearCommandHistory = new ClearCommandHistory(name);
    AttackStep.allAttackSteps.remove(cron);
    cron = new Cron(name);
    AttackStep.allAttackSteps.remove(distributedComponentObjectModel);
    distributedComponentObjectModel = new DistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(elevatedExecutionWithPrompt);
    elevatedExecutionWithPrompt = new ElevatedExecutionWithPrompt(name);
    AttackStep.allAttackSteps.remove(emailCollection);
    emailCollection = new EmailCollection(name);
    AttackStep.allAttackSteps.remove(executableInstallerFilePermissionsWeakness);
    executableInstallerFilePermissionsWeakness = new ExecutableInstallerFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(executionThroughModuleLoad);
    executionThroughModuleLoad = new ExecutionThroughModuleLoad(name);
    AttackStep.allAttackSteps.remove(forcedAuthentication);
    forcedAuthentication = new ForcedAuthentication(name);
    AttackStep.allAttackSteps.remove(goldenTicket);
    goldenTicket = new GoldenTicket(name);
    AttackStep.allAttackSteps.remove(groupPolicyModification);
    groupPolicyModification = new GroupPolicyModification(name);
    AttackStep.allAttackSteps.remove(groupPolicyPreferences);
    groupPolicyPreferences = new GroupPolicyPreferences(name);
    AttackStep.allAttackSteps.remove(gUIInputCapture);
    gUIInputCapture = new GUIInputCapture(name);
    AttackStep.allAttackSteps.remove(hiddenWindow);
    hiddenWindow = new HiddenWindow(name);
    AttackStep.allAttackSteps.remove(hISTCONTROL);
    hISTCONTROL = new HISTCONTROL(name);
    AttackStep.allAttackSteps.remove(indirectCommandExecution);
    indirectCommandExecution = new IndirectCommandExecution(name);
    AttackStep.allAttackSteps.remove(installUtil);
    installUtil = new InstallUtil(name);
    AttackStep.allAttackSteps.remove(launchctl);
    launchctl = new Launchctl(name);
    AttackStep.allAttackSteps.remove(lC_LOAD_DYLIB_Addition);
    lC_LOAD_DYLIB_Addition = new LC_LOAD_DYLIB_Addition(name);
    AttackStep.allAttackSteps.remove(lLMNR_NBT_NS_PoisoningAndSMBRelay);
    lLMNR_NBT_NS_PoisoningAndSMBRelay = new LLMNR_NBT_NS_PoisoningAndSMBRelay(name);
    AttackStep.allAttackSteps.remove(lSASecrets);
    lSASecrets = new LSASecrets(name);
    AttackStep.allAttackSteps.remove(lSASSMemory);
    lSASSMemory = new LSASSMemory(name);
    AttackStep.allAttackSteps.remove(manInTheBrowser);
    manInTheBrowser = new ManInTheBrowser(name);
    AttackStep.allAttackSteps.remove(masqueradeTaskOrService);
    masqueradeTaskOrService = new MasqueradeTaskOrService(name);
    AttackStep.allAttackSteps.remove(modifyRegistry);
    modifyRegistry = new ModifyRegistry(name);
    AttackStep.allAttackSteps.remove(msiexec);
    msiexec = new Msiexec(name);
    AttackStep.allAttackSteps.remove(networkShareConnectionRemoval);
    networkShareConnectionRemoval = new NetworkShareConnectionRemoval(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(nTDS);
    nTDS = new NTDS(name);
    AttackStep.allAttackSteps.remove(odbcconf);
    odbcconf = new Odbcconf(name);
    AttackStep.allAttackSteps.remove(parentPIDSpoofing);
    parentPIDSpoofing = new ParentPIDSpoofing(name);
    AttackStep.allAttackSteps.remove(pathInterceptionBySearchOrderHijacking);
    pathInterceptionBySearchOrderHijacking = new PathInterceptionBySearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(peripheralDeviceDiscovery);
    peripheralDeviceDiscovery = new PeripheralDeviceDiscovery(name);
    AttackStep.allAttackSteps.remove(plistModification);
    plistModification = new PlistModification(name);
    AttackStep.allAttackSteps.remove(portableExecutableInjection);
    portableExecutableInjection = new PortableExecutableInjection(name);
    AttackStep.allAttackSteps.remove(portKnocking);
    portKnocking = new PortKnocking(name);
    AttackStep.allAttackSteps.remove(powerShellUserProfile);
    powerShellUserProfile = new PowerShellUserProfile(name);
    AttackStep.allAttackSteps.remove(processDoppelganging);
    processDoppelganging = new ProcessDoppelganging(name);
    AttackStep.allAttackSteps.remove(processHollowing);
    processHollowing = new ProcessHollowing(name);
    AttackStep.allAttackSteps.remove(pubPrn);
    pubPrn = new PubPrn(name);
    AttackStep.allAttackSteps.remove(rDPHijacking);
    rDPHijacking = new RDPHijacking(name);
    AttackStep.allAttackSteps.remove(registryRunKeysOrStartupFolder);
    registryRunKeysOrStartupFolder = new RegistryRunKeysOrStartupFolder(name);
    AttackStep.allAttackSteps.remove(regsvcsOrRegasm);
    regsvcsOrRegasm = new RegsvcsOrRegasm(name);
    AttackStep.allAttackSteps.remove(regsvr32);
    regsvr32 = new Regsvr32(name);
    AttackStep.allAttackSteps.remove(remoteDesktopProtocol);
    remoteDesktopProtocol = new RemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(reopenedApplications);
    reopenedApplications = new ReopenedApplications(name);
    AttackStep.allAttackSteps.remove(rundll32);
    rundll32 = new Rundll32(name);
    AttackStep.allAttackSteps.remove(screensaver);
    screensaver = new Screensaver(name);
    AttackStep.allAttackSteps.remove(securityAccountManager);
    securityAccountManager = new SecurityAccountManager(name);
    AttackStep.allAttackSteps.remove(servicesFilePermissionsWeakness);
    servicesFilePermissionsWeakness = new ServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(servicesRegistryPermissionsWeakness);
    servicesRegistryPermissionsWeakness = new ServicesRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(serviceStop);
    serviceStop = new ServiceStop(name);
    AttackStep.allAttackSteps.remove(signedScriptProxyExecution);
    signedScriptProxyExecution = new SignedScriptProxyExecution(name);
    AttackStep.allAttackSteps.remove(silverTicket);
    silverTicket = new SilverTicket(name);
    AttackStep.allAttackSteps.remove(sIPAndTrustProviderHijacking);
    sIPAndTrustProviderHijacking = new SIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(source);
    source = new Source(name);
    AttackStep.allAttackSteps.remove(spaceAfterFileName);
    spaceAfterFileName = new SpaceAfterFileName(name);
    AttackStep.allAttackSteps.remove(sSH);
    sSH = new SSH(name);
    AttackStep.allAttackSteps.remove(sSHHijacking);
    sSHHijacking = new SSHHijacking(name);
    AttackStep.allAttackSteps.remove(sudoAndSudoCaching);
    sudoAndSudoCaching = new SudoAndSudoCaching(name);
    AttackStep.allAttackSteps.remove(systemdService);
    systemdService = new SystemdService(name);
    AttackStep.allAttackSteps.remove(systemServiceDiscovery);
    systemServiceDiscovery = new SystemServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(templateInjection);
    templateInjection = new TemplateInjection(name);
    AttackStep.allAttackSteps.remove(threadExecutionHijacking);
    threadExecutionHijacking = new ThreadExecutionHijacking(name);
    AttackStep.allAttackSteps.remove(trap);
    trap = new Trap(name);
    AttackStep.allAttackSteps.remove(trustedDeveloperUtilities);
    trustedDeveloperUtilities = new TrustedDeveloperUtilities(name);
    AttackStep.allAttackSteps.remove(videoCapture);
    videoCapture = new VideoCapture(name);
    AttackStep.allAttackSteps.remove(windowsAdminShares);
    windowsAdminShares = new WindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentation);
    windowsManagementInstrumentation = new WindowsManagementInstrumentation(name);
    AttackStep.allAttackSteps.remove(attemptWindowsManagementInstrumentationEventSubscription);
    attemptWindowsManagementInstrumentationEventSubscription = new AttemptWindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentationEventSubscription);
    windowsManagementInstrumentationEventSubscription = new WindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(xslScriptProcessing);
    xslScriptProcessing = new XslScriptProcessing(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(archiveCollectedData);
    archiveCollectedData = new ArchiveCollectedData(name);
    AttackStep.allAttackSteps.remove(archiveViaUtility);
    archiveViaUtility = new ArchiveViaUtility(name);
    AttackStep.allAttackSteps.remove(archiveViaLibrary);
    archiveViaLibrary = new ArchiveViaLibrary(name);
    AttackStep.allAttackSteps.remove(archiveViaCustomMethod);
    archiveViaCustomMethod = new ArchiveViaCustomMethod(name);
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountAccessRemoval);
    accountAccessRemoval = new AccountAccessRemoval(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(infectedOS);
    infectedOS = new InfectedOS(name);
    AttackStep.allAttackSteps.remove(clipboardData);
    clipboardData = new ClipboardData(name);
    AttackStep.allAttackSteps.remove(accountDiscovery);
    accountDiscovery = new AccountDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptDomainAccount);
    attemptDomainAccount = new AttemptDomainAccount(name);
    AttackStep.allAttackSteps.remove(domainAccount);
    domainAccount = new DomainAccount(name);
    AttackStep.allAttackSteps.remove(attemptLocalAccount);
    attemptLocalAccount = new AttemptLocalAccount(name);
    AttackStep.allAttackSteps.remove(localAccount);
    localAccount = new LocalAccount(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(visualBasic);
    visualBasic = new VisualBasic(name);
    AttackStep.allAttackSteps.remove(python);
    python = new Python(name);
    AttackStep.allAttackSteps.remove(javaScriptOrJScript);
    javaScriptOrJScript = new JavaScriptOrJScript(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(credentialsFromPasswordStores);
    credentialsFromPasswordStores = new CredentialsFromPasswordStores(name);
    AttackStep.allAttackSteps.remove(dataManipulation);
    dataManipulation = new DataManipulation(name);
    AttackStep.allAttackSteps.remove(dataFromLocalSystem);
    dataFromLocalSystem = new DataFromLocalSystem(name);
    AttackStep.allAttackSteps.remove(defacement);
    defacement = new Defacement(name);
    AttackStep.allAttackSteps.remove(domainDiscovery);
    domainDiscovery = new DomainDiscovery(name);
    AttackStep.allAttackSteps.remove(domainGenerationAlgorithms);
    domainGenerationAlgorithms = new DomainGenerationAlgorithms(name);
    AttackStep.allAttackSteps.remove(compromisedDataOrSystem);
    compromisedDataOrSystem = new CompromisedDataOrSystem(name);
    AttackStep.allAttackSteps.remove(attemptBinaryPadding);
    attemptBinaryPadding = new AttemptBinaryPadding(name);
    AttackStep.allAttackSteps.remove(binaryPadding);
    binaryPadding = new BinaryPadding(name);
    AttackStep.allAttackSteps.remove(applicationWindowDiscovery);
    applicationWindowDiscovery = new ApplicationWindowDiscovery(name);
    AttackStep.allAttackSteps.remove(processDiscovery);
    processDiscovery = new ProcessDiscovery(name);
    AttackStep.allAttackSteps.remove(collectHashInformation);
    collectHashInformation = new CollectHashInformation(name);
    AttackStep.allAttackSteps.remove(compileAfterDelivery);
    compileAfterDelivery = new CompileAfterDelivery(name);
    AttackStep.allAttackSteps.remove(oSCredentialDumping);
    oSCredentialDumping = new OSCredentialDumping(name);
    AttackStep.allAttackSteps.remove(attemptEncryptedChannel);
    attemptEncryptedChannel = new AttemptEncryptedChannel(name);
    AttackStep.allAttackSteps.remove(encryptedChannel);
    encryptedChannel = new EncryptedChannel(name);
    AttackStep.allAttackSteps.remove(dataEncoding);
    dataEncoding = new DataEncoding(name);
    AttackStep.allAttackSteps.remove(standardEncoding);
    standardEncoding = new StandardEncoding(name);
    AttackStep.allAttackSteps.remove(nonStandardEncoding);
    nonStandardEncoding = new NonStandardEncoding(name);
    AttackStep.allAttackSteps.remove(dynamicResolution);
    dynamicResolution = new DynamicResolution(name);
    AttackStep.allAttackSteps.remove(fastFluxDNS);
    fastFluxDNS = new FastFluxDNS(name);
    AttackStep.allAttackSteps.remove(dNSCalculation);
    dNSCalculation = new DNSCalculation(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    AttackStep.allAttackSteps.remove(attemptEndpointDenialOfService);
    attemptEndpointDenialOfService = new AttemptEndpointDenialOfService(name);
    AttackStep.allAttackSteps.remove(endpointDenialOfService);
    endpointDenialOfService = new EndpointDenialOfService(name);
    AttackStep.allAttackSteps.remove(applicationExhaustionFlood);
    applicationExhaustionFlood = new ApplicationExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(oSExhaustionFlood);
    oSExhaustionFlood = new OSExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(applicationOrSystemExploitation);
    applicationOrSystemExploitation = new ApplicationOrSystemExploitation(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(executionGuardrails);
    executionGuardrails = new ExecutionGuardrails(name);
    AttackStep.allAttackSteps.remove(environmentalKeying);
    environmentalKeying = new EnvironmentalKeying(name);
    AttackStep.allAttackSteps.remove(payloadDelivery);
    payloadDelivery = new PayloadDelivery(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverOtherNetworkMedium);
    exfiltrationOverOtherNetworkMedium = new ExfiltrationOverOtherNetworkMedium(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverBluetooth);
    exfiltrationOverBluetooth = new ExfiltrationOverBluetooth(name);
    AttackStep.allAttackSteps.remove(fallbackChannels);
    fallbackChannels = new FallbackChannels(name);
    AttackStep.allAttackSteps.remove(firmwareCorruption);
    firmwareCorruption = new FirmwareCorruption(name);
    AttackStep.allAttackSteps.remove(hideArtifacts);
    hideArtifacts = new HideArtifacts(name);
    AttackStep.allAttackSteps.remove(hiddenFileSystem);
    hiddenFileSystem = new HiddenFileSystem(name);
    AttackStep.allAttackSteps.remove(runVirtualInstance);
    runVirtualInstance = new RunVirtualInstance(name);
    AttackStep.allAttackSteps.remove(hiddenFilesAndDirectories);
    hiddenFilesAndDirectories = new HiddenFilesAndDirectories(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalFromTools);
    indicatorRemovalFromTools = new IndicatorRemovalFromTools(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(timestomp);
    timestomp = new Timestomp(name);
    AttackStep.allAttackSteps.remove(inputCapture);
    inputCapture = new InputCapture(name);
    AttackStep.allAttackSteps.remove(keylogging);
    keylogging = new Keylogging(name);
    AttackStep.allAttackSteps.remove(lateralToolTransfer);
    lateralToolTransfer = new LateralToolTransfer(name);
    AttackStep.allAttackSteps.remove(webPortalCapture);
    webPortalCapture = new WebPortalCapture(name);
    AttackStep.allAttackSteps.remove(internalSpearphishing);
    internalSpearphishing = new InternalSpearphishing(name);
    AttackStep.allAttackSteps.remove(attemptDynamicDataExchange);
    attemptDynamicDataExchange = new AttemptDynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(manInTheMiddle);
    manInTheMiddle = new ManInTheMiddle(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(rightToLeftOverride);
    rightToLeftOverride = new RightToLeftOverride(name);
    AttackStep.allAttackSteps.remove(renameSystemUtilities);
    renameSystemUtilities = new RenameSystemUtilities(name);
    AttackStep.allAttackSteps.remove(matchLegitimateNameOrLocation);
    matchLegitimateNameOrLocation = new MatchLegitimateNameOrLocation(name);
    AttackStep.allAttackSteps.remove(proxy);
    proxy = new Proxy(name);
    AttackStep.allAttackSteps.remove(internalProxy);
    internalProxy = new InternalProxy(name);
    AttackStep.allAttackSteps.remove(externalProxy);
    externalProxy = new ExternalProxy(name);
    AttackStep.allAttackSteps.remove(attemptMultiHopProxy);
    attemptMultiHopProxy = new AttemptMultiHopProxy(name);
    AttackStep.allAttackSteps.remove(multiHopProxy);
    multiHopProxy = new MultiHopProxy(name);
    AttackStep.allAttackSteps.remove(domainFronting);
    domainFronting = new DomainFronting(name);
    AttackStep.allAttackSteps.remove(attemptMultiStageChannels);
    attemptMultiStageChannels = new AttemptMultiStageChannels(name);
    AttackStep.allAttackSteps.remove(multiStageChannels);
    multiStageChannels = new MultiStageChannels(name);
    AttackStep.allAttackSteps.remove(networkDenialOfService);
    networkDenialOfService = new NetworkDenialOfService(name);
    AttackStep.allAttackSteps.remove(directNetworkFlood);
    directNetworkFlood = new DirectNetworkFlood(name);
    AttackStep.allAttackSteps.remove(reflectionAmplification);
    reflectionAmplification = new ReflectionAmplification(name);
    AttackStep.allAttackSteps.remove(networkSniffing);
    networkSniffing = new NetworkSniffing(name);
    AttackStep.allAttackSteps.remove(obfuscatedFilesOrInformation);
    obfuscatedFilesOrInformation = new ObfuscatedFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(steganography);
    steganography = new Steganography(name);
    AttackStep.allAttackSteps.remove(attemptPrivateKeys);
    attemptPrivateKeys = new AttemptPrivateKeys(name);
    AttackStep.allAttackSteps.remove(privateKeys);
    privateKeys = new PrivateKeys(name);
    AttackStep.allAttackSteps.remove(privateKeysWithPassphrase);
    privateKeysWithPassphrase = new PrivateKeysWithPassphrase(name);
    AttackStep.allAttackSteps.remove(resourceHijacking);
    resourceHijacking = new ResourceHijacking(name);
    AttackStep.allAttackSteps.remove(communicationThroughRemovableMedia);
    communicationThroughRemovableMedia = new CommunicationThroughRemovableMedia(name);
    AttackStep.allAttackSteps.remove(remoteSystemDiscovery);
    remoteSystemDiscovery = new RemoteSystemDiscovery(name);
    AttackStep.allAttackSteps.remove(detailedRemoteSystemDiscovery);
    detailedRemoteSystemDiscovery = new DetailedRemoteSystemDiscovery(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(attemptDisableOrModifyTools);
    attemptDisableOrModifyTools = new AttemptDisableOrModifyTools(name);
    AttackStep.allAttackSteps.remove(disableOrModifyTools);
    disableOrModifyTools = new DisableOrModifyTools(name);
    AttackStep.allAttackSteps.remove(disableOrModifySystemFirewall);
    disableOrModifySystemFirewall = new DisableOrModifySystemFirewall(name);
    AttackStep.allAttackSteps.remove(attemptIndicatorBlocking);
    attemptIndicatorBlocking = new AttemptIndicatorBlocking(name);
    AttackStep.allAttackSteps.remove(indicatorBlocking);
    indicatorBlocking = new IndicatorBlocking(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(serverSoftwareComponent);
    serverSoftwareComponent = new ServerSoftwareComponent(name);
    AttackStep.allAttackSteps.remove(softwareDiscovery);
    softwareDiscovery = new SoftwareDiscovery(name);
    AttackStep.allAttackSteps.remove(securitySoftwareDiscovery);
    securitySoftwareDiscovery = new SecuritySoftwareDiscovery(name);
    AttackStep.allAttackSteps.remove(systemAccess);
    systemAccess = new SystemAccess(name);
    AttackStep.allAttackSteps.remove(systemInformationDiscovery);
    systemInformationDiscovery = new SystemInformationDiscovery(name);
    AttackStep.allAttackSteps.remove(systemNetworkConnectionsDiscovery);
    systemNetworkConnectionsDiscovery = new SystemNetworkConnectionsDiscovery(name);
    AttackStep.allAttackSteps.remove(systemOwnerOrUserDiscovery);
    systemOwnerOrUserDiscovery = new SystemOwnerOrUserDiscovery(name);
    AttackStep.allAttackSteps.remove(systemServices);
    systemServices = new SystemServices(name);
    AttackStep.allAttackSteps.remove(systemShutdownOrReboot);
    systemShutdownOrReboot = new SystemShutdownOrReboot(name);
    AttackStep.allAttackSteps.remove(processInjection);
    processInjection = new ProcessInjection(name);
    AttackStep.allAttackSteps.remove(attemptProtocolTunneling);
    attemptProtocolTunneling = new AttemptProtocolTunneling(name);
    AttackStep.allAttackSteps.remove(protocolTunneling);
    protocolTunneling = new ProtocolTunneling(name);
    AttackStep.allAttackSteps.remove(rootkit);
    rootkit = new Rootkit(name);
    AttackStep.allAttackSteps.remove(runtimeDataManipulation);
    runtimeDataManipulation = new RuntimeDataManipulation(name);
    AttackStep.allAttackSteps.remove(attemptApplicationLayerProtocol);
    attemptApplicationLayerProtocol = new AttemptApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(applicationLayerProtocol);
    applicationLayerProtocol = new ApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(attemptNonApplicationLayerProtocol);
    attemptNonApplicationLayerProtocol = new AttemptNonApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(nonApplicationLayerProtocol);
    nonApplicationLayerProtocol = new NonApplicationLayerProtocol(name);
    AttackStep.allAttackSteps.remove(webProtocols);
    webProtocols = new WebProtocols(name);
    AttackStep.allAttackSteps.remove(fileTransferProtocols);
    fileTransferProtocols = new FileTransferProtocols(name);
    AttackStep.allAttackSteps.remove(mailProtocols);
    mailProtocols = new MailProtocols(name);
    AttackStep.allAttackSteps.remove(dNS);
    dNS = new DNS(name);
    AttackStep.allAttackSteps.remove(systemNetworkConfigurationDiscovery);
    systemNetworkConfigurationDiscovery = new SystemNetworkConfigurationDiscovery(name);
    AttackStep.allAttackSteps.remove(twoFactorAuthenticationInterception);
    twoFactorAuthenticationInterception = new TwoFactorAuthenticationInterception(name);
    AttackStep.allAttackSteps.remove(modifyAPICalls);
    modifyAPICalls = new ModifyAPICalls(name);
    AttackStep.allAttackSteps.remove(bypassAntivirus);
    bypassAntivirus = new BypassAntivirus(name);
    AttackStep.allAttackSteps.remove(bypassAutorunsAnalysis);
    bypassAutorunsAnalysis = new BypassAutorunsAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassApplicationControl);
    bypassApplicationControl = new BypassApplicationControl(name);
    AttackStep.allAttackSteps.remove(bypassApplicationWhitelisting);
    bypassApplicationWhitelisting = new BypassApplicationWhitelisting(name);
    AttackStep.allAttackSteps.remove(bypassBinaryAnalysis);
    bypassBinaryAnalysis = new BypassBinaryAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassDefensiveNetworkServiceScanning);
    bypassDefensiveNetworkServiceScanning = new BypassDefensiveNetworkServiceScanning(name);
    AttackStep.allAttackSteps.remove(bypassDigitalCertificateValidation);
    bypassDigitalCertificateValidation = new BypassDigitalCertificateValidation(name);
    AttackStep.allAttackSteps.remove(bypassEgressFiltering);
    bypassEgressFiltering = new BypassEgressFiltering(name);
    AttackStep.allAttackSteps.remove(bypassFileMonitoring);
    bypassFileMonitoring = new BypassFileMonitoring(name);
    AttackStep.allAttackSteps.remove(bypassFileOrPathWhitelisting);
    bypassFileOrPathWhitelisting = new BypassFileOrPathWhitelisting(name);
    AttackStep.allAttackSteps.remove(bypassFileSystemAccessControls);
    bypassFileSystemAccessControls = new BypassFileSystemAccessControls(name);
    AttackStep.allAttackSteps.remove(bypassHeuristicDetection);
    bypassHeuristicDetection = new BypassHeuristicDetection(name);
    AttackStep.allAttackSteps.remove(bypassHostForensicAnalysis);
    bypassHostForensicAnalysis = new BypassHostForensicAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassHostIntrusionPrevention);
    bypassHostIntrusionPrevention = new BypassHostIntrusionPrevention(name);
    AttackStep.allAttackSteps.remove(bypassProcessWhitelisting);
    bypassProcessWhitelisting = new BypassProcessWhitelisting(name);
    AttackStep.allAttackSteps.remove(bypassSystemAccessControls);
    bypassSystemAccessControls = new BypassSystemAccessControls(name);
    AttackStep.allAttackSteps.remove(bypassLogAnalysis);
    bypassLogAnalysis = new BypassLogAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassSignatureBasedDetection);
    bypassSignatureBasedDetection = new BypassSignatureBasedDetection(name);
    AttackStep.allAttackSteps.remove(bypassStaticFileAnalysis);
    bypassStaticFileAnalysis = new BypassStaticFileAnalysis(name);
    AttackStep.allAttackSteps.remove(bypassUserModeSignatureValidation);
    bypassUserModeSignatureValidation = new BypassUserModeSignatureValidation(name);
    AttackStep.allAttackSteps.remove(passwordPolicyDiscovery);
    passwordPolicyDiscovery = new PasswordPolicyDiscovery(name);
    AttackStep.allAttackSteps.remove(bruteForceWithPasswordPolicy);
    bruteForceWithPasswordPolicy = new BruteForceWithPasswordPolicy(name);
    AttackStep.allAttackSteps.remove(bruteForce);
    bruteForce = new BruteForce(name);
    AttackStep.allAttackSteps.remove(passTheHash);
    passTheHash = new PassTheHash(name);
    AttackStep.allAttackSteps.remove(passTheTicket);
    passTheTicket = new PassTheTicket(name);
    AttackStep.allAttackSteps.remove(passwordGuessing);
    passwordGuessing = new PasswordGuessing(name);
    AttackStep.allAttackSteps.remove(attemptPasswordCracking);
    attemptPasswordCracking = new AttemptPasswordCracking(name);
    AttackStep.allAttackSteps.remove(passwordCracking);
    passwordCracking = new PasswordCracking(name);
    AttackStep.allAttackSteps.remove(passwordSpraying);
    passwordSpraying = new PasswordSpraying(name);
    AttackStep.allAttackSteps.remove(credentialStuffing);
    credentialStuffing = new CredentialStuffing(name);
    AttackStep.allAttackSteps.remove(permissionGroupsDiscovery);
    permissionGroupsDiscovery = new PermissionGroupsDiscovery(name);
    AttackStep.allAttackSteps.remove(localGroups);
    localGroups = new LocalGroups(name);
    AttackStep.allAttackSteps.remove(domainGroups);
    domainGroups = new DomainGroups(name);
    AttackStep.allAttackSteps.remove(preOSBoot);
    preOSBoot = new PreOSBoot(name);
    AttackStep.allAttackSteps.remove(attemptAntivirusCheck);
    attemptAntivirusCheck = new AttemptAntivirusCheck(name);
    AttackStep.allAttackSteps.remove(antivirusCheck);
    antivirusCheck = new AntivirusCheck(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(sSHCredentialInterception);
    sSHCredentialInterception = new SSHCredentialInterception(name);
    AttackStep.allAttackSteps.remove(storedDataManipulation);
    storedDataManipulation = new StoredDataManipulation(name);
    AttackStep.allAttackSteps.remove(nonStandardPort);
    nonStandardPort = new NonStandardPort(name);
    AttackStep.allAttackSteps.remove(subvertTrustControls);
    subvertTrustControls = new SubvertTrustControls(name);
    AttackStep.allAttackSteps.remove(installRootCertificate);
    installRootCertificate = new InstallRootCertificate(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(attemptCredentialsInFiles);
    attemptCredentialsInFiles = new AttemptCredentialsInFiles(name);
    AttackStep.allAttackSteps.remove(credentialsInFiles);
    credentialsInFiles = new CredentialsInFiles(name);
    AttackStep.allAttackSteps.remove(validAccounts);
    validAccounts = new ValidAccounts(name);
    AttackStep.allAttackSteps.remove(defaultAccounts);
    defaultAccounts = new DefaultAccounts(name);
    AttackStep.allAttackSteps.remove(attemptDomainAccounts);
    attemptDomainAccounts = new AttemptDomainAccounts(name);
    AttackStep.allAttackSteps.remove(domainAccounts);
    domainAccounts = new DomainAccounts(name);
    AttackStep.allAttackSteps.remove(attemptLocalAccounts);
    attemptLocalAccounts = new AttemptLocalAccounts(name);
    AttackStep.allAttackSteps.remove(localAccounts);
    localAccounts = new LocalAccounts(name);
    AttackStep.allAttackSteps.remove(virtualizationOrSandboxEvasion);
    virtualizationOrSandboxEvasion = new VirtualizationOrSandboxEvasion(name);
    AttackStep.allAttackSteps.remove(systemChecks);
    systemChecks = new SystemChecks(name);
    AttackStep.allAttackSteps.remove(userActivityBasedChecks);
    userActivityBasedChecks = new UserActivityBasedChecks(name);
    AttackStep.allAttackSteps.remove(timeBasedEvasion);
    timeBasedEvasion = new TimeBasedEvasion(name);
    AttackStep.allAttackSteps.remove(vNC);
    vNC = new VNC(name);
    AttackStep.allAttackSteps.remove(fileDeletion);
    fileDeletion = new FileDeletion(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryDiscovery);
    fileAndDirectoryDiscovery = new FileAndDirectoryDiscovery(name);
    AttackStep.allAttackSteps.remove(diskWipe);
    diskWipe = new DiskWipe(name);
    AttackStep.allAttackSteps.remove(diskContentWipe);
    diskContentWipe = new DiskContentWipe(name);
    AttackStep.allAttackSteps.remove(diskStructureWipe);
    diskStructureWipe = new DiskStructureWipe(name);
    AttackStep.allAttackSteps.remove(remoteFileCopy);
    remoteFileCopy = new RemoteFileCopy(name);
    AttackStep.allAttackSteps.remove(sensitiveDataCollected);
    sensitiveDataCollected = new SensitiveDataCollected(name);
    AttackStep.allAttackSteps.remove(dataCollected);
    dataCollected = new DataCollected(name);
    AttackStep.allAttackSteps.remove(dataEncrypted);
    dataEncrypted = new DataEncrypted(name);
    AttackStep.allAttackSteps.remove(dataSizedTransfer);
    dataSizedTransfer = new DataSizedTransfer(name);
    AttackStep.allAttackSteps.remove(dataStaged);
    dataStaged = new DataStaged(name);
    AttackStep.allAttackSteps.remove(localDataStaging);
    localDataStaging = new LocalDataStaging(name);
    AttackStep.allAttackSteps.remove(replicationThroughRemovableMedia);
    replicationThroughRemovableMedia = new ReplicationThroughRemovableMedia(name);
    AttackStep.allAttackSteps.remove(remoteDataStaging);
    remoteDataStaging = new RemoteDataStaging(name);
    AttackStep.allAttackSteps.remove(attemptDataDestruction);
    attemptDataDestruction = new AttemptDataDestruction(name);
    AttackStep.allAttackSteps.remove(dataDestruction);
    dataDestruction = new DataDestruction(name);
    AttackStep.allAttackSteps.remove(attemptDataEncryptedForImpact);
    attemptDataEncryptedForImpact = new AttemptDataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataCompressed);
    dataCompressed = new DataCompressed(name);
    AttackStep.allAttackSteps.remove(inhibitSystemRecovery);
    inhibitSystemRecovery = new InhibitSystemRecovery(name);
    AttackStep.allAttackSteps.remove(screenCapture);
    screenCapture = new ScreenCapture(name);
    AttackStep.allAttackSteps.remove(scheduledExfiltration);
    scheduledExfiltration = new ScheduledExfiltration(name);
    AttackStep.allAttackSteps.remove(attemptExfiltrationOverAternativeProtocol);
    attemptExfiltrationOverAternativeProtocol = new AttemptExfiltrationOverAternativeProtocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverAternativeProtocol);
    exfiltrationOverAternativeProtocol = new ExfiltrationOverAternativeProtocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverAsymmetricEncryptedNonC2Protocol);
    exfiltrationOverAsymmetricEncryptedNonC2Protocol = new ExfiltrationOverAsymmetricEncryptedNonC2Protocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverSymmetricEncryptedNonC2Protocol);
    exfiltrationOverSymmetricEncryptedNonC2Protocol = new ExfiltrationOverSymmetricEncryptedNonC2Protocol(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol);
    exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol = new ExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol(name);
    AttackStep.allAttackSteps.remove(dataFromInformationRepositories);
    dataFromInformationRepositories = new DataFromInformationRepositories(name);
    AttackStep.allAttackSteps.remove(confluence);
    confluence = new Confluence(name);
    AttackStep.allAttackSteps.remove(sharepoint);
    sharepoint = new Sharepoint(name);
    AttackStep.allAttackSteps.remove(windowsService);
    windowsService = new WindowsService(name);
    AttackStep.allAttackSteps.remove(attemptAutomatedCollection);
    attemptAutomatedCollection = new AttemptAutomatedCollection(name);
    AttackStep.allAttackSteps.remove(automatedCollection);
    automatedCollection = new AutomatedCollection(name);
    AttackStep.allAttackSteps.remove(automatedExfiltration);
    automatedExfiltration = new AutomatedExfiltration(name);
    AttackStep.allAttackSteps.remove(networkServiceScan);
    networkServiceScan = new NetworkServiceScan(name);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, false);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, false);
    if (restrictRegistryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictRegistryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictRegistryPermissions);
    restrictRegistryPermissions = new RestrictRegistryPermissions(name, false);
    if (accountUsePolicies != null) {
      AttackStep.allAttackSteps.remove(accountUsePolicies.disable);
    }
    Defense.allDefenses.remove(accountUsePolicies);
    accountUsePolicies = new AccountUsePolicies(name, false);
    if (behaviorPreventionOnEndpoint != null) {
      AttackStep.allAttackSteps.remove(behaviorPreventionOnEndpoint.disable);
    }
    Defense.allDefenses.remove(behaviorPreventionOnEndpoint);
    behaviorPreventionOnEndpoint = new BehaviorPreventionOnEndpoint(name, false);
    if (bootIntegrity != null) {
      AttackStep.allAttackSteps.remove(bootIntegrity.disable);
    }
    Defense.allDefenses.remove(bootIntegrity);
    bootIntegrity = new BootIntegrity(name, false);
    if (dataBackup != null) {
      AttackStep.allAttackSteps.remove(dataBackup.disable);
    }
    Defense.allDefenses.remove(dataBackup);
    dataBackup = new DataBackup(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
    if (applicationIsolationAndSandboxing != null) {
      AttackStep.allAttackSteps.remove(applicationIsolationAndSandboxing.disable);
    }
    Defense.allDefenses.remove(applicationIsolationAndSandboxing);
    applicationIsolationAndSandboxing = new ApplicationIsolationAndSandboxing(name, false);
    if (doNotMitigate != null) {
      AttackStep.allAttackSteps.remove(doNotMitigate.disable);
    }
    Defense.allDefenses.remove(doNotMitigate);
    doNotMitigate = new DoNotMitigate(name, false);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, false);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, false);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, false);
    if (applicationDeveloperGuidance != null) {
      AttackStep.allAttackSteps.remove(applicationDeveloperGuidance.disable);
    }
    Defense.allDefenses.remove(applicationDeveloperGuidance);
    applicationDeveloperGuidance = new ApplicationDeveloperGuidance(name, false);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, false);
    if (limitHardwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitHardwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitHardwareInstallation);
    limitHardwareInstallation = new LimitHardwareInstallation(name, false);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, false);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, false);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, false);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, false);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, false);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, false);
    if (limitSoftwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitSoftwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitSoftwareInstallation);
    limitSoftwareInstallation = new LimitSoftwareInstallation(name, false);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, false);
    if (userAccountControl != null) {
      AttackStep.allAttackSteps.remove(userAccountControl.disable);
    }
    Defense.allDefenses.remove(userAccountControl);
    userAccountControl = new UserAccountControl(name, false);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, false);
  }

  public OS(boolean isAntivirusEnabled, boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled) {
    this("Anonymous", isAntivirusEnabled, isRestrictFileAndDirectoryPermissionsEnabled, isRestrictRegistryPermissionsEnabled, isAccountUsePoliciesEnabled, isBehaviorPreventionOnEndpointEnabled, isBootIntegrityEnabled, isDataBackupEnabled, isMultiFactorAuthenticationEnabled, isPasswordPoliciesEnabled, isApplicationIsolationAndSandboxingEnabled, isDoNotMitigateEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isActiveDirectoryConfigurationEnabled, isAuditEnabled, isApplicationDeveloperGuidanceEnabled, isCodeSigningEnabled, isLimitHardwareInstallationEnabled, isOperatingSystemConfigurationEnabled, isSoftwareConfigurationEnabled, isExecutionPreventionEnabled, isPrivilegedAccountManagementEnabled, isEncryptSensitiveInformationEnabled, isRemoteDataStorageEnabled, isLimitSoftwareInstallationEnabled, isUpdateSoftwareEnabled, isUserAccountControlEnabled, isExploitProtectionEnabled);
  }

  public OS() {
    this("Anonymous");
  }

  public void addUserAccount(UserAccount userAccount) {
    this.userAccount.add(userAccount);
    userAccount.os = this;
  }

  public void addAdminAccount(AdminAccount adminAccount) {
    this.adminAccount.add(adminAccount);
    adminAccount.os = this;
  }

  public void addService(Service service) {
    this.service.add(service);
    service.os = this;
  }

  public void addComputer(Computer computer) {
    this.computer.add(computer);
    computer.os.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("userAccount")) {
      return UserAccount.class.getName();
    } else if (field.equals("adminAccount")) {
      return AdminAccount.class.getName();
    } else if (field.equals("service")) {
      return Service.class.getName();
    } else if (field.equals("computer")) {
      return Computer.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("userAccount")) {
      assets.addAll(userAccount);
    } else if (field.equals("adminAccount")) {
      assets.addAll(adminAccount);
    } else if (field.equals("service")) {
      assets.addAll(service);
    } else if (field.equals("computer")) {
      assets.addAll(computer);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(userAccount);
    assets.addAll(adminAccount);
    assets.addAll(service);
    assets.addAll(computer);
    return assets;
  }

  public class AttemptBITSJobs extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptBITSJobs;

    public AttemptBITSJobs(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptBITSJobs == null) {
        _cacheParentAttemptBITSJobs = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptBITSJobs.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAttemptBITSJobs.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptBITSJobs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptBITSJobs");
    }
  }

  public class AttemptAppCertDLLs extends AttackStepMin {
    public AttemptAppCertDLLs(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptAppCertDLLs");
    }
  }

  public class AppCertDLLs extends AttackStepMax {
    private Set<AttackStep> _cacheParentAppCertDLLs;

    public AppCertDLLs(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAppCertDLLs == null) {
        _cacheParentAppCertDLLs = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAppCertDLLs.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAppCertDLLs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.appCertDLLs");
    }
  }

  public class BypassUserAccessControl extends AttackStepMax {
    private Set<AttackStep> _cacheParentBypassUserAccessControl;

    public BypassUserAccessControl(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassUserAccessControl == null) {
        _cacheParentBypassUserAccessControl = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentBypassUserAccessControl.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassUserAccessControl) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassUserAccessControl");
    }
  }

  public class ChangeDefaultFileAssociation extends AttackStepMin {
    private Set<AttackStep> _cacheParentChangeDefaultFileAssociation;

    public ChangeDefaultFileAssociation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentChangeDefaultFileAssociation == null) {
        _cacheParentChangeDefaultFileAssociation = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentChangeDefaultFileAssociation.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentChangeDefaultFileAssociation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.changeDefaultFileAssociation");
    }
  }

  public class AttemptGatekeeperBypass extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptGatekeeperBypass;

    public AttemptGatekeeperBypass(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptGatekeeperBypass == null) {
        _cacheParentAttemptGatekeeperBypass = new HashSet<>();
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheParentAttemptGatekeeperBypass.add(_1.driveByCompromise);
          }
        }
        for (Computer _2 : computer) {
          if (_2 instanceof HardwareAddition) {
            _cacheParentAttemptGatekeeperBypass.add(((asset.HardwareAddition) _2).hardwareAdditions);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptGatekeeperBypass) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptGatekeeperBypass");
    }
  }

  public class GatekeeperBypass extends AttackStepMax {
    private Set<AttackStep> _cacheParentGatekeeperBypass;

    public GatekeeperBypass(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGatekeeperBypass == null) {
        _cacheParentGatekeeperBypass = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentGatekeeperBypass.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentGatekeeperBypass) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.gatekeeperBypass");
    }
  }

  public class Cmstp extends AttackStepMax {
    private Set<AttackStep> _cacheParentCmstp;

    public Cmstp(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCmstp == null) {
        _cacheParentCmstp = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentCmstp.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentCmstp) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.cmstp");
    }
  }

  public class CompiledHTMLFile extends AttackStepMax {
    private Set<AttackStep> _cacheParentCompiledHTMLFile;

    public CompiledHTMLFile(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCompiledHTMLFile == null) {
        _cacheParentCompiledHTMLFile = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentCompiledHTMLFile.add(_0.userRights);
        }
        for (Service _1 : service) {
          for (Browser _2 : _1.browser) {
            _cacheParentCompiledHTMLFile.add(_2.restrictWebBasedContent.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCompiledHTMLFile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.compiledHTMLFile");
    }
  }

  public class COR_PROFILER extends AttackStepMax {
    private Set<AttackStep> _cacheParentCOR_PROFILER;

    public COR_PROFILER(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCOR_PROFILER == null) {
        _cacheParentCOR_PROFILER = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentCOR_PROFILER.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentCOR_PROFILER.add(_1.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentCOR_PROFILER) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.cOR_PROFILER");
    }
  }

  public class ComponentObjectModelHijacking extends AttackStepMin {
    private Set<AttackStep> _cacheParentComponentObjectModelHijacking;

    public ComponentObjectModelHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentComponentObjectModelHijacking == null) {
        _cacheParentComponentObjectModelHijacking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentComponentObjectModelHijacking.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentComponentObjectModelHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.componentObjectModelHijacking");
    }
  }

  public class ControlPanel extends AttackStepMax {
    private Set<AttackStep> _cacheParentControlPanel;

    public ControlPanel(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentControlPanel == null) {
        _cacheParentControlPanel = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentControlPanel.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentControlPanel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.controlPanel");
    }
  }

  public class CredentialsInRegistry extends AttackStepMax {
    private Set<AttackStep> _cacheParentCredentialsInRegistry;

    public CredentialsInRegistry(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialsInRegistry == null) {
        _cacheParentCredentialsInRegistry = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentCredentialsInRegistry.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentCredentialsInRegistry) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.credentialsInRegistry");
    }
  }

  public class DeobfuscateOrDecodeFilesOrInformation extends AttackStepMin {
    private Set<AttackStep> _cacheParentDeobfuscateOrDecodeFilesOrInformation;

    public DeobfuscateOrDecodeFilesOrInformation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDeobfuscateOrDecodeFilesOrInformation == null) {
        _cacheParentDeobfuscateOrDecodeFilesOrInformation = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDeobfuscateOrDecodeFilesOrInformation.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDeobfuscateOrDecodeFilesOrInformation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.deobfuscateOrDecodeFilesOrInformation");
    }
  }

  public class DLLSearchOrderHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheParentDLLSearchOrderHijacking;

    public DLLSearchOrderHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDLLSearchOrderHijacking == null) {
        _cacheParentDLLSearchOrderHijacking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDLLSearchOrderHijacking.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDLLSearchOrderHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dLLSearchOrderHijacking");
    }
  }

  public class DomainTrustDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheParentDomainTrustDiscovery;

    public DomainTrustDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainTrustDiscovery == null) {
        _cacheParentDomainTrustDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDomainTrustDiscovery.add(_0.userRights);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentDomainTrustDiscovery.add(_3.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDomainTrustDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainTrustDiscovery");
    }
  }

  public class DynamicDataExchange extends AttackStepMax {
    private Set<AttackStep> _cacheParentDynamicDataExchange;

    public DynamicDataExchange(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDynamicDataExchange == null) {
        _cacheParentDynamicDataExchange = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDynamicDataExchange.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDynamicDataExchange) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dynamicDataExchange");
    }
  }

  public class Mshta extends AttackStepMax {
    private Set<AttackStep> _cacheParentMshta;

    public Mshta(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMshta == null) {
        _cacheParentMshta = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentMshta.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentMshta) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.mshta");
    }
  }

  public class WindowsRemoteManagement extends AttackStepMin {
    private Set<AttackStep> _cacheParentWindowsRemoteManagement;

    public WindowsRemoteManagement(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsRemoteManagement == null) {
        _cacheParentWindowsRemoteManagement = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentWindowsRemoteManagement.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentWindowsRemoteManagement.add(_1.adminRights);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentWindowsRemoteManagement.add(_2.privilegedAccountManagement.disable);
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            if (_4.firewall != null) {
              _cacheParentWindowsRemoteManagement.add(_4.firewall.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentWindowsRemoteManagement) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.windowsRemoteManagement");
    }
  }

  public class _etc_passwdAND_etc_shadow extends AttackStepMax {
    public _etc_passwdAND_etc_shadow(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS._etc_passwdAND_etc_shadow");
    }
  }

  public class AccessibilityFeatures extends AttackStepMax {
    private Set<AttackStep> _cacheParentAccessibilityFeatures;

    public AccessibilityFeatures(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccessibilityFeatures == null) {
        _cacheParentAccessibilityFeatures = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAccessibilityFeatures.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAccessibilityFeatures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.accessibilityFeatures");
    }
  }

  public class AppInitDLLs extends AttackStepMax {
    private Set<AttackStep> _cacheParentAppInitDLLs;

    public AppInitDLLs(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAppInitDLLs == null) {
        _cacheParentAppInitDLLs = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAppInitDLLs.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAppInitDLLs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.appInitDLLs");
    }
  }

  public class ApplicationShimming extends AttackStepMax {
    private Set<AttackStep> _cacheParentApplicationShimming;

    public ApplicationShimming(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationShimming == null) {
        _cacheParentApplicationShimming = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentApplicationShimming.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentApplicationShimming) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.applicationShimming");
    }
  }

  public class At extends AttackStepMax {
    private Set<AttackStep> _cacheParentAt;

    public At(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAt == null) {
        _cacheParentAt = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAt.add(_0.userAccountManagement.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAt.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAt) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.at");
    }
  }

  public class AttemptBootkit extends AttackStepMin {
    public AttemptBootkit(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptBootkit");
    }
  }

  public class AttemptElevatedExecutionWithPrompt extends AttackStepMin {
    public AttemptElevatedExecutionWithPrompt(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptElevatedExecutionWithPrompt");
    }
  }

  public class AttemptLSASSDriver extends AttackStepMin {
    public AttemptLSASSDriver(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptLSASSDriver");
    }
  }

  public class AttemptLSASSMemory extends AttackStepMin {
    public AttemptLSASSMemory(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptLSASSMemory");
    }
  }

  public class AttemptPasswordFilterDLL extends AttackStepMin {
    public AttemptPasswordFilterDLL(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptPasswordFilterDLL");
    }
  }

  public class AttemptServiceExecution extends AttackStepMin {
    public AttemptServiceExecution(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptServiceExecution");
    }
  }

  public class AttemptServiceRegistryPermissionsWeakness extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptServiceRegistryPermissionsWeakness;

    public AttemptServiceRegistryPermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptServiceRegistryPermissionsWeakness == null) {
        _cacheParentAttemptServiceRegistryPermissionsWeakness = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptServiceRegistryPermissionsWeakness.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptServiceRegistryPermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptServiceRegistryPermissionsWeakness");
    }
  }

  public class AttemptServicesFilePermissionsWeakness extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptServicesFilePermissionsWeakness;

    public AttemptServicesFilePermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptServicesFilePermissionsWeakness == null) {
        _cacheParentAttemptServicesFilePermissionsWeakness = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptServicesFilePermissionsWeakness.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptServicesFilePermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptServicesFilePermissionsWeakness");
    }
  }

  public class AttemptSIDHistoryInjection extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptSIDHistoryInjection;

    public AttemptSIDHistoryInjection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSIDHistoryInjection == null) {
        _cacheParentAttemptSIDHistoryInjection = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptSIDHistoryInjection.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptSIDHistoryInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptSIDHistoryInjection");
    }
  }

  public class AttemptSIPAndTrustProviderHijacking extends AttackStepMin {
    public AttemptSIPAndTrustProviderHijacking(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptSIPAndTrustProviderHijacking");
    }
  }

  public class AttemptSQLStoredProcedures extends AttackStepMin {
    public AttemptSQLStoredProcedures(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptSQLStoredProcedures");
    }
  }

  public class AttemptStartupItems extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptStartupItems;

    public AttemptStartupItems(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptStartupItems == null) {
        _cacheParentAttemptStartupItems = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptStartupItems.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptStartupItems) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptStartupItems");
    }
  }

  public class AttemptSystemFirmware extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptSystemFirmware;

    public AttemptSystemFirmware(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSystemFirmware == null) {
        _cacheParentAttemptSystemFirmware = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentAttemptSystemFirmware.add(_0.externalRemoteServices);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptSystemFirmware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptSystemFirmware");
    }
  }

  public class AttemptTimeProviders extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptTimeProviders;

    public AttemptTimeProviders(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTimeProviders == null) {
        _cacheParentAttemptTimeProviders = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptTimeProviders.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptTimeProviders) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptTimeProviders");
    }
  }

  public class AttemptTransportAgent extends AttackStepMin {
    public AttemptTransportAgent(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptTransportAgent");
    }
  }

  public class AttemptWinlogonHelperDLL extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptWinlogonHelperDLL;

    public AttemptWinlogonHelperDLL(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWinlogonHelperDLL == null) {
        _cacheParentAttemptWinlogonHelperDLL = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptWinlogonHelperDLL.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptWinlogonHelperDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptWinlogonHelperDLL");
    }
  }

  public class AttemptWindowsRemoteManagement extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptWindowsRemoteManagement;

    public AttemptWindowsRemoteManagement(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWindowsRemoteManagement == null) {
        _cacheParentAttemptWindowsRemoteManagement = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentAttemptWindowsRemoteManagement.add(_0.remoteServices);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptWindowsRemoteManagement) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptWindowsRemoteManagement");
    }
  }

  public class WinlogonHelperDLL extends AttackStepMax {
    private Set<AttackStep> _cacheParentWinlogonHelperDLL;

    public WinlogonHelperDLL(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWinlogonHelperDLL == null) {
        _cacheParentWinlogonHelperDLL = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentWinlogonHelperDLL.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentWinlogonHelperDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.winlogonHelperDLL");
    }
  }

  public class AuthenticationPackage extends AttackStepMax {
    private Set<AttackStep> _cacheParentAuthenticationPackage;

    public AuthenticationPackage(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAuthenticationPackage == null) {
        _cacheParentAuthenticationPackage = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAuthenticationPackage.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAuthenticationPackage) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.authenticationPackage");
    }
  }

  public class Bootkit extends AttackStepMax {
    private Set<AttackStep> _cacheParentBootkit;

    public Bootkit(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBootkit == null) {
        _cacheParentBootkit = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentBootkit.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentBootkit) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bootkit");
    }
  }

  public class ClearWindowsEventLogs extends AttackStepMax {
    private Set<AttackStep> _cacheParentClearWindowsEventLogs;

    public ClearWindowsEventLogs(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClearWindowsEventLogs == null) {
        _cacheParentClearWindowsEventLogs = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentClearWindowsEventLogs.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentClearWindowsEventLogs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.clearWindowsEventLogs");
    }
  }

  public class ComponentFirmware extends AttackStepMin {
    public ComponentFirmware(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.componentFirmware");
    }
  }

  public class CredentialAPIHooking extends AttackStepMin {
    private Set<AttackStep> _cacheParentCredentialAPIHooking;

    public CredentialAPIHooking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialAPIHooking == null) {
        _cacheParentCredentialAPIHooking = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentCredentialAPIHooking.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentCredentialAPIHooking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.credentialAPIHooking");
    }
  }

  public class DCShadow extends AttackStepMin {
    private Set<AttackStep> _cacheParentDCShadow;

    public DCShadow(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDCShadow == null) {
        _cacheParentDCShadow = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentDCShadow.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDCShadow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dCShadow");
    }
  }

  public class DCSync extends AttackStepMax {
    private Set<AttackStep> _cacheParentDCSync;

    public DCSync(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDCSync == null) {
        _cacheParentDCSync = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentDCSync.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDCSync) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dCSync");
    }
  }

  public class DisableWindowsEventLogging extends AttackStepMax {
    private Set<AttackStep> _cacheParentDisableWindowsEventLogging;

    public DisableWindowsEventLogging(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDisableWindowsEventLogging == null) {
        _cacheParentDisableWindowsEventLogging = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDisableWindowsEventLogging.add(_0.userAccountManagement.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentDisableWindowsEventLogging.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDisableWindowsEventLogging) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.disableWindowsEventLogging");
    }
  }

  public class DomainControllerAuthentication extends AttackStepMax {
    private Set<AttackStep> _cacheParentDomainControllerAuthentication;

    public DomainControllerAuthentication(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainControllerAuthentication == null) {
        _cacheParentDomainControllerAuthentication = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentDomainControllerAuthentication.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDomainControllerAuthentication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainControllerAuthentication");
    }
  }

  public class Emond extends AttackStepMax {
    public Emond(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.emond");
    }
  }

  public class ExchangeEmailDelegatePermissions extends AttackStepMax {
    private Set<AttackStep> _cacheParentExchangeEmailDelegatePermissions;

    public ExchangeEmailDelegatePermissions(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExchangeEmailDelegatePermissions == null) {
        _cacheParentExchangeEmailDelegatePermissions = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentExchangeEmailDelegatePermissions.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentExchangeEmailDelegatePermissions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.exchangeEmailDelegatePermissions");
    }
  }

  public class FileSystemLogicalOffsets extends AttackStepMin {
    private Set<AttackStep> _cacheParentFileSystemLogicalOffsets;

    public FileSystemLogicalOffsets(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFileSystemLogicalOffsets == null) {
        _cacheParentFileSystemLogicalOffsets = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentFileSystemLogicalOffsets.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentFileSystemLogicalOffsets) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.fileSystemLogicalOffsets");
    }
  }

  public class HiddenUsers extends AttackStepMax {
    public HiddenUsers(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.hiddenUsers");
    }
  }

  public class ImageFileExecutionOptionsInjection extends AttackStepMin {
    private Set<AttackStep> _cacheParentImageFileExecutionOptionsInjection;

    public ImageFileExecutionOptionsInjection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentImageFileExecutionOptionsInjection == null) {
        _cacheParentImageFileExecutionOptionsInjection = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentImageFileExecutionOptionsInjection.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentImageFileExecutionOptionsInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.imageFileExecutionOptionsInjection");
    }
  }

  public class KernelModulesAndExtensions extends AttackStepMax {
    private Set<AttackStep> _cacheParentKernelModulesAndExtensions;

    public KernelModulesAndExtensions(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentKernelModulesAndExtensions == null) {
        _cacheParentKernelModulesAndExtensions = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentKernelModulesAndExtensions.add(_0.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentKernelModulesAndExtensions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.kernelModulesAndExtensions");
    }
  }

  public class Keychain extends AttackStepMax {
    public Keychain(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.keychain");
    }
  }

  public class Launchd extends AttackStepMax {
    private Set<AttackStep> _cacheParentLaunchd;

    public Launchd(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchd == null) {
        _cacheParentLaunchd = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLaunchd.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentLaunchd) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.launchd");
    }
  }

  public class LaunchDaemon extends AttackStepMax {
    private Set<AttackStep> _cacheParentLaunchDaemon;

    public LaunchDaemon(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchDaemon == null) {
        _cacheParentLaunchDaemon = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLaunchDaemon.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentLaunchDaemon) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.launchDaemon");
    }
  }

  public class LSASSDriver extends AttackStepMax {
    private Set<AttackStep> _cacheParentLSASSDriver;

    public LSASSDriver(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLSASSDriver == null) {
        _cacheParentLSASSDriver = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentLSASSDriver.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentLSASSDriver) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.lSASSDriver");
    }
  }

  public class NetshHelperDLL extends AttackStepMin {
    private Set<AttackStep> _cacheParentNetshHelperDLL;

    public NetshHelperDLL(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetshHelperDLL == null) {
        _cacheParentNetshHelperDLL = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentNetshHelperDLL.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentNetshHelperDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.netshHelperDLL");
    }
  }

  public class PasswordFilterDLL extends AttackStepMax {
    private Set<AttackStep> _cacheParentPasswordFilterDLL;

    public PasswordFilterDLL(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPasswordFilterDLL == null) {
        _cacheParentPasswordFilterDLL = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentPasswordFilterDLL.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPasswordFilterDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.passwordFilterDLL");
    }
  }

  public class PluggableAuthenticationModules extends AttackStepMax {
    public PluggableAuthenticationModules(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.pluggableAuthenticationModules");
    }
  }

  public class PortMonitors extends AttackStepMin {
    private Set<AttackStep> _cacheParentPortMonitors;

    public PortMonitors(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPortMonitors == null) {
        _cacheParentPortMonitors = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentPortMonitors.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPortMonitors) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.portMonitors");
    }
  }

  public class AttemptPowerShell extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptPowerShell;

    public AttemptPowerShell(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPowerShell == null) {
        _cacheParentAttemptPowerShell = new HashSet<>();
        for (Computer _0 : computer) {
          _cacheParentAttemptPowerShell.add(_0.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptPowerShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptPowerShell");
    }
  }

  public class PowerShell extends AttackStepMax {
    private Set<AttackStep> _cacheParentPowerShell;

    public PowerShell(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPowerShell == null) {
        _cacheParentPowerShell = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentPowerShell.add(_0.adminRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentPowerShell.add(_1.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentPowerShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.powerShell");
    }
  }

  public class AttemptPowerShellAdminProfile extends AttackStepMin {
    public AttemptPowerShellAdminProfile(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptPowerShellAdminProfile");
    }
  }

  public class PowerShellAdminProfile extends AttackStepMax {
    private Set<AttackStep> _cacheParentPowerShellAdminProfile;

    public PowerShellAdminProfile(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPowerShellAdminProfile == null) {
        _cacheParentPowerShellAdminProfile = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentPowerShellAdminProfile.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPowerShellAdminProfile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.powerShellAdminProfile");
    }
  }

  public class ProcFilesystem extends AttackStepMax {
    public ProcFilesystem(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.procFilesystem");
    }
  }

  public class QueryRegistry extends AttackStepMax {
    private Set<AttackStep> _cacheParentQueryRegistry;

    public QueryRegistry(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentQueryRegistry == null) {
        _cacheParentQueryRegistry = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentQueryRegistry.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentQueryRegistry) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.queryRegistry");
    }
  }

  public class Rc_common extends AttackStepMax {
    private Set<AttackStep> _cacheParentRc_common;

    public Rc_common(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRc_common == null) {
        _cacheParentRc_common = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRc_common.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentRc_common) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.rc_common");
    }
  }

  public class RemoteScheduledTask extends AttackStepMax {
    private Set<AttackStep> _cacheParentRemoteScheduledTask;

    public RemoteScheduledTask(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteScheduledTask == null) {
        _cacheParentRemoteScheduledTask = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRemoteScheduledTask.add(_0.userAccountManagement.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentRemoteScheduledTask.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteScheduledTask) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.remoteScheduledTask");
    }
  }

  public class ScheduledTask extends AttackStepMax {
    private Set<AttackStep> _cacheParentScheduledTask;

    public ScheduledTask(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentScheduledTask == null) {
        _cacheParentScheduledTask = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentScheduledTask.add(_0.userAccountManagement.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentScheduledTask.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentScheduledTask) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.scheduledTask");
    }
  }

  public class SecuritydMemory extends AttackStepMax {
    public SecuritydMemory(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.securitydMemory");
    }
  }

  public class SecuritySupportProvider extends AttackStepMax {
    private Set<AttackStep> _cacheParentSecuritySupportProvider;

    public SecuritySupportProvider(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSecuritySupportProvider == null) {
        _cacheParentSecuritySupportProvider = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentSecuritySupportProvider.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSecuritySupportProvider) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.securitySupportProvider");
    }
  }

  public class ServiceExecution extends AttackStepMax {
    private Set<AttackStep> _cacheParentServiceExecution;

    public ServiceExecution(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceExecution == null) {
        _cacheParentServiceExecution = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentServiceExecution.add(_0.adminRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentServiceExecution.add(_1.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentServiceExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.serviceExecution");
    }
  }

  public class SQLStoredProcedures extends AttackStepMax {
    private Set<AttackStep> _cacheParentSQLStoredProcedures;

    public SQLStoredProcedures(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSQLStoredProcedures == null) {
        _cacheParentSQLStoredProcedures = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentSQLStoredProcedures.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSQLStoredProcedures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sQLStoredProcedures");
    }
  }

  public class SystemFirmware extends AttackStepMax {
    private Set<AttackStep> _cacheParentSystemFirmware;

    public SystemFirmware(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemFirmware == null) {
        _cacheParentSystemFirmware = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentSystemFirmware.add(_0.adminRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentSystemFirmware.add(_1.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentSystemFirmware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemFirmware");
    }
  }

  public class TransportAgent extends AttackStepMax {
    private Set<AttackStep> _cacheParentTransportAgent;

    public TransportAgent(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTransportAgent == null) {
        _cacheParentTransportAgent = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentTransportAgent.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentTransportAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.transportAgent");
    }
  }

  public class AttemptWindowsAdminShares extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptWindowsAdminShares;

    public AttemptWindowsAdminShares(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWindowsAdminShares == null) {
        _cacheParentAttemptWindowsAdminShares = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptWindowsAdminShares.add(_0.adminRights);
        }
        for (Service _1 : service) {
          _cacheParentAttemptWindowsAdminShares.add(_1.remoteServices);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptWindowsAdminShares) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptWindowsAdminShares");
    }
  }

  public class AttemptExecutionThroughAPI extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptExecutionThroughAPI;

    public AttemptExecutionThroughAPI(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExecutionThroughAPI == null) {
        _cacheParentAttemptExecutionThroughAPI = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptExecutionThroughAPI.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAttemptExecutionThroughAPI.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExecutionThroughAPI) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptExecutionThroughAPI");
    }
  }

  public class AttemptAccessTokenManipulation extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptAccessTokenManipulation;

    public AttemptAccessTokenManipulation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptAccessTokenManipulation == null) {
        _cacheParentAttemptAccessTokenManipulation = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptAccessTokenManipulation.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAttemptAccessTokenManipulation.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptAccessTokenManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptAccessTokenManipulation");
    }
  }

  public class AccessTokenManipulation extends AttackStepMax {
    private Set<AttackStep> _cacheParentAccessTokenManipulation;

    public AccessTokenManipulation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccessTokenManipulation == null) {
        _cacheParentAccessTokenManipulation = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAccessTokenManipulation.add(_0.userAccountManagement.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAccessTokenManipulation.add(_1.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentAccessTokenManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.accessTokenManipulation");
    }
  }

  public class AttemptControlPanel extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptControlPanel;

    public AttemptControlPanel(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptControlPanel == null) {
        _cacheParentAttemptControlPanel = new HashSet<>();
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheParentAttemptControlPanel.add(_1.spearphishingAttachment);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptControlPanel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptControlPanel");
    }
  }

  public class AttemptDistributedComponentObjectModel extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptDistributedComponentObjectModel;

    public AttemptDistributedComponentObjectModel(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDistributedComponentObjectModel == null) {
        _cacheParentAttemptDistributedComponentObjectModel = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentAttemptDistributedComponentObjectModel.add(_0.remoteServices);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptDistributedComponentObjectModel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptDistributedComponentObjectModel");
    }
  }

  public class AttemptLaunchAgent extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptLaunchAgent;

    public AttemptLaunchAgent(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLaunchAgent == null) {
        _cacheParentAttemptLaunchAgent = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptLaunchAgent.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptLaunchAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptLaunchAgent");
    }
  }

  public class LaunchAgent extends AttackStepMax {
    private Set<AttackStep> _cacheParentLaunchAgent;

    public LaunchAgent(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchAgent == null) {
        _cacheParentLaunchAgent = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLaunchAgent.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentLaunchAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.launchAgent");
    }
  }

  public class AttemptAccessibilityFeatures extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptAccessibilityFeatures;

    public AttemptAccessibilityFeatures(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptAccessibilityFeatures == null) {
        _cacheParentAttemptAccessibilityFeatures = new HashSet<>();
        for (Computer _0 : computer) {
          if (_0 instanceof HardwareAddition) {
            _cacheParentAttemptAccessibilityFeatures.add(((asset.HardwareAddition) _0).physicalAccess);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptAccessibilityFeatures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptAccessibilityFeatures");
    }
  }

  public class AttemptLogonScripts extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptLogonScripts;

    public AttemptLogonScripts(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLogonScripts == null) {
        _cacheParentAttemptLogonScripts = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptLogonScripts.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptLogonScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptLogonScripts");
    }
  }

  public class AttemptPlistModification extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptPlistModification;

    public AttemptPlistModification(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPlistModification == null) {
        _cacheParentAttemptPlistModification = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptPlistModification.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptPlistModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptPlistModification");
    }
  }

  public class AttemptRemoteDesktopProtocol extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptRemoteDesktopProtocol;

    public AttemptRemoteDesktopProtocol(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptRemoteDesktopProtocol == null) {
        _cacheParentAttemptRemoteDesktopProtocol = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentAttemptRemoteDesktopProtocol.add(_0.remoteServices);
        }
        for (Service _1 : service) {
          if (_1 instanceof CloudService) {
            _cacheParentAttemptRemoteDesktopProtocol.add(((asset.CloudService) _1).remoteEmailCollection);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptRemoteDesktopProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptRemoteDesktopProtocol");
    }
  }

  public class AttemptServiceStop extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptServiceStop;

    public AttemptServiceStop(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptServiceStop == null) {
        _cacheParentAttemptServiceStop = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptServiceStop.add(_0.adminRights);
        }
        for (Service _1 : service) {
          if (_1 instanceof CloudService) {
            _cacheParentAttemptServiceStop.add(((asset.CloudService) _1).serviceExhaustionFlood);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptServiceStop) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptServiceStop");
    }
  }

  public class AttemptSetuidAndSetgid extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptSetuidAndSetgid;

    public AttemptSetuidAndSetgid(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSetuidAndSetgid == null) {
        _cacheParentAttemptSetuidAndSetgid = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptSetuidAndSetgid.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptSetuidAndSetgid) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptSetuidAndSetgid");
    }
  }

  public class AttemptShortcutModification extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptShortcutModification;

    public AttemptShortcutModification(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptShortcutModification == null) {
        _cacheParentAttemptShortcutModification = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptShortcutModification.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAttemptShortcutModification.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptShortcutModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptShortcutModification");
    }
  }

  public class ShortcutModification extends AttackStepMax {
    private Set<AttackStep> _cacheParentShortcutModification;

    public ShortcutModification(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentShortcutModification == null) {
        _cacheParentShortcutModification = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentShortcutModification.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentShortcutModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.shortcutModification");
    }
  }

  public class AttemptSSHAuthorizedKeys extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptSSHAuthorizedKeys;

    public AttemptSSHAuthorizedKeys(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSSHAuthorizedKeys == null) {
        _cacheParentAttemptSSHAuthorizedKeys = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptSSHAuthorizedKeys.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptSSHAuthorizedKeys) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptSSHAuthorizedKeys");
    }
  }

  public class AttemptTaintSharedContent extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptTaintSharedContent;

    public AttemptTaintSharedContent(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTaintSharedContent == null) {
        _cacheParentAttemptTaintSharedContent = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptTaintSharedContent.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptTaintSharedContent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptTaintSharedContent");
    }
  }

  public class Bash_profileAndBashrc extends AttackStepMax {
    private Set<AttackStep> _cacheParentBash_profileAndBashrc;

    public Bash_profileAndBashrc(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBash_profileAndBashrc == null) {
        _cacheParentBash_profileAndBashrc = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentBash_profileAndBashrc.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentBash_profileAndBashrc) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bash_profileAndBashrc");
    }
  }

  public class BashHistory extends AttackStepMax {
    private Set<AttackStep> _cacheParentBashHistory;

    public BashHistory(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBashHistory == null) {
        _cacheParentBashHistory = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentBashHistory.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentBashHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bashHistory");
    }
  }

  public class BITSJobs extends AttackStepMax {
    private Set<AttackStep> _cacheParentBITSJobs;

    public BITSJobs(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBITSJobs == null) {
        _cacheParentBITSJobs = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentBITSJobs.add(_0.userAccountManagement.disable);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentBITSJobs.add(_3.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (ExternalNetwork _6 : _5.externalNetwork) {
              _cacheParentBITSJobs.add(_6.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _7 : computer) {
          for (Router _8 : _7.router) {
            if (_8.firewall != null) {
              _cacheParentBITSJobs.add(_8.firewall.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentBITSJobs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bITSJobs");
    }
  }

  public class CachedDomainCredentials extends AttackStepMax {
    private Set<AttackStep> _cacheParentCachedDomainCredentials;

    public CachedDomainCredentials(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCachedDomainCredentials == null) {
        _cacheParentCachedDomainCredentials = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentCachedDomainCredentials.add(_0.userTraining.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentCachedDomainCredentials) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.cachedDomainCredentials");
    }
  }

  public class ClearCommandHistory extends AttackStepMax {
    private Set<AttackStep> _cacheParentClearCommandHistory;

    public ClearCommandHistory(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClearCommandHistory == null) {
        _cacheParentClearCommandHistory = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentClearCommandHistory.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentClearCommandHistory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.clearCommandHistory");
    }
  }

  public class Cron extends AttackStepMax {
    private Set<AttackStep> _cacheParentCron;

    public Cron(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCron == null) {
        _cacheParentCron = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentCron.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentCron.add(_1.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentCron) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.cron");
    }
  }

  public class DistributedComponentObjectModel extends AttackStepMax {
    private Set<AttackStep> _cacheParentDistributedComponentObjectModel;

    public DistributedComponentObjectModel(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDistributedComponentObjectModel == null) {
        _cacheParentDistributedComponentObjectModel = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentDistributedComponentObjectModel.add(_0.adminRights);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            if (_2.firewall != null) {
              _cacheParentDistributedComponentObjectModel.add(_2.firewall.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDistributedComponentObjectModel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.distributedComponentObjectModel");
    }
  }

  public class ElevatedExecutionWithPrompt extends AttackStepMax {
    private Set<AttackStep> _cacheParentElevatedExecutionWithPrompt;

    public ElevatedExecutionWithPrompt(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentElevatedExecutionWithPrompt == null) {
        _cacheParentElevatedExecutionWithPrompt = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentElevatedExecutionWithPrompt.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentElevatedExecutionWithPrompt) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.elevatedExecutionWithPrompt");
    }
  }

  public class EmailCollection extends AttackStepMin {
    private Set<AttackStep> _cacheParentEmailCollection;

    public EmailCollection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEmailCollection == null) {
        _cacheParentEmailCollection = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentEmailCollection.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentEmailCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.emailCollection");
    }
  }

  public class ExecutableInstallerFilePermissionsWeakness extends AttackStepMax {
    private Set<AttackStep> _cacheParentExecutableInstallerFilePermissionsWeakness;

    public ExecutableInstallerFilePermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecutableInstallerFilePermissionsWeakness == null) {
        _cacheParentExecutableInstallerFilePermissionsWeakness = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentExecutableInstallerFilePermissionsWeakness.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentExecutableInstallerFilePermissionsWeakness.add(_1.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentExecutableInstallerFilePermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.executableInstallerFilePermissionsWeakness");
    }
  }

  public class ExecutionThroughModuleLoad extends AttackStepMax {
    private Set<AttackStep> _cacheParentExecutionThroughModuleLoad;

    public ExecutionThroughModuleLoad(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecutionThroughModuleLoad == null) {
        _cacheParentExecutionThroughModuleLoad = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentExecutionThroughModuleLoad.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentExecutionThroughModuleLoad) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.executionThroughModuleLoad");
    }
  }

  public class ForcedAuthentication extends AttackStepMax {
    private Set<AttackStep> _cacheParentForcedAuthentication;

    public ForcedAuthentication(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentForcedAuthentication == null) {
        _cacheParentForcedAuthentication = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentForcedAuthentication.add(_0.userRights);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentForcedAuthentication.add(_3.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentForcedAuthentication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.forcedAuthentication");
    }
  }

  public class GoldenTicket extends AttackStepMax {
    private Set<AttackStep> _cacheParentGoldenTicket;

    public GoldenTicket(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGoldenTicket == null) {
        _cacheParentGoldenTicket = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentGoldenTicket.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentGoldenTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.goldenTicket");
    }
  }

  public class GroupPolicyModification extends AttackStepMax {
    private Set<AttackStep> _cacheParentGroupPolicyModification;

    public GroupPolicyModification(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGroupPolicyModification == null) {
        _cacheParentGroupPolicyModification = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentGroupPolicyModification.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentGroupPolicyModification.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentGroupPolicyModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.groupPolicyModification");
    }
  }

  public class GroupPolicyPreferences extends AttackStepMax {
    private Set<AttackStep> _cacheParentGroupPolicyPreferences;

    public GroupPolicyPreferences(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGroupPolicyPreferences == null) {
        _cacheParentGroupPolicyPreferences = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentGroupPolicyPreferences.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentGroupPolicyPreferences) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.groupPolicyPreferences");
    }
  }

  public class GUIInputCapture extends AttackStepMax {
    private Set<AttackStep> _cacheParentGUIInputCapture;

    public GUIInputCapture(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGUIInputCapture == null) {
        _cacheParentGUIInputCapture = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentGUIInputCapture.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentGUIInputCapture.add(_1.userTraining.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentGUIInputCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.gUIInputCapture");
    }
  }

  public class HiddenWindow extends AttackStepMax {
    private Set<AttackStep> _cacheParentHiddenWindow;

    public HiddenWindow(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHiddenWindow == null) {
        _cacheParentHiddenWindow = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentHiddenWindow.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentHiddenWindow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.hiddenWindow");
    }
  }

  public class HISTCONTROL extends AttackStepMax {
    private Set<AttackStep> _cacheParentHISTCONTROL;

    public HISTCONTROL(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHISTCONTROL == null) {
        _cacheParentHISTCONTROL = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentHISTCONTROL.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentHISTCONTROL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.hISTCONTROL");
    }
  }

  public class IndirectCommandExecution extends AttackStepMin {
    private Set<AttackStep> _cacheParentIndirectCommandExecution;

    public IndirectCommandExecution(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentIndirectCommandExecution == null) {
        _cacheParentIndirectCommandExecution = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentIndirectCommandExecution.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentIndirectCommandExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.indirectCommandExecution");
    }
  }

  public class InstallUtil extends AttackStepMax {
    private Set<AttackStep> _cacheParentInstallUtil;

    public InstallUtil(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInstallUtil == null) {
        _cacheParentInstallUtil = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentInstallUtil.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentInstallUtil) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.installUtil");
    }
  }

  public class Launchctl extends AttackStepMax {
    private Set<AttackStep> _cacheParentLaunchctl;

    public Launchctl(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLaunchctl == null) {
        _cacheParentLaunchctl = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLaunchctl.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentLaunchctl.add(_1.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentLaunchctl) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.launchctl");
    }
  }

  public class LC_LOAD_DYLIB_Addition extends AttackStepMax {
    private Set<AttackStep> _cacheParentLC_LOAD_DYLIB_Addition;

    public LC_LOAD_DYLIB_Addition(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLC_LOAD_DYLIB_Addition == null) {
        _cacheParentLC_LOAD_DYLIB_Addition = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLC_LOAD_DYLIB_Addition.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentLC_LOAD_DYLIB_Addition) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.lC_LOAD_DYLIB_Addition");
    }
  }

  public class LLMNR_NBT_NS_PoisoningAndSMBRelay extends AttackStepMax {
    private Set<AttackStep> _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay;

    public LLMNR_NBT_NS_PoisoningAndSMBRelay(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay == null) {
        _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay.add(_0.userRights);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay.add(_3.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (InternalNetwork _6 : _5.internalNetwork) {
              _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay.add(_6.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _7 : computer) {
          for (Router _8 : _7.router) {
            for (InternalNetwork _9 : _8.internalNetwork) {
              _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay.add(_9.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.lLMNR_NBT_NS_PoisoningAndSMBRelay");
    }
  }

  public class LSASecrets extends AttackStepMax {
    private Set<AttackStep> _cacheParentLSASecrets;

    public LSASecrets(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLSASecrets == null) {
        _cacheParentLSASecrets = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLSASecrets.add(_0.userTraining.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentLSASecrets) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.lSASecrets");
    }
  }

  public class LSASSMemory extends AttackStepMax {
    private Set<AttackStep> _cacheParentLSASSMemory;

    public LSASSMemory(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLSASSMemory == null) {
        _cacheParentLSASSMemory = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLSASSMemory.add(_0.userTraining.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentLSASSMemory.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentLSASSMemory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.lSASSMemory");
    }
  }

  public class ManInTheBrowser extends AttackStepMax {
    private Set<AttackStep> _cacheParentManInTheBrowser;

    public ManInTheBrowser(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentManInTheBrowser == null) {
        _cacheParentManInTheBrowser = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentManInTheBrowser.add(_0.userTraining.disable);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentManInTheBrowser.add(_1.userAccountManagement.disable);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentManInTheBrowser.add(_2.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentManInTheBrowser) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.manInTheBrowser");
    }
  }

  public class MasqueradeTaskOrService extends AttackStepMin {
    private Set<AttackStep> _cacheParentMasqueradeTaskOrService;

    public MasqueradeTaskOrService(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMasqueradeTaskOrService == null) {
        _cacheParentMasqueradeTaskOrService = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentMasqueradeTaskOrService.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentMasqueradeTaskOrService.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentMasqueradeTaskOrService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.masqueradeTaskOrService");
    }
  }

  public class ModifyRegistry extends AttackStepMax {
    private Set<AttackStep> _cacheParentModifyRegistry;

    public ModifyRegistry(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentModifyRegistry == null) {
        _cacheParentModifyRegistry = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentModifyRegistry.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentModifyRegistry.add(_1.adminRights);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentModifyRegistry.add(_2.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentModifyRegistry) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.modifyRegistry");
    }
  }

  public class Msiexec extends AttackStepMax {
    private Set<AttackStep> _cacheParentMsiexec;

    public Msiexec(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMsiexec == null) {
        _cacheParentMsiexec = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentMsiexec.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentMsiexec) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.msiexec");
    }
  }

  public class NetworkShareConnectionRemoval extends AttackStepMin {
    private Set<AttackStep> _cacheParentNetworkShareConnectionRemoval;

    public NetworkShareConnectionRemoval(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkShareConnectionRemoval == null) {
        _cacheParentNetworkShareConnectionRemoval = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentNetworkShareConnectionRemoval.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentNetworkShareConnectionRemoval.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentNetworkShareConnectionRemoval) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.networkShareConnectionRemoval");
    }
  }

  public class NetworkShareDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheParentNetworkShareDiscovery;

    public NetworkShareDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkShareDiscovery == null) {
        _cacheParentNetworkShareDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentNetworkShareDiscovery.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentNetworkShareDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.networkShareDiscovery");
    }
  }

  public class NTDS extends AttackStepMax {
    private Set<AttackStep> _cacheParentNTDS;

    public NTDS(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNTDS == null) {
        _cacheParentNTDS = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentNTDS.add(_0.userTraining.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentNTDS) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.nTDS");
    }
  }

  public class Odbcconf extends AttackStepMax {
    private Set<AttackStep> _cacheParentOdbcconf;

    public Odbcconf(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOdbcconf == null) {
        _cacheParentOdbcconf = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentOdbcconf.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentOdbcconf) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.odbcconf");
    }
  }

  public class ParentPIDSpoofing extends AttackStepMin {
    private Set<AttackStep> _cacheParentParentPIDSpoofing;

    public ParentPIDSpoofing(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentParentPIDSpoofing == null) {
        _cacheParentParentPIDSpoofing = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentParentPIDSpoofing.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentParentPIDSpoofing.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentParentPIDSpoofing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.parentPIDSpoofing");
    }
  }

  public class PathInterceptionBySearchOrderHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheParentPathInterceptionBySearchOrderHijacking;

    public PathInterceptionBySearchOrderHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPathInterceptionBySearchOrderHijacking == null) {
        _cacheParentPathInterceptionBySearchOrderHijacking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPathInterceptionBySearchOrderHijacking.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPathInterceptionBySearchOrderHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.pathInterceptionBySearchOrderHijacking");
    }
  }

  public class PeripheralDeviceDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentPeripheralDeviceDiscovery;

    public PeripheralDeviceDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPeripheralDeviceDiscovery == null) {
        _cacheParentPeripheralDeviceDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPeripheralDeviceDiscovery.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPeripheralDeviceDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.peripheralDeviceDiscovery");
    }
  }

  public class PlistModification extends AttackStepMax {
    private Set<AttackStep> _cacheParentPlistModification;

    public PlistModification(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPlistModification == null) {
        _cacheParentPlistModification = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPlistModification.add(_0.userTraining.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentPlistModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.plistModification");
    }
  }

  public class PortableExecutableInjection extends AttackStepMax {
    private Set<AttackStep> _cacheParentPortableExecutableInjection;

    public PortableExecutableInjection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPortableExecutableInjection == null) {
        _cacheParentPortableExecutableInjection = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPortableExecutableInjection.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPortableExecutableInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.portableExecutableInjection");
    }
  }

  public class PortKnocking extends AttackStepMax {
    private Set<AttackStep> _cacheParentPortKnocking;

    public PortKnocking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPortKnocking == null) {
        _cacheParentPortKnocking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPortKnocking.add(_0.userRights);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            if (_2.firewall != null) {
              _cacheParentPortKnocking.add(_2.firewall.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentPortKnocking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.portKnocking");
    }
  }

  public class PowerShellUserProfile extends AttackStepMax {
    private Set<AttackStep> _cacheParentPowerShellUserProfile;

    public PowerShellUserProfile(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPowerShellUserProfile == null) {
        _cacheParentPowerShellUserProfile = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPowerShellUserProfile.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPowerShellUserProfile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.powerShellUserProfile");
    }
  }

  public class ProcessDoppelganging extends AttackStepMax {
    private Set<AttackStep> _cacheParentProcessDoppelganging;

    public ProcessDoppelganging(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcessDoppelganging == null) {
        _cacheParentProcessDoppelganging = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentProcessDoppelganging.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentProcessDoppelganging) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.processDoppelganging");
    }
  }

  public class ProcessHollowing extends AttackStepMax {
    private Set<AttackStep> _cacheParentProcessHollowing;

    public ProcessHollowing(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcessHollowing == null) {
        _cacheParentProcessHollowing = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentProcessHollowing.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentProcessHollowing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.processHollowing");
    }
  }

  public class PubPrn extends AttackStepMax {
    private Set<AttackStep> _cacheParentPubPrn;

    public PubPrn(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPubPrn == null) {
        _cacheParentPubPrn = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPubPrn.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPubPrn) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.pubPrn");
    }
  }

  public class RDPHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheParentRDPHijacking;

    public RDPHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRDPHijacking == null) {
        _cacheParentRDPHijacking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRDPHijacking.add(_0.userAccountManagement.disable);
        }
        for (Service _1 : service) {
          _cacheParentRDPHijacking.add(_1.remoteServiceSessionHijacking);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheParentRDPHijacking.add(_4.limitAccessToResourceOverNetwork.disable);
            }
          }
        }
        for (Computer _5 : computer) {
          for (Router _6 : _5.router) {
            for (InternalNetwork _7 : _6.internalNetwork) {
              _cacheParentRDPHijacking.add(_7.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRDPHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.rDPHijacking");
    }
  }

  public class RegistryRunKeysOrStartupFolder extends AttackStepMin {
    private Set<AttackStep> _cacheParentRegistryRunKeysOrStartupFolder;

    public RegistryRunKeysOrStartupFolder(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRegistryRunKeysOrStartupFolder == null) {
        _cacheParentRegistryRunKeysOrStartupFolder = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRegistryRunKeysOrStartupFolder.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentRegistryRunKeysOrStartupFolder.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentRegistryRunKeysOrStartupFolder) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.registryRunKeysOrStartupFolder");
    }
  }

  public class RegsvcsOrRegasm extends AttackStepMax {
    private Set<AttackStep> _cacheParentRegsvcsOrRegasm;

    public RegsvcsOrRegasm(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRegsvcsOrRegasm == null) {
        _cacheParentRegsvcsOrRegasm = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRegsvcsOrRegasm.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentRegsvcsOrRegasm) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.regsvcsOrRegasm");
    }
  }

  public class Regsvr32 extends AttackStepMax {
    private Set<AttackStep> _cacheParentRegsvr32;

    public Regsvr32(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRegsvr32 == null) {
        _cacheParentRegsvr32 = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRegsvr32.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentRegsvr32) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.regsvr32");
    }
  }

  public class RemoteDesktopProtocol extends AttackStepMax {
    private Set<AttackStep> _cacheParentRemoteDesktopProtocol;

    public RemoteDesktopProtocol(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteDesktopProtocol == null) {
        _cacheParentRemoteDesktopProtocol = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRemoteDesktopProtocol.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentRemoteDesktopProtocol.add(_1.userAccountManagement.disable);
        }
        for (UserAccount _2 : userAccount) {
          if (_2 instanceof RemoteDesktopUser) {
            _cacheParentRemoteDesktopProtocol.add(((asset.RemoteDesktopUser) _2).multiFactorAuthentication.disable);
          }
        }
        for (AdminAccount _3 : adminAccount) {
          _cacheParentRemoteDesktopProtocol.add(_3.privilegedAccountManagement.disable);
        }
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (InternalNetwork _6 : _5.internalNetwork) {
              _cacheParentRemoteDesktopProtocol.add(_6.limitAccessToResourceOverNetwork.disable);
            }
          }
        }
        for (Computer _7 : computer) {
          for (Router _8 : _7.router) {
            if (_8.firewall != null) {
              _cacheParentRemoteDesktopProtocol.add(_8.firewall.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteDesktopProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.remoteDesktopProtocol");
    }
  }

  public class ReopenedApplications extends AttackStepMax {
    private Set<AttackStep> _cacheParentReopenedApplications;

    public ReopenedApplications(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentReopenedApplications == null) {
        _cacheParentReopenedApplications = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentReopenedApplications.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentReopenedApplications.add(_1.userTraining.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentReopenedApplications) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.reopenedApplications");
    }
  }

  public class Rundll32 extends AttackStepMax {
    private Set<AttackStep> _cacheParentRundll32;

    public Rundll32(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRundll32 == null) {
        _cacheParentRundll32 = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRundll32.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentRundll32) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.rundll32");
    }
  }

  public class Screensaver extends AttackStepMax {
    private Set<AttackStep> _cacheParentScreensaver;

    public Screensaver(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentScreensaver == null) {
        _cacheParentScreensaver = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentScreensaver.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentScreensaver) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.screensaver");
    }
  }

  public class SecurityAccountManager extends AttackStepMax {
    private Set<AttackStep> _cacheParentSecurityAccountManager;

    public SecurityAccountManager(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSecurityAccountManager == null) {
        _cacheParentSecurityAccountManager = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSecurityAccountManager.add(_0.userTraining.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentSecurityAccountManager) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.securityAccountManager");
    }
  }

  public class ServicesFilePermissionsWeakness extends AttackStepMax {
    private Set<AttackStep> _cacheParentServicesFilePermissionsWeakness;

    public ServicesFilePermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServicesFilePermissionsWeakness == null) {
        _cacheParentServicesFilePermissionsWeakness = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentServicesFilePermissionsWeakness.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentServicesFilePermissionsWeakness.add(_1.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentServicesFilePermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.servicesFilePermissionsWeakness");
    }
  }

  public class ServicesRegistryPermissionsWeakness extends AttackStepMax {
    private Set<AttackStep> _cacheParentServicesRegistryPermissionsWeakness;

    public ServicesRegistryPermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServicesRegistryPermissionsWeakness == null) {
        _cacheParentServicesRegistryPermissionsWeakness = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentServicesRegistryPermissionsWeakness.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentServicesRegistryPermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.servicesRegistryPermissionsWeakness");
    }
  }

  public class ServiceStop extends AttackStepMax {
    private Set<AttackStep> _cacheParentServiceStop;

    public ServiceStop(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceStop == null) {
        _cacheParentServiceStop = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentServiceStop.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentServiceStop.add(_1.userAccountManagement.disable);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheParentServiceStop.add(_4.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentServiceStop) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.serviceStop");
    }
  }

  public class SignedScriptProxyExecution extends AttackStepMin {
    private Set<AttackStep> _cacheParentSignedScriptProxyExecution;

    public SignedScriptProxyExecution(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSignedScriptProxyExecution == null) {
        _cacheParentSignedScriptProxyExecution = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSignedScriptProxyExecution.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSignedScriptProxyExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.signedScriptProxyExecution");
    }
  }

  public class SilverTicket extends AttackStepMax {
    private Set<AttackStep> _cacheParentSilverTicket;

    public SilverTicket(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSilverTicket == null) {
        _cacheParentSilverTicket = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSilverTicket.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSilverTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.silverTicket");
    }
  }

  public class SIPAndTrustProviderHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheParentSIPAndTrustProviderHijacking;

    public SIPAndTrustProviderHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSIPAndTrustProviderHijacking == null) {
        _cacheParentSIPAndTrustProviderHijacking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSIPAndTrustProviderHijacking.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSIPAndTrustProviderHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sIPAndTrustProviderHijacking");
    }
  }

  public class Source extends AttackStepMin {
    private Set<AttackStep> _cacheParentSource;

    public Source(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSource == null) {
        _cacheParentSource = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSource.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSource) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.source");
    }
  }

  public class SpaceAfterFileName extends AttackStepMin {
    private Set<AttackStep> _cacheParentSpaceAfterFileName;

    public SpaceAfterFileName(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSpaceAfterFileName == null) {
        _cacheParentSpaceAfterFileName = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSpaceAfterFileName.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSpaceAfterFileName) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.spaceAfterFileName");
    }
  }

  public class SSH extends AttackStepMax {
    private Set<AttackStep> _cacheParentSSH;

    public SSH(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSH == null) {
        _cacheParentSSH = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentSSH.add(_0.remoteServices);
        }
      }
      for (AttackStep attackStep : _cacheParentSSH) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sSH");
    }
  }

  public class SSHHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheParentSSHHijacking;

    public SSHHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSHHijacking == null) {
        _cacheParentSSHHijacking = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentSSHHijacking.add(_0.remoteServiceSessionHijacking);
        }
      }
      for (AttackStep attackStep : _cacheParentSSHHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sSHHijacking");
    }
  }

  public class SudoAndSudoCaching extends AttackStepMax {
    private Set<AttackStep> _cacheParentSudoAndSudoCaching;

    public SudoAndSudoCaching(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSudoAndSudoCaching == null) {
        _cacheParentSudoAndSudoCaching = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSudoAndSudoCaching.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentSudoAndSudoCaching.add(_1.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentSudoAndSudoCaching) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sudoAndSudoCaching");
    }
  }

  public class SystemdService extends AttackStepMax {
    private Set<AttackStep> _cacheParentSystemdService;

    public SystemdService(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemdService == null) {
        _cacheParentSystemdService = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSystemdService.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentSystemdService.add(_1.userAccountManagement.disable);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentSystemdService.add(_2.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentSystemdService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemdService");
    }
  }

  public class SystemServiceDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentSystemServiceDiscovery;

    public SystemServiceDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemServiceDiscovery == null) {
        _cacheParentSystemServiceDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSystemServiceDiscovery.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentSystemServiceDiscovery.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSystemServiceDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemServiceDiscovery");
    }
  }

  public class TemplateInjection extends AttackStepMax {
    private Set<AttackStep> _cacheParentTemplateInjection;

    public TemplateInjection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTemplateInjection == null) {
        _cacheParentTemplateInjection = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentTemplateInjection.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentTemplateInjection.add(_1.userTraining.disable);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheParentTemplateInjection.add(_4.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentTemplateInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.templateInjection");
    }
  }

  public class ThreadExecutionHijacking extends AttackStepMax {
    private Set<AttackStep> _cacheParentThreadExecutionHijacking;

    public ThreadExecutionHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentThreadExecutionHijacking == null) {
        _cacheParentThreadExecutionHijacking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentThreadExecutionHijacking.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentThreadExecutionHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.threadExecutionHijacking");
    }
  }

  public class Trap extends AttackStepMin {
    private Set<AttackStep> _cacheParentTrap;

    public Trap(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTrap == null) {
        _cacheParentTrap = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentTrap.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentTrap) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.trap");
    }
  }

  public class TrustedDeveloperUtilities extends AttackStepMin {
    private Set<AttackStep> _cacheParentTrustedDeveloperUtilities;

    public TrustedDeveloperUtilities(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTrustedDeveloperUtilities == null) {
        _cacheParentTrustedDeveloperUtilities = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentTrustedDeveloperUtilities.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentTrustedDeveloperUtilities) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.trustedDeveloperUtilities");
    }
  }

  public class VideoCapture extends AttackStepMin {
    private Set<AttackStep> _cacheParentVideoCapture;

    public VideoCapture(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentVideoCapture == null) {
        _cacheParentVideoCapture = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentVideoCapture.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentVideoCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.videoCapture");
    }
  }

  public class WindowsAdminShares extends AttackStepMax {
    private Set<AttackStep> _cacheParentWindowsAdminShares;

    public WindowsAdminShares(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsAdminShares == null) {
        _cacheParentWindowsAdminShares = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentWindowsAdminShares.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentWindowsAdminShares.add(_1.privilegedAccountManagement.disable);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheParentWindowsAdminShares.add(_4.limitAccessToResourceOverNetwork.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentWindowsAdminShares) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.windowsAdminShares");
    }
  }

  public class WindowsManagementInstrumentation extends AttackStepMin {
    private Set<AttackStep> _cacheParentWindowsManagementInstrumentation;

    public WindowsManagementInstrumentation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsManagementInstrumentation == null) {
        _cacheParentWindowsManagementInstrumentation = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentWindowsManagementInstrumentation.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentWindowsManagementInstrumentation.add(_1.userAccountManagement.disable);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentWindowsManagementInstrumentation.add(_2.adminRights);
        }
        for (AdminAccount _3 : adminAccount) {
          _cacheParentWindowsManagementInstrumentation.add(_3.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentWindowsManagementInstrumentation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.windowsManagementInstrumentation");
    }
  }

  public class AttemptWindowsManagementInstrumentationEventSubscription extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptWindowsManagementInstrumentationEventSubscription;

    public AttemptWindowsManagementInstrumentationEventSubscription(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWindowsManagementInstrumentationEventSubscription == null) {
        _cacheParentAttemptWindowsManagementInstrumentationEventSubscription = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptWindowsManagementInstrumentationEventSubscription.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptWindowsManagementInstrumentationEventSubscription) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptWindowsManagementInstrumentationEventSubscription");
    }
  }

  public class WindowsManagementInstrumentationEventSubscription extends AttackStepMax {
    private Set<AttackStep> _cacheParentWindowsManagementInstrumentationEventSubscription;

    public WindowsManagementInstrumentationEventSubscription(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsManagementInstrumentationEventSubscription == null) {
        _cacheParentWindowsManagementInstrumentationEventSubscription = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentWindowsManagementInstrumentationEventSubscription.add(_0.userAccountManagement.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentWindowsManagementInstrumentationEventSubscription.add(_1.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentWindowsManagementInstrumentationEventSubscription) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.windowsManagementInstrumentationEventSubscription");
    }
  }

  public class XslScriptProcessing extends AttackStepMax {
    private Set<AttackStep> _cacheParentXslScriptProcessing;

    public XslScriptProcessing(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentXslScriptProcessing == null) {
        _cacheParentXslScriptProcessing = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentXslScriptProcessing.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentXslScriptProcessing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.xslScriptProcessing");
    }
  }

  public class AccountManipulation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAccountManipulation;

    private Set<AttackStep> _cacheParentAccountManipulation;

    public AccountManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAccountManipulation == null) {
        _cacheChildrenAccountManipulation = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenAccountManipulation.add(_0.userCredentials);
        }
        _cacheChildrenAccountManipulation.add(persistence);
        for (Service _1 : service) {
          _cacheChildrenAccountManipulation.add(_1.additionalAzureServicePrincipalCredentials);
        }
        for (Service _2 : service) {
          _cacheChildrenAccountManipulation.add(_2.exchangeEmailDelegatePermissions);
        }
        for (Service _3 : service) {
          _cacheChildrenAccountManipulation.add(_3.addOffice365GlobalAdministratorRole);
        }
      }
      for (AttackStep attackStep : _cacheChildrenAccountManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccountManipulation == null) {
        _cacheParentAccountManipulation = new HashSet<>();
        for (Computer _4 : computer) {
          _cacheParentAccountManipulation.add(_4.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentAccountManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.accountManipulation");
    }
  }

  public class ArchiveCollectedData extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenArchiveCollectedData;

    private Set<AttackStep> _cacheParentArchiveCollectedData;

    public ArchiveCollectedData(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenArchiveCollectedData == null) {
        _cacheChildrenArchiveCollectedData = new HashSet<>();
        _cacheChildrenArchiveCollectedData.add(archiveViaUtility);
        _cacheChildrenArchiveCollectedData.add(archiveViaLibrary);
        _cacheChildrenArchiveCollectedData.add(archiveViaCustomMethod);
      }
      for (AttackStep attackStep : _cacheChildrenArchiveCollectedData) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentArchiveCollectedData == null) {
        _cacheParentArchiveCollectedData = new HashSet<>();
        _cacheParentArchiveCollectedData.add(localDataStaging);
        _cacheParentArchiveCollectedData.add(remoteDataStaging);
      }
      for (AttackStep attackStep : _cacheParentArchiveCollectedData) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.archiveCollectedData");
    }
  }

  public class ArchiveViaUtility extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenArchiveViaUtility;

    private Set<AttackStep> _cacheParentArchiveViaUtility;

    public ArchiveViaUtility(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenArchiveViaUtility == null) {
        _cacheChildrenArchiveViaUtility = new HashSet<>();
        _cacheChildrenArchiveViaUtility.add(dataCompressed);
        _cacheChildrenArchiveViaUtility.add(dataEncrypted);
      }
      for (AttackStep attackStep : _cacheChildrenArchiveViaUtility) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentArchiveViaUtility == null) {
        _cacheParentArchiveViaUtility = new HashSet<>();
        _cacheParentArchiveViaUtility.add(archiveCollectedData);
        _cacheParentArchiveViaUtility.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentArchiveViaUtility) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.archiveViaUtility");
    }
  }

  public class ArchiveViaLibrary extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenArchiveViaLibrary;

    private Set<AttackStep> _cacheParentArchiveViaLibrary;

    public ArchiveViaLibrary(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenArchiveViaLibrary == null) {
        _cacheChildrenArchiveViaLibrary = new HashSet<>();
        _cacheChildrenArchiveViaLibrary.add(dataCompressed);
        _cacheChildrenArchiveViaLibrary.add(dataEncrypted);
      }
      for (AttackStep attackStep : _cacheChildrenArchiveViaLibrary) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentArchiveViaLibrary == null) {
        _cacheParentArchiveViaLibrary = new HashSet<>();
        _cacheParentArchiveViaLibrary.add(archiveCollectedData);
      }
      for (AttackStep attackStep : _cacheParentArchiveViaLibrary) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.archiveViaLibrary");
    }
  }

  public class ArchiveViaCustomMethod extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenArchiveViaCustomMethod;

    private Set<AttackStep> _cacheParentArchiveViaCustomMethod;

    public ArchiveViaCustomMethod(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenArchiveViaCustomMethod == null) {
        _cacheChildrenArchiveViaCustomMethod = new HashSet<>();
        _cacheChildrenArchiveViaCustomMethod.add(dataCompressed);
        _cacheChildrenArchiveViaCustomMethod.add(dataEncrypted);
      }
      for (AttackStep attackStep : _cacheChildrenArchiveViaCustomMethod) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentArchiveViaCustomMethod == null) {
        _cacheParentArchiveViaCustomMethod = new HashSet<>();
        _cacheParentArchiveViaCustomMethod.add(archiveCollectedData);
      }
      for (AttackStep attackStep : _cacheParentArchiveViaCustomMethod) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.archiveViaCustomMethod");
    }
  }

  public class AbuseElevationControlMechanism extends AttackStepMin {
    private Set<AttackStep> _cacheParentAbuseElevationControlMechanism;

    public AbuseElevationControlMechanism(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAbuseElevationControlMechanism == null) {
        _cacheParentAbuseElevationControlMechanism = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAbuseElevationControlMechanism.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAbuseElevationControlMechanism.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAbuseElevationControlMechanism) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.abuseElevationControlMechanism");
    }
  }

  public class AccountAccessRemoval extends AttackStepMin {
    private Set<AttackStep> _cacheParentAccountAccessRemoval;

    public AccountAccessRemoval(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccountAccessRemoval == null) {
        _cacheParentAccountAccessRemoval = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAccountAccessRemoval.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAccountAccessRemoval.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAccountAccessRemoval) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.accountAccessRemoval");
    }
  }

  public class BootOrLogonAutostartExecution extends AttackStepMin {
    public BootOrLogonAutostartExecution(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bootOrLogonAutostartExecution");
    }
  }

  public class InfectedOS extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenInfectedOS;

    public InfectedOS(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInfectedOS == null) {
        _cacheChildrenInfectedOS = new HashSet<>();
        _cacheChildrenInfectedOS.add(clipboardData);
        _cacheChildrenInfectedOS.add(dataFromInformationRepositories);
        for (Computer _0 : computer) {
          _cacheChildrenInfectedOS.add(_0.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheChildrenInfectedOS) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.infectedOS");
    }
  }

  public class ClipboardData extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenClipboardData;

    private Set<AttackStep> _cacheParentClipboardData;

    public ClipboardData(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenClipboardData == null) {
        _cacheChildrenClipboardData = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheChildrenClipboardData.add(_0.adminCredentials);
        }
        for (UserAccount _1 : userAccount) {
          _cacheChildrenClipboardData.add(_1.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenClipboardData) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClipboardData == null) {
        _cacheParentClipboardData = new HashSet<>();
        _cacheParentClipboardData.add(infectedOS);
      }
      for (AttackStep attackStep : _cacheParentClipboardData) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.clipboardData");
    }
  }

  public class AccountDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAccountDiscovery;

    private Set<AttackStep> _cacheParentAccountDiscovery;

    public AccountDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAccountDiscovery == null) {
        _cacheChildrenAccountDiscovery = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenAccountDiscovery.add(_0.cloudAccount);
        }
        for (Service _1 : service) {
          _cacheChildrenAccountDiscovery.add(_1.emailAccount);
        }
        _cacheChildrenAccountDiscovery.add(attemptDomainAccount);
        _cacheChildrenAccountDiscovery.add(attemptLocalAccount);
      }
      for (AttackStep attackStep : _cacheChildrenAccountDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccountDiscovery == null) {
        _cacheParentAccountDiscovery = new HashSet<>();
        for (UserAccount _2 : userAccount) {
          _cacheParentAccountDiscovery.add(_2.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAccountDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.accountDiscovery");
    }
  }

  public class AttemptDomainAccount extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDomainAccount;

    private Set<AttackStep> _cacheParentAttemptDomainAccount;

    public AttemptDomainAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDomainAccount == null) {
        _cacheChildrenAttemptDomainAccount = new HashSet<>();
        _cacheChildrenAttemptDomainAccount.add(domainAccount);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDomainAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDomainAccount == null) {
        _cacheParentAttemptDomainAccount = new HashSet<>();
        _cacheParentAttemptDomainAccount.add(accountDiscovery);
      }
      for (AttackStep attackStep : _cacheParentAttemptDomainAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptDomainAccount");
    }
  }

  public class DomainAccount extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDomainAccount;

    private Set<AttackStep> _cacheParentDomainAccount;

    public DomainAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDomainAccount == null) {
        _cacheChildrenDomainAccount = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenDomainAccount.add(_0.userInformation);
        }
        _cacheChildrenDomainAccount.add(persistence);
      }
      for (AttackStep attackStep : _cacheChildrenDomainAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainAccount == null) {
        _cacheParentDomainAccount = new HashSet<>();
        for (AdminAccount _1 : adminAccount) {
          _cacheParentDomainAccount.add(_1.createAccount);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentDomainAccount.add(_2.privilegedAccountManagement.disable);
        }
        _cacheParentDomainAccount.add(attemptDomainAccount);
        _cacheParentDomainAccount.add(multiFactorAuthentication.disable);
        _cacheParentDomainAccount.add(operatingSystemConfiguration.disable);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentDomainAccount.add(_5.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDomainAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainAccount");
    }
  }

  public class AttemptLocalAccount extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptLocalAccount;

    private Set<AttackStep> _cacheParentAttemptLocalAccount;

    public AttemptLocalAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptLocalAccount == null) {
        _cacheChildrenAttemptLocalAccount = new HashSet<>();
        _cacheChildrenAttemptLocalAccount.add(localAccount);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLocalAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLocalAccount == null) {
        _cacheParentAttemptLocalAccount = new HashSet<>();
        _cacheParentAttemptLocalAccount.add(accountDiscovery);
      }
      for (AttackStep attackStep : _cacheParentAttemptLocalAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptLocalAccount");
    }
  }

  public class LocalAccount extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenLocalAccount;

    private Set<AttackStep> _cacheParentLocalAccount;

    public LocalAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLocalAccount == null) {
        _cacheChildrenLocalAccount = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenLocalAccount.add(_0.userInformation);
        }
        _cacheChildrenLocalAccount.add(persistence);
      }
      for (AttackStep attackStep : _cacheChildrenLocalAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLocalAccount == null) {
        _cacheParentLocalAccount = new HashSet<>();
        for (AdminAccount _1 : adminAccount) {
          _cacheParentLocalAccount.add(_1.createAccount);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentLocalAccount.add(_2.privilegedAccountManagement.disable);
        }
        _cacheParentLocalAccount.add(attemptLocalAccount);
        _cacheParentLocalAccount.add(multiFactorAuthentication.disable);
        _cacheParentLocalAccount.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentLocalAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.localAccount");
    }
  }

  public class CommandAndScriptingInterpreter extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCommandAndScriptingInterpreter;

    private Set<AttackStep> _cacheParentCommandAndScriptingInterpreter;

    public CommandAndScriptingInterpreter(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCommandAndScriptingInterpreter == null) {
        _cacheChildrenCommandAndScriptingInterpreter = new HashSet<>();
        _cacheChildrenCommandAndScriptingInterpreter.add(dataFromLocalSystem);
        _cacheChildrenCommandAndScriptingInterpreter.add(screenCapture);
        _cacheChildrenCommandAndScriptingInterpreter.add(visualBasic);
        _cacheChildrenCommandAndScriptingInterpreter.add(python);
        _cacheChildrenCommandAndScriptingInterpreter.add(javaScriptOrJScript);
      }
      for (AttackStep attackStep : _cacheChildrenCommandAndScriptingInterpreter) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCommandAndScriptingInterpreter == null) {
        _cacheParentCommandAndScriptingInterpreter = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentCommandAndScriptingInterpreter.add(_0.userRights);
        }
        for (Service _1 : service) {
          for (Browser _2 : _1.browser) {
            _cacheParentCommandAndScriptingInterpreter.add(_2.restrictWebBasedContent.disable);
          }
        }
        _cacheParentCommandAndScriptingInterpreter.add(antivirus.disable);
        _cacheParentCommandAndScriptingInterpreter.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentCommandAndScriptingInterpreter.add(codeSigning.disable);
        _cacheParentCommandAndScriptingInterpreter.add(executionPrevention.disable);
        _cacheParentCommandAndScriptingInterpreter.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentCommandAndScriptingInterpreter) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.commandAndScriptingInterpreter");
    }
  }

  public class VisualBasic extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenVisualBasic;

    private Set<AttackStep> _cacheParentVisualBasic;

    public VisualBasic(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenVisualBasic == null) {
        _cacheChildrenVisualBasic = new HashSet<>();
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheChildrenVisualBasic.add(_1.attemptSpearphishingAttachment);
          }
        }
        _cacheChildrenVisualBasic.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenVisualBasic) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentVisualBasic == null) {
        _cacheParentVisualBasic = new HashSet<>();
        _cacheParentVisualBasic.add(commandAndScriptingInterpreter);
        _cacheParentVisualBasic.add(antivirus.disable);
        _cacheParentVisualBasic.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentVisualBasic.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentVisualBasic.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentVisualBasic) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.visualBasic");
    }
  }

  public class Python extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenPython;

    private Set<AttackStep> _cacheParentPython;

    public Python(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPython == null) {
        _cacheChildrenPython = new HashSet<>();
        _cacheChildrenPython.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenPython) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPython == null) {
        _cacheParentPython = new HashSet<>();
        _cacheParentPython.add(commandAndScriptingInterpreter);
        _cacheParentPython.add(antivirus.disable);
        _cacheParentPython.add(audit.disable);
        _cacheParentPython.add(executionPrevention.disable);
        _cacheParentPython.add(limitSoftwareInstallation.disable);
      }
      for (AttackStep attackStep : _cacheParentPython) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.python");
    }
  }

  public class JavaScriptOrJScript extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenJavaScriptOrJScript;

    private Set<AttackStep> _cacheParentJavaScriptOrJScript;

    public JavaScriptOrJScript(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenJavaScriptOrJScript == null) {
        _cacheChildrenJavaScriptOrJScript = new HashSet<>();
        _cacheChildrenJavaScriptOrJScript.add(executeCode);
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheChildrenJavaScriptOrJScript.add(_1.driveByCompromise);
          }
        }
        _cacheChildrenJavaScriptOrJScript.add(obfuscatedFilesOrInformation);
      }
      for (AttackStep attackStep : _cacheChildrenJavaScriptOrJScript) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentJavaScriptOrJScript == null) {
        _cacheParentJavaScriptOrJScript = new HashSet<>();
        _cacheParentJavaScriptOrJScript.add(commandAndScriptingInterpreter);
        _cacheParentJavaScriptOrJScript.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentJavaScriptOrJScript.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentJavaScriptOrJScript.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentJavaScriptOrJScript) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.javaScriptOrJScript");
    }
  }

  public class CreateOrModifySystemProcess extends AttackStepMin {
    public CreateOrModifySystemProcess(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.createOrModifySystemProcess");
    }
  }

  public class CredentialsFromPasswordStores extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCredentialsFromPasswordStores;

    private Set<AttackStep> _cacheParentCredentialsFromPasswordStores;

    public CredentialsFromPasswordStores(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCredentialsFromPasswordStores == null) {
        _cacheChildrenCredentialsFromPasswordStores = new HashSet<>();
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheChildrenCredentialsFromPasswordStores.add(_1.credentialsFromWebBrowsers);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCredentialsFromPasswordStores) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialsFromPasswordStores == null) {
        _cacheParentCredentialsFromPasswordStores = new HashSet<>();
        for (AdminAccount _2 : adminAccount) {
          _cacheParentCredentialsFromPasswordStores.add(_2.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentCredentialsFromPasswordStores) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.credentialsFromPasswordStores");
    }
  }

  public class DataManipulation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataManipulation;

    private Set<AttackStep> _cacheParentDataManipulation;

    public DataManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataManipulation == null) {
        _cacheChildrenDataManipulation = new HashSet<>();
        _cacheChildrenDataManipulation.add(storedDataManipulation);
        for (Service _0 : service) {
          _cacheChildrenDataManipulation.add(_0.transmittedDataManipulation);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (ExternalNetwork _3 : _2.externalNetwork) {
              _cacheChildrenDataManipulation.add(_3.attemptTransmittedDataManipulation);
            }
          }
        }
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (InternalNetwork _6 : _5.internalNetwork) {
              _cacheChildrenDataManipulation.add(_6.attemptTransmittedDataManipulation);
            }
          }
        }
        _cacheChildrenDataManipulation.add(runtimeDataManipulation);
      }
      for (AttackStep attackStep : _cacheChildrenDataManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataManipulation == null) {
        _cacheParentDataManipulation = new HashSet<>();
        for (UserAccount _7 : userAccount) {
          _cacheParentDataManipulation.add(_7.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataManipulation");
    }
  }

  public class DataFromLocalSystem extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataFromLocalSystem;

    private Set<AttackStep> _cacheParentDataFromLocalSystem;

    public DataFromLocalSystem(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataFromLocalSystem == null) {
        _cacheChildrenDataFromLocalSystem = new HashSet<>();
        _cacheChildrenDataFromLocalSystem.add(attemptAutomatedCollection);
      }
      for (AttackStep attackStep : _cacheChildrenDataFromLocalSystem) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataFromLocalSystem == null) {
        _cacheParentDataFromLocalSystem = new HashSet<>();
        for (Service _0 : service) {
          if (_0 instanceof CloudService) {
            _cacheParentDataFromLocalSystem.add(((asset.CloudService) _0).createCloudInstance);
          }
        }
        _cacheParentDataFromLocalSystem.add(commandAndScriptingInterpreter);
      }
      for (AttackStep attackStep : _cacheParentDataFromLocalSystem) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataFromLocalSystem");
    }
  }

  public class Defacement extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDefacement;

    public Defacement(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDefacement == null) {
        _cacheChildrenDefacement = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenDefacement.add(_2.internalDefacement);
            }
          }
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (ExternalNetwork _5 : _4.externalNetwork) {
              _cacheChildrenDefacement.add(_5.externalDefacement);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDefacement) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.defacement");
    }
  }

  public class DomainDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheParentDomainDiscovery;

    public DomainDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainDiscovery == null) {
        _cacheParentDomainDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDomainDiscovery.add(_0.userRights);
        }
        _cacheParentDomainDiscovery.add(operatingSystemConfiguration.disable);
        _cacheParentDomainDiscovery.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentDomainDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainDiscovery");
    }
  }

  public class DomainGenerationAlgorithms extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDomainGenerationAlgorithms;

    private Set<AttackStep> _cacheParentDomainGenerationAlgorithms;

    public DomainGenerationAlgorithms(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDomainGenerationAlgorithms == null) {
        _cacheChildrenDomainGenerationAlgorithms = new HashSet<>();
        _cacheChildrenDomainGenerationAlgorithms.add(fallbackChannels);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenDomainGenerationAlgorithms.add(_2.communicate);
            }
          }
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheChildrenDomainGenerationAlgorithms.add(_5.generateDomainNames);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDomainGenerationAlgorithms) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainGenerationAlgorithms == null) {
        _cacheParentDomainGenerationAlgorithms = new HashSet<>();
        for (Service _6 : service) {
          for (Browser _7 : _6.browser) {
            _cacheParentDomainGenerationAlgorithms.add(_7.restrictWebBasedContent.disable);
          }
        }
        _cacheParentDomainGenerationAlgorithms.add(dynamicResolution);
        for (Computer _8 : computer) {
          for (Router _9 : _8.router) {
            for (InternalNetwork _a : _9.internalNetwork) {
              _cacheParentDomainGenerationAlgorithms.add(_a.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDomainGenerationAlgorithms) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainGenerationAlgorithms");
    }
  }

  public class CompromisedDataOrSystem extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCompromisedDataOrSystem;

    private Set<AttackStep> _cacheParentCompromisedDataOrSystem;

    public CompromisedDataOrSystem(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCompromisedDataOrSystem == null) {
        _cacheChildrenCompromisedDataOrSystem = new HashSet<>();
        _cacheChildrenCompromisedDataOrSystem.add(attemptPrivateKeys);
        _cacheChildrenCompromisedDataOrSystem.add(systemNetworkConnectionsDiscovery);
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheChildrenCompromisedDataOrSystem.add(_1.installExtensions);
          }
        }
        for (Computer _2 : computer) {
          for (PeripheralDevice _3 : _2.peripheralDevice) {
            _cacheChildrenCompromisedDataOrSystem.add(_3.infectedMedia);
          }
        }
        for (Service _4 : service) {
          _cacheChildrenCompromisedDataOrSystem.add(_4.attemptTrustedRelationship);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCompromisedDataOrSystem) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCompromisedDataOrSystem == null) {
        _cacheParentCompromisedDataOrSystem = new HashSet<>();
        for (Service _5 : service) {
          _cacheParentCompromisedDataOrSystem.add(_5.compromiseSoftwareDependenciesAndDevelopmentTools);
        }
        for (Service _6 : service) {
          _cacheParentCompromisedDataOrSystem.add(_6.compromiseSoftwareSupplyChain);
        }
        for (Service _7 : service) {
          _cacheParentCompromisedDataOrSystem.add(_7.compromiseHardwareSupplyChain);
        }
      }
      for (AttackStep attackStep : _cacheParentCompromisedDataOrSystem) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.compromisedDataOrSystem");
    }
  }

  public class AttemptBinaryPadding extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBinaryPadding;

    private Set<AttackStep> _cacheParentAttemptBinaryPadding;

    public AttemptBinaryPadding(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBinaryPadding == null) {
        _cacheChildrenAttemptBinaryPadding = new HashSet<>();
        _cacheChildrenAttemptBinaryPadding.add(binaryPadding);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBinaryPadding) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptBinaryPadding == null) {
        _cacheParentAttemptBinaryPadding = new HashSet<>();
        _cacheParentAttemptBinaryPadding.add(obfuscatedFilesOrInformation);
      }
      for (AttackStep attackStep : _cacheParentAttemptBinaryPadding) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptBinaryPadding");
    }
  }

  public class BinaryPadding extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenBinaryPadding;

    private Set<AttackStep> _cacheParentBinaryPadding;

    public BinaryPadding(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBinaryPadding == null) {
        _cacheChildrenBinaryPadding = new HashSet<>();
        _cacheChildrenBinaryPadding.add(bypassSignatureBasedDetection);
        _cacheChildrenBinaryPadding.add(bypassAntivirus);
      }
      for (AttackStep attackStep : _cacheChildrenBinaryPadding) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBinaryPadding == null) {
        _cacheParentBinaryPadding = new HashSet<>();
        _cacheParentBinaryPadding.add(attemptBinaryPadding);
        _cacheParentBinaryPadding.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentBinaryPadding) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.binaryPadding");
    }
  }

  public class ApplicationWindowDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheParentApplicationWindowDiscovery;

    public ApplicationWindowDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationWindowDiscovery == null) {
        _cacheParentApplicationWindowDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentApplicationWindowDiscovery.add(_0.userRights);
        }
        _cacheParentApplicationWindowDiscovery.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentApplicationWindowDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.applicationWindowDiscovery");
    }
  }

  public class ProcessDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenProcessDiscovery;

    private Set<AttackStep> _cacheParentProcessDiscovery;

    public ProcessDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenProcessDiscovery == null) {
        _cacheChildrenProcessDiscovery = new HashSet<>();
        _cacheChildrenProcessDiscovery.add(processInjection);
      }
      for (AttackStep attackStep : _cacheChildrenProcessDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcessDiscovery == null) {
        _cacheParentProcessDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentProcessDiscovery.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentProcessDiscovery.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentProcessDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.processDiscovery");
    }
  }

  public class CollectHashInformation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCollectHashInformation;

    private Set<AttackStep> _cacheParentCollectHashInformation;

    public CollectHashInformation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCollectHashInformation == null) {
        _cacheChildrenCollectHashInformation = new HashSet<>();
        _cacheChildrenCollectHashInformation.add(attemptPasswordCracking);
      }
      for (AttackStep attackStep : _cacheChildrenCollectHashInformation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCollectHashInformation == null) {
        _cacheParentCollectHashInformation = new HashSet<>();
        if (OS.this instanceof Linux) {
          _cacheParentCollectHashInformation.add(((asset.Linux) OS.this)._etc_passwdAND_etc_shadow);
        }
        if (OS.this instanceof Linux) {
          _cacheParentCollectHashInformation.add(((asset.Linux) OS.this).procFilesystem);
        }
      }
      for (AttackStep attackStep : _cacheParentCollectHashInformation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.collectHashInformation");
    }
  }

  public class CompileAfterDelivery extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCompileAfterDelivery;

    private Set<AttackStep> _cacheParentCompileAfterDelivery;

    public CompileAfterDelivery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCompileAfterDelivery == null) {
        _cacheChildrenCompileAfterDelivery = new HashSet<>();
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheChildrenCompileAfterDelivery.add(_1.phishing);
          }
        }
        _cacheChildrenCompileAfterDelivery.add(bypassStaticFileAnalysis);
        _cacheChildrenCompileAfterDelivery.add(bypassBinaryAnalysis);
        _cacheChildrenCompileAfterDelivery.add(bypassAntivirus);
        _cacheChildrenCompileAfterDelivery.add(bypassHostIntrusionPrevention);
        _cacheChildrenCompileAfterDelivery.add(bypassSignatureBasedDetection);
      }
      for (AttackStep attackStep : _cacheChildrenCompileAfterDelivery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCompileAfterDelivery == null) {
        _cacheParentCompileAfterDelivery = new HashSet<>();
        for (UserAccount _2 : userAccount) {
          _cacheParentCompileAfterDelivery.add(_2.userRights);
        }
        _cacheParentCompileAfterDelivery.add(obfuscatedFilesOrInformation);
      }
      for (AttackStep attackStep : _cacheParentCompileAfterDelivery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.compileAfterDelivery");
    }
  }

  public class OSCredentialDumping extends AttackStepMin {
    private Set<AttackStep> _cacheParentOSCredentialDumping;

    public OSCredentialDumping(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOSCredentialDumping == null) {
        _cacheParentOSCredentialDumping = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentOSCredentialDumping.add(_0.adminRights);
        }
        _cacheParentOSCredentialDumping.add(dataEncryptedForImpact);
      }
      for (AttackStep attackStep : _cacheParentOSCredentialDumping) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.oSCredentialDumping");
    }
  }

  public class AttemptEncryptedChannel extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptEncryptedChannel;

    public AttemptEncryptedChannel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptEncryptedChannel == null) {
        _cacheChildrenAttemptEncryptedChannel = new HashSet<>();
        _cacheChildrenAttemptEncryptedChannel.add(encryptedChannel);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptEncryptedChannel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptEncryptedChannel");
    }
  }

  public class EncryptedChannel extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenEncryptedChannel;

    private Set<AttackStep> _cacheParentEncryptedChannel;

    public EncryptedChannel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenEncryptedChannel == null) {
        _cacheChildrenEncryptedChannel = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenEncryptedChannel.add(_2.c2Connected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenEncryptedChannel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEncryptedChannel == null) {
        _cacheParentEncryptedChannel = new HashSet<>();
        _cacheParentEncryptedChannel.add(attemptEncryptedChannel);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentEncryptedChannel.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (InternalNetwork _8 : _7.internalNetwork) {
              _cacheParentEncryptedChannel.add(_8.sSLOrTLSInspection.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentEncryptedChannel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.encryptedChannel");
    }
  }

  public class DataEncoding extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataEncoding;

    private Set<AttackStep> _cacheParentDataEncoding;

    public DataEncoding(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataEncoding == null) {
        _cacheChildrenDataEncoding = new HashSet<>();
        _cacheChildrenDataEncoding.add(standardEncoding);
        _cacheChildrenDataEncoding.add(nonStandardEncoding);
      }
      for (AttackStep attackStep : _cacheChildrenDataEncoding) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataEncoding == null) {
        _cacheParentDataEncoding = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDataEncoding.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDataEncoding) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataEncoding");
    }
  }

  public class StandardEncoding extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenStandardEncoding;

    private Set<AttackStep> _cacheParentStandardEncoding;

    public StandardEncoding(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenStandardEncoding == null) {
        _cacheChildrenStandardEncoding = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenStandardEncoding.add(_2.communicate);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenStandardEncoding) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentStandardEncoding == null) {
        _cacheParentStandardEncoding = new HashSet<>();
        _cacheParentStandardEncoding.add(dataEncoding);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentStandardEncoding.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentStandardEncoding) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.standardEncoding");
    }
  }

  public class NonStandardEncoding extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenNonStandardEncoding;

    private Set<AttackStep> _cacheParentNonStandardEncoding;

    public NonStandardEncoding(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNonStandardEncoding == null) {
        _cacheChildrenNonStandardEncoding = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenNonStandardEncoding.add(_2.communicate);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenNonStandardEncoding) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNonStandardEncoding == null) {
        _cacheParentNonStandardEncoding = new HashSet<>();
        _cacheParentNonStandardEncoding.add(dataEncoding);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentNonStandardEncoding.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentNonStandardEncoding) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.nonStandardEncoding");
    }
  }

  public class DynamicResolution extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDynamicResolution;

    private Set<AttackStep> _cacheParentDynamicResolution;

    public DynamicResolution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDynamicResolution == null) {
        _cacheChildrenDynamicResolution = new HashSet<>();
        _cacheChildrenDynamicResolution.add(fallbackChannels);
        _cacheChildrenDynamicResolution.add(fastFluxDNS);
        _cacheChildrenDynamicResolution.add(domainGenerationAlgorithms);
        _cacheChildrenDynamicResolution.add(dNSCalculation);
      }
      for (AttackStep attackStep : _cacheChildrenDynamicResolution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDynamicResolution == null) {
        _cacheParentDynamicResolution = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDynamicResolution.add(_0.userRights);
        }
        _cacheParentDynamicResolution.add(protocolTunneling);
      }
      for (AttackStep attackStep : _cacheParentDynamicResolution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dynamicResolution");
    }
  }

  public class FastFluxDNS extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenFastFluxDNS;

    private Set<AttackStep> _cacheParentFastFluxDNS;

    public FastFluxDNS(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenFastFluxDNS == null) {
        _cacheChildrenFastFluxDNS = new HashSet<>();
        _cacheChildrenFastFluxDNS.add(fallbackChannels);
      }
      for (AttackStep attackStep : _cacheChildrenFastFluxDNS) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFastFluxDNS == null) {
        _cacheParentFastFluxDNS = new HashSet<>();
        _cacheParentFastFluxDNS.add(dynamicResolution);
      }
      for (AttackStep attackStep : _cacheParentFastFluxDNS) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.fastFluxDNS");
    }
  }

  public class DNSCalculation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDNSCalculation;

    private Set<AttackStep> _cacheParentDNSCalculation;

    public DNSCalculation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDNSCalculation == null) {
        _cacheChildrenDNSCalculation = new HashSet<>();
        _cacheChildrenDNSCalculation.add(bypassEgressFiltering);
      }
      for (AttackStep attackStep : _cacheChildrenDNSCalculation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDNSCalculation == null) {
        _cacheParentDNSCalculation = new HashSet<>();
        _cacheParentDNSCalculation.add(dynamicResolution);
      }
      for (AttackStep attackStep : _cacheParentDNSCalculation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dNSCalculation");
    }
  }

  public class ExecuteCode extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExecuteCode;

    private Set<AttackStep> _cacheParentExecuteCode;

    public ExecuteCode(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExecuteCode == null) {
        _cacheChildrenExecuteCode = new HashSet<>();
        for (Computer _0 : computer) {
          _cacheChildrenExecuteCode.add(_0.infectedComputer);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheChildrenExecuteCode.add(_3.remoteAccess);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExecuteCode) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecuteCode == null) {
        _cacheParentExecuteCode = new HashSet<>();
        for (Computer _4 : computer) {
          for (User _5 : _4.user) {
            _cacheParentExecuteCode.add(_5.maliciousLink);
          }
        }
        for (Computer _6 : computer) {
          for (User _7 : _6.user) {
            _cacheParentExecuteCode.add(_7.maliciousFile);
          }
        }
        for (Service _8 : service) {
          _cacheParentExecuteCode.add(_8.applicationDeploymentSoftware);
        }
        for (Service _9 : service) {
          _cacheParentExecuteCode.add(_9.exploitationOfSQLInjection);
        }
        for (Service _a : service) {
          _cacheParentExecuteCode.add(_a.exploitationOfNTLMAuthentication);
        }
        for (Service _b : service) {
          if (_b instanceof ThirdpartySoftware) {
            _cacheParentExecuteCode.add(((asset.ThirdpartySoftware) _b).useThirdpartySoftware);
          }
        }
        _cacheParentExecuteCode.add(visualBasic);
        _cacheParentExecuteCode.add(python);
        _cacheParentExecuteCode.add(javaScriptOrJScript);
        _cacheParentExecuteCode.add(antivirusCheck);
        for (Computer _c : computer) {
          for (Router _d : _c.router) {
            for (InternalNetwork _e : _d.internalNetwork) {
              if (_e instanceof NetworkSharedDrive) {
                _cacheParentExecuteCode.add(((asset.NetworkSharedDrive) _e).taintSharedContent);
              }
            }
          }
        }
        for (Computer _f : computer) {
          if (_f instanceof HardwareAddition) {
            _cacheParentExecuteCode.add(((asset.HardwareAddition) _f).hardwareAdditions);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentExecuteCode) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.executeCode");
    }
  }

  public class AttemptEndpointDenialOfService extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptEndpointDenialOfService;

    public AttemptEndpointDenialOfService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptEndpointDenialOfService == null) {
        _cacheChildrenAttemptEndpointDenialOfService = new HashSet<>();
        _cacheChildrenAttemptEndpointDenialOfService.add(endpointDenialOfService);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptEndpointDenialOfService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptEndpointDenialOfService");
    }
  }

  public class EndpointDenialOfService extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenEndpointDenialOfService;

    private Set<AttackStep> _cacheParentEndpointDenialOfService;

    public EndpointDenialOfService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenEndpointDenialOfService == null) {
        _cacheChildrenEndpointDenialOfService = new HashSet<>();
        _cacheChildrenEndpointDenialOfService.add(applicationExhaustionFlood);
        _cacheChildrenEndpointDenialOfService.add(oSExhaustionFlood);
        _cacheChildrenEndpointDenialOfService.add(serviceExhaustionFlood);
        _cacheChildrenEndpointDenialOfService.add(applicationOrSystemExploitation);
        for (Service _0 : service) {
          _cacheChildrenEndpointDenialOfService.add(_0.applicationExhaustionFlood);
        }
        for (Service _1 : service) {
          _cacheChildrenEndpointDenialOfService.add(_1.serviceExhaustionFlood);
        }
        for (Service _2 : service) {
          _cacheChildrenEndpointDenialOfService.add(_2.applicationOrSystemExploitation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenEndpointDenialOfService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEndpointDenialOfService == null) {
        _cacheParentEndpointDenialOfService = new HashSet<>();
        _cacheParentEndpointDenialOfService.add(attemptEndpointDenialOfService);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentEndpointDenialOfService.add(_5.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (ExternalNetwork _8 : _7.externalNetwork) {
              _cacheParentEndpointDenialOfService.add(_8.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentEndpointDenialOfService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.endpointDenialOfService");
    }
  }

  public class ApplicationExhaustionFlood extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenApplicationExhaustionFlood;

    private Set<AttackStep> _cacheParentApplicationExhaustionFlood;

    public ApplicationExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenApplicationExhaustionFlood == null) {
        _cacheChildrenApplicationExhaustionFlood = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenApplicationExhaustionFlood.add(_0.blockUserAccess);
        }
      }
      for (AttackStep attackStep : _cacheChildrenApplicationExhaustionFlood) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationExhaustionFlood == null) {
        _cacheParentApplicationExhaustionFlood = new HashSet<>();
        _cacheParentApplicationExhaustionFlood.add(endpointDenialOfService);
        _cacheParentApplicationExhaustionFlood.add(directNetworkFlood);
        _cacheParentApplicationExhaustionFlood.add(reflectionAmplification);
      }
      for (AttackStep attackStep : _cacheParentApplicationExhaustionFlood) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.applicationExhaustionFlood");
    }
  }

  public class OSExhaustionFlood extends AttackStepMin {
    private Set<AttackStep> _cacheParentOSExhaustionFlood;

    public OSExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOSExhaustionFlood == null) {
        _cacheParentOSExhaustionFlood = new HashSet<>();
        _cacheParentOSExhaustionFlood.add(endpointDenialOfService);
      }
      for (AttackStep attackStep : _cacheParentOSExhaustionFlood) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.oSExhaustionFlood");
    }
  }

  public class ServiceExhaustionFlood extends AttackStepMin {
    private Set<AttackStep> _cacheParentServiceExhaustionFlood;

    public ServiceExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceExhaustionFlood == null) {
        _cacheParentServiceExhaustionFlood = new HashSet<>();
        _cacheParentServiceExhaustionFlood.add(endpointDenialOfService);
      }
      for (AttackStep attackStep : _cacheParentServiceExhaustionFlood) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.serviceExhaustionFlood");
    }
  }

  public class ApplicationOrSystemExploitation extends AttackStepMin {
    private Set<AttackStep> _cacheParentApplicationOrSystemExploitation;

    public ApplicationOrSystemExploitation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationOrSystemExploitation == null) {
        _cacheParentApplicationOrSystemExploitation = new HashSet<>();
        _cacheParentApplicationOrSystemExploitation.add(endpointDenialOfService);
      }
      for (AttackStep attackStep : _cacheParentApplicationOrSystemExploitation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.applicationOrSystemExploitation");
    }
  }

  public class EventTriggeredExecution extends AttackStepMin {
    public EventTriggeredExecution(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.eventTriggeredExecution");
    }
  }

  public class ExecutionGuardrails extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExecutionGuardrails;

    private Set<AttackStep> _cacheParentExecutionGuardrails;

    public ExecutionGuardrails(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExecutionGuardrails == null) {
        _cacheChildrenExecutionGuardrails = new HashSet<>();
        _cacheChildrenExecutionGuardrails.add(environmentalKeying);
      }
      for (AttackStep attackStep : _cacheChildrenExecutionGuardrails) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecutionGuardrails == null) {
        _cacheParentExecutionGuardrails = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentExecutionGuardrails.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentExecutionGuardrails) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.executionGuardrails");
    }
  }

  public class EnvironmentalKeying extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenEnvironmentalKeying;

    private Set<AttackStep> _cacheParentEnvironmentalKeying;

    public EnvironmentalKeying(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenEnvironmentalKeying == null) {
        _cacheChildrenEnvironmentalKeying = new HashSet<>();
        _cacheChildrenEnvironmentalKeying.add(payloadDelivery);
      }
      for (AttackStep attackStep : _cacheChildrenEnvironmentalKeying) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEnvironmentalKeying == null) {
        _cacheParentEnvironmentalKeying = new HashSet<>();
        _cacheParentEnvironmentalKeying.add(executionGuardrails);
        _cacheParentEnvironmentalKeying.add(doNotMitigate.disable);
      }
      for (AttackStep attackStep : _cacheParentEnvironmentalKeying) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.environmentalKeying");
    }
  }

  public class PayloadDelivery extends AttackStepMin {
    private Set<AttackStep> _cacheParentPayloadDelivery;

    public PayloadDelivery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPayloadDelivery == null) {
        _cacheParentPayloadDelivery = new HashSet<>();
        _cacheParentPayloadDelivery.add(environmentalKeying);
      }
      for (AttackStep attackStep : _cacheParentPayloadDelivery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.payloadDelivery");
    }
  }

  public class ExfiltrationOverOtherNetworkMedium extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExfiltrationOverOtherNetworkMedium;

    private Set<AttackStep> _cacheParentExfiltrationOverOtherNetworkMedium;

    public ExfiltrationOverOtherNetworkMedium(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverOtherNetworkMedium == null) {
        _cacheChildrenExfiltrationOverOtherNetworkMedium = new HashSet<>();
        _cacheChildrenExfiltrationOverOtherNetworkMedium.add(exfiltrationOverBluetooth);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenExfiltrationOverOtherNetworkMedium.add(_2.dataExfiltration);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverOtherNetworkMedium) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverOtherNetworkMedium == null) {
        _cacheParentExfiltrationOverOtherNetworkMedium = new HashSet<>();
        _cacheParentExfiltrationOverOtherNetworkMedium.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverOtherNetworkMedium) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.exfiltrationOverOtherNetworkMedium");
    }
  }

  public class ExfiltrationOverBluetooth extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExfiltrationOverBluetooth;

    private Set<AttackStep> _cacheParentExfiltrationOverBluetooth;

    public ExfiltrationOverBluetooth(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverBluetooth == null) {
        _cacheChildrenExfiltrationOverBluetooth = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenExfiltrationOverBluetooth.add(_2.dataExfiltration);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverBluetooth) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverBluetooth == null) {
        _cacheParentExfiltrationOverBluetooth = new HashSet<>();
        _cacheParentExfiltrationOverBluetooth.add(exfiltrationOverOtherNetworkMedium);
        _cacheParentExfiltrationOverBluetooth.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverBluetooth) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.exfiltrationOverBluetooth");
    }
  }

  public class FallbackChannels extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenFallbackChannels;

    private Set<AttackStep> _cacheParentFallbackChannels;

    public FallbackChannels(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenFallbackChannels == null) {
        _cacheChildrenFallbackChannels = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenFallbackChannels.add(_2.communicate);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenFallbackChannels) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFallbackChannels == null) {
        _cacheParentFallbackChannels = new HashSet<>();
        _cacheParentFallbackChannels.add(domainGenerationAlgorithms);
        _cacheParentFallbackChannels.add(dynamicResolution);
        _cacheParentFallbackChannels.add(fastFluxDNS);
        _cacheParentFallbackChannels.add(multiStageChannels);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentFallbackChannels.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (ExternalNetwork _8 : _7.externalNetwork) {
              _cacheParentFallbackChannels.add(_8.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentFallbackChannels) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.fallbackChannels");
    }
  }

  public class FirmwareCorruption extends AttackStepMax {
    private Set<AttackStep> _cacheParentFirmwareCorruption;

    public FirmwareCorruption(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFirmwareCorruption == null) {
        _cacheParentFirmwareCorruption = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentFirmwareCorruption.add(_0.adminRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentFirmwareCorruption.add(_1.privilegedAccountManagement.disable);
        }
        _cacheParentFirmwareCorruption.add(bootIntegrity.disable);
        _cacheParentFirmwareCorruption.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentFirmwareCorruption) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.firmwareCorruption");
    }
  }

  public class HideArtifacts extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenHideArtifacts;

    public HideArtifacts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenHideArtifacts == null) {
        _cacheChildrenHideArtifacts = new HashSet<>();
        _cacheChildrenHideArtifacts.add(hiddenFilesAndDirectories);
        _cacheChildrenHideArtifacts.add(hiddenFileSystem);
        _cacheChildrenHideArtifacts.add(runVirtualInstance);
      }
      for (AttackStep attackStep : _cacheChildrenHideArtifacts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.hideArtifacts");
    }
  }

  public class HiddenFileSystem extends AttackStepMax {
    private Set<AttackStep> _cacheParentHiddenFileSystem;

    public HiddenFileSystem(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHiddenFileSystem == null) {
        _cacheParentHiddenFileSystem = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentHiddenFileSystem.add(_0.userRights);
        }
        _cacheParentHiddenFileSystem.add(hideArtifacts);
      }
      for (AttackStep attackStep : _cacheParentHiddenFileSystem) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.hiddenFileSystem");
    }
  }

  public class RunVirtualInstance extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenRunVirtualInstance;

    private Set<AttackStep> _cacheParentRunVirtualInstance;

    public RunVirtualInstance(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRunVirtualInstance == null) {
        _cacheChildrenRunVirtualInstance = new HashSet<>();
        _cacheChildrenRunVirtualInstance.add(bypassHostIntrusionPrevention);
      }
      for (AttackStep attackStep : _cacheChildrenRunVirtualInstance) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRunVirtualInstance == null) {
        _cacheParentRunVirtualInstance = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRunVirtualInstance.add(_0.userRights);
        }
        _cacheParentRunVirtualInstance.add(hideArtifacts);
        _cacheParentRunVirtualInstance.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentRunVirtualInstance.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentRunVirtualInstance) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.runVirtualInstance");
    }
  }

  public class HiddenFilesAndDirectories extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenHiddenFilesAndDirectories;

    private Set<AttackStep> _cacheParentHiddenFilesAndDirectories;

    public HiddenFilesAndDirectories(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenHiddenFilesAndDirectories == null) {
        _cacheChildrenHiddenFilesAndDirectories = new HashSet<>();
        _cacheChildrenHiddenFilesAndDirectories.add(bypassHostForensicAnalysis);
        _cacheChildrenHiddenFilesAndDirectories.add(persistence);
      }
      for (AttackStep attackStep : _cacheChildrenHiddenFilesAndDirectories) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHiddenFilesAndDirectories == null) {
        _cacheParentHiddenFilesAndDirectories = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentHiddenFilesAndDirectories.add(_0.userRights);
        }
        _cacheParentHiddenFilesAndDirectories.add(hideArtifacts);
      }
      for (AttackStep attackStep : _cacheParentHiddenFilesAndDirectories) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.hiddenFilesAndDirectories");
    }
  }

  public class HijackExecutionFlow extends AttackStepMin {
    public HijackExecutionFlow(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.hijackExecutionFlow");
    }
  }

  public class IndicatorRemovalFromTools extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenIndicatorRemovalFromTools;

    private Set<AttackStep> _cacheParentIndicatorRemovalFromTools;

    public IndicatorRemovalFromTools(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenIndicatorRemovalFromTools == null) {
        _cacheChildrenIndicatorRemovalFromTools = new HashSet<>();
        _cacheChildrenIndicatorRemovalFromTools.add(bypassHostIntrusionPrevention);
        _cacheChildrenIndicatorRemovalFromTools.add(bypassLogAnalysis);
        _cacheChildrenIndicatorRemovalFromTools.add(bypassAntivirus);
      }
      for (AttackStep attackStep : _cacheChildrenIndicatorRemovalFromTools) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentIndicatorRemovalFromTools == null) {
        _cacheParentIndicatorRemovalFromTools = new HashSet<>();
        _cacheParentIndicatorRemovalFromTools.add(obfuscatedFilesOrInformation);
        if (OS.this instanceof Windows) {
          _cacheParentIndicatorRemovalFromTools.add(((asset.Windows) OS.this).softwarePacking);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentIndicatorRemovalFromTools.add(((asset.MacOS) OS.this).softwarePacking);
        }
      }
      for (AttackStep attackStep : _cacheParentIndicatorRemovalFromTools) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.indicatorRemovalFromTools");
    }
  }

  public class IndicatorRemovalOnHost extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenIndicatorRemovalOnHost;

    private Set<AttackStep> _cacheParentIndicatorRemovalOnHost;

    public IndicatorRemovalOnHost(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenIndicatorRemovalOnHost == null) {
        _cacheChildrenIndicatorRemovalOnHost = new HashSet<>();
        _cacheChildrenIndicatorRemovalOnHost.add(fileDeletion);
        _cacheChildrenIndicatorRemovalOnHost.add(timestomp);
      }
      for (AttackStep attackStep : _cacheChildrenIndicatorRemovalOnHost) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentIndicatorRemovalOnHost == null) {
        _cacheParentIndicatorRemovalOnHost = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentIndicatorRemovalOnHost.add(_0.userRights);
        }
        _cacheParentIndicatorRemovalOnHost.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentIndicatorRemovalOnHost.add(encryptSensitiveInformation.disable);
        _cacheParentIndicatorRemovalOnHost.add(remoteDataStorage.disable);
      }
      for (AttackStep attackStep : _cacheParentIndicatorRemovalOnHost) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.indicatorRemovalOnHost");
    }
  }

  public class Timestomp extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenTimestomp;

    private Set<AttackStep> _cacheParentTimestomp;

    public Timestomp(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenTimestomp == null) {
        _cacheChildrenTimestomp = new HashSet<>();
        _cacheChildrenTimestomp.add(bypassHostForensicAnalysis);
        _cacheChildrenTimestomp.add(masquerading);
      }
      for (AttackStep attackStep : _cacheChildrenTimestomp) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTimestomp == null) {
        _cacheParentTimestomp = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentTimestomp.add(_0.userRights);
        }
        _cacheParentTimestomp.add(indicatorRemovalOnHost);
      }
      for (AttackStep attackStep : _cacheParentTimestomp) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.timestomp");
    }
  }

  public class InputCapture extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenInputCapture;

    private Set<AttackStep> _cacheParentInputCapture;

    public InputCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInputCapture == null) {
        _cacheChildrenInputCapture = new HashSet<>();
        _cacheChildrenInputCapture.add(keylogging);
        _cacheChildrenInputCapture.add(webPortalCapture);
      }
      for (AttackStep attackStep : _cacheChildrenInputCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInputCapture == null) {
        _cacheParentInputCapture = new HashSet<>();
        _cacheParentInputCapture.add(internalSpearphishing);
      }
      for (AttackStep attackStep : _cacheParentInputCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.inputCapture");
    }
  }

  public class Keylogging extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenKeylogging;

    private Set<AttackStep> _cacheParentKeylogging;

    public Keylogging(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenKeylogging == null) {
        _cacheChildrenKeylogging = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenKeylogging.add(_0.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenKeylogging) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentKeylogging == null) {
        _cacheParentKeylogging = new HashSet<>();
        _cacheParentKeylogging.add(inputCapture);
      }
      for (AttackStep attackStep : _cacheParentKeylogging) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.keylogging");
    }
  }

  public class LateralToolTransfer extends AttackStepMax {
    private Set<AttackStep> _cacheParentLateralToolTransfer;

    public LateralToolTransfer(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLateralToolTransfer == null) {
        _cacheParentLateralToolTransfer = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLateralToolTransfer.add(_0.userRights);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentLateralToolTransfer.add(_3.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (InternalNetwork _6 : _5.internalNetwork) {
              _cacheParentLateralToolTransfer.add(_6.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentLateralToolTransfer) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.lateralToolTransfer");
    }
  }

  public class WebPortalCapture extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenWebPortalCapture;

    private Set<AttackStep> _cacheParentWebPortalCapture;

    public WebPortalCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWebPortalCapture == null) {
        _cacheChildrenWebPortalCapture = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenWebPortalCapture.add(_0.attemptExternalRemoteServices);
        }
        _cacheChildrenWebPortalCapture.add(validAccounts);
      }
      for (AttackStep attackStep : _cacheChildrenWebPortalCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWebPortalCapture == null) {
        _cacheParentWebPortalCapture = new HashSet<>();
        _cacheParentWebPortalCapture.add(inputCapture);
        _cacheParentWebPortalCapture.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentWebPortalCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.webPortalCapture");
    }
  }

  public class InternalSpearphishing extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenInternalSpearphishing;

    private Set<AttackStep> _cacheParentInternalSpearphishing;

    public InternalSpearphishing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInternalSpearphishing == null) {
        _cacheChildrenInternalSpearphishing = new HashSet<>();
        for (Computer _0 : computer) {
          for (User _1 : _0.user) {
            _cacheChildrenInternalSpearphishing.add(_1.attemptMaliciousFile);
          }
        }
        for (Service _2 : service) {
          _cacheChildrenInternalSpearphishing.add(_2.applicationAccessToken);
        }
        for (Service _3 : service) {
          _cacheChildrenInternalSpearphishing.add(_3.attemptExploitationForClientExecution);
        }
        _cacheChildrenInternalSpearphishing.add(attemptDynamicDataExchange);
        _cacheChildrenInternalSpearphishing.add(inputCapture);
      }
      for (AttackStep attackStep : _cacheChildrenInternalSpearphishing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInternalSpearphishing == null) {
        _cacheParentInternalSpearphishing = new HashSet<>();
        for (UserAccount _4 : userAccount) {
          _cacheParentInternalSpearphishing.add(_4.userRights);
        }
        for (Service _5 : service) {
          if (_5 instanceof CloudService) {
            _cacheParentInternalSpearphishing.add(((asset.CloudService) _5).exchangeEmailDelegatePermissions);
          }
        }
        if (OS.this instanceof Windows) {
          _cacheParentInternalSpearphishing.add(((asset.Windows) OS.this).exchangeEmailDelegatePermissions);
        }
      }
      for (AttackStep attackStep : _cacheParentInternalSpearphishing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.internalSpearphishing");
    }
  }

  public class AttemptDynamicDataExchange extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptDynamicDataExchange;

    public AttemptDynamicDataExchange(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDynamicDataExchange == null) {
        _cacheParentAttemptDynamicDataExchange = new HashSet<>();
        for (Computer _0 : computer) {
          for (User _1 : _0.user) {
            _cacheParentAttemptDynamicDataExchange.add(_1.maliciousFile);
          }
        }
        _cacheParentAttemptDynamicDataExchange.add(internalSpearphishing);
      }
      for (AttackStep attackStep : _cacheParentAttemptDynamicDataExchange) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptDynamicDataExchange");
    }
  }

  public class ManInTheMiddle extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenManInTheMiddle;

    private Set<AttackStep> _cacheParentManInTheMiddle;

    public ManInTheMiddle(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenManInTheMiddle == null) {
        _cacheChildrenManInTheMiddle = new HashSet<>();
        _cacheChildrenManInTheMiddle.add(networkSniffing);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenManInTheMiddle.add(_2.attemptTransmittedDataManipulation);
            }
          }
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (ExternalNetwork _5 : _4.externalNetwork) {
              _cacheChildrenManInTheMiddle.add(_5.attemptTransmittedDataManipulation);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenManInTheMiddle) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentManInTheMiddle == null) {
        _cacheParentManInTheMiddle = new HashSet<>();
        for (UserAccount _6 : userAccount) {
          _cacheParentManInTheMiddle.add(_6.userRights);
        }
        _cacheParentManInTheMiddle.add(disableOrRemoveFeatureOrProgram.disable);
        for (Computer _7 : computer) {
          for (Router _8 : _7.router) {
            for (InternalNetwork _9 : _8.internalNetwork) {
              _cacheParentManInTheMiddle.add(_9.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _a : computer) {
          for (Router _b : _a.router) {
            for (InternalNetwork _c : _b.internalNetwork) {
              _cacheParentManInTheMiddle.add(_c.limitAccessToResourceOverNetwork.disable);
            }
          }
        }
        for (Computer _d : computer) {
          for (Router _e : _d.router) {
            for (InternalNetwork _f : _e.internalNetwork) {
              _cacheParentManInTheMiddle.add(_f.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _10 : computer) {
          for (Router _11 : _10.router) {
            for (InternalNetwork _12 : _11.internalNetwork) {
              _cacheParentManInTheMiddle.add(_12.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentManInTheMiddle) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.manInTheMiddle");
    }
  }

  public class Masquerading extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenMasquerading;

    private Set<AttackStep> _cacheParentMasquerading;

    public Masquerading(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMasquerading == null) {
        _cacheChildrenMasquerading = new HashSet<>();
        _cacheChildrenMasquerading.add(matchLegitimateNameOrLocation);
        _cacheChildrenMasquerading.add(rightToLeftOverride);
        _cacheChildrenMasquerading.add(renameSystemUtilities);
      }
      for (AttackStep attackStep : _cacheChildrenMasquerading) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMasquerading == null) {
        _cacheParentMasquerading = new HashSet<>();
        _cacheParentMasquerading.add(timestomp);
      }
      for (AttackStep attackStep : _cacheParentMasquerading) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.masquerading");
    }
  }

  public class ModifyAuthenticationProcess extends AttackStepMin {
    public ModifyAuthenticationProcess(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.modifyAuthenticationProcess");
    }
  }

  public class RightToLeftOverride extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenRightToLeftOverride;

    private Set<AttackStep> _cacheParentRightToLeftOverride;

    public RightToLeftOverride(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRightToLeftOverride == null) {
        _cacheChildrenRightToLeftOverride = new HashSet<>();
        for (Service _0 : service) {
          for (Browser _1 : _0.browser) {
            _cacheChildrenRightToLeftOverride.add(_1.attemptSpearphishingAttachment);
          }
        }
        for (Computer _2 : computer) {
          for (User _3 : _2.user) {
            _cacheChildrenRightToLeftOverride.add(_3.attemptMaliciousFile);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenRightToLeftOverride) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRightToLeftOverride == null) {
        _cacheParentRightToLeftOverride = new HashSet<>();
        _cacheParentRightToLeftOverride.add(masquerading);
      }
      for (AttackStep attackStep : _cacheParentRightToLeftOverride) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.rightToLeftOverride");
    }
  }

  public class RenameSystemUtilities extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenRenameSystemUtilities;

    private Set<AttackStep> _cacheParentRenameSystemUtilities;

    public RenameSystemUtilities(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRenameSystemUtilities == null) {
        _cacheChildrenRenameSystemUtilities = new HashSet<>();
        _cacheChildrenRenameSystemUtilities.add(bypassFileMonitoring);
      }
      for (AttackStep attackStep : _cacheChildrenRenameSystemUtilities) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRenameSystemUtilities == null) {
        _cacheParentRenameSystemUtilities = new HashSet<>();
        _cacheParentRenameSystemUtilities.add(masquerading);
        _cacheParentRenameSystemUtilities.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentRenameSystemUtilities) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.renameSystemUtilities");
    }
  }

  public class MatchLegitimateNameOrLocation extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenMatchLegitimateNameOrLocation;

    private Set<AttackStep> _cacheParentMatchLegitimateNameOrLocation;

    public MatchLegitimateNameOrLocation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMatchLegitimateNameOrLocation == null) {
        _cacheChildrenMatchLegitimateNameOrLocation = new HashSet<>();
        _cacheChildrenMatchLegitimateNameOrLocation.add(bypassFileOrPathWhitelisting);
      }
      for (AttackStep attackStep : _cacheChildrenMatchLegitimateNameOrLocation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMatchLegitimateNameOrLocation == null) {
        _cacheParentMatchLegitimateNameOrLocation = new HashSet<>();
        _cacheParentMatchLegitimateNameOrLocation.add(masquerading);
        _cacheParentMatchLegitimateNameOrLocation.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentMatchLegitimateNameOrLocation.add(codeSigning.disable);
        _cacheParentMatchLegitimateNameOrLocation.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentMatchLegitimateNameOrLocation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.matchLegitimateNameOrLocation");
    }
  }

  public class Proxy extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenProxy;

    private Set<AttackStep> _cacheParentProxy;

    public Proxy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenProxy == null) {
        _cacheChildrenProxy = new HashSet<>();
        _cacheChildrenProxy.add(internalProxy);
        _cacheChildrenProxy.add(externalProxy);
        _cacheChildrenProxy.add(attemptMultiHopProxy);
        _cacheChildrenProxy.add(domainFronting);
      }
      for (AttackStep attackStep : _cacheChildrenProxy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProxy == null) {
        _cacheParentProxy = new HashSet<>();
        _cacheParentProxy.add(protocolTunneling);
        _cacheParentProxy.add(twoFactorAuthenticationInterception);
      }
      for (AttackStep attackStep : _cacheParentProxy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.proxy");
    }
  }

  public class InternalProxy extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenInternalProxy;

    private Set<AttackStep> _cacheParentInternalProxy;

    public InternalProxy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInternalProxy == null) {
        _cacheChildrenInternalProxy = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenInternalProxy.add(_2.c2Connected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenInternalProxy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInternalProxy == null) {
        _cacheParentInternalProxy = new HashSet<>();
        _cacheParentInternalProxy.add(proxy);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentInternalProxy.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentInternalProxy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.internalProxy");
    }
  }

  public class ExternalProxy extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExternalProxy;

    private Set<AttackStep> _cacheParentExternalProxy;

    public ExternalProxy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExternalProxy == null) {
        _cacheChildrenExternalProxy = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenExternalProxy.add(_2.c2Connected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExternalProxy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExternalProxy == null) {
        _cacheParentExternalProxy = new HashSet<>();
        _cacheParentExternalProxy.add(proxy);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentExternalProxy.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentExternalProxy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.externalProxy");
    }
  }

  public class AttemptMultiHopProxy extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptMultiHopProxy;

    private Set<AttackStep> _cacheParentAttemptMultiHopProxy;

    public AttemptMultiHopProxy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptMultiHopProxy == null) {
        _cacheChildrenAttemptMultiHopProxy = new HashSet<>();
        _cacheChildrenAttemptMultiHopProxy.add(multiHopProxy);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptMultiHopProxy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptMultiHopProxy == null) {
        _cacheParentAttemptMultiHopProxy = new HashSet<>();
        _cacheParentAttemptMultiHopProxy.add(proxy);
      }
      for (AttackStep attackStep : _cacheParentAttemptMultiHopProxy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptMultiHopProxy");
    }
  }

  public class MultiHopProxy extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenMultiHopProxy;

    private Set<AttackStep> _cacheParentMultiHopProxy;

    public MultiHopProxy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMultiHopProxy == null) {
        _cacheChildrenMultiHopProxy = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenMultiHopProxy.add(_2.c2Connected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenMultiHopProxy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMultiHopProxy == null) {
        _cacheParentMultiHopProxy = new HashSet<>();
        _cacheParentMultiHopProxy.add(attemptMultiHopProxy);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentMultiHopProxy.add(_5.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (ExternalNetwork _8 : _7.externalNetwork) {
              _cacheParentMultiHopProxy.add(_8.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentMultiHopProxy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.multiHopProxy");
    }
  }

  public class DomainFronting extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDomainFronting;

    private Set<AttackStep> _cacheParentDomainFronting;

    public DomainFronting(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDomainFronting == null) {
        _cacheChildrenDomainFronting = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenDomainFronting.add(_2.obfuscateNetworkTraffic);
            }
          }
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (ExternalNetwork _5 : _4.externalNetwork) {
              _cacheChildrenDomainFronting.add(_5.obfuscateNetworkTraffic);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDomainFronting) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainFronting == null) {
        _cacheParentDomainFronting = new HashSet<>();
        _cacheParentDomainFronting.add(proxy);
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (InternalNetwork _8 : _7.internalNetwork) {
              _cacheParentDomainFronting.add(_8.sSLOrTLSInspection.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDomainFronting) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainFronting");
    }
  }

  public class AttemptMultiStageChannels extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptMultiStageChannels;

    private Set<AttackStep> _cacheParentAttemptMultiStageChannels;

    public AttemptMultiStageChannels(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptMultiStageChannels == null) {
        _cacheChildrenAttemptMultiStageChannels = new HashSet<>();
        _cacheChildrenAttemptMultiStageChannels.add(multiStageChannels);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptMultiStageChannels) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptMultiStageChannels == null) {
        _cacheParentAttemptMultiStageChannels = new HashSet<>();
        _cacheParentAttemptMultiStageChannels.add(timeBasedEvasion);
      }
      for (AttackStep attackStep : _cacheParentAttemptMultiStageChannels) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptMultiStageChannels");
    }
  }

  public class MultiStageChannels extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenMultiStageChannels;

    private Set<AttackStep> _cacheParentMultiStageChannels;

    public MultiStageChannels(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMultiStageChannels == null) {
        _cacheChildrenMultiStageChannels = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenMultiStageChannels.add(_2.c2Connected);
            }
          }
        }
        _cacheChildrenMultiStageChannels.add(fallbackChannels);
      }
      for (AttackStep attackStep : _cacheChildrenMultiStageChannels) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMultiStageChannels == null) {
        _cacheParentMultiStageChannels = new HashSet<>();
        _cacheParentMultiStageChannels.add(attemptMultiStageChannels);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentMultiStageChannels.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (ExternalNetwork _8 : _7.externalNetwork) {
              _cacheParentMultiStageChannels.add(_8.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentMultiStageChannels) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.multiStageChannels");
    }
  }

  public class NetworkDenialOfService extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenNetworkDenialOfService;

    public NetworkDenialOfService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNetworkDenialOfService == null) {
        _cacheChildrenNetworkDenialOfService = new HashSet<>();
        _cacheChildrenNetworkDenialOfService.add(directNetworkFlood);
        _cacheChildrenNetworkDenialOfService.add(reflectionAmplification);
      }
      for (AttackStep attackStep : _cacheChildrenNetworkDenialOfService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.networkDenialOfService");
    }
  }

  public class DirectNetworkFlood extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDirectNetworkFlood;

    private Set<AttackStep> _cacheParentDirectNetworkFlood;

    public DirectNetworkFlood(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDirectNetworkFlood == null) {
        _cacheChildrenDirectNetworkFlood = new HashSet<>();
        _cacheChildrenDirectNetworkFlood.add(applicationExhaustionFlood);
        for (Service _0 : service) {
          _cacheChildrenDirectNetworkFlood.add(_0.serviceExhaustionFlood);
        }
      }
      for (AttackStep attackStep : _cacheChildrenDirectNetworkFlood) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDirectNetworkFlood == null) {
        _cacheParentDirectNetworkFlood = new HashSet<>();
        _cacheParentDirectNetworkFlood.add(networkDenialOfService);
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentDirectNetworkFlood.add(_3.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (ExternalNetwork _6 : _5.externalNetwork) {
              _cacheParentDirectNetworkFlood.add(_6.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDirectNetworkFlood) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.directNetworkFlood");
    }
  }

  public class ReflectionAmplification extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenReflectionAmplification;

    private Set<AttackStep> _cacheParentReflectionAmplification;

    public ReflectionAmplification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenReflectionAmplification == null) {
        _cacheChildrenReflectionAmplification = new HashSet<>();
        _cacheChildrenReflectionAmplification.add(applicationExhaustionFlood);
        for (Service _0 : service) {
          _cacheChildrenReflectionAmplification.add(_0.serviceExhaustionFlood);
        }
      }
      for (AttackStep attackStep : _cacheChildrenReflectionAmplification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentReflectionAmplification == null) {
        _cacheParentReflectionAmplification = new HashSet<>();
        _cacheParentReflectionAmplification.add(networkDenialOfService);
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentReflectionAmplification.add(_3.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (ExternalNetwork _6 : _5.externalNetwork) {
              _cacheParentReflectionAmplification.add(_6.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentReflectionAmplification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.reflectionAmplification");
    }
  }

  public class NetworkSniffing extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenNetworkSniffing;

    private Set<AttackStep> _cacheParentNetworkSniffing;

    public NetworkSniffing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNetworkSniffing == null) {
        _cacheChildrenNetworkSniffing = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenNetworkSniffing.add(_0.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenNetworkSniffing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkSniffing == null) {
        _cacheParentNetworkSniffing = new HashSet<>();
        for (AdminAccount _1 : adminAccount) {
          _cacheParentNetworkSniffing.add(_1.adminRights);
        }
        _cacheParentNetworkSniffing.add(manInTheMiddle);
        _cacheParentNetworkSniffing.add(multiFactorAuthentication.disable);
        _cacheParentNetworkSniffing.add(encryptSensitiveInformation.disable);
        if (OS.this instanceof Windows) {
          _cacheParentNetworkSniffing.add(((asset.Windows) OS.this).collectHashInformation);
        }
        if (OS.this instanceof Windows) {
          _cacheParentNetworkSniffing.add(((asset.Windows) OS.this).lLMNR_NBT_NS_PoisoningAndSMBRelay);
        }
      }
      for (AttackStep attackStep : _cacheParentNetworkSniffing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.networkSniffing");
    }
  }

  public class ObfuscatedFilesOrInformation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenObfuscatedFilesOrInformation;

    private Set<AttackStep> _cacheParentObfuscatedFilesOrInformation;

    public ObfuscatedFilesOrInformation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenObfuscatedFilesOrInformation == null) {
        _cacheChildrenObfuscatedFilesOrInformation = new HashSet<>();
        _cacheChildrenObfuscatedFilesOrInformation.add(attemptBinaryPadding);
        _cacheChildrenObfuscatedFilesOrInformation.add(steganography);
        _cacheChildrenObfuscatedFilesOrInformation.add(compileAfterDelivery);
        _cacheChildrenObfuscatedFilesOrInformation.add(indicatorRemovalFromTools);
      }
      for (AttackStep attackStep : _cacheChildrenObfuscatedFilesOrInformation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentObfuscatedFilesOrInformation == null) {
        _cacheParentObfuscatedFilesOrInformation = new HashSet<>();
        _cacheParentObfuscatedFilesOrInformation.add(javaScriptOrJScript);
      }
      for (AttackStep attackStep : _cacheParentObfuscatedFilesOrInformation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.obfuscatedFilesOrInformation");
    }
  }

  public class Steganography extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSteganography;

    private Set<AttackStep> _cacheParentSteganography;

    public Steganography(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSteganography == null) {
        _cacheChildrenSteganography = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenSteganography.add(_2.bypassNetworkIntrusionDetection);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSteganography) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSteganography == null) {
        _cacheParentSteganography = new HashSet<>();
        _cacheParentSteganography.add(obfuscatedFilesOrInformation);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentSteganography.add(_5.dataObfuscation);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentSteganography) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.steganography");
    }
  }

  public class AttemptPrivateKeys extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptPrivateKeys;

    private Set<AttackStep> _cacheParentAttemptPrivateKeys;

    public AttemptPrivateKeys(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptPrivateKeys == null) {
        _cacheChildrenAttemptPrivateKeys = new HashSet<>();
        _cacheChildrenAttemptPrivateKeys.add(privateKeys);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPrivateKeys) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPrivateKeys == null) {
        _cacheParentAttemptPrivateKeys = new HashSet<>();
        _cacheParentAttemptPrivateKeys.add(compromisedDataOrSystem);
        _cacheParentAttemptPrivateKeys.add(bruteForce);
      }
      for (AttackStep attackStep : _cacheParentAttemptPrivateKeys) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptPrivateKeys");
    }
  }

  public class PrivateKeys extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenPrivateKeys;

    private Set<AttackStep> _cacheParentPrivateKeys;

    public PrivateKeys(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPrivateKeys == null) {
        _cacheChildrenPrivateKeys = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenPrivateKeys.add(_0.remoteServices);
        }
        _cacheChildrenPrivateKeys.add(privateKeysWithPassphrase);
      }
      for (AttackStep attackStep : _cacheChildrenPrivateKeys) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPrivateKeys == null) {
        _cacheParentPrivateKeys = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentPrivateKeys.add(_1.userRights);
        }
        _cacheParentPrivateKeys.add(attemptPrivateKeys);
        _cacheParentPrivateKeys.add(unsecuredCredentials);
        _cacheParentPrivateKeys.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentPrivateKeys.add(passwordPolicies.disable);
        _cacheParentPrivateKeys.add(audit.disable);
        _cacheParentPrivateKeys.add(encryptSensitiveInformation.disable);
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheParentPrivateKeys.add(_4.networkSegmentation.disable);
            }
          }
        }
        for (Computer _5 : computer) {
          for (Router _6 : _5.router) {
            for (ExternalNetwork _7 : _6.externalNetwork) {
              _cacheParentPrivateKeys.add(_7.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentPrivateKeys) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.privateKeys");
    }
  }

  public class PrivateKeysWithPassphrase extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenPrivateKeysWithPassphrase;

    private Set<AttackStep> _cacheParentPrivateKeysWithPassphrase;

    public PrivateKeysWithPassphrase(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPrivateKeysWithPassphrase == null) {
        _cacheChildrenPrivateKeysWithPassphrase = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenPrivateKeysWithPassphrase.add(_0.remoteServices);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPrivateKeysWithPassphrase) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPrivateKeysWithPassphrase == null) {
        _cacheParentPrivateKeysWithPassphrase = new HashSet<>();
        _cacheParentPrivateKeysWithPassphrase.add(privateKeys);
        if (OS.this instanceof Windows) {
          _cacheParentPrivateKeysWithPassphrase.add(((asset.Windows) OS.this).gUIInputCapture);
        }
      }
      for (AttackStep attackStep : _cacheParentPrivateKeysWithPassphrase) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.privateKeysWithPassphrase");
    }
  }

  public class ResourceHijacking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenResourceHijacking;

    private Set<AttackStep> _cacheParentResourceHijacking;

    public ResourceHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenResourceHijacking == null) {
        _cacheChildrenResourceHijacking = new HashSet<>();
        for (Computer _0 : computer) {
          _cacheChildrenResourceHijacking.add(_0.unresponsive);
        }
      }
      for (AttackStep attackStep : _cacheChildrenResourceHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentResourceHijacking == null) {
        _cacheParentResourceHijacking = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentResourceHijacking.add(_1.userRights);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentResourceHijacking.add(_2.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentResourceHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.resourceHijacking");
    }
  }

  public class CommunicationThroughRemovableMedia extends AttackStepMax {
    private Set<AttackStep> _cacheParentCommunicationThroughRemovableMedia;

    public CommunicationThroughRemovableMedia(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCommunicationThroughRemovableMedia == null) {
        _cacheParentCommunicationThroughRemovableMedia = new HashSet<>();
        _cacheParentCommunicationThroughRemovableMedia.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentCommunicationThroughRemovableMedia.add(operatingSystemConfiguration.disable);
        if (OS.this instanceof Windows) {
          _cacheParentCommunicationThroughRemovableMedia.add(((asset.Windows) OS.this).replicationThroughRemovableMedia);
        }
      }
      for (AttackStep attackStep : _cacheParentCommunicationThroughRemovableMedia) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.communicationThroughRemovableMedia");
    }
  }

  public class RemoteSystemDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentRemoteSystemDiscovery;

    public RemoteSystemDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteSystemDiscovery == null) {
        _cacheParentRemoteSystemDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRemoteSystemDiscovery.add(_0.userRights);
        }
        if (OS.this instanceof Windows) {
          _cacheParentRemoteSystemDiscovery.add(((asset.Windows) OS.this).rDPHijacking);
        }
        if (OS.this instanceof Windows) {
          _cacheParentRemoteSystemDiscovery.add(((asset.Windows) OS.this).remoteDesktopProtocol);
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteSystemDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.remoteSystemDiscovery");
    }
  }

  public class DetailedRemoteSystemDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheParentDetailedRemoteSystemDiscovery;

    public DetailedRemoteSystemDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDetailedRemoteSystemDiscovery == null) {
        _cacheParentDetailedRemoteSystemDiscovery = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentDetailedRemoteSystemDiscovery.add(_0.adminRights);
        }
        _cacheParentDetailedRemoteSystemDiscovery.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentDetailedRemoteSystemDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.detailedRemoteSystemDiscovery");
    }
  }

  public class FileAndDirectoryPermissionsModification extends AttackStepMin {
    private Set<AttackStep> _cacheParentFileAndDirectoryPermissionsModification;

    public FileAndDirectoryPermissionsModification(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFileAndDirectoryPermissionsModification == null) {
        _cacheParentFileAndDirectoryPermissionsModification = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentFileAndDirectoryPermissionsModification.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentFileAndDirectoryPermissionsModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.fileAndDirectoryPermissionsModification");
    }
  }

  public class ImpareDefenses extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenImpareDefenses;

    public ImpareDefenses(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenImpareDefenses == null) {
        _cacheChildrenImpareDefenses = new HashSet<>();
        _cacheChildrenImpareDefenses.add(attemptDisableOrModifyTools);
        _cacheChildrenImpareDefenses.add(disableOrModifySystemFirewall);
        _cacheChildrenImpareDefenses.add(attemptIndicatorBlocking);
        for (Service _0 : service) {
          _cacheChildrenImpareDefenses.add(_0.disableOrModifyCloudFirewall);
        }
      }
      for (AttackStep attackStep : _cacheChildrenImpareDefenses) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.impareDefenses");
    }
  }

  public class AttemptDisableOrModifyTools extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDisableOrModifyTools;

    private Set<AttackStep> _cacheParentAttemptDisableOrModifyTools;

    public AttemptDisableOrModifyTools(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDisableOrModifyTools == null) {
        _cacheChildrenAttemptDisableOrModifyTools = new HashSet<>();
        _cacheChildrenAttemptDisableOrModifyTools.add(disableOrModifyTools);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDisableOrModifyTools) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDisableOrModifyTools == null) {
        _cacheParentAttemptDisableOrModifyTools = new HashSet<>();
        _cacheParentAttemptDisableOrModifyTools.add(impareDefenses);
        if (OS.this instanceof Windows) {
          _cacheParentAttemptDisableOrModifyTools.add(((asset.Windows) OS.this).groupPolicyModification);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptDisableOrModifyTools) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptDisableOrModifyTools");
    }
  }

  public class DisableOrModifyTools extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDisableOrModifyTools;

    private Set<AttackStep> _cacheParentDisableOrModifyTools;

    public DisableOrModifyTools(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDisableOrModifyTools == null) {
        _cacheChildrenDisableOrModifyTools = new HashSet<>();
        _cacheChildrenDisableOrModifyTools.add(bypassAntivirus);
        _cacheChildrenDisableOrModifyTools.add(bypassFileMonitoring);
        _cacheChildrenDisableOrModifyTools.add(bypassHostIntrusionPrevention);
        _cacheChildrenDisableOrModifyTools.add(bypassLogAnalysis);
        _cacheChildrenDisableOrModifyTools.add(bypassSignatureBasedDetection);
      }
      for (AttackStep attackStep : _cacheChildrenDisableOrModifyTools) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDisableOrModifyTools == null) {
        _cacheParentDisableOrModifyTools = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDisableOrModifyTools.add(_0.userRights);
        }
        for (UserAccount _1 : userAccount) {
          _cacheParentDisableOrModifyTools.add(_1.userAccountManagement.disable);
        }
        _cacheParentDisableOrModifyTools.add(attemptDisableOrModifyTools);
        _cacheParentDisableOrModifyTools.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentDisableOrModifyTools.add(restrictRegistryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentDisableOrModifyTools) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.disableOrModifyTools");
    }
  }

  public class DisableOrModifySystemFirewall extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDisableOrModifySystemFirewall;

    private Set<AttackStep> _cacheParentDisableOrModifySystemFirewall;

    public DisableOrModifySystemFirewall(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDisableOrModifySystemFirewall == null) {
        _cacheChildrenDisableOrModifySystemFirewall = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            if (_1.firewall != null) {
              _cacheChildrenDisableOrModifySystemFirewall.add(_1.firewall.bypassFirewall);
            }
          }
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheChildrenDisableOrModifySystemFirewall.add(_4.c2Connected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDisableOrModifySystemFirewall) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDisableOrModifySystemFirewall == null) {
        _cacheParentDisableOrModifySystemFirewall = new HashSet<>();
        for (UserAccount _5 : userAccount) {
          _cacheParentDisableOrModifySystemFirewall.add(_5.userAccountManagement.disable);
        }
        _cacheParentDisableOrModifySystemFirewall.add(impareDefenses);
        _cacheParentDisableOrModifySystemFirewall.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentDisableOrModifySystemFirewall.add(restrictRegistryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentDisableOrModifySystemFirewall) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.disableOrModifySystemFirewall");
    }
  }

  public class AttemptIndicatorBlocking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptIndicatorBlocking;

    private Set<AttackStep> _cacheParentAttemptIndicatorBlocking;

    public AttemptIndicatorBlocking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptIndicatorBlocking == null) {
        _cacheChildrenAttemptIndicatorBlocking = new HashSet<>();
        _cacheChildrenAttemptIndicatorBlocking.add(indicatorBlocking);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptIndicatorBlocking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptIndicatorBlocking == null) {
        _cacheParentAttemptIndicatorBlocking = new HashSet<>();
        _cacheParentAttemptIndicatorBlocking.add(impareDefenses);
        if (OS.this instanceof Windows) {
          _cacheParentAttemptIndicatorBlocking.add(((asset.Windows) OS.this).powerShell);
        }
        if (OS.this instanceof Windows) {
          _cacheParentAttemptIndicatorBlocking.add(((asset.Windows) OS.this).windowsManagementInstrumentation);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptIndicatorBlocking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptIndicatorBlocking");
    }
  }

  public class IndicatorBlocking extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenIndicatorBlocking;

    private Set<AttackStep> _cacheParentIndicatorBlocking;

    public IndicatorBlocking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenIndicatorBlocking == null) {
        _cacheChildrenIndicatorBlocking = new HashSet<>();
        _cacheChildrenIndicatorBlocking.add(bypassAntivirus);
        _cacheChildrenIndicatorBlocking.add(bypassHostIntrusionPrevention);
      }
      for (AttackStep attackStep : _cacheChildrenIndicatorBlocking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentIndicatorBlocking == null) {
        _cacheParentIndicatorBlocking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentIndicatorBlocking.add(_0.userAccountManagement.disable);
        }
        _cacheParentIndicatorBlocking.add(attemptIndicatorBlocking);
      }
      for (AttackStep attackStep : _cacheParentIndicatorBlocking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.indicatorBlocking");
    }
  }

  public class ScheduledTaskOrJob extends AttackStepMin {
    private Set<AttackStep> _cacheParentScheduledTaskOrJob;

    public ScheduledTaskOrJob(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentScheduledTaskOrJob == null) {
        _cacheParentScheduledTaskOrJob = new HashSet<>();
        _cacheParentScheduledTaskOrJob.add(timeBasedEvasion);
      }
      for (AttackStep attackStep : _cacheParentScheduledTaskOrJob) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.scheduledTaskOrJob");
    }
  }

  public class ServerSoftwareComponent extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenServerSoftwareComponent;

    public ServerSoftwareComponent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenServerSoftwareComponent == null) {
        _cacheChildrenServerSoftwareComponent = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenServerSoftwareComponent.add(_2.webShell);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenServerSoftwareComponent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.serverSoftwareComponent");
    }
  }

  public class SoftwareDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSoftwareDiscovery;

    private Set<AttackStep> _cacheParentSoftwareDiscovery;

    public SoftwareDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSoftwareDiscovery == null) {
        _cacheChildrenSoftwareDiscovery = new HashSet<>();
        _cacheChildrenSoftwareDiscovery.add(securitySoftwareDiscovery);
        for (Service _0 : service) {
          _cacheChildrenSoftwareDiscovery.add(_0.attemptExploitationForPrivilegeEscalation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSoftwareDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSoftwareDiscovery == null) {
        _cacheParentSoftwareDiscovery = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentSoftwareDiscovery.add(_1.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSoftwareDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.softwareDiscovery");
    }
  }

  public class SecuritySoftwareDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSecuritySoftwareDiscovery;

    private Set<AttackStep> _cacheParentSecuritySoftwareDiscovery;

    public SecuritySoftwareDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSecuritySoftwareDiscovery == null) {
        _cacheChildrenSecuritySoftwareDiscovery = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenSecuritySoftwareDiscovery.add(_0.attemptExploitationForDefenseEvasion);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSecuritySoftwareDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSecuritySoftwareDiscovery == null) {
        _cacheParentSecuritySoftwareDiscovery = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentSecuritySoftwareDiscovery.add(_1.userRights);
        }
        _cacheParentSecuritySoftwareDiscovery.add(softwareDiscovery);
      }
      for (AttackStep attackStep : _cacheParentSecuritySoftwareDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.securitySoftwareDiscovery");
    }
  }

  public class SystemAccess extends AttackStepMin {
    private Set<AttackStep> _cacheParentSystemAccess;

    public SystemAccess(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemAccess == null) {
        _cacheParentSystemAccess = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentSystemAccess.add(_0.exploitHighVulnerabilityPublicFacingApplication);
        }
        for (Service _1 : service) {
          _cacheParentSystemAccess.add(_1.exploitMediumVulnerabilityPublicFacingApplication);
        }
        for (Service _2 : service) {
          _cacheParentSystemAccess.add(_2.exploitLowVulnerabilityPublicFacingApplication);
        }
      }
      for (AttackStep attackStep : _cacheParentSystemAccess) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemAccess");
    }
  }

  public class SystemInformationDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSystemInformationDiscovery;

    private Set<AttackStep> _cacheParentSystemInformationDiscovery;

    public SystemInformationDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSystemInformationDiscovery == null) {
        _cacheChildrenSystemInformationDiscovery = new HashSet<>();
        _cacheChildrenSystemInformationDiscovery.add(processInjection);
        _cacheChildrenSystemInformationDiscovery.add(systemChecks);
        _cacheChildrenSystemInformationDiscovery.add(systemNetworkConfigurationDiscovery);
        _cacheChildrenSystemInformationDiscovery.add(systemNetworkConnectionsDiscovery);
      }
      for (AttackStep attackStep : _cacheChildrenSystemInformationDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemInformationDiscovery == null) {
        _cacheParentSystemInformationDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSystemInformationDiscovery.add(_0.userRights);
        }
        _cacheParentSystemInformationDiscovery.add(executionPrevention.disable);
        if (OS.this instanceof Windows) {
          _cacheParentSystemInformationDiscovery.add(((asset.Windows) OS.this).windowsManagementInstrumentation);
        }
        if (OS.this instanceof Windows) {
          _cacheParentSystemInformationDiscovery.add(((asset.Windows) OS.this).queryRegistry);
        }
      }
      for (AttackStep attackStep : _cacheParentSystemInformationDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemInformationDiscovery");
    }
  }

  public class SystemNetworkConnectionsDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentSystemNetworkConnectionsDiscovery;

    public SystemNetworkConnectionsDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemNetworkConnectionsDiscovery == null) {
        _cacheParentSystemNetworkConnectionsDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSystemNetworkConnectionsDiscovery.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentSystemNetworkConnectionsDiscovery.add(_1.adminRights);
        }
        _cacheParentSystemNetworkConnectionsDiscovery.add(compromisedDataOrSystem);
        _cacheParentSystemNetworkConnectionsDiscovery.add(systemInformationDiscovery);
      }
      for (AttackStep attackStep : _cacheParentSystemNetworkConnectionsDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemNetworkConnectionsDiscovery");
    }
  }

  public class SystemOwnerOrUserDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSystemOwnerOrUserDiscovery;

    private Set<AttackStep> _cacheParentSystemOwnerOrUserDiscovery;

    public SystemOwnerOrUserDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSystemOwnerOrUserDiscovery == null) {
        _cacheChildrenSystemOwnerOrUserDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenSystemOwnerOrUserDiscovery.add(_0.userInformation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSystemOwnerOrUserDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemOwnerOrUserDiscovery == null) {
        _cacheParentSystemOwnerOrUserDiscovery = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentSystemOwnerOrUserDiscovery.add(_1.userRights);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentSystemOwnerOrUserDiscovery.add(_2.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentSystemOwnerOrUserDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemOwnerOrUserDiscovery");
    }
  }

  public class SystemServices extends AttackStepMin {
    public SystemServices(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemServices");
    }
  }

  public class SystemShutdownOrReboot extends AttackStepMin {
    private Set<AttackStep> _cacheParentSystemShutdownOrReboot;

    public SystemShutdownOrReboot(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemShutdownOrReboot == null) {
        _cacheParentSystemShutdownOrReboot = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSystemShutdownOrReboot.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentSystemShutdownOrReboot.add(_1.adminRights);
        }
        _cacheParentSystemShutdownOrReboot.add(inhibitSystemRecovery);
      }
      for (AttackStep attackStep : _cacheParentSystemShutdownOrReboot) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemShutdownOrReboot");
    }
  }

  public class ProcessInjection extends AttackStepMin {
    private Set<AttackStep> _cacheParentProcessInjection;

    public ProcessInjection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcessInjection == null) {
        _cacheParentProcessInjection = new HashSet<>();
        _cacheParentProcessInjection.add(processDiscovery);
        _cacheParentProcessInjection.add(systemInformationDiscovery);
      }
      for (AttackStep attackStep : _cacheParentProcessInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.processInjection");
    }
  }

  public class AttemptProtocolTunneling extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptProtocolTunneling;

    public AttemptProtocolTunneling(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptProtocolTunneling == null) {
        _cacheChildrenAttemptProtocolTunneling = new HashSet<>();
        _cacheChildrenAttemptProtocolTunneling.add(protocolTunneling);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptProtocolTunneling) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptProtocolTunneling");
    }
  }

  public class ProtocolTunneling extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenProtocolTunneling;

    private Set<AttackStep> _cacheParentProtocolTunneling;

    public ProtocolTunneling(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenProtocolTunneling == null) {
        _cacheChildrenProtocolTunneling = new HashSet<>();
        _cacheChildrenProtocolTunneling.add(dynamicResolution);
        _cacheChildrenProtocolTunneling.add(proxy);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenProtocolTunneling.add(_2.attemptProtocolImpersonation);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenProtocolTunneling) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProtocolTunneling == null) {
        _cacheParentProtocolTunneling = new HashSet<>();
        _cacheParentProtocolTunneling.add(attemptProtocolTunneling);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentProtocolTunneling.add(_5.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (InternalNetwork _8 : _7.internalNetwork) {
              _cacheParentProtocolTunneling.add(_8.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentProtocolTunneling) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.protocolTunneling");
    }
  }

  public class Rootkit extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenRootkit;

    private Set<AttackStep> _cacheParentRootkit;

    public Rootkit(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRootkit == null) {
        _cacheChildrenRootkit = new HashSet<>();
        _cacheChildrenRootkit.add(modifyAPICalls);
        _cacheChildrenRootkit.add(bypassAntivirus);
        _cacheChildrenRootkit.add(bypassFileMonitoring);
        _cacheChildrenRootkit.add(bypassProcessWhitelisting);
        _cacheChildrenRootkit.add(bypassSignatureBasedDetection);
        _cacheChildrenRootkit.add(bypassHostIntrusionPrevention);
        _cacheChildrenRootkit.add(bypassSystemAccessControls);
        _cacheChildrenRootkit.add(bypassFileOrPathWhitelisting);
      }
      for (AttackStep attackStep : _cacheChildrenRootkit) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRootkit == null) {
        _cacheParentRootkit = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentRootkit.add(_0.userRights);
        }
        if (OS.this instanceof Linux) {
          _cacheParentRootkit.add(((asset.Linux) OS.this).kernelModulesAndExtensions);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentRootkit.add(((asset.MacOS) OS.this).kernelModulesAndExtensions);
        }
      }
      for (AttackStep attackStep : _cacheParentRootkit) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.rootkit");
    }
  }

  public class RuntimeDataManipulation extends AttackStepMax {
    private Set<AttackStep> _cacheParentRuntimeDataManipulation;

    public RuntimeDataManipulation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRuntimeDataManipulation == null) {
        _cacheParentRuntimeDataManipulation = new HashSet<>();
        _cacheParentRuntimeDataManipulation.add(dataManipulation);
        _cacheParentRuntimeDataManipulation.add(restrictFileAndDirectoryPermissions.disable);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheParentRuntimeDataManipulation.add(_2.networkSegmentation.disable);
            }
          }
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (ExternalNetwork _5 : _4.externalNetwork) {
              _cacheParentRuntimeDataManipulation.add(_5.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRuntimeDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.runtimeDataManipulation");
    }
  }

  public class AttemptApplicationLayerProtocol extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptApplicationLayerProtocol;

    public AttemptApplicationLayerProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptApplicationLayerProtocol == null) {
        _cacheChildrenAttemptApplicationLayerProtocol = new HashSet<>();
        _cacheChildrenAttemptApplicationLayerProtocol.add(applicationLayerProtocol);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptApplicationLayerProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptApplicationLayerProtocol");
    }
  }

  public class ApplicationLayerProtocol extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenApplicationLayerProtocol;

    private Set<AttackStep> _cacheParentApplicationLayerProtocol;

    public ApplicationLayerProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenApplicationLayerProtocol == null) {
        _cacheChildrenApplicationLayerProtocol = new HashSet<>();
        _cacheChildrenApplicationLayerProtocol.add(webProtocols);
        _cacheChildrenApplicationLayerProtocol.add(fileTransferProtocols);
        _cacheChildrenApplicationLayerProtocol.add(mailProtocols);
        _cacheChildrenApplicationLayerProtocol.add(dNS);
      }
      for (AttackStep attackStep : _cacheChildrenApplicationLayerProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationLayerProtocol == null) {
        _cacheParentApplicationLayerProtocol = new HashSet<>();
        _cacheParentApplicationLayerProtocol.add(attemptApplicationLayerProtocol);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheParentApplicationLayerProtocol.add(_2.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (ExternalNetwork _5 : _4.externalNetwork) {
              _cacheParentApplicationLayerProtocol.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentApplicationLayerProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.applicationLayerProtocol");
    }
  }

  public class AttemptNonApplicationLayerProtocol extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptNonApplicationLayerProtocol;

    public AttemptNonApplicationLayerProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptNonApplicationLayerProtocol == null) {
        _cacheChildrenAttemptNonApplicationLayerProtocol = new HashSet<>();
        _cacheChildrenAttemptNonApplicationLayerProtocol.add(nonApplicationLayerProtocol);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptNonApplicationLayerProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptNonApplicationLayerProtocol");
    }
  }

  public class NonApplicationLayerProtocol extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenNonApplicationLayerProtocol;

    private Set<AttackStep> _cacheParentNonApplicationLayerProtocol;

    public NonApplicationLayerProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNonApplicationLayerProtocol == null) {
        _cacheChildrenNonApplicationLayerProtocol = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenNonApplicationLayerProtocol.add(_2.c2Connected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenNonApplicationLayerProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNonApplicationLayerProtocol == null) {
        _cacheParentNonApplicationLayerProtocol = new HashSet<>();
        _cacheParentNonApplicationLayerProtocol.add(attemptNonApplicationLayerProtocol);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentNonApplicationLayerProtocol.add(_5.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (InternalNetwork _8 : _7.internalNetwork) {
              _cacheParentNonApplicationLayerProtocol.add(_8.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _9 : computer) {
          for (Router _a : _9.router) {
            for (InternalNetwork _b : _a.internalNetwork) {
              _cacheParentNonApplicationLayerProtocol.add(_b.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentNonApplicationLayerProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.nonApplicationLayerProtocol");
    }
  }

  public class WebProtocols extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenWebProtocols;

    private Set<AttackStep> _cacheParentWebProtocols;

    public WebProtocols(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWebProtocols == null) {
        _cacheChildrenWebProtocols = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenWebProtocols.add(_2.c2Connexion);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenWebProtocols) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWebProtocols == null) {
        _cacheParentWebProtocols = new HashSet<>();
        _cacheParentWebProtocols.add(applicationLayerProtocol);
      }
      for (AttackStep attackStep : _cacheParentWebProtocols) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.webProtocols");
    }
  }

  public class FileTransferProtocols extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenFileTransferProtocols;

    private Set<AttackStep> _cacheParentFileTransferProtocols;

    public FileTransferProtocols(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenFileTransferProtocols == null) {
        _cacheChildrenFileTransferProtocols = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenFileTransferProtocols.add(_2.c2Connexion);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenFileTransferProtocols) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFileTransferProtocols == null) {
        _cacheParentFileTransferProtocols = new HashSet<>();
        _cacheParentFileTransferProtocols.add(applicationLayerProtocol);
      }
      for (AttackStep attackStep : _cacheParentFileTransferProtocols) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.fileTransferProtocols");
    }
  }

  public class MailProtocols extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenMailProtocols;

    private Set<AttackStep> _cacheParentMailProtocols;

    public MailProtocols(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMailProtocols == null) {
        _cacheChildrenMailProtocols = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenMailProtocols.add(_2.c2Connexion);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenMailProtocols) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMailProtocols == null) {
        _cacheParentMailProtocols = new HashSet<>();
        _cacheParentMailProtocols.add(applicationLayerProtocol);
      }
      for (AttackStep attackStep : _cacheParentMailProtocols) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.mailProtocols");
    }
  }

  public class DNS extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDNS;

    private Set<AttackStep> _cacheParentDNS;

    public DNS(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDNS == null) {
        _cacheChildrenDNS = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenDNS.add(_2.c2Connexion);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDNS) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDNS == null) {
        _cacheParentDNS = new HashSet<>();
        _cacheParentDNS.add(applicationLayerProtocol);
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentDNS.add(_5.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDNS) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dNS");
    }
  }

  public class SystemNetworkConfigurationDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentSystemNetworkConfigurationDiscovery;

    public SystemNetworkConfigurationDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemNetworkConfigurationDiscovery == null) {
        _cacheParentSystemNetworkConfigurationDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentSystemNetworkConfigurationDiscovery.add(_0.userRights);
        }
        _cacheParentSystemNetworkConfigurationDiscovery.add(systemInformationDiscovery);
      }
      for (AttackStep attackStep : _cacheParentSystemNetworkConfigurationDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemNetworkConfigurationDiscovery");
    }
  }

  public class TwoFactorAuthenticationInterception extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenTwoFactorAuthenticationInterception;

    private Set<AttackStep> _cacheParentTwoFactorAuthenticationInterception;

    public TwoFactorAuthenticationInterception(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenTwoFactorAuthenticationInterception == null) {
        _cacheChildrenTwoFactorAuthenticationInterception = new HashSet<>();
        _cacheChildrenTwoFactorAuthenticationInterception.add(proxy);
      }
      for (AttackStep attackStep : _cacheChildrenTwoFactorAuthenticationInterception) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTwoFactorAuthenticationInterception == null) {
        _cacheParentTwoFactorAuthenticationInterception = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentTwoFactorAuthenticationInterception.add(_0.userTraining.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentTwoFactorAuthenticationInterception.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentTwoFactorAuthenticationInterception) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.twoFactorAuthenticationInterception");
    }
  }

  public class ModifyAPICalls extends AttackStepMin {
    private Set<AttackStep> _cacheParentModifyAPICalls;

    public ModifyAPICalls(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentModifyAPICalls == null) {
        _cacheParentModifyAPICalls = new HashSet<>();
        _cacheParentModifyAPICalls.add(rootkit);
      }
      for (AttackStep attackStep : _cacheParentModifyAPICalls) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.modifyAPICalls");
    }
  }

  public class BypassAntivirus extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassAntivirus;

    public BypassAntivirus(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassAntivirus == null) {
        _cacheParentBypassAntivirus = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentBypassAntivirus.add(_0.exploitationForDefenseEvasion);
        }
        for (Service _1 : service) {
          if (_1 instanceof CloudService) {
            _cacheParentBypassAntivirus.add(((asset.CloudService) _1).cloudAccounts);
          }
        }
        _cacheParentBypassAntivirus.add(binaryPadding);
        _cacheParentBypassAntivirus.add(compileAfterDelivery);
        _cacheParentBypassAntivirus.add(indicatorRemovalFromTools);
        _cacheParentBypassAntivirus.add(disableOrModifyTools);
        _cacheParentBypassAntivirus.add(indicatorBlocking);
        _cacheParentBypassAntivirus.add(rootkit);
        _cacheParentBypassAntivirus.add(defaultAccounts);
        _cacheParentBypassAntivirus.add(domainAccounts);
        _cacheParentBypassAntivirus.add(localAccounts);
        _cacheParentBypassAntivirus.add(systemChecks);
        _cacheParentBypassAntivirus.add(userActivityBasedChecks);
        _cacheParentBypassAntivirus.add(timeBasedEvasion);
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).clearWindowsEventLogs);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).cmstp);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).componentFirmware);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).dynamicLinkLibraryInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).portableExecutableInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).threadExecutionHijacking);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).asynchronousProcedureCall);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).threadLocalStorage);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).deobfuscateOrDecodeFilesOrInformation);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).dLLSideLoading);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).extraWindowMemoryInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).ntfsFileAttributes);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).processDoppelganging);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).processHollowing);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).regsvr32);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).rundll32);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).softwarePacking);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAntivirus.add(((asset.Windows) OS.this).xslScriptProcessing);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassAntivirus.add(((asset.Linux) OS.this).ptraceSystemCalls);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassAntivirus.add(((asset.Linux) OS.this).procMemory);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassAntivirus.add(((asset.Linux) OS.this).vDSOHijacking);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassAntivirus.add(((asset.MacOS) OS.this).gatekeeperBypass);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassAntivirus.add(((asset.MacOS) OS.this).softwarePacking);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassAntivirus) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassAntivirus");
    }
  }

  public class BypassAutorunsAnalysis extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassAutorunsAnalysis;

    public BypassAutorunsAnalysis(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassAutorunsAnalysis == null) {
        _cacheParentBypassAutorunsAnalysis = new HashSet<>();
        if (OS.this instanceof Windows) {
          _cacheParentBypassAutorunsAnalysis.add(((asset.Windows) OS.this).imageFileExecutionOptionsInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassAutorunsAnalysis.add(((asset.Windows) OS.this).sIPAndTrustProviderHijacking);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassAutorunsAnalysis) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassAutorunsAnalysis");
    }
  }

  public class BypassApplicationControl extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassApplicationControl;

    public BypassApplicationControl(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassApplicationControl == null) {
        _cacheParentBypassApplicationControl = new HashSet<>();
        for (Service _0 : service) {
          if (_0 instanceof CloudService) {
            _cacheParentBypassApplicationControl.add(((asset.CloudService) _0).cloudAccounts);
          }
        }
        _cacheParentBypassApplicationControl.add(defaultAccounts);
        _cacheParentBypassApplicationControl.add(domainAccounts);
        _cacheParentBypassApplicationControl.add(localAccounts);
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).controlPanel);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).dynamicLinkLibraryInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).portableExecutableInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).threadExecutionHijacking);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).asynchronousProcedureCall);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).threadLocalStorage);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).mshta);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).extraWindowMemoryInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).processDoppelganging);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).processHollowing);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).codeProxyExecution);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).fileProxyExecution);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationControl.add(((asset.Windows) OS.this).sIPAndTrustProviderHijacking);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassApplicationControl.add(((asset.Linux) OS.this).ptraceSystemCalls);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassApplicationControl.add(((asset.Linux) OS.this).procMemory);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassApplicationControl.add(((asset.Linux) OS.this).vDSOHijacking);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassApplicationControl.add(((asset.MacOS) OS.this).gatekeeperBypass);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassApplicationControl) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassApplicationControl");
    }
  }

  public class BypassApplicationWhitelisting extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassApplicationWhitelisting;

    public BypassApplicationWhitelisting(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassApplicationWhitelisting == null) {
        _cacheParentBypassApplicationWhitelisting = new HashSet<>();
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationWhitelisting.add(((asset.Windows) OS.this).compiledHTMLFile);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationWhitelisting.add(((asset.Windows) OS.this).indirectCommandExecution);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassApplicationWhitelisting.add(((asset.Windows) OS.this).xslScriptProcessing);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassApplicationWhitelisting.add(((asset.MacOS) OS.this).plistModification);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassApplicationWhitelisting) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassApplicationWhitelisting");
    }
  }

  public class BypassBinaryAnalysis extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassBinaryAnalysis;

    public BypassBinaryAnalysis(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassBinaryAnalysis == null) {
        _cacheParentBypassBinaryAnalysis = new HashSet<>();
        _cacheParentBypassBinaryAnalysis.add(compileAfterDelivery);
      }
      for (AttackStep attackStep : _cacheParentBypassBinaryAnalysis) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassBinaryAnalysis");
    }
  }

  public class BypassDefensiveNetworkServiceScanning extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassDefensiveNetworkServiceScanning;

    public BypassDefensiveNetworkServiceScanning(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassDefensiveNetworkServiceScanning == null) {
        _cacheParentBypassDefensiveNetworkServiceScanning = new HashSet<>();
        if (OS.this instanceof Linux) {
          _cacheParentBypassDefensiveNetworkServiceScanning.add(((asset.Linux) OS.this).portKnocking);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassDefensiveNetworkServiceScanning.add(((asset.MacOS) OS.this).portKnocking);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassDefensiveNetworkServiceScanning) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassDefensiveNetworkServiceScanning");
    }
  }

  public class BypassDigitalCertificateValidation extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassDigitalCertificateValidation;

    public BypassDigitalCertificateValidation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassDigitalCertificateValidation == null) {
        _cacheParentBypassDigitalCertificateValidation = new HashSet<>();
        _cacheParentBypassDigitalCertificateValidation.add(installRootCertificate);
        if (OS.this instanceof Windows) {
          _cacheParentBypassDigitalCertificateValidation.add(((asset.Windows) OS.this).compiledHTMLFile);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassDigitalCertificateValidation.add(((asset.Windows) OS.this).mshta);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassDigitalCertificateValidation.add(((asset.Windows) OS.this).codeProxyExecution);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassDigitalCertificateValidation.add(((asset.Windows) OS.this).fileProxyExecution);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassDigitalCertificateValidation.add(((asset.Windows) OS.this).sIPAndTrustProviderHijacking);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassDigitalCertificateValidation.add(((asset.Windows) OS.this).xslScriptProcessing);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassDigitalCertificateValidation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassDigitalCertificateValidation");
    }
  }

  public class BypassEgressFiltering extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassEgressFiltering;

    public BypassEgressFiltering(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassEgressFiltering == null) {
        _cacheParentBypassEgressFiltering = new HashSet<>();
        _cacheParentBypassEgressFiltering.add(dNSCalculation);
      }
      for (AttackStep attackStep : _cacheParentBypassEgressFiltering) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassEgressFiltering");
    }
  }

  public class BypassFileMonitoring extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassFileMonitoring;

    public BypassFileMonitoring(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassFileMonitoring == null) {
        _cacheParentBypassFileMonitoring = new HashSet<>();
        _cacheParentBypassFileMonitoring.add(renameSystemUtilities);
        _cacheParentBypassFileMonitoring.add(disableOrModifyTools);
        _cacheParentBypassFileMonitoring.add(rootkit);
        if (OS.this instanceof Windows) {
          _cacheParentBypassFileMonitoring.add(((asset.Windows) OS.this).componentFirmware);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassFileMonitoring.add(((asset.Windows) OS.this).fileSystemLogicalOffsets);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassFileMonitoring) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassFileMonitoring");
    }
  }

  public class BypassFileOrPathWhitelisting extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassFileOrPathWhitelisting;

    public BypassFileOrPathWhitelisting(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassFileOrPathWhitelisting == null) {
        _cacheParentBypassFileOrPathWhitelisting = new HashSet<>();
        _cacheParentBypassFileOrPathWhitelisting.add(matchLegitimateNameOrLocation);
        _cacheParentBypassFileOrPathWhitelisting.add(rootkit);
        if (OS.this instanceof Windows) {
          _cacheParentBypassFileOrPathWhitelisting.add(((asset.Windows) OS.this).indirectCommandExecution);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassFileOrPathWhitelisting.add(((asset.MacOS) OS.this).plistModification);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassFileOrPathWhitelisting) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassFileOrPathWhitelisting");
    }
  }

  public class BypassFileSystemAccessControls extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassFileSystemAccessControls;

    public BypassFileSystemAccessControls(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassFileSystemAccessControls == null) {
        _cacheParentBypassFileSystemAccessControls = new HashSet<>();
        if (OS.this instanceof Windows) {
          _cacheParentBypassFileSystemAccessControls.add(((asset.Windows) OS.this).fileSystemLogicalOffsets);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassFileSystemAccessControls.add(((asset.Windows) OS.this).groupPolicyModification);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassFileSystemAccessControls) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassFileSystemAccessControls");
    }
  }

  public class BypassHeuristicDetection extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassHeuristicDetection;

    public BypassHeuristicDetection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassHeuristicDetection == null) {
        _cacheParentBypassHeuristicDetection = new HashSet<>();
        if (OS.this instanceof Windows) {
          _cacheParentBypassHeuristicDetection.add(((asset.Windows) OS.this).parentPIDSpoofing);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassHeuristicDetection.add(((asset.Windows) OS.this).softwarePacking);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassHeuristicDetection.add(((asset.MacOS) OS.this).softwarePacking);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassHeuristicDetection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassHeuristicDetection");
    }
  }

  public class BypassHostForensicAnalysis extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassHostForensicAnalysis;

    public BypassHostForensicAnalysis(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassHostForensicAnalysis == null) {
        _cacheParentBypassHostForensicAnalysis = new HashSet<>();
        _cacheParentBypassHostForensicAnalysis.add(hiddenFilesAndDirectories);
        _cacheParentBypassHostForensicAnalysis.add(timestomp);
        _cacheParentBypassHostForensicAnalysis.add(systemChecks);
        _cacheParentBypassHostForensicAnalysis.add(userActivityBasedChecks);
        _cacheParentBypassHostForensicAnalysis.add(timeBasedEvasion);
        _cacheParentBypassHostForensicAnalysis.add(fileDeletion);
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.Windows) OS.this).modifyRegistry);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.Windows) OS.this).networkShareConnectionRemoval);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.Windows) OS.this).ntfsFileAttributes);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.Windows) OS.this).parentPIDSpoofing);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.Linux) OS.this).clearCommandHistory);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.Linux) OS.this).hISTCONTROL);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.MacOS) OS.this).clearCommandHistory);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassHostForensicAnalysis.add(((asset.MacOS) OS.this).hISTCONTROL);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassHostForensicAnalysis) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassHostForensicAnalysis");
    }
  }

  public class BypassHostIntrusionPrevention extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassHostIntrusionPrevention;

    public BypassHostIntrusionPrevention(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassHostIntrusionPrevention == null) {
        _cacheParentBypassHostIntrusionPrevention = new HashSet<>();
        for (Service _0 : service) {
          if (_0 instanceof CloudService) {
            _cacheParentBypassHostIntrusionPrevention.add(((asset.CloudService) _0).cloudAccounts);
          }
        }
        _cacheParentBypassHostIntrusionPrevention.add(compileAfterDelivery);
        _cacheParentBypassHostIntrusionPrevention.add(runVirtualInstance);
        _cacheParentBypassHostIntrusionPrevention.add(indicatorRemovalFromTools);
        _cacheParentBypassHostIntrusionPrevention.add(disableOrModifyTools);
        _cacheParentBypassHostIntrusionPrevention.add(indicatorBlocking);
        _cacheParentBypassHostIntrusionPrevention.add(rootkit);
        _cacheParentBypassHostIntrusionPrevention.add(defaultAccounts);
        _cacheParentBypassHostIntrusionPrevention.add(domainAccounts);
        _cacheParentBypassHostIntrusionPrevention.add(localAccounts);
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostIntrusionPrevention.add(((asset.Windows) OS.this).clearWindowsEventLogs);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostIntrusionPrevention.add(((asset.Windows) OS.this).componentFirmware);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostIntrusionPrevention.add(((asset.Windows) OS.this).deobfuscateOrDecodeFilesOrInformation);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassHostIntrusionPrevention.add(((asset.Windows) OS.this).masqueradeTaskOrService);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassHostIntrusionPrevention.add(((asset.Linux) OS.this).masqueradeTaskOrService);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassHostIntrusionPrevention) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassHostIntrusionPrevention");
    }
  }

  public class BypassProcessWhitelisting extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassProcessWhitelisting;

    public BypassProcessWhitelisting(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassProcessWhitelisting == null) {
        _cacheParentBypassProcessWhitelisting = new HashSet<>();
        _cacheParentBypassProcessWhitelisting.add(rootkit);
        if (OS.this instanceof Windows) {
          _cacheParentBypassProcessWhitelisting.add(((asset.Windows) OS.this).dLLSearchOrderHijacking);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassProcessWhitelisting.add(((asset.Windows) OS.this).dLLSideLoading);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassProcessWhitelisting.add(((asset.Windows) OS.this).indirectCommandExecution);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassProcessWhitelisting.add(((asset.MacOS) OS.this).plistModification);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassProcessWhitelisting) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassProcessWhitelisting");
    }
  }

  public class BypassSystemAccessControls extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassSystemAccessControls;

    public BypassSystemAccessControls(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassSystemAccessControls == null) {
        _cacheParentBypassSystemAccessControls = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentBypassSystemAccessControls.add(_0.exploitationForDefenseEvasion);
        }
        for (Service _1 : service) {
          if (_1 instanceof CloudService) {
            _cacheParentBypassSystemAccessControls.add(((asset.CloudService) _1).cloudAccounts);
          }
        }
        _cacheParentBypassSystemAccessControls.add(rootkit);
        _cacheParentBypassSystemAccessControls.add(defaultAccounts);
        _cacheParentBypassSystemAccessControls.add(domainAccounts);
        _cacheParentBypassSystemAccessControls.add(localAccounts);
        if (OS.this instanceof Windows) {
          _cacheParentBypassSystemAccessControls.add(((asset.Windows) OS.this).groupPolicyModification);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassSystemAccessControls.add(((asset.Windows) OS.this).passTheHash);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassSystemAccessControls) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassSystemAccessControls");
    }
  }

  public class BypassLogAnalysis extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassLogAnalysis;

    public BypassLogAnalysis(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassLogAnalysis == null) {
        _cacheParentBypassLogAnalysis = new HashSet<>();
        _cacheParentBypassLogAnalysis.add(indicatorRemovalFromTools);
        _cacheParentBypassLogAnalysis.add(disableOrModifyTools);
        if (OS.this instanceof Windows) {
          _cacheParentBypassLogAnalysis.add(((asset.Windows) OS.this).clearWindowsEventLogs);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassLogAnalysis.add(((asset.Windows) OS.this).dCShadow);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassLogAnalysis.add(((asset.Windows) OS.this).disableWindowsEventLogging);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassLogAnalysis.add(((asset.Linux) OS.this).clearCommandHistory);
        }
        if (OS.this instanceof Linux) {
          _cacheParentBypassLogAnalysis.add(((asset.Linux) OS.this).hISTCONTROL);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassLogAnalysis.add(((asset.MacOS) OS.this).clearCommandHistory);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassLogAnalysis.add(((asset.MacOS) OS.this).hISTCONTROL);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassLogAnalysis) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassLogAnalysis");
    }
  }

  public class BypassSignatureBasedDetection extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassSignatureBasedDetection;

    public BypassSignatureBasedDetection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassSignatureBasedDetection == null) {
        _cacheParentBypassSignatureBasedDetection = new HashSet<>();
        _cacheParentBypassSignatureBasedDetection.add(binaryPadding);
        _cacheParentBypassSignatureBasedDetection.add(compileAfterDelivery);
        _cacheParentBypassSignatureBasedDetection.add(disableOrModifyTools);
        _cacheParentBypassSignatureBasedDetection.add(rootkit);
        _cacheParentBypassSignatureBasedDetection.add(systemChecks);
        _cacheParentBypassSignatureBasedDetection.add(userActivityBasedChecks);
        _cacheParentBypassSignatureBasedDetection.add(timeBasedEvasion);
        if (OS.this instanceof Windows) {
          _cacheParentBypassSignatureBasedDetection.add(((asset.Windows) OS.this).deobfuscateOrDecodeFilesOrInformation);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassSignatureBasedDetection.add(((asset.Windows) OS.this).ntfsFileAttributes);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassSignatureBasedDetection.add(((asset.Windows) OS.this).softwarePacking);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentBypassSignatureBasedDetection.add(((asset.MacOS) OS.this).softwarePacking);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassSignatureBasedDetection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassSignatureBasedDetection");
    }
  }

  public class BypassStaticFileAnalysis extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassStaticFileAnalysis;

    public BypassStaticFileAnalysis(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassStaticFileAnalysis == null) {
        _cacheParentBypassStaticFileAnalysis = new HashSet<>();
        _cacheParentBypassStaticFileAnalysis.add(compileAfterDelivery);
        _cacheParentBypassStaticFileAnalysis.add(systemChecks);
        _cacheParentBypassStaticFileAnalysis.add(userActivityBasedChecks);
        _cacheParentBypassStaticFileAnalysis.add(timeBasedEvasion);
        if (OS.this instanceof Windows) {
          _cacheParentBypassStaticFileAnalysis.add(((asset.Windows) OS.this).indirectCommandExecution);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBypassStaticFileAnalysis.add(((asset.Windows) OS.this).templateInjection);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassStaticFileAnalysis) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassStaticFileAnalysis");
    }
  }

  public class BypassUserModeSignatureValidation extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassUserModeSignatureValidation;

    public BypassUserModeSignatureValidation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassUserModeSignatureValidation == null) {
        _cacheParentBypassUserModeSignatureValidation = new HashSet<>();
        if (OS.this instanceof Windows) {
          _cacheParentBypassUserModeSignatureValidation.add(((asset.Windows) OS.this).sIPAndTrustProviderHijacking);
        }
      }
      for (AttackStep attackStep : _cacheParentBypassUserModeSignatureValidation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bypassUserModeSignatureValidation");
    }
  }

  public class PasswordPolicyDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenPasswordPolicyDiscovery;

    private Set<AttackStep> _cacheParentPasswordPolicyDiscovery;

    public PasswordPolicyDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPasswordPolicyDiscovery == null) {
        _cacheChildrenPasswordPolicyDiscovery = new HashSet<>();
        _cacheChildrenPasswordPolicyDiscovery.add(bruteForceWithPasswordPolicy);
      }
      for (AttackStep attackStep : _cacheChildrenPasswordPolicyDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPasswordPolicyDiscovery == null) {
        _cacheParentPasswordPolicyDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPasswordPolicyDiscovery.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentPasswordPolicyDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.passwordPolicyDiscovery");
    }
  }

  public class BruteForceWithPasswordPolicy extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenBruteForceWithPasswordPolicy;

    private Set<AttackStep> _cacheParentBruteForceWithPasswordPolicy;

    public BruteForceWithPasswordPolicy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBruteForceWithPasswordPolicy == null) {
        _cacheChildrenBruteForceWithPasswordPolicy = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenBruteForceWithPasswordPolicy.add(_0.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenBruteForceWithPasswordPolicy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBruteForceWithPasswordPolicy == null) {
        _cacheParentBruteForceWithPasswordPolicy = new HashSet<>();
        _cacheParentBruteForceWithPasswordPolicy.add(passwordPolicyDiscovery);
      }
      for (AttackStep attackStep : _cacheParentBruteForceWithPasswordPolicy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bruteForceWithPasswordPolicy");
    }
  }

  public class BruteForce extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenBruteForce;

    private Set<AttackStep> _cacheParentBruteForce;

    public BruteForce(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBruteForce == null) {
        _cacheChildrenBruteForce = new HashSet<>();
        _cacheChildrenBruteForce.add(passwordGuessing);
        _cacheChildrenBruteForce.add(attemptPasswordCracking);
        _cacheChildrenBruteForce.add(passwordSpraying);
        _cacheChildrenBruteForce.add(credentialStuffing);
        _cacheChildrenBruteForce.add(attemptPrivateKeys);
      }
      for (AttackStep attackStep : _cacheChildrenBruteForce) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBruteForce == null) {
        _cacheParentBruteForce = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentBruteForce.add(_0.userRights);
        }
        for (Service _1 : service) {
          _cacheParentBruteForce.add(_1.spearphishingViaSocialMedia);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBruteForce.add(((asset.Windows) OS.this).forcedAuthentication);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBruteForce.add(((asset.Windows) OS.this).kerberoasting);
        }
        if (OS.this instanceof Windows) {
          _cacheParentBruteForce.add(((asset.Windows) OS.this).lLMNR_NBT_NS_PoisoningAndSMBRelay);
        }
      }
      for (AttackStep attackStep : _cacheParentBruteForce) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.bruteForce");
    }
  }

  public class PassTheHash extends AttackStepMax {
    private Set<AttackStep> _cacheParentPassTheHash;

    public PassTheHash(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPassTheHash == null) {
        _cacheParentPassTheHash = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPassTheHash.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentPassTheHash) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.passTheHash");
    }
  }

  public class PassTheTicket extends AttackStepMax {
    private Set<AttackStep> _cacheParentPassTheTicket;

    public PassTheTicket(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPassTheTicket == null) {
        _cacheParentPassTheTicket = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentPassTheTicket.add(_0.userAccountManagement.disable);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentPassTheTicket.add(_1.privilegedAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentPassTheTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.passTheTicket");
    }
  }

  public class PasswordGuessing extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenPasswordGuessing;

    private Set<AttackStep> _cacheParentPasswordGuessing;

    public PasswordGuessing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPasswordGuessing == null) {
        _cacheChildrenPasswordGuessing = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenPasswordGuessing.add(_0.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPasswordGuessing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPasswordGuessing == null) {
        _cacheParentPasswordGuessing = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentPasswordGuessing.add(_1.userRights);
        }
        _cacheParentPasswordGuessing.add(bruteForce);
        _cacheParentPasswordGuessing.add(accountUsePolicies.disable);
        _cacheParentPasswordGuessing.add(multiFactorAuthentication.disable);
        _cacheParentPasswordGuessing.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentPasswordGuessing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.passwordGuessing");
    }
  }

  public class AttemptPasswordCracking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptPasswordCracking;

    private Set<AttackStep> _cacheParentAttemptPasswordCracking;

    public AttemptPasswordCracking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptPasswordCracking == null) {
        _cacheChildrenAttemptPasswordCracking = new HashSet<>();
        _cacheChildrenAttemptPasswordCracking.add(passwordCracking);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPasswordCracking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPasswordCracking == null) {
        _cacheParentAttemptPasswordCracking = new HashSet<>();
        _cacheParentAttemptPasswordCracking.add(collectHashInformation);
        _cacheParentAttemptPasswordCracking.add(bruteForce);
      }
      for (AttackStep attackStep : _cacheParentAttemptPasswordCracking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptPasswordCracking");
    }
  }

  public class PasswordCracking extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenPasswordCracking;

    private Set<AttackStep> _cacheParentPasswordCracking;

    public PasswordCracking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPasswordCracking == null) {
        _cacheChildrenPasswordCracking = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenPasswordCracking.add(_0.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPasswordCracking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPasswordCracking == null) {
        _cacheParentPasswordCracking = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentPasswordCracking.add(_1.userRights);
        }
        _cacheParentPasswordCracking.add(attemptPasswordCracking);
        _cacheParentPasswordCracking.add(multiFactorAuthentication.disable);
        _cacheParentPasswordCracking.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentPasswordCracking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.passwordCracking");
    }
  }

  public class PasswordSpraying extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenPasswordSpraying;

    private Set<AttackStep> _cacheParentPasswordSpraying;

    public PasswordSpraying(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPasswordSpraying == null) {
        _cacheChildrenPasswordSpraying = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenPasswordSpraying.add(_0.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPasswordSpraying) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPasswordSpraying == null) {
        _cacheParentPasswordSpraying = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentPasswordSpraying.add(_1.userRights);
        }
        _cacheParentPasswordSpraying.add(bruteForce);
        _cacheParentPasswordSpraying.add(accountUsePolicies.disable);
        _cacheParentPasswordSpraying.add(multiFactorAuthentication.disable);
        _cacheParentPasswordSpraying.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentPasswordSpraying) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.passwordSpraying");
    }
  }

  public class CredentialStuffing extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCredentialStuffing;

    private Set<AttackStep> _cacheParentCredentialStuffing;

    public CredentialStuffing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCredentialStuffing == null) {
        _cacheChildrenCredentialStuffing = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenCredentialStuffing.add(_0.userCredentials);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCredentialStuffing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialStuffing == null) {
        _cacheParentCredentialStuffing = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentCredentialStuffing.add(_1.userRights);
        }
        for (UserAccount _2 : userAccount) {
          _cacheParentCredentialStuffing.add(_2.userAccountManagement.disable);
        }
        _cacheParentCredentialStuffing.add(bruteForce);
        _cacheParentCredentialStuffing.add(accountUsePolicies.disable);
        _cacheParentCredentialStuffing.add(multiFactorAuthentication.disable);
        _cacheParentCredentialStuffing.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentCredentialStuffing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.credentialStuffing");
    }
  }

  public class PermissionGroupsDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenPermissionGroupsDiscovery;

    public PermissionGroupsDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPermissionGroupsDiscovery == null) {
        _cacheChildrenPermissionGroupsDiscovery = new HashSet<>();
        _cacheChildrenPermissionGroupsDiscovery.add(localGroups);
        _cacheChildrenPermissionGroupsDiscovery.add(domainGroups);
        for (Service _0 : service) {
          _cacheChildrenPermissionGroupsDiscovery.add(_0.cloudGroups);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPermissionGroupsDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.permissionGroupsDiscovery");
    }
  }

  public class LocalGroups extends AttackStepMax {
    private Set<AttackStep> _cacheParentLocalGroups;

    public LocalGroups(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLocalGroups == null) {
        _cacheParentLocalGroups = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentLocalGroups.add(_0.userRights);
        }
        _cacheParentLocalGroups.add(permissionGroupsDiscovery);
      }
      for (AttackStep attackStep : _cacheParentLocalGroups) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.localGroups");
    }
  }

  public class DomainGroups extends AttackStepMax {
    private Set<AttackStep> _cacheParentDomainGroups;

    public DomainGroups(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainGroups == null) {
        _cacheParentDomainGroups = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDomainGroups.add(_0.userRights);
        }
        _cacheParentDomainGroups.add(permissionGroupsDiscovery);
      }
      for (AttackStep attackStep : _cacheParentDomainGroups) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainGroups");
    }
  }

  public class PreOSBoot extends AttackStepMin {
    public PreOSBoot(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.preOSBoot");
    }
  }

  public class AttemptAntivirusCheck extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptAntivirusCheck;

    public AttemptAntivirusCheck(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptAntivirusCheck == null) {
        _cacheChildrenAttemptAntivirusCheck = new HashSet<>();
        _cacheChildrenAttemptAntivirusCheck.add(antivirusCheck);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptAntivirusCheck) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptAntivirusCheck");
    }
  }

  public class AntivirusCheck extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenAntivirusCheck;

    private Set<AttackStep> _cacheParentAntivirusCheck;

    public AntivirusCheck(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAntivirusCheck == null) {
        _cacheChildrenAntivirusCheck = new HashSet<>();
        _cacheChildrenAntivirusCheck.add(executeCode);
        for (Service _0 : service) {
          _cacheChildrenAntivirusCheck.add(_0.attemptExploitationForClientExecution);
        }
      }
      for (AttackStep attackStep : _cacheChildrenAntivirusCheck) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAntivirusCheck == null) {
        _cacheParentAntivirusCheck = new HashSet<>();
        _cacheParentAntivirusCheck.add(attemptAntivirusCheck);
        _cacheParentAntivirusCheck.add(antivirus.disable);
      }
      for (AttackStep attackStep : _cacheParentAntivirusCheck) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.antivirusCheck");
    }
  }

  public class Persistence extends AttackStepMin {
    private Set<AttackStep> _cacheParentPersistence;

    public Persistence(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPersistence == null) {
        _cacheParentPersistence = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentPersistence.add(_0.implantContainerImage);
        }
        for (Service _1 : service) {
          if (_1 instanceof CloudService) {
            _cacheParentPersistence.add(((asset.CloudService) _1).cloudAccount);
          }
        }
        for (Service _2 : service) {
          if (_2 instanceof CloudService) {
            _cacheParentPersistence.add(((asset.CloudService) _2).officeTemplateMacros);
          }
        }
        for (Service _3 : service) {
          if (_3 instanceof CloudService) {
            _cacheParentPersistence.add(((asset.CloudService) _3).officeTest);
          }
        }
        for (Service _4 : service) {
          if (_4 instanceof CloudService) {
            _cacheParentPersistence.add(((asset.CloudService) _4).outlookForms);
          }
        }
        for (Service _5 : service) {
          if (_5 instanceof CloudService) {
            _cacheParentPersistence.add(((asset.CloudService) _5).outlookHomePage);
          }
        }
        for (Service _6 : service) {
          if (_6 instanceof CloudService) {
            _cacheParentPersistence.add(((asset.CloudService) _6).outlookRules);
          }
        }
        for (Service _7 : service) {
          if (_7 instanceof CloudService) {
            _cacheParentPersistence.add(((asset.CloudService) _7).addIns);
          }
        }
        for (Service _8 : service) {
          for (Browser _9 : _8.browser) {
            _cacheParentPersistence.add(_9.browserExtensions);
          }
        }
        _cacheParentPersistence.add(accountManipulation);
        _cacheParentPersistence.add(domainAccount);
        _cacheParentPersistence.add(localAccount);
        _cacheParentPersistence.add(hiddenFilesAndDirectories);
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).appInitDLLs);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).accessibilityFeatures);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).bITSJobs);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).componentObjectModelHijacking);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).cOR_PROFILER);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).lSASSDriver);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).fileSystemPermissionsWeakness);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).kerberoasting);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).modifyRegistry);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).netshHelperDLL);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).windowsService);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).pathInterceptionByUnquotedPath);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).servicesFilePermissionsWeakness);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).servicesRegistryPermissionsWeakness);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).sQLStoredProcedures);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).transportAgent);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).powerShell);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).powerShellUserProfile);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).powerShellAdminProfile);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).registryRunKeysOrStartupFolder);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).screensaver);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).securitySupportProvider);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).shortcutModification);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).sIDHistoryInjection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).timeProviders);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).scheduledTask);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).windowsManagementInstrumentationEventSubscription);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).winlogonHelperDLL);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).portMonitors);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).applicationShimming);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).authenticationPackage);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).changeDefaultFileAssociation);
        }
        if (OS.this instanceof Windows) {
          _cacheParentPersistence.add(((asset.Windows) OS.this).bootkit);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).bootkit);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).cron);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).bash_profileAndBashrc);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).setuidAndSetgid);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).sSHAuthorizedKeys);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).sQLStoredProcedures);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).systemdService);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).transportAgent);
        }
        if (OS.this instanceof Linux) {
          _cacheParentPersistence.add(((asset.Linux) OS.this).trap);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).bash_profileAndBashrc);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).cron);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).elevatedExecutionWithPrompt);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).emond);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).launchAgent);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).launchd);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).launchDaemon);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).lC_LOAD_DYLIB_Addition);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).plistModification);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).rc_common);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).reopenedApplications);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).setuidAndSetgid);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).sSHAuthorizedKeys);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).trap);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentPersistence.add(((asset.MacOS) OS.this).startupItems);
        }
      }
      for (AttackStep attackStep : _cacheParentPersistence) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.persistence");
    }
  }

  public class SSHCredentialInterception extends AttackStepMin {
    private Set<AttackStep> _cacheParentSSHCredentialInterception;

    public SSHCredentialInterception(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSSHCredentialInterception == null) {
        _cacheParentSSHCredentialInterception = new HashSet<>();
        if (OS.this instanceof Linux) {
          _cacheParentSSHCredentialInterception.add(((asset.Linux) OS.this).sSHHijacking);
        }
        if (OS.this instanceof MacOS) {
          _cacheParentSSHCredentialInterception.add(((asset.MacOS) OS.this).sSHHijacking);
        }
      }
      for (AttackStep attackStep : _cacheParentSSHCredentialInterception) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sSHCredentialInterception");
    }
  }

  public class StoredDataManipulation extends AttackStepMax {
    private Set<AttackStep> _cacheParentStoredDataManipulation;

    public StoredDataManipulation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentStoredDataManipulation == null) {
        _cacheParentStoredDataManipulation = new HashSet<>();
        _cacheParentStoredDataManipulation.add(dataManipulation);
        _cacheParentStoredDataManipulation.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentStoredDataManipulation.add(encryptSensitiveInformation.disable);
        _cacheParentStoredDataManipulation.add(remoteDataStorage.disable);
      }
      for (AttackStep attackStep : _cacheParentStoredDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.storedDataManipulation");
    }
  }

  public class NonStandardPort extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenNonStandardPort;

    private Set<AttackStep> _cacheParentNonStandardPort;

    public NonStandardPort(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNonStandardPort == null) {
        _cacheChildrenNonStandardPort = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenNonStandardPort.add(_2.c2Connected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenNonStandardPort) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNonStandardPort == null) {
        _cacheParentNonStandardPort = new HashSet<>();
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentNonStandardPort.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (InternalNetwork _8 : _7.internalNetwork) {
              _cacheParentNonStandardPort.add(_8.networkSegmentation.disable);
            }
          }
        }
        for (Computer _9 : computer) {
          for (Router _a : _9.router) {
            for (ExternalNetwork _b : _a.externalNetwork) {
              _cacheParentNonStandardPort.add(_b.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _c : computer) {
          for (Router _d : _c.router) {
            for (ExternalNetwork _e : _d.externalNetwork) {
              _cacheParentNonStandardPort.add(_e.networkSegmentation.disable);
            }
          }
        }
        for (Computer _f : computer) {
          for (Router _10 : _f.router) {
            if (_10.firewall != null) {
              _cacheParentNonStandardPort.add(_10.firewall.networkSegmentation.disable);
            }
          }
        }
        for (Computer _11 : computer) {
          _cacheParentNonStandardPort.add(_11.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentNonStandardPort) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.nonStandardPort");
    }
  }

  public class SubvertTrustControls extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSubvertTrustControls;

    public SubvertTrustControls(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSubvertTrustControls == null) {
        _cacheChildrenSubvertTrustControls = new HashSet<>();
        _cacheChildrenSubvertTrustControls.add(installRootCertificate);
      }
      for (AttackStep attackStep : _cacheChildrenSubvertTrustControls) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.subvertTrustControls");
    }
  }

  public class InstallRootCertificate extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenInstallRootCertificate;

    private Set<AttackStep> _cacheParentInstallRootCertificate;

    public InstallRootCertificate(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInstallRootCertificate == null) {
        _cacheChildrenInstallRootCertificate = new HashSet<>();
        _cacheChildrenInstallRootCertificate.add(bypassDigitalCertificateValidation);
      }
      for (AttackStep attackStep : _cacheChildrenInstallRootCertificate) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInstallRootCertificate == null) {
        _cacheParentInstallRootCertificate = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentInstallRootCertificate.add(_0.userRights);
        }
        _cacheParentInstallRootCertificate.add(subvertTrustControls);
        _cacheParentInstallRootCertificate.add(operatingSystemConfiguration.disable);
        _cacheParentInstallRootCertificate.add(softwareConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentInstallRootCertificate) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.installRootCertificate");
    }
  }

  public class UnsecuredCredentials extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenUnsecuredCredentials;

    public UnsecuredCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUnsecuredCredentials == null) {
        _cacheChildrenUnsecuredCredentials = new HashSet<>();
        _cacheChildrenUnsecuredCredentials.add(credentialsInFiles);
        _cacheChildrenUnsecuredCredentials.add(privateKeys);
        for (Service _0 : service) {
          _cacheChildrenUnsecuredCredentials.add(_0.cloudInstanceMetadataAPI);
        }
      }
      for (AttackStep attackStep : _cacheChildrenUnsecuredCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.unsecuredCredentials");
    }
  }

  public class AttemptCredentialsInFiles extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptCredentialsInFiles;

    private Set<AttackStep> _cacheParentAttemptCredentialsInFiles;

    public AttemptCredentialsInFiles(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptCredentialsInFiles == null) {
        _cacheChildrenAttemptCredentialsInFiles = new HashSet<>();
        _cacheChildrenAttemptCredentialsInFiles.add(credentialsInFiles);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptCredentialsInFiles) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptCredentialsInFiles == null) {
        _cacheParentAttemptCredentialsInFiles = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptCredentialsInFiles.add(_0.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptCredentialsInFiles) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptCredentialsInFiles");
    }
  }

  public class CredentialsInFiles extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCredentialsInFiles;

    private Set<AttackStep> _cacheParentCredentialsInFiles;

    public CredentialsInFiles(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCredentialsInFiles == null) {
        _cacheChildrenCredentialsInFiles = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheChildrenCredentialsInFiles.add(_0.userCredentials);
        }
        for (Service _1 : service) {
          for (Browser _2 : _1.browser) {
            _cacheChildrenCredentialsInFiles.add(_2.browserBookmarkDiscovery);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCredentialsInFiles) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialsInFiles == null) {
        _cacheParentCredentialsInFiles = new HashSet<>();
        for (UserAccount _3 : userAccount) {
          _cacheParentCredentialsInFiles.add(_3.userRights);
        }
        for (UserAccount _4 : userAccount) {
          _cacheParentCredentialsInFiles.add(_4.userTraining.disable);
        }
        _cacheParentCredentialsInFiles.add(unsecuredCredentials);
        _cacheParentCredentialsInFiles.add(attemptCredentialsInFiles);
        _cacheParentCredentialsInFiles.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentCredentialsInFiles.add(passwordPolicies.disable);
        _cacheParentCredentialsInFiles.add(activeDirectoryConfiguration.disable);
        _cacheParentCredentialsInFiles.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentCredentialsInFiles) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.credentialsInFiles");
    }
  }

  public class ValidAccounts extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenValidAccounts;

    private Set<AttackStep> _cacheParentValidAccounts;

    public ValidAccounts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenValidAccounts == null) {
        _cacheChildrenValidAccounts = new HashSet<>();
        _cacheChildrenValidAccounts.add(defaultAccounts);
        _cacheChildrenValidAccounts.add(attemptDomainAccounts);
        _cacheChildrenValidAccounts.add(attemptLocalAccounts);
        for (Service _0 : service) {
          _cacheChildrenValidAccounts.add(_0.cloudAccounts);
        }
      }
      for (AttackStep attackStep : _cacheChildrenValidAccounts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentValidAccounts == null) {
        _cacheParentValidAccounts = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentValidAccounts.add(_1.userCredentials);
        }
        for (AdminAccount _2 : adminAccount) {
          _cacheParentValidAccounts.add(_2.adminCredentials);
        }
        for (Service _3 : service) {
          if (_3 instanceof ThirdpartySoftware) {
            _cacheParentValidAccounts.add(((asset.ThirdpartySoftware) _3).trustedRelationship);
          }
        }
        _cacheParentValidAccounts.add(webPortalCapture);
        _cacheParentValidAccounts.add(dataEncryptedForImpact);
        if (OS.this instanceof Windows) {
          _cacheParentValidAccounts.add(((asset.Windows) OS.this).kerberoasting);
        }
        for (Computer _4 : computer) {
          _cacheParentValidAccounts.add(_4.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentValidAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.validAccounts");
    }
  }

  public class DefaultAccounts extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDefaultAccounts;

    private Set<AttackStep> _cacheParentDefaultAccounts;

    public DefaultAccounts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDefaultAccounts == null) {
        _cacheChildrenDefaultAccounts = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenDefaultAccounts.add(_0.remoteServices);
        }
        for (Service _1 : service) {
          _cacheChildrenDefaultAccounts.add(_1.attemptExternalRemoteServices);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheChildrenDefaultAccounts.add(_4.bypassNetworkIntrusionDetection);
            }
          }
        }
        for (Computer _5 : computer) {
          for (Router _6 : _5.router) {
            if (_6.firewall != null) {
              _cacheChildrenDefaultAccounts.add(_6.firewall.bypassFirewall);
            }
          }
        }
        _cacheChildrenDefaultAccounts.add(bypassHostIntrusionPrevention);
        _cacheChildrenDefaultAccounts.add(bypassApplicationControl);
        _cacheChildrenDefaultAccounts.add(bypassSystemAccessControls);
        _cacheChildrenDefaultAccounts.add(bypassAntivirus);
      }
      for (AttackStep attackStep : _cacheChildrenDefaultAccounts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDefaultAccounts == null) {
        _cacheParentDefaultAccounts = new HashSet<>();
        for (UserAccount _7 : userAccount) {
          _cacheParentDefaultAccounts.add(_7.userRights);
        }
        _cacheParentDefaultAccounts.add(validAccounts);
        _cacheParentDefaultAccounts.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentDefaultAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.defaultAccounts");
    }
  }

  public class AttemptDomainAccounts extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDomainAccounts;

    private Set<AttackStep> _cacheParentAttemptDomainAccounts;

    public AttemptDomainAccounts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDomainAccounts == null) {
        _cacheChildrenAttemptDomainAccounts = new HashSet<>();
        _cacheChildrenAttemptDomainAccounts.add(domainAccounts);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDomainAccounts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDomainAccounts == null) {
        _cacheParentAttemptDomainAccounts = new HashSet<>();
        _cacheParentAttemptDomainAccounts.add(validAccounts);
        if (OS.this instanceof Windows) {
          _cacheParentAttemptDomainAccounts.add(((asset.Windows) OS.this).cachedDomainCredentials);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptDomainAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptDomainAccounts");
    }
  }

  public class DomainAccounts extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDomainAccounts;

    private Set<AttackStep> _cacheParentDomainAccounts;

    public DomainAccounts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDomainAccounts == null) {
        _cacheChildrenDomainAccounts = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenDomainAccounts.add(_0.remoteServices);
        }
        for (Service _1 : service) {
          _cacheChildrenDomainAccounts.add(_1.attemptExternalRemoteServices);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheChildrenDomainAccounts.add(_4.bypassNetworkIntrusionDetection);
            }
          }
        }
        for (Computer _5 : computer) {
          for (Router _6 : _5.router) {
            if (_6.firewall != null) {
              _cacheChildrenDomainAccounts.add(_6.firewall.bypassFirewall);
            }
          }
        }
        _cacheChildrenDomainAccounts.add(bypassHostIntrusionPrevention);
        _cacheChildrenDomainAccounts.add(bypassApplicationControl);
        _cacheChildrenDomainAccounts.add(bypassSystemAccessControls);
        _cacheChildrenDomainAccounts.add(bypassAntivirus);
      }
      for (AttackStep attackStep : _cacheChildrenDomainAccounts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainAccounts == null) {
        _cacheParentDomainAccounts = new HashSet<>();
        for (UserAccount _7 : userAccount) {
          _cacheParentDomainAccounts.add(_7.userRights);
        }
        _cacheParentDomainAccounts.add(attemptDomainAccounts);
        _cacheParentDomainAccounts.add(multiFactorAuthentication.disable);
        _cacheParentDomainAccounts.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentDomainAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.domainAccounts");
    }
  }

  public class AttemptLocalAccounts extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptLocalAccounts;

    private Set<AttackStep> _cacheParentAttemptLocalAccounts;

    public AttemptLocalAccounts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptLocalAccounts == null) {
        _cacheChildrenAttemptLocalAccounts = new HashSet<>();
        _cacheChildrenAttemptLocalAccounts.add(localAccounts);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLocalAccounts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLocalAccounts == null) {
        _cacheParentAttemptLocalAccounts = new HashSet<>();
        _cacheParentAttemptLocalAccounts.add(validAccounts);
        if (OS.this instanceof Windows) {
          _cacheParentAttemptLocalAccounts.add(((asset.Windows) OS.this).securityAccountManager);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptLocalAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptLocalAccounts");
    }
  }

  public class LocalAccounts extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenLocalAccounts;

    private Set<AttackStep> _cacheParentLocalAccounts;

    public LocalAccounts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLocalAccounts == null) {
        _cacheChildrenLocalAccounts = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenLocalAccounts.add(_0.remoteServices);
        }
        for (Service _1 : service) {
          _cacheChildrenLocalAccounts.add(_1.attemptExternalRemoteServices);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheChildrenLocalAccounts.add(_4.bypassNetworkIntrusionDetection);
            }
          }
        }
        for (Computer _5 : computer) {
          for (Router _6 : _5.router) {
            if (_6.firewall != null) {
              _cacheChildrenLocalAccounts.add(_6.firewall.bypassFirewall);
            }
          }
        }
        _cacheChildrenLocalAccounts.add(bypassHostIntrusionPrevention);
        _cacheChildrenLocalAccounts.add(bypassApplicationControl);
        _cacheChildrenLocalAccounts.add(bypassSystemAccessControls);
        _cacheChildrenLocalAccounts.add(bypassAntivirus);
      }
      for (AttackStep attackStep : _cacheChildrenLocalAccounts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLocalAccounts == null) {
        _cacheParentLocalAccounts = new HashSet<>();
        for (UserAccount _7 : userAccount) {
          _cacheParentLocalAccounts.add(_7.userRights);
        }
        _cacheParentLocalAccounts.add(attemptLocalAccounts);
        _cacheParentLocalAccounts.add(passwordPolicies.disable);
        _cacheParentLocalAccounts.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentLocalAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.localAccounts");
    }
  }

  public class VirtualizationOrSandboxEvasion extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenVirtualizationOrSandboxEvasion;

    public VirtualizationOrSandboxEvasion(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenVirtualizationOrSandboxEvasion == null) {
        _cacheChildrenVirtualizationOrSandboxEvasion = new HashSet<>();
        _cacheChildrenVirtualizationOrSandboxEvasion.add(systemChecks);
        _cacheChildrenVirtualizationOrSandboxEvasion.add(userActivityBasedChecks);
        _cacheChildrenVirtualizationOrSandboxEvasion.add(timeBasedEvasion);
      }
      for (AttackStep attackStep : _cacheChildrenVirtualizationOrSandboxEvasion) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.virtualizationOrSandboxEvasion");
    }
  }

  public class SystemChecks extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSystemChecks;

    private Set<AttackStep> _cacheParentSystemChecks;

    public SystemChecks(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSystemChecks == null) {
        _cacheChildrenSystemChecks = new HashSet<>();
        _cacheChildrenSystemChecks.add(bypassAntivirus);
        _cacheChildrenSystemChecks.add(bypassHostForensicAnalysis);
        _cacheChildrenSystemChecks.add(bypassSignatureBasedDetection);
        _cacheChildrenSystemChecks.add(bypassStaticFileAnalysis);
      }
      for (AttackStep attackStep : _cacheChildrenSystemChecks) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemChecks == null) {
        _cacheParentSystemChecks = new HashSet<>();
        _cacheParentSystemChecks.add(systemInformationDiscovery);
        _cacheParentSystemChecks.add(virtualizationOrSandboxEvasion);
        if (OS.this instanceof Windows) {
          _cacheParentSystemChecks.add(((asset.Windows) OS.this).powerShell);
        }
        if (OS.this instanceof Windows) {
          _cacheParentSystemChecks.add(((asset.Windows) OS.this).windowsManagementInstrumentation);
        }
        if (OS.this instanceof Windows) {
          _cacheParentSystemChecks.add(((asset.Windows) OS.this).queryRegistry);
        }
      }
      for (AttackStep attackStep : _cacheParentSystemChecks) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.systemChecks");
    }
  }

  public class UserActivityBasedChecks extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenUserActivityBasedChecks;

    private Set<AttackStep> _cacheParentUserActivityBasedChecks;

    public UserActivityBasedChecks(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUserActivityBasedChecks == null) {
        _cacheChildrenUserActivityBasedChecks = new HashSet<>();
        _cacheChildrenUserActivityBasedChecks.add(bypassAntivirus);
        _cacheChildrenUserActivityBasedChecks.add(bypassHostForensicAnalysis);
        _cacheChildrenUserActivityBasedChecks.add(bypassSignatureBasedDetection);
        _cacheChildrenUserActivityBasedChecks.add(bypassStaticFileAnalysis);
      }
      for (AttackStep attackStep : _cacheChildrenUserActivityBasedChecks) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUserActivityBasedChecks == null) {
        _cacheParentUserActivityBasedChecks = new HashSet<>();
        _cacheParentUserActivityBasedChecks.add(virtualizationOrSandboxEvasion);
      }
      for (AttackStep attackStep : _cacheParentUserActivityBasedChecks) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.userActivityBasedChecks");
    }
  }

  public class TimeBasedEvasion extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenTimeBasedEvasion;

    private Set<AttackStep> _cacheParentTimeBasedEvasion;

    public TimeBasedEvasion(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenTimeBasedEvasion == null) {
        _cacheChildrenTimeBasedEvasion = new HashSet<>();
        _cacheChildrenTimeBasedEvasion.add(scheduledTaskOrJob);
        _cacheChildrenTimeBasedEvasion.add(attemptMultiStageChannels);
        _cacheChildrenTimeBasedEvasion.add(bypassAntivirus);
        _cacheChildrenTimeBasedEvasion.add(bypassHostForensicAnalysis);
        _cacheChildrenTimeBasedEvasion.add(bypassSignatureBasedDetection);
        _cacheChildrenTimeBasedEvasion.add(bypassStaticFileAnalysis);
      }
      for (AttackStep attackStep : _cacheChildrenTimeBasedEvasion) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTimeBasedEvasion == null) {
        _cacheParentTimeBasedEvasion = new HashSet<>();
        _cacheParentTimeBasedEvasion.add(virtualizationOrSandboxEvasion);
      }
      for (AttackStep attackStep : _cacheParentTimeBasedEvasion) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.timeBasedEvasion");
    }
  }

  public class VNC extends AttackStepMax {
    private Set<AttackStep> _cacheParentVNC;

    public VNC(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentVNC == null) {
        _cacheParentVNC = new HashSet<>();
        for (Service _0 : service) {
          _cacheParentVNC.add(_0.remoteServices);
        }
        _cacheParentVNC.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentVNC.add(audit.disable);
        _cacheParentVNC.add(limitSoftwareInstallation.disable);
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheParentVNC.add(_3.filterNetworkTraffic.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentVNC) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.vNC");
    }
  }

  public class FileDeletion extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenFileDeletion;

    private Set<AttackStep> _cacheParentFileDeletion;

    public FileDeletion(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenFileDeletion == null) {
        _cacheChildrenFileDeletion = new HashSet<>();
        _cacheChildrenFileDeletion.add(bypassHostForensicAnalysis);
      }
      for (AttackStep attackStep : _cacheChildrenFileDeletion) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFileDeletion == null) {
        _cacheParentFileDeletion = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentFileDeletion.add(_0.userRights);
        }
        _cacheParentFileDeletion.add(indicatorRemovalOnHost);
        for (Computer _1 : computer) {
          _cacheParentFileDeletion.add(_1.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentFileDeletion) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.fileDeletion");
    }
  }

  public class FileAndDirectoryDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenFileAndDirectoryDiscovery;

    private Set<AttackStep> _cacheParentFileAndDirectoryDiscovery;

    public FileAndDirectoryDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenFileAndDirectoryDiscovery == null) {
        _cacheChildrenFileAndDirectoryDiscovery = new HashSet<>();
        _cacheChildrenFileAndDirectoryDiscovery.add(attemptAutomatedCollection);
      }
      for (AttackStep attackStep : _cacheChildrenFileAndDirectoryDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFileAndDirectoryDiscovery == null) {
        _cacheParentFileAndDirectoryDiscovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentFileAndDirectoryDiscovery.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentFileAndDirectoryDiscovery.add(_1.adminRights);
        }
      }
      for (AttackStep attackStep : _cacheParentFileAndDirectoryDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.fileAndDirectoryDiscovery");
    }
  }

  public class DiskWipe extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDiskWipe;

    private Set<AttackStep> _cacheParentDiskWipe;

    public DiskWipe(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDiskWipe == null) {
        _cacheChildrenDiskWipe = new HashSet<>();
        _cacheChildrenDiskWipe.add(diskContentWipe);
        _cacheChildrenDiskWipe.add(diskStructureWipe);
      }
      for (AttackStep attackStep : _cacheChildrenDiskWipe) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDiskWipe == null) {
        _cacheParentDiskWipe = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDiskWipe.add(_0.userRights);
        }
      }
      for (AttackStep attackStep : _cacheParentDiskWipe) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.diskWipe");
    }
  }

  public class DiskContentWipe extends AttackStepMax {
    private Set<AttackStep> _cacheParentDiskContentWipe;

    public DiskContentWipe(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDiskContentWipe == null) {
        _cacheParentDiskContentWipe = new HashSet<>();
        _cacheParentDiskContentWipe.add(diskWipe);
        _cacheParentDiskContentWipe.add(dataBackup.disable);
      }
      for (AttackStep attackStep : _cacheParentDiskContentWipe) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.diskContentWipe");
    }
  }

  public class DiskStructureWipe extends AttackStepMax {
    private Set<AttackStep> _cacheParentDiskStructureWipe;

    public DiskStructureWipe(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDiskStructureWipe == null) {
        _cacheParentDiskStructureWipe = new HashSet<>();
        _cacheParentDiskStructureWipe.add(diskWipe);
        _cacheParentDiskStructureWipe.add(dataBackup.disable);
      }
      for (AttackStep attackStep : _cacheParentDiskStructureWipe) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.diskStructureWipe");
    }
  }

  public class RemoteFileCopy extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenRemoteFileCopy;

    private Set<AttackStep> _cacheParentRemoteFileCopy;

    public RemoteFileCopy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRemoteFileCopy == null) {
        _cacheChildrenRemoteFileCopy = new HashSet<>();
        for (Computer _0 : computer) {
          for (User _1 : _0.user) {
            _cacheChildrenRemoteFileCopy.add(_1.attemptUserExecution);
          }
        }
        _cacheChildrenRemoteFileCopy.add(attemptAutomatedCollection);
      }
      for (AttackStep attackStep : _cacheChildrenRemoteFileCopy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteFileCopy == null) {
        _cacheParentRemoteFileCopy = new HashSet<>();
        for (UserAccount _2 : userAccount) {
          _cacheParentRemoteFileCopy.add(_2.userRights);
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentRemoteFileCopy.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (ExternalNetwork _8 : _7.externalNetwork) {
              _cacheParentRemoteFileCopy.add(_8.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteFileCopy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.remoteFileCopy");
    }
  }

  public class SensitiveDataCollected extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSensitiveDataCollected;

    private Set<AttackStep> _cacheParentSensitiveDataCollected;

    public SensitiveDataCollected(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSensitiveDataCollected == null) {
        _cacheChildrenSensitiveDataCollected = new HashSet<>();
        _cacheChildrenSensitiveDataCollected.add(dataCompressed);
        for (Computer _0 : computer) {
          _cacheChildrenSensitiveDataCollected.add(_0.attemptExfiltrationOverPhysicalMedium);
        }
        _cacheChildrenSensitiveDataCollected.add(dataSizedTransfer);
        _cacheChildrenSensitiveDataCollected.add(attemptExfiltrationOverAternativeProtocol);
        _cacheChildrenSensitiveDataCollected.add(scheduledExfiltration);
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheChildrenSensitiveDataCollected.add(_3.attemptExfiltrationOverC2Channel);
            }
          }
        }
        _cacheChildrenSensitiveDataCollected.add(automatedExfiltration);
        _cacheChildrenSensitiveDataCollected.add(dataEncrypted);
        _cacheChildrenSensitiveDataCollected.add(dataStaged);
      }
      for (AttackStep attackStep : _cacheChildrenSensitiveDataCollected) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSensitiveDataCollected == null) {
        _cacheParentSensitiveDataCollected = new HashSet<>();
        for (Service _4 : service) {
          _cacheParentSensitiveDataCollected.add(_4.informationRepositories);
        }
        for (Service _5 : service) {
          for (Browser _6 : _5.browser) {
            _cacheParentSensitiveDataCollected.add(_6.webSessionCookie);
          }
        }
        _cacheParentSensitiveDataCollected.add(automatedCollection);
        if (OS.this instanceof Windows) {
          _cacheParentSensitiveDataCollected.add(((asset.Windows) OS.this).localEmailCollection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentSensitiveDataCollected.add(((asset.Windows) OS.this).remoteEmailCollection);
        }
        if (OS.this instanceof Windows) {
          _cacheParentSensitiveDataCollected.add(((asset.Windows) OS.this).emailForwardingRule);
        }
        for (Computer _7 : computer) {
          for (Router _8 : _7.router) {
            for (InternalNetwork _9 : _8.internalNetwork) {
              if (_9 instanceof NetworkSharedDrive) {
                _cacheParentSensitiveDataCollected.add(((asset.NetworkSharedDrive) _9).dataFromNetworkSharedDrive);
              }
            }
          }
        }
        for (Computer _a : computer) {
          for (PeripheralDevice _b : _a.peripheralDevice) {
            if (_b instanceof RemovableMedia) {
              _cacheParentSensitiveDataCollected.add(((asset.RemovableMedia) _b).dataFromRemovableMedia);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentSensitiveDataCollected) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sensitiveDataCollected");
    }
  }

  public class DataCollected extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataCollected;

    private Set<AttackStep> _cacheParentDataCollected;

    public DataCollected(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataCollected == null) {
        _cacheChildrenDataCollected = new HashSet<>();
        _cacheChildrenDataCollected.add(dataCompressed);
        for (Computer _0 : computer) {
          _cacheChildrenDataCollected.add(_0.attemptExfiltrationOverPhysicalMedium);
        }
        _cacheChildrenDataCollected.add(attemptExfiltrationOverAternativeProtocol);
        _cacheChildrenDataCollected.add(scheduledExfiltration);
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheChildrenDataCollected.add(_3.attemptExfiltrationOverC2Channel);
            }
          }
        }
        _cacheChildrenDataCollected.add(dataEncrypted);
        _cacheChildrenDataCollected.add(dataStaged);
        _cacheChildrenDataCollected.add(automatedExfiltration);
        _cacheChildrenDataCollected.add(dataSizedTransfer);
      }
      for (AttackStep attackStep : _cacheChildrenDataCollected) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataCollected == null) {
        _cacheParentDataCollected = new HashSet<>();
        for (Service _4 : service) {
          _cacheParentDataCollected.add(_4.informationRepositories);
        }
        _cacheParentDataCollected.add(screenCapture);
        _cacheParentDataCollected.add(automatedCollection);
        for (Computer _5 : computer) {
          for (Router _6 : _5.router) {
            for (InternalNetwork _7 : _6.internalNetwork) {
              _cacheParentDataCollected.add(_7.exchangeServerCollection);
            }
          }
        }
        for (Computer _8 : computer) {
          _cacheParentDataCollected.add(_8.collectAudio);
        }
        for (Computer _9 : computer) {
          _cacheParentDataCollected.add(_9.collectVideo);
        }
      }
      for (AttackStep attackStep : _cacheParentDataCollected) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataCollected");
    }
  }

  public class DataEncrypted extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataEncrypted;

    private Set<AttackStep> _cacheParentDataEncrypted;

    public DataEncrypted(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataEncrypted == null) {
        _cacheChildrenDataEncrypted = new HashSet<>();
        for (Computer _0 : computer) {
          _cacheChildrenDataEncrypted.add(_0.attemptExfiltrationOverPhysicalMedium);
        }
        _cacheChildrenDataEncrypted.add(attemptExfiltrationOverAternativeProtocol);
        _cacheChildrenDataEncrypted.add(scheduledExfiltration);
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheChildrenDataEncrypted.add(_3.attemptExfiltrationOverC2Channel);
            }
          }
        }
        _cacheChildrenDataEncrypted.add(automatedExfiltration);
      }
      for (AttackStep attackStep : _cacheChildrenDataEncrypted) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataEncrypted == null) {
        _cacheParentDataEncrypted = new HashSet<>();
        _cacheParentDataEncrypted.add(archiveViaUtility);
        _cacheParentDataEncrypted.add(archiveViaLibrary);
        _cacheParentDataEncrypted.add(archiveViaCustomMethod);
        _cacheParentDataEncrypted.add(sensitiveDataCollected);
        _cacheParentDataEncrypted.add(dataCollected);
        _cacheParentDataEncrypted.add(localDataStaging);
        _cacheParentDataEncrypted.add(remoteDataStaging);
        _cacheParentDataEncrypted.add(dataCompressed);
      }
      for (AttackStep attackStep : _cacheParentDataEncrypted) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataEncrypted");
    }
  }

  public class DataSizedTransfer extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataSizedTransfer;

    private Set<AttackStep> _cacheParentDataSizedTransfer;

    public DataSizedTransfer(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataSizedTransfer == null) {
        _cacheChildrenDataSizedTransfer = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenDataSizedTransfer.add(_2.dataExfiltration);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDataSizedTransfer) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataSizedTransfer == null) {
        _cacheParentDataSizedTransfer = new HashSet<>();
        _cacheParentDataSizedTransfer.add(sensitiveDataCollected);
        _cacheParentDataSizedTransfer.add(dataCollected);
      }
      for (AttackStep attackStep : _cacheParentDataSizedTransfer) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataSizedTransfer");
    }
  }

  public class DataStaged extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataStaged;

    private Set<AttackStep> _cacheParentDataStaged;

    public DataStaged(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataStaged == null) {
        _cacheChildrenDataStaged = new HashSet<>();
        _cacheChildrenDataStaged.add(localDataStaging);
        _cacheChildrenDataStaged.add(remoteDataStaging);
      }
      for (AttackStep attackStep : _cacheChildrenDataStaged) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataStaged == null) {
        _cacheParentDataStaged = new HashSet<>();
        _cacheParentDataStaged.add(sensitiveDataCollected);
        _cacheParentDataStaged.add(dataCollected);
      }
      for (AttackStep attackStep : _cacheParentDataStaged) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataStaged");
    }
  }

  public class LocalDataStaging extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenLocalDataStaging;

    private Set<AttackStep> _cacheParentLocalDataStaging;

    public LocalDataStaging(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLocalDataStaging == null) {
        _cacheChildrenLocalDataStaging = new HashSet<>();
        _cacheChildrenLocalDataStaging.add(archiveCollectedData);
        for (Computer _0 : computer) {
          _cacheChildrenLocalDataStaging.add(_0.attemptExfiltrationOverPhysicalMedium);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheChildrenLocalDataStaging.add(_3.attemptExfiltrationOverC2Channel);
            }
          }
        }
        _cacheChildrenLocalDataStaging.add(attemptExfiltrationOverAternativeProtocol);
        _cacheChildrenLocalDataStaging.add(scheduledExfiltration);
        _cacheChildrenLocalDataStaging.add(dataCompressed);
        _cacheChildrenLocalDataStaging.add(dataEncrypted);
      }
      for (AttackStep attackStep : _cacheChildrenLocalDataStaging) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLocalDataStaging == null) {
        _cacheParentLocalDataStaging = new HashSet<>();
        _cacheParentLocalDataStaging.add(dataStaged);
      }
      for (AttackStep attackStep : _cacheParentLocalDataStaging) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.localDataStaging");
    }
  }

  public class ReplicationThroughRemovableMedia extends AttackStepMax {
    private Set<AttackStep> _cacheParentReplicationThroughRemovableMedia;

    public ReplicationThroughRemovableMedia(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentReplicationThroughRemovableMedia == null) {
        _cacheParentReplicationThroughRemovableMedia = new HashSet<>();
        for (Computer _0 : computer) {
          for (User _1 : _0.user) {
            _cacheParentReplicationThroughRemovableMedia.add(_1.mediaInserted);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentReplicationThroughRemovableMedia) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.replicationThroughRemovableMedia");
    }
  }

  public class RemoteDataStaging extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenRemoteDataStaging;

    private Set<AttackStep> _cacheParentRemoteDataStaging;

    public RemoteDataStaging(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRemoteDataStaging == null) {
        _cacheChildrenRemoteDataStaging = new HashSet<>();
        _cacheChildrenRemoteDataStaging.add(archiveCollectedData);
        for (Computer _0 : computer) {
          _cacheChildrenRemoteDataStaging.add(_0.attemptExfiltrationOverPhysicalMedium);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheChildrenRemoteDataStaging.add(_3.attemptExfiltrationOverC2Channel);
            }
          }
        }
        _cacheChildrenRemoteDataStaging.add(attemptExfiltrationOverAternativeProtocol);
        _cacheChildrenRemoteDataStaging.add(scheduledExfiltration);
        _cacheChildrenRemoteDataStaging.add(dataCompressed);
        _cacheChildrenRemoteDataStaging.add(dataEncrypted);
      }
      for (AttackStep attackStep : _cacheChildrenRemoteDataStaging) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteDataStaging == null) {
        _cacheParentRemoteDataStaging = new HashSet<>();
        for (Service _4 : service) {
          if (_4 instanceof CloudService) {
            _cacheParentRemoteDataStaging.add(((asset.CloudService) _4).createCloudInstance);
          }
        }
        _cacheParentRemoteDataStaging.add(dataStaged);
      }
      for (AttackStep attackStep : _cacheParentRemoteDataStaging) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.remoteDataStaging");
    }
  }

  public class AttemptDataDestruction extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDataDestruction;

    private Set<AttackStep> _cacheParentAttemptDataDestruction;

    public AttemptDataDestruction(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDataDestruction == null) {
        _cacheChildrenAttemptDataDestruction = new HashSet<>();
        _cacheChildrenAttemptDataDestruction.add(dataDestruction);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDataDestruction) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDataDestruction == null) {
        _cacheParentAttemptDataDestruction = new HashSet<>();
        for (AdminAccount _0 : adminAccount) {
          _cacheParentAttemptDataDestruction.add(_0.adminRights);
        }
        if (OS.this instanceof Windows) {
          _cacheParentAttemptDataDestruction.add(((asset.Windows) OS.this).serviceStop);
        }
        if (OS.this instanceof Windows) {
          _cacheParentAttemptDataDestruction.add(((asset.Windows) OS.this).systemFirmware);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptDataDestruction) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptDataDestruction");
    }
  }

  public class DataDestruction extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDataDestruction;

    private Set<AttackStep> _cacheParentDataDestruction;

    public DataDestruction(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataDestruction == null) {
        _cacheChildrenDataDestruction = new HashSet<>();
        _cacheChildrenDataDestruction.add(inhibitSystemRecovery);
      }
      for (AttackStep attackStep : _cacheChildrenDataDestruction) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataDestruction == null) {
        _cacheParentDataDestruction = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDataDestruction.add(_0.userRights);
        }
        _cacheParentDataDestruction.add(attemptDataDestruction);
        _cacheParentDataDestruction.add(dataBackup.disable);
      }
      for (AttackStep attackStep : _cacheParentDataDestruction) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataDestruction");
    }
  }

  public class AttemptDataEncryptedForImpact extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDataEncryptedForImpact;

    private Set<AttackStep> _cacheParentAttemptDataEncryptedForImpact;

    public AttemptDataEncryptedForImpact(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDataEncryptedForImpact == null) {
        _cacheChildrenAttemptDataEncryptedForImpact = new HashSet<>();
        _cacheChildrenAttemptDataEncryptedForImpact.add(dataEncryptedForImpact);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDataEncryptedForImpact) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDataEncryptedForImpact == null) {
        _cacheParentAttemptDataEncryptedForImpact = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptDataEncryptedForImpact.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAttemptDataEncryptedForImpact.add(_1.adminRights);
        }
        if (OS.this instanceof Windows) {
          _cacheParentAttemptDataEncryptedForImpact.add(((asset.Windows) OS.this).serviceStop);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptDataEncryptedForImpact) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptDataEncryptedForImpact");
    }
  }

  public class DataEncryptedForImpact extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDataEncryptedForImpact;

    private Set<AttackStep> _cacheParentDataEncryptedForImpact;

    public DataEncryptedForImpact(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataEncryptedForImpact == null) {
        _cacheChildrenDataEncryptedForImpact = new HashSet<>();
        _cacheChildrenDataEncryptedForImpact.add(validAccounts);
        _cacheChildrenDataEncryptedForImpact.add(oSCredentialDumping);
        _cacheChildrenDataEncryptedForImpact.add(inhibitSystemRecovery);
      }
      for (AttackStep attackStep : _cacheChildrenDataEncryptedForImpact) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataEncryptedForImpact == null) {
        _cacheParentDataEncryptedForImpact = new HashSet<>();
        _cacheParentDataEncryptedForImpact.add(attemptDataEncryptedForImpact);
        _cacheParentDataEncryptedForImpact.add(dataBackup.disable);
      }
      for (AttackStep attackStep : _cacheParentDataEncryptedForImpact) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataEncryptedForImpact");
    }
  }

  public class DataCompressed extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDataCompressed;

    private Set<AttackStep> _cacheParentDataCompressed;

    public DataCompressed(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataCompressed == null) {
        _cacheChildrenDataCompressed = new HashSet<>();
        _cacheChildrenDataCompressed.add(dataEncrypted);
        _cacheChildrenDataCompressed.add(automatedExfiltration);
        for (Computer _0 : computer) {
          _cacheChildrenDataCompressed.add(_0.attemptExfiltrationOverPhysicalMedium);
        }
        for (Computer _1 : computer) {
          for (Router _2 : _1.router) {
            for (InternalNetwork _3 : _2.internalNetwork) {
              _cacheChildrenDataCompressed.add(_3.attemptExfiltrationOverC2Channel);
            }
          }
        }
        _cacheChildrenDataCompressed.add(scheduledExfiltration);
      }
      for (AttackStep attackStep : _cacheChildrenDataCompressed) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataCompressed == null) {
        _cacheParentDataCompressed = new HashSet<>();
        _cacheParentDataCompressed.add(archiveViaUtility);
        _cacheParentDataCompressed.add(archiveViaLibrary);
        _cacheParentDataCompressed.add(archiveViaCustomMethod);
        _cacheParentDataCompressed.add(sensitiveDataCollected);
        _cacheParentDataCompressed.add(dataCollected);
        _cacheParentDataCompressed.add(localDataStaging);
        _cacheParentDataCompressed.add(remoteDataStaging);
        _cacheParentDataCompressed.add(executionPrevention.disable);
        for (Computer _4 : computer) {
          for (Router _5 : _4.router) {
            for (InternalNetwork _6 : _5.internalNetwork) {
              _cacheParentDataCompressed.add(_6.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDataCompressed) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataCompressed");
    }
  }

  public class InhibitSystemRecovery extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenInhibitSystemRecovery;

    private Set<AttackStep> _cacheParentInhibitSystemRecovery;

    public InhibitSystemRecovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInhibitSystemRecovery == null) {
        _cacheChildrenInhibitSystemRecovery = new HashSet<>();
        _cacheChildrenInhibitSystemRecovery.add(systemShutdownOrReboot);
      }
      for (AttackStep attackStep : _cacheChildrenInhibitSystemRecovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInhibitSystemRecovery == null) {
        _cacheParentInhibitSystemRecovery = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentInhibitSystemRecovery.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentInhibitSystemRecovery.add(_1.adminRights);
        }
        _cacheParentInhibitSystemRecovery.add(dataDestruction);
        _cacheParentInhibitSystemRecovery.add(dataEncryptedForImpact);
        _cacheParentInhibitSystemRecovery.add(dataBackup.disable);
        _cacheParentInhibitSystemRecovery.add(operatingSystemConfiguration.disable);
        if (OS.this instanceof Windows) {
          _cacheParentInhibitSystemRecovery.add(((asset.Windows) OS.this).windowsManagementInstrumentation);
        }
      }
      for (AttackStep attackStep : _cacheParentInhibitSystemRecovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.inhibitSystemRecovery");
    }
  }

  public class ScreenCapture extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenScreenCapture;

    private Set<AttackStep> _cacheParentScreenCapture;

    public ScreenCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenScreenCapture == null) {
        _cacheChildrenScreenCapture = new HashSet<>();
        _cacheChildrenScreenCapture.add(dataCollected);
      }
      for (AttackStep attackStep : _cacheChildrenScreenCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentScreenCapture == null) {
        _cacheParentScreenCapture = new HashSet<>();
        _cacheParentScreenCapture.add(commandAndScriptingInterpreter);
        for (Computer _0 : computer) {
          _cacheParentScreenCapture.add(_0.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentScreenCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.screenCapture");
    }
  }

  public class ScheduledExfiltration extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenScheduledExfiltration;

    private Set<AttackStep> _cacheParentScheduledExfiltration;

    public ScheduledExfiltration(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenScheduledExfiltration == null) {
        _cacheChildrenScheduledExfiltration = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenScheduledExfiltration.add(_2.dataExfiltration);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenScheduledExfiltration) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentScheduledExfiltration == null) {
        _cacheParentScheduledExfiltration = new HashSet<>();
        _cacheParentScheduledExfiltration.add(sensitiveDataCollected);
        _cacheParentScheduledExfiltration.add(dataCollected);
        _cacheParentScheduledExfiltration.add(dataEncrypted);
        _cacheParentScheduledExfiltration.add(localDataStaging);
        _cacheParentScheduledExfiltration.add(remoteDataStaging);
        _cacheParentScheduledExfiltration.add(dataCompressed);
      }
      for (AttackStep attackStep : _cacheParentScheduledExfiltration) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.scheduledExfiltration");
    }
  }

  public class AttemptExfiltrationOverAternativeProtocol extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExfiltrationOverAternativeProtocol;

    private Set<AttackStep> _cacheParentAttemptExfiltrationOverAternativeProtocol;

    public AttemptExfiltrationOverAternativeProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExfiltrationOverAternativeProtocol == null) {
        _cacheChildrenAttemptExfiltrationOverAternativeProtocol = new HashSet<>();
        _cacheChildrenAttemptExfiltrationOverAternativeProtocol.add(exfiltrationOverAternativeProtocol);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExfiltrationOverAternativeProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExfiltrationOverAternativeProtocol == null) {
        _cacheParentAttemptExfiltrationOverAternativeProtocol = new HashSet<>();
        _cacheParentAttemptExfiltrationOverAternativeProtocol.add(sensitiveDataCollected);
        _cacheParentAttemptExfiltrationOverAternativeProtocol.add(dataCollected);
        _cacheParentAttemptExfiltrationOverAternativeProtocol.add(dataEncrypted);
        _cacheParentAttemptExfiltrationOverAternativeProtocol.add(localDataStaging);
        _cacheParentAttemptExfiltrationOverAternativeProtocol.add(remoteDataStaging);
        _cacheParentAttemptExfiltrationOverAternativeProtocol.add(automatedExfiltration);
        if (OS.this instanceof Windows) {
          _cacheParentAttemptExfiltrationOverAternativeProtocol.add(((asset.Windows) OS.this).bITSJobs);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExfiltrationOverAternativeProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptExfiltrationOverAternativeProtocol");
    }
  }

  public class ExfiltrationOverAternativeProtocol extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExfiltrationOverAternativeProtocol;

    private Set<AttackStep> _cacheParentExfiltrationOverAternativeProtocol;

    public ExfiltrationOverAternativeProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverAternativeProtocol == null) {
        _cacheChildrenExfiltrationOverAternativeProtocol = new HashSet<>();
        _cacheChildrenExfiltrationOverAternativeProtocol.add(exfiltrationOverAsymmetricEncryptedNonC2Protocol);
        _cacheChildrenExfiltrationOverAternativeProtocol.add(exfiltrationOverSymmetricEncryptedNonC2Protocol);
        _cacheChildrenExfiltrationOverAternativeProtocol.add(exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol);
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverAternativeProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverAternativeProtocol == null) {
        _cacheParentExfiltrationOverAternativeProtocol = new HashSet<>();
        _cacheParentExfiltrationOverAternativeProtocol.add(attemptExfiltrationOverAternativeProtocol);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheParentExfiltrationOverAternativeProtocol.add(_2.filterNetworkTraffic.disable);
            }
          }
        }
        for (Computer _3 : computer) {
          for (Router _4 : _3.router) {
            for (InternalNetwork _5 : _4.internalNetwork) {
              _cacheParentExfiltrationOverAternativeProtocol.add(_5.networkIntrusionPrevention.disable);
            }
          }
        }
        for (Computer _6 : computer) {
          for (Router _7 : _6.router) {
            for (InternalNetwork _8 : _7.internalNetwork) {
              _cacheParentExfiltrationOverAternativeProtocol.add(_8.networkSegmentation.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverAternativeProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.exfiltrationOverAternativeProtocol");
    }
  }

  public class ExfiltrationOverAsymmetricEncryptedNonC2Protocol extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExfiltrationOverAsymmetricEncryptedNonC2Protocol;

    private Set<AttackStep> _cacheParentExfiltrationOverAsymmetricEncryptedNonC2Protocol;

    public ExfiltrationOverAsymmetricEncryptedNonC2Protocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverAsymmetricEncryptedNonC2Protocol == null) {
        _cacheChildrenExfiltrationOverAsymmetricEncryptedNonC2Protocol = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenExfiltrationOverAsymmetricEncryptedNonC2Protocol.add(_2.dataExfiltration);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverAsymmetricEncryptedNonC2Protocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverAsymmetricEncryptedNonC2Protocol == null) {
        _cacheParentExfiltrationOverAsymmetricEncryptedNonC2Protocol = new HashSet<>();
        _cacheParentExfiltrationOverAsymmetricEncryptedNonC2Protocol.add(exfiltrationOverAternativeProtocol);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverAsymmetricEncryptedNonC2Protocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.exfiltrationOverAsymmetricEncryptedNonC2Protocol");
    }
  }

  public class ExfiltrationOverSymmetricEncryptedNonC2Protocol extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExfiltrationOverSymmetricEncryptedNonC2Protocol;

    private Set<AttackStep> _cacheParentExfiltrationOverSymmetricEncryptedNonC2Protocol;

    public ExfiltrationOverSymmetricEncryptedNonC2Protocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverSymmetricEncryptedNonC2Protocol == null) {
        _cacheChildrenExfiltrationOverSymmetricEncryptedNonC2Protocol = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenExfiltrationOverSymmetricEncryptedNonC2Protocol.add(_2.dataExfiltration);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverSymmetricEncryptedNonC2Protocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverSymmetricEncryptedNonC2Protocol == null) {
        _cacheParentExfiltrationOverSymmetricEncryptedNonC2Protocol = new HashSet<>();
        _cacheParentExfiltrationOverSymmetricEncryptedNonC2Protocol.add(exfiltrationOverAternativeProtocol);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverSymmetricEncryptedNonC2Protocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.exfiltrationOverSymmetricEncryptedNonC2Protocol");
    }
  }

  public class ExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol;

    private Set<AttackStep> _cacheParentExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol;

    public ExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol == null) {
        _cacheChildrenExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol = new HashSet<>();
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol.add(_2.dataExfiltration);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol == null) {
        _cacheParentExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol = new HashSet<>();
        _cacheParentExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol.add(exfiltrationOverAternativeProtocol);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverUnencryptedOrObfuscatedNonC2Protocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.exfiltrationOverUnencryptedOrObfuscatedNonC2Protocol");
    }
  }

  public class DataFromInformationRepositories extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDataFromInformationRepositories;

    private Set<AttackStep> _cacheParentDataFromInformationRepositories;

    public DataFromInformationRepositories(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataFromInformationRepositories == null) {
        _cacheChildrenDataFromInformationRepositories = new HashSet<>();
        _cacheChildrenDataFromInformationRepositories.add(confluence);
        _cacheChildrenDataFromInformationRepositories.add(sharepoint);
      }
      for (AttackStep attackStep : _cacheChildrenDataFromInformationRepositories) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataFromInformationRepositories == null) {
        _cacheParentDataFromInformationRepositories = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentDataFromInformationRepositories.add(_0.userRights);
        }
        _cacheParentDataFromInformationRepositories.add(infectedOS);
      }
      for (AttackStep attackStep : _cacheParentDataFromInformationRepositories) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.dataFromInformationRepositories");
    }
  }

  public class Confluence extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenConfluence;

    private Set<AttackStep> _cacheParentConfluence;

    public Confluence(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenConfluence == null) {
        _cacheChildrenConfluence = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenConfluence.add(_0.informationRepositories);
        }
      }
      for (AttackStep attackStep : _cacheChildrenConfluence) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentConfluence == null) {
        _cacheParentConfluence = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentConfluence.add(_1.userTraining.disable);
        }
        for (UserAccount _2 : userAccount) {
          _cacheParentConfluence.add(_2.userAccountManagement.disable);
        }
        _cacheParentConfluence.add(dataFromInformationRepositories);
        _cacheParentConfluence.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentConfluence) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.confluence");
    }
  }

  public class Sharepoint extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSharepoint;

    private Set<AttackStep> _cacheParentSharepoint;

    public Sharepoint(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSharepoint == null) {
        _cacheChildrenSharepoint = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenSharepoint.add(_0.informationRepositories);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSharepoint) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSharepoint == null) {
        _cacheParentSharepoint = new HashSet<>();
        for (UserAccount _1 : userAccount) {
          _cacheParentSharepoint.add(_1.userTraining.disable);
        }
        for (UserAccount _2 : userAccount) {
          _cacheParentSharepoint.add(_2.userAccountManagement.disable);
        }
        _cacheParentSharepoint.add(dataFromInformationRepositories);
        _cacheParentSharepoint.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentSharepoint) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.sharepoint");
    }
  }

  public class WindowsService extends AttackStepMax {
    private Set<AttackStep> _cacheParentWindowsService;

    public WindowsService(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsService == null) {
        _cacheParentWindowsService = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentWindowsService.add(_0.userAccountManagement.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentWindowsService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.windowsService");
    }
  }

  public class AttemptAutomatedCollection extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptAutomatedCollection;

    private Set<AttackStep> _cacheParentAttemptAutomatedCollection;

    public AttemptAutomatedCollection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptAutomatedCollection == null) {
        _cacheChildrenAttemptAutomatedCollection = new HashSet<>();
        _cacheChildrenAttemptAutomatedCollection.add(automatedCollection);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptAutomatedCollection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptAutomatedCollection == null) {
        _cacheParentAttemptAutomatedCollection = new HashSet<>();
        for (UserAccount _0 : userAccount) {
          _cacheParentAttemptAutomatedCollection.add(_0.userRights);
        }
        for (AdminAccount _1 : adminAccount) {
          _cacheParentAttemptAutomatedCollection.add(_1.adminRights);
        }
        _cacheParentAttemptAutomatedCollection.add(dataFromLocalSystem);
        _cacheParentAttemptAutomatedCollection.add(fileAndDirectoryDiscovery);
        _cacheParentAttemptAutomatedCollection.add(remoteFileCopy);
      }
      for (AttackStep attackStep : _cacheParentAttemptAutomatedCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.attemptAutomatedCollection");
    }
  }

  public class AutomatedCollection extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenAutomatedCollection;

    private Set<AttackStep> _cacheParentAutomatedCollection;

    public AutomatedCollection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAutomatedCollection == null) {
        _cacheChildrenAutomatedCollection = new HashSet<>();
        _cacheChildrenAutomatedCollection.add(dataCollected);
        _cacheChildrenAutomatedCollection.add(sensitiveDataCollected);
      }
      for (AttackStep attackStep : _cacheChildrenAutomatedCollection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAutomatedCollection == null) {
        _cacheParentAutomatedCollection = new HashSet<>();
        _cacheParentAutomatedCollection.add(attemptAutomatedCollection);
        _cacheParentAutomatedCollection.add(remoteDataStorage.disable);
      }
      for (AttackStep attackStep : _cacheParentAutomatedCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.automatedCollection");
    }
  }

  public class AutomatedExfiltration extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAutomatedExfiltration;

    private Set<AttackStep> _cacheParentAutomatedExfiltration;

    public AutomatedExfiltration(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAutomatedExfiltration == null) {
        _cacheChildrenAutomatedExfiltration = new HashSet<>();
        _cacheChildrenAutomatedExfiltration.add(attemptExfiltrationOverAternativeProtocol);
        for (Computer _0 : computer) {
          for (Router _1 : _0.router) {
            for (InternalNetwork _2 : _1.internalNetwork) {
              _cacheChildrenAutomatedExfiltration.add(_2.attemptExfiltrationOverC2Channel);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenAutomatedExfiltration) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAutomatedExfiltration == null) {
        _cacheParentAutomatedExfiltration = new HashSet<>();
        _cacheParentAutomatedExfiltration.add(sensitiveDataCollected);
        _cacheParentAutomatedExfiltration.add(dataCollected);
        _cacheParentAutomatedExfiltration.add(dataEncrypted);
        _cacheParentAutomatedExfiltration.add(dataCompressed);
      }
      for (AttackStep attackStep : _cacheParentAutomatedExfiltration) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.automatedExfiltration");
    }
  }

  public class NetworkServiceScan extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenNetworkServiceScan;

    private Set<AttackStep> _cacheParentNetworkServiceScan;

    public NetworkServiceScan(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNetworkServiceScan == null) {
        _cacheChildrenNetworkServiceScan = new HashSet<>();
        for (Service _0 : service) {
          _cacheChildrenNetworkServiceScan.add(_0.attemptExploitationOfRemoteServices);
        }
      }
      for (AttackStep attackStep : _cacheChildrenNetworkServiceScan) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkServiceScan == null) {
        _cacheParentNetworkServiceScan = new HashSet<>();
        for (AdminAccount _1 : adminAccount) {
          _cacheParentNetworkServiceScan.add(_1.adminRights);
        }
        for (Computer _2 : computer) {
          for (Router _3 : _2.router) {
            for (InternalNetwork _4 : _3.internalNetwork) {
              _cacheParentNetworkServiceScan.add(_4.executionPrevention.disable);
            }
          }
        }
        for (Computer _5 : computer) {
          for (Router _6 : _5.router) {
            for (InternalNetwork _7 : _6.internalNetwork) {
              _cacheParentNetworkServiceScan.add(_7.networkIntrusionPrevention.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentNetworkServiceScan) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("OS.networkServiceScan");
    }
  }

  public class Antivirus extends Defense {
    public Antivirus(String name) {
      this(name, false);
    }

    public Antivirus(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenAntivirus;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenAntivirus == null) {
          _cacheChildrenAntivirus = new HashSet<>();
          _cacheChildrenAntivirus.add(antivirusCheck);
          _cacheChildrenAntivirus.add(commandAndScriptingInterpreter);
          _cacheChildrenAntivirus.add(visualBasic);
          _cacheChildrenAntivirus.add(python);
          for (Service _0 : service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenAntivirus.add(_1.spearphishingAttachment);
            }
          }
          for (Service _2 : service) {
            for (Browser _3 : _2.browser) {
              _cacheChildrenAntivirus.add(_3.spearphishingLink);
            }
          }
          for (Service _4 : service) {
            _cacheChildrenAntivirus.add(_4.spearphishingViaService);
          }
        }
        for (AttackStep attackStep : _cacheChildrenAntivirus) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.antivirus";
      }
    }
  }

  public class RestrictFileAndDirectoryPermissions extends Defense {
    public RestrictFileAndDirectoryPermissions(String name) {
      this(name, false);
    }

    public RestrictFileAndDirectoryPermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenRestrictFileAndDirectoryPermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenRestrictFileAndDirectoryPermissions == null) {
          _cacheChildrenRestrictFileAndDirectoryPermissions = new HashSet<>();
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(credentialsInFiles);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(disableOrModifyTools);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(disableOrModifySystemFirewall);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(indicatorRemovalOnHost);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(matchLegitimateNameOrLocation);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(privateKeys);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(renameSystemUtilities);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(runtimeDataManipulation);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(storedDataManipulation);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(visualBasic);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(javaScriptOrJScript);
          for (Computer _0 : computer) {
            for (Router _1 : _0.router) {
              for (ExternalNetwork _2 : _1.externalNetwork) {
                _cacheChildrenRestrictFileAndDirectoryPermissions.add(_2.dataFromCloudStorageObject);
              }
            }
          }
          for (Computer _3 : computer) {
            for (Router _4 : _3.router) {
              for (InternalNetwork _5 : _4.internalNetwork) {
                _cacheChildrenRestrictFileAndDirectoryPermissions.add(_5.taintSharedContent);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenRestrictFileAndDirectoryPermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.restrictFileAndDirectoryPermissions";
      }
    }
  }

  public class RestrictRegistryPermissions extends Defense {
    public RestrictRegistryPermissions(String name) {
      this(name, false);
    }

    public RestrictRegistryPermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenRestrictRegistryPermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenRestrictRegistryPermissions == null) {
          _cacheChildrenRestrictRegistryPermissions = new HashSet<>();
          _cacheChildrenRestrictRegistryPermissions.add(disableOrModifyTools);
          _cacheChildrenRestrictRegistryPermissions.add(disableOrModifySystemFirewall);
        }
        for (AttackStep attackStep : _cacheChildrenRestrictRegistryPermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.restrictRegistryPermissions";
      }
    }
  }

  public class AccountUsePolicies extends Defense {
    public AccountUsePolicies(String name) {
      this(name, false);
    }

    public AccountUsePolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenAccountUsePolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenAccountUsePolicies == null) {
          _cacheChildrenAccountUsePolicies = new HashSet<>();
          _cacheChildrenAccountUsePolicies.add(passwordGuessing);
          _cacheChildrenAccountUsePolicies.add(passwordSpraying);
          _cacheChildrenAccountUsePolicies.add(credentialStuffing);
        }
        for (AttackStep attackStep : _cacheChildrenAccountUsePolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.accountUsePolicies";
      }
    }
  }

  public class BehaviorPreventionOnEndpoint extends Defense {
    public BehaviorPreventionOnEndpoint(String name) {
      this(name, false);
    }

    public BehaviorPreventionOnEndpoint(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      public Disable(String name) {
        super(name);
      }

      @Override
      public String fullName() {
        return "OS.behaviorPreventionOnEndpoint";
      }
    }
  }

  public class BootIntegrity extends Defense {
    public BootIntegrity(String name) {
      this(name, false);
    }

    public BootIntegrity(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenBootIntegrity;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenBootIntegrity == null) {
          _cacheChildrenBootIntegrity = new HashSet<>();
          _cacheChildrenBootIntegrity.add(firmwareCorruption);
          for (Service _0 : service) {
            _cacheChildrenBootIntegrity.add(_0.compromiseHardwareSupplyChain);
          }
        }
        for (AttackStep attackStep : _cacheChildrenBootIntegrity) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.bootIntegrity";
      }
    }
  }

  public class DataBackup extends Defense {
    public DataBackup(String name) {
      this(name, false);
    }

    public DataBackup(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenDataBackup;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenDataBackup == null) {
          _cacheChildrenDataBackup = new HashSet<>();
          _cacheChildrenDataBackup.add(dataDestruction);
          _cacheChildrenDataBackup.add(dataEncryptedForImpact);
          _cacheChildrenDataBackup.add(inhibitSystemRecovery);
          _cacheChildrenDataBackup.add(diskContentWipe);
          _cacheChildrenDataBackup.add(diskStructureWipe);
          for (Computer _0 : computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenDataBackup.add(_2.internalDefacement);
              }
            }
          }
          for (Computer _3 : computer) {
            for (Router _4 : _3.router) {
              for (ExternalNetwork _5 : _4.externalNetwork) {
                _cacheChildrenDataBackup.add(_5.externalDefacement);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenDataBackup) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.dataBackup";
      }
    }
  }

  public class MultiFactorAuthentication extends Defense {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(credentialStuffing);
          _cacheChildrenMultiFactorAuthentication.add(localAccount);
          _cacheChildrenMultiFactorAuthentication.add(domainAccount);
          _cacheChildrenMultiFactorAuthentication.add(domainAccounts);
          _cacheChildrenMultiFactorAuthentication.add(passwordGuessing);
          _cacheChildrenMultiFactorAuthentication.add(passwordCracking);
          _cacheChildrenMultiFactorAuthentication.add(passwordSpraying);
          _cacheChildrenMultiFactorAuthentication.add(networkSniffing);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.multiFactorAuthentication";
      }
    }
  }

  public class PasswordPolicies extends Defense {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenPasswordPolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenPasswordPolicies == null) {
          _cacheChildrenPasswordPolicies = new HashSet<>();
          _cacheChildrenPasswordPolicies.add(passwordGuessing);
          _cacheChildrenPasswordPolicies.add(passwordCracking);
          _cacheChildrenPasswordPolicies.add(passwordSpraying);
          _cacheChildrenPasswordPolicies.add(credentialStuffing);
          _cacheChildrenPasswordPolicies.add(credentialsInFiles);
          _cacheChildrenPasswordPolicies.add(defaultAccounts);
          _cacheChildrenPasswordPolicies.add(localAccounts);
          _cacheChildrenPasswordPolicies.add(privateKeys);
        }
        for (AttackStep attackStep : _cacheChildrenPasswordPolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.passwordPolicies";
      }
    }
  }

  public class ApplicationIsolationAndSandboxing extends Defense {
    public ApplicationIsolationAndSandboxing(String name) {
      this(name, false);
    }

    public ApplicationIsolationAndSandboxing(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenApplicationIsolationAndSandboxing;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenApplicationIsolationAndSandboxing == null) {
          _cacheChildrenApplicationIsolationAndSandboxing = new HashSet<>();
          for (Service _0 : service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenApplicationIsolationAndSandboxing.add(_1.driveByCompromise);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenApplicationIsolationAndSandboxing) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.applicationIsolationAndSandboxing";
      }
    }
  }

  public class DoNotMitigate extends Defense {
    public DoNotMitigate(String name) {
      this(name, false);
    }

    public DoNotMitigate(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenDoNotMitigate;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenDoNotMitigate == null) {
          _cacheChildrenDoNotMitigate = new HashSet<>();
          _cacheChildrenDoNotMitigate.add(environmentalKeying);
        }
        for (AttackStep attackStep : _cacheChildrenDoNotMitigate) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.doNotMitigate";
      }
    }
  }

  public class DisableOrRemoveFeatureOrProgram extends Defense {
    public DisableOrRemoveFeatureOrProgram(String name) {
      this(name, false);
    }

    public DisableOrRemoveFeatureOrProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenDisableOrRemoveFeatureOrProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenDisableOrRemoveFeatureOrProgram == null) {
          _cacheChildrenDisableOrRemoveFeatureOrProgram = new HashSet<>();
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(javaScriptOrJScript);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(visualBasic);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(communicationThroughRemovableMedia);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(commandAndScriptingInterpreter);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(exfiltrationOverBluetooth);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(manInTheMiddle);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(runVirtualInstance);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(vNC);
        }
        for (AttackStep attackStep : _cacheChildrenDisableOrRemoveFeatureOrProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.disableOrRemoveFeatureOrProgram";
      }
    }
  }

  public class ActiveDirectoryConfiguration extends Defense {
    public ActiveDirectoryConfiguration(String name) {
      this(name, false);
    }

    public ActiveDirectoryConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenActiveDirectoryConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenActiveDirectoryConfiguration == null) {
          _cacheChildrenActiveDirectoryConfiguration = new HashSet<>();
          _cacheChildrenActiveDirectoryConfiguration.add(credentialsInFiles);
        }
        for (AttackStep attackStep : _cacheChildrenActiveDirectoryConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.activeDirectoryConfiguration";
      }
    }
  }

  public class Audit extends Defense {
    public Audit(String name) {
      this(name, false);
    }

    public Audit(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenAudit;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenAudit == null) {
          _cacheChildrenAudit = new HashSet<>();
          _cacheChildrenAudit.add(archiveViaUtility);
          _cacheChildrenAudit.add(confluence);
          _cacheChildrenAudit.add(sharepoint);
          _cacheChildrenAudit.add(credentialsInFiles);
          for (Computer _0 : computer) {
            for (Router _1 : _0.router) {
              for (ExternalNetwork _2 : _1.externalNetwork) {
                _cacheChildrenAudit.add(_2.dataFromCloudStorageObject);
              }
            }
          }
          _cacheChildrenAudit.add(privateKeys);
          _cacheChildrenAudit.add(python);
          _cacheChildrenAudit.add(vNC);
        }
        for (AttackStep attackStep : _cacheChildrenAudit) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.audit";
      }
    }
  }

  public class ApplicationDeveloperGuidance extends Defense {
    public ApplicationDeveloperGuidance(String name) {
      this(name, false);
    }

    public ApplicationDeveloperGuidance(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      public Disable(String name) {
        super(name);
      }

      @Override
      public String fullName() {
        return "OS.applicationDeveloperGuidance";
      }
    }
  }

  public class CodeSigning extends Defense {
    public CodeSigning(String name) {
      this(name, false);
    }

    public CodeSigning(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenCodeSigning;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenCodeSigning == null) {
          _cacheChildrenCodeSigning = new HashSet<>();
          _cacheChildrenCodeSigning.add(commandAndScriptingInterpreter);
          _cacheChildrenCodeSigning.add(matchLegitimateNameOrLocation);
          for (Service _0 : service) {
            _cacheChildrenCodeSigning.add(_0.applicationDeploymentSoftware);
          }
          for (Service _1 : service) {
            _cacheChildrenCodeSigning.add(_1.implantContainerImage);
          }
        }
        for (AttackStep attackStep : _cacheChildrenCodeSigning) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.codeSigning";
      }
    }
  }

  public class LimitHardwareInstallation extends Defense {
    public LimitHardwareInstallation(String name) {
      this(name, false);
    }

    public LimitHardwareInstallation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenLimitHardwareInstallation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenLimitHardwareInstallation == null) {
          _cacheChildrenLimitHardwareInstallation = new HashSet<>();
          for (Computer _0 : computer) {
            _cacheChildrenLimitHardwareInstallation.add(_0.hardwareAdditions);
          }
          for (Computer _1 : computer) {
            _cacheChildrenLimitHardwareInstallation.add(_1.exfiltrationOverPhysicalMedium);
          }
        }
        for (AttackStep attackStep : _cacheChildrenLimitHardwareInstallation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.limitHardwareInstallation";
      }
    }
  }

  public class OperatingSystemConfiguration extends Defense {
    public OperatingSystemConfiguration(String name) {
      this(name, false);
    }

    public OperatingSystemConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenOperatingSystemConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenOperatingSystemConfiguration == null) {
          _cacheChildrenOperatingSystemConfiguration = new HashSet<>();
          _cacheChildrenOperatingSystemConfiguration.add(communicationThroughRemovableMedia);
          _cacheChildrenOperatingSystemConfiguration.add(domainDiscovery);
          _cacheChildrenOperatingSystemConfiguration.add(exfiltrationOverOtherNetworkMedium);
          _cacheChildrenOperatingSystemConfiguration.add(inhibitSystemRecovery);
          _cacheChildrenOperatingSystemConfiguration.add(installRootCertificate);
          _cacheChildrenOperatingSystemConfiguration.add(localAccount);
          _cacheChildrenOperatingSystemConfiguration.add(domainAccount);
        }
        for (AttackStep attackStep : _cacheChildrenOperatingSystemConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.operatingSystemConfiguration";
      }
    }
  }

  public class SoftwareConfiguration extends Defense {
    public SoftwareConfiguration(String name) {
      this(name, false);
    }

    public SoftwareConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenSoftwareConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenSoftwareConfiguration == null) {
          _cacheChildrenSoftwareConfiguration = new HashSet<>();
          _cacheChildrenSoftwareConfiguration.add(installRootCertificate);
          for (Service _0 : service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenSoftwareConfiguration.add(_1.stealWebSessionCookie);
            }
          }
          for (Service _2 : service) {
            for (Browser _3 : _2.browser) {
              _cacheChildrenSoftwareConfiguration.add(_3.webSessionCookie);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenSoftwareConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.softwareConfiguration";
      }
    }
  }

  public class ExecutionPrevention extends Defense {
    public ExecutionPrevention(String name) {
      this(name, false);
    }

    public ExecutionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenExecutionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenExecutionPrevention == null) {
          _cacheChildrenExecutionPrevention = new HashSet<>();
          _cacheChildrenExecutionPrevention.add(applicationWindowDiscovery);
          _cacheChildrenExecutionPrevention.add(commandAndScriptingInterpreter);
          _cacheChildrenExecutionPrevention.add(binaryPadding);
          for (Service _0 : service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenExecutionPrevention.add(_1.browserExtensions);
            }
          }
          for (Computer _2 : computer) {
            _cacheChildrenExecutionPrevention.add(_2.collectAudio);
          }
          _cacheChildrenExecutionPrevention.add(dataCompressed);
          _cacheChildrenExecutionPrevention.add(detailedRemoteSystemDiscovery);
          _cacheChildrenExecutionPrevention.add(domainDiscovery);
          _cacheChildrenExecutionPrevention.add(javaScriptOrJScript);
          _cacheChildrenExecutionPrevention.add(matchLegitimateNameOrLocation);
          _cacheChildrenExecutionPrevention.add(python);
          _cacheChildrenExecutionPrevention.add(runVirtualInstance);
          _cacheChildrenExecutionPrevention.add(systemInformationDiscovery);
          _cacheChildrenExecutionPrevention.add(visualBasic);
          for (UserAccount _3 : userAccount) {
            _cacheChildrenExecutionPrevention.add(_3.userExecution);
          }
          for (UserAccount _4 : userAccount) {
            if (_4.user != null) {
              _cacheChildrenExecutionPrevention.add(_4.user.maliciousFile);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenExecutionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.executionPrevention";
      }
    }
  }

  public class PrivilegedAccountManagement extends Defense {
    public PrivilegedAccountManagement(String name) {
      this(name, false);
    }

    public PrivilegedAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenPrivilegedAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenPrivilegedAccountManagement == null) {
          _cacheChildrenPrivilegedAccountManagement = new HashSet<>();
          _cacheChildrenPrivilegedAccountManagement.add(commandAndScriptingInterpreter);
          _cacheChildrenPrivilegedAccountManagement.add(domainAccounts);
          _cacheChildrenPrivilegedAccountManagement.add(localAccounts);
          _cacheChildrenPrivilegedAccountManagement.add(webPortalCapture);
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.privilegedAccountManagement";
      }
    }
  }

  public class EncryptSensitiveInformation extends Defense {
    public EncryptSensitiveInformation(String name) {
      this(name, false);
    }

    public EncryptSensitiveInformation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenEncryptSensitiveInformation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenEncryptSensitiveInformation == null) {
          _cacheChildrenEncryptSensitiveInformation = new HashSet<>();
          _cacheChildrenEncryptSensitiveInformation.add(indicatorRemovalOnHost);
          _cacheChildrenEncryptSensitiveInformation.add(networkSniffing);
          _cacheChildrenEncryptSensitiveInformation.add(privateKeys);
          _cacheChildrenEncryptSensitiveInformation.add(storedDataManipulation);
          for (Computer _0 : computer) {
            for (Router _1 : _0.router) {
              for (ExternalNetwork _2 : _1.externalNetwork) {
                _cacheChildrenEncryptSensitiveInformation.add(_2.dataFromCloudStorageObject);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenEncryptSensitiveInformation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.encryptSensitiveInformation";
      }
    }
  }

  public class RemoteDataStorage extends Defense {
    public RemoteDataStorage(String name) {
      this(name, false);
    }

    public RemoteDataStorage(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenRemoteDataStorage;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenRemoteDataStorage == null) {
          _cacheChildrenRemoteDataStorage = new HashSet<>();
          _cacheChildrenRemoteDataStorage.add(automatedCollection);
          _cacheChildrenRemoteDataStorage.add(indicatorRemovalOnHost);
          _cacheChildrenRemoteDataStorage.add(storedDataManipulation);
          for (Service _0 : service) {
            _cacheChildrenRemoteDataStorage.add(_0.useThirdpartySoftware);
          }
        }
        for (AttackStep attackStep : _cacheChildrenRemoteDataStorage) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.remoteDataStorage";
      }
    }
  }

  public class LimitSoftwareInstallation extends Defense {
    public LimitSoftwareInstallation(String name) {
      this(name, false);
    }

    public LimitSoftwareInstallation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenLimitSoftwareInstallation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenLimitSoftwareInstallation == null) {
          _cacheChildrenLimitSoftwareInstallation = new HashSet<>();
          _cacheChildrenLimitSoftwareInstallation.add(python);
          _cacheChildrenLimitSoftwareInstallation.add(vNC);
          for (Service _0 : service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenLimitSoftwareInstallation.add(_1.browserExtensions);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenLimitSoftwareInstallation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.limitSoftwareInstallation";
      }
    }
  }

  public class UpdateSoftware extends Defense {
    public UpdateSoftware(String name) {
      this(name, false);
    }

    public UpdateSoftware(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenUpdateSoftware;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenUpdateSoftware == null) {
          _cacheChildrenUpdateSoftware = new HashSet<>();
          _cacheChildrenUpdateSoftware.add(firmwareCorruption);
        }
        for (AttackStep attackStep : _cacheChildrenUpdateSoftware) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.updateSoftware";
      }
    }
  }

  public class UserAccountControl extends Defense {
    public UserAccountControl(String name) {
      this(name, false);
    }

    public UserAccountControl(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenUserAccountControl;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenUserAccountControl == null) {
          _cacheChildrenUserAccountControl = new HashSet<>();
          for (Service _0 : service) {
            _cacheChildrenUserAccountControl.add(_0.trustedRelationship);
          }
        }
        for (AttackStep attackStep : _cacheChildrenUserAccountControl) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "OS.userAccountControl";
      }
    }
  }

  public class ExploitProtection extends Defense {
    public ExploitProtection(String name) {
      this(name, false);
    }

    public ExploitProtection(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      public Disable(String name) {
        super(name);
      }

      @Override
      public String fullName() {
        return "OS.exploitProtection";
      }
    }
  }
}
