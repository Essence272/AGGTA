package asset;

import core.AttackStep;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Webcam extends PeripheralDevice {
  public Webcam(String name) {
    super(name);
    assetClassName = "Webcam";
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
  }

  public Webcam() {
    this("Anonymous");
  }

  public class CollectVideo extends PeripheralDevice.CollectVideo {
    private Set<AttackStep> _cacheChildrenCollectVideo;

    public CollectVideo(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCollectVideo == null) {
        _cacheChildrenCollectVideo = new HashSet<>();
        if (Webcam.this instanceof Webcam) {
          for (Computer _0 : ((asset.Webcam) Webcam.this).computer) {
            _cacheChildrenCollectVideo.add(_0.collectVideo);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCollectVideo) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Webcam.collectVideo");
    }
  }
}
