package asset;

import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Windows extends OS {
  public AttemptAppInitDLLs attemptAppInitDLLs;

  public AttemptBootOrLogonInitializationScripts attemptBootOrLogonInitializationScripts;

  public BootOrLogonInitializationScripts bootOrLogonInitializationScripts;

  public NetworkLogonScripts networkLogonScripts;

  public CodeSigningCertificate codeSigningCertificate;

  public AttemptComponentObjectModel attemptComponentObjectModel;

  public ComponentObjectModel componentObjectModel;

  public AttemptCOR_PROFILER attemptCOR_PROFILER;

  public DynamicLinkLibraryInjection dynamicLinkLibraryInjection;

  public AsynchronousProcedureCall asynchronousProcedureCall;

  public ThreadLocalStorage threadLocalStorage;

  public AttemptDLLSearchOrderHijacking attemptDLLSearchOrderHijacking;

  public DLLSideLoading dLLSideLoading;

  public ExecutionThroughAPI executionThroughAPI;

  public ExtraWindowMemoryInjection extraWindowMemoryInjection;

  public WindowsFileAndDirectoryPermissionsModification windowsFileAndDirectoryPermissionsModification;

  public AttemptFileSystemPermissionsWeakness attemptFileSystemPermissionsWeakness;

  public FileSystemPermissionsWeakness fileSystemPermissionsWeakness;

  public AttemptGUIInputCapture attemptGUIInputCapture;

  public AttemptHiddenWindow attemptHiddenWindow;

  public InterProcessCommunication interProcessCommunication;

  public InvalidCodeSignature invalidCodeSignature;

  public StealOrForgeKerberosTickets stealOrForgeKerberosTickets;

  public AttemptGoldenTicket attemptGoldenTicket;

  public AttemptSilverTicket attemptSilverTicket;

  public Kerberoasting kerberoasting;

  public AttemptLLMNR_NBT_NS_PoisoningAndSMBRelay attemptLLMNR_NBT_NS_PoisoningAndSMBRelay;

  public UseAlternateAuthenticationMaterial useAlternateAuthenticationMaterial;

  public AttemptWindowsService attemptWindowsService;

  public NtfsFileAttributes ntfsFileAttributes;

  public OfficeApplicationStartup officeApplicationStartup;

  public AttemptPassTheHash attemptPassTheHash;

  public AttemptPassTheTicket attemptPassTheTicket;

  public PathInterception pathInterception;

  public PathInterceptionByPATHEnvironmentVariable pathInterceptionByPATHEnvironmentVariable;

  public PathInterceptionByUnquotedPath pathInterceptionByUnquotedPath;

  public AttemptPowerShellUserProfile attemptPowerShellUserProfile;

  public CodeProxyExecution codeProxyExecution;

  public FileProxyExecution fileProxyExecution;

  public RDPSessionHijacking rDPSessionHijacking;

  public SearchOrderHijacking searchOrderHijacking;

  public ServiceRegistryPermissionsWeakness serviceRegistryPermissionsWeakness;

  public SIDHistoryInjection sIDHistoryInjection;

  public SignedBinaryProxyExecution signedBinaryProxyExecution;

  public AttemptSoftwarePacking attemptSoftwarePacking;

  public SoftwarePacking softwarePacking;

  public TimeProviders timeProviders;

  public MSBuild mSBuild;

  public UnquotedPaths unquotedPaths;

  public AttemptScheduledTask attemptScheduledTask;

  public AttemptSystemTimeDiscovery attemptSystemTimeDiscovery;

  public SystemTimeDiscovery systemTimeDiscovery;

  public WindowsCommandShell windowsCommandShell;

  public AttemptRegistryKeysEnabled attemptRegistryKeysEnabled;

  public RegistryKeysEnabled registryKeysEnabled;

  public CaptureAPICalls captureAPICalls;

  public LogonScripts logonScripts;

  public TokenImpersonationOrTheft tokenImpersonationOrTheft;

  public CreateProcessWithAToken createProcessWithAToken;

  public MakeAndImpersonateToken makeAndImpersonateToken;

  public AttemptBypassUserAccessControl attemptBypassUserAccessControl;

  public LocalEmailCollection localEmailCollection;

  public RemoteEmailCollection remoteEmailCollection;

  public EmailForwardingRule emailForwardingRule;

  public AttemptApplicationShimming attemptApplicationShimming;

  public TrustedDomainInfo trustedDomainInfo;

  public CredentialAccessProtection credentialAccessProtection;

  public PrivilegedProcessIntegrity privilegedProcessIntegrity;

  public RestrictLibraryLoading restrictLibraryLoading;

  public Windows(String name, boolean isAntivirusEnabled,
      boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled, boolean isCredentialAccessProtectionEnabled,
      boolean isPrivilegedProcessIntegrityEnabled, boolean isRestrictLibraryLoadingEnabled) {
    super(name, isAntivirusEnabled, isRestrictFileAndDirectoryPermissionsEnabled, isRestrictRegistryPermissionsEnabled, isAccountUsePoliciesEnabled, isBehaviorPreventionOnEndpointEnabled, isBootIntegrityEnabled, isDataBackupEnabled, isMultiFactorAuthenticationEnabled, isPasswordPoliciesEnabled, isApplicationIsolationAndSandboxingEnabled, isDoNotMitigateEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isActiveDirectoryConfigurationEnabled, isAuditEnabled, isApplicationDeveloperGuidanceEnabled, isCodeSigningEnabled, isLimitHardwareInstallationEnabled, isOperatingSystemConfigurationEnabled, isSoftwareConfigurationEnabled, isExecutionPreventionEnabled, isPrivilegedAccountManagementEnabled, isEncryptSensitiveInformationEnabled, isRemoteDataStorageEnabled, isLimitSoftwareInstallationEnabled, isUpdateSoftwareEnabled, isUserAccountControlEnabled, isExploitProtectionEnabled);
    assetClassName = "Windows";
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(at);
    at = new At(name);
    AttackStep.allAttackSteps.remove(attemptAppCertDLLs);
    attemptAppCertDLLs = new AttemptAppCertDLLs(name);
    AttackStep.allAttackSteps.remove(appCertDLLs);
    appCertDLLs = new AppCertDLLs(name);
    AttackStep.allAttackSteps.remove(attemptAppInitDLLs);
    attemptAppInitDLLs = new AttemptAppInitDLLs(name);
    AttackStep.allAttackSteps.remove(appInitDLLs);
    appInitDLLs = new AppInitDLLs(name);
    AttackStep.allAttackSteps.remove(attemptAccessibilityFeatures);
    attemptAccessibilityFeatures = new AttemptAccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(accessibilityFeatures);
    accessibilityFeatures = new AccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(attemptBITSJobs);
    attemptBITSJobs = new AttemptBITSJobs(name);
    AttackStep.allAttackSteps.remove(bITSJobs);
    bITSJobs = new BITSJobs(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(attemptBootOrLogonInitializationScripts);
    attemptBootOrLogonInitializationScripts = new AttemptBootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(bootOrLogonInitializationScripts);
    bootOrLogonInitializationScripts = new BootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(networkLogonScripts);
    networkLogonScripts = new NetworkLogonScripts(name);
    AttackStep.allAttackSteps.remove(clearWindowsEventLogs);
    clearWindowsEventLogs = new ClearWindowsEventLogs(name);
    AttackStep.allAttackSteps.remove(cmstp);
    cmstp = new Cmstp(name);
    AttackStep.allAttackSteps.remove(codeSigningCertificate);
    codeSigningCertificate = new CodeSigningCertificate(name);
    AttackStep.allAttackSteps.remove(collectHashInformation);
    collectHashInformation = new CollectHashInformation(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(attemptComponentObjectModel);
    attemptComponentObjectModel = new AttemptComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(componentObjectModel);
    componentObjectModel = new ComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(attemptDistributedComponentObjectModel);
    attemptDistributedComponentObjectModel = new AttemptDistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(distributedComponentObjectModel);
    distributedComponentObjectModel = new DistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(attemptControlPanel);
    attemptControlPanel = new AttemptControlPanel(name);
    AttackStep.allAttackSteps.remove(controlPanel);
    controlPanel = new ControlPanel(name);
    AttackStep.allAttackSteps.remove(componentObjectModelHijacking);
    componentObjectModelHijacking = new ComponentObjectModelHijacking(name);
    AttackStep.allAttackSteps.remove(componentFirmware);
    componentFirmware = new ComponentFirmware(name);
    AttackStep.allAttackSteps.remove(compiledHTMLFile);
    compiledHTMLFile = new CompiledHTMLFile(name);
    AttackStep.allAttackSteps.remove(attemptCOR_PROFILER);
    attemptCOR_PROFILER = new AttemptCOR_PROFILER(name);
    AttackStep.allAttackSteps.remove(cOR_PROFILER);
    cOR_PROFILER = new COR_PROFILER(name);
    AttackStep.allAttackSteps.remove(credentialAPIHooking);
    credentialAPIHooking = new CredentialAPIHooking(name);
    AttackStep.allAttackSteps.remove(credentialsInRegistry);
    credentialsInRegistry = new CredentialsInRegistry(name);
    AttackStep.allAttackSteps.remove(dCShadow);
    dCShadow = new DCShadow(name);
    AttackStep.allAttackSteps.remove(dCSync);
    dCSync = new DCSync(name);
    AttackStep.allAttackSteps.remove(dynamicLinkLibraryInjection);
    dynamicLinkLibraryInjection = new DynamicLinkLibraryInjection(name);
    AttackStep.allAttackSteps.remove(portableExecutableInjection);
    portableExecutableInjection = new PortableExecutableInjection(name);
    AttackStep.allAttackSteps.remove(threadExecutionHijacking);
    threadExecutionHijacking = new ThreadExecutionHijacking(name);
    AttackStep.allAttackSteps.remove(asynchronousProcedureCall);
    asynchronousProcedureCall = new AsynchronousProcedureCall(name);
    AttackStep.allAttackSteps.remove(threadLocalStorage);
    threadLocalStorage = new ThreadLocalStorage(name);
    AttackStep.allAttackSteps.remove(deobfuscateOrDecodeFilesOrInformation);
    deobfuscateOrDecodeFilesOrInformation = new DeobfuscateOrDecodeFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(disableWindowsEventLogging);
    disableWindowsEventLogging = new DisableWindowsEventLogging(name);
    AttackStep.allAttackSteps.remove(attemptDLLSearchOrderHijacking);
    attemptDLLSearchOrderHijacking = new AttemptDLLSearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(dLLSearchOrderHijacking);
    dLLSearchOrderHijacking = new DLLSearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(dLLSideLoading);
    dLLSideLoading = new DLLSideLoading(name);
    AttackStep.allAttackSteps.remove(domainControllerAuthentication);
    domainControllerAuthentication = new DomainControllerAuthentication(name);
    AttackStep.allAttackSteps.remove(attemptLSASSDriver);
    attemptLSASSDriver = new AttemptLSASSDriver(name);
    AttackStep.allAttackSteps.remove(lSASSDriver);
    lSASSDriver = new LSASSDriver(name);
    AttackStep.allAttackSteps.remove(cachedDomainCredentials);
    cachedDomainCredentials = new CachedDomainCredentials(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(hideArtifacts);
    hideArtifacts = new HideArtifacts(name);
    AttackStep.allAttackSteps.remove(lSASecrets);
    lSASecrets = new LSASecrets(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(inputCapture);
    inputCapture = new InputCapture(name);
    AttackStep.allAttackSteps.remove(lateralToolTransfer);
    lateralToolTransfer = new LateralToolTransfer(name);
    AttackStep.allAttackSteps.remove(manInTheMiddle);
    manInTheMiddle = new ManInTheMiddle(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(mshta);
    mshta = new Mshta(name);
    AttackStep.allAttackSteps.remove(msiexec);
    msiexec = new Msiexec(name);
    AttackStep.allAttackSteps.remove(odbcconf);
    odbcconf = new Odbcconf(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    AttackStep.allAttackSteps.remove(attemptExecutionThroughAPI);
    attemptExecutionThroughAPI = new AttemptExecutionThroughAPI(name);
    AttackStep.allAttackSteps.remove(executionThroughAPI);
    executionThroughAPI = new ExecutionThroughAPI(name);
    AttackStep.allAttackSteps.remove(executionThroughModuleLoad);
    executionThroughModuleLoad = new ExecutionThroughModuleLoad(name);
    AttackStep.allAttackSteps.remove(extraWindowMemoryInjection);
    extraWindowMemoryInjection = new ExtraWindowMemoryInjection(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(windowsFileAndDirectoryPermissionsModification);
    windowsFileAndDirectoryPermissionsModification = new WindowsFileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(fileSystemLogicalOffsets);
    fileSystemLogicalOffsets = new FileSystemLogicalOffsets(name);
    AttackStep.allAttackSteps.remove(attemptFileSystemPermissionsWeakness);
    attemptFileSystemPermissionsWeakness = new AttemptFileSystemPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(fileSystemPermissionsWeakness);
    fileSystemPermissionsWeakness = new FileSystemPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(forcedAuthentication);
    forcedAuthentication = new ForcedAuthentication(name);
    AttackStep.allAttackSteps.remove(groupPolicyModification);
    groupPolicyModification = new GroupPolicyModification(name);
    AttackStep.allAttackSteps.remove(groupPolicyPreferences);
    groupPolicyPreferences = new GroupPolicyPreferences(name);
    AttackStep.allAttackSteps.remove(attemptGUIInputCapture);
    attemptGUIInputCapture = new AttemptGUIInputCapture(name);
    AttackStep.allAttackSteps.remove(gUIInputCapture);
    gUIInputCapture = new GUIInputCapture(name);
    AttackStep.allAttackSteps.remove(attemptHiddenWindow);
    attemptHiddenWindow = new AttemptHiddenWindow(name);
    AttackStep.allAttackSteps.remove(hiddenWindow);
    hiddenWindow = new HiddenWindow(name);
    AttackStep.allAttackSteps.remove(imageFileExecutionOptionsInjection);
    imageFileExecutionOptionsInjection = new ImageFileExecutionOptionsInjection(name);
    AttackStep.allAttackSteps.remove(indirectCommandExecution);
    indirectCommandExecution = new IndirectCommandExecution(name);
    AttackStep.allAttackSteps.remove(installUtil);
    installUtil = new InstallUtil(name);
    AttackStep.allAttackSteps.remove(interProcessCommunication);
    interProcessCommunication = new InterProcessCommunication(name);
    AttackStep.allAttackSteps.remove(invalidCodeSignature);
    invalidCodeSignature = new InvalidCodeSignature(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(stealOrForgeKerberosTickets);
    stealOrForgeKerberosTickets = new StealOrForgeKerberosTickets(name);
    AttackStep.allAttackSteps.remove(attemptGoldenTicket);
    attemptGoldenTicket = new AttemptGoldenTicket(name);
    AttackStep.allAttackSteps.remove(goldenTicket);
    goldenTicket = new GoldenTicket(name);
    AttackStep.allAttackSteps.remove(attemptSilverTicket);
    attemptSilverTicket = new AttemptSilverTicket(name);
    AttackStep.allAttackSteps.remove(silverTicket);
    silverTicket = new SilverTicket(name);
    AttackStep.allAttackSteps.remove(visualBasic);
    visualBasic = new VisualBasic(name);
    AttackStep.allAttackSteps.remove(javaScriptOrJScript);
    javaScriptOrJScript = new JavaScriptOrJScript(name);
    AttackStep.allAttackSteps.remove(kerberoasting);
    kerberoasting = new Kerberoasting(name);
    AttackStep.allAttackSteps.remove(attemptLLMNR_NBT_NS_PoisoningAndSMBRelay);
    attemptLLMNR_NBT_NS_PoisoningAndSMBRelay = new AttemptLLMNR_NBT_NS_PoisoningAndSMBRelay(name);
    AttackStep.allAttackSteps.remove(lLMNR_NBT_NS_PoisoningAndSMBRelay);
    lLMNR_NBT_NS_PoisoningAndSMBRelay = new LLMNR_NBT_NS_PoisoningAndSMBRelay(name);
    AttackStep.allAttackSteps.remove(attemptLSASSMemory);
    attemptLSASSMemory = new AttemptLSASSMemory(name);
    AttackStep.allAttackSteps.remove(lSASSMemory);
    lSASSMemory = new LSASSMemory(name);
    AttackStep.allAttackSteps.remove(useAlternateAuthenticationMaterial);
    useAlternateAuthenticationMaterial = new UseAlternateAuthenticationMaterial(name);
    AttackStep.allAttackSteps.remove(manInTheBrowser);
    manInTheBrowser = new ManInTheBrowser(name);
    AttackStep.allAttackSteps.remove(masqueradeTaskOrService);
    masqueradeTaskOrService = new MasqueradeTaskOrService(name);
    AttackStep.allAttackSteps.remove(modifyRegistry);
    modifyRegistry = new ModifyRegistry(name);
    AttackStep.allAttackSteps.remove(netshHelperDLL);
    netshHelperDLL = new NetshHelperDLL(name);
    AttackStep.allAttackSteps.remove(networkShareConnectionRemoval);
    networkShareConnectionRemoval = new NetworkShareConnectionRemoval(name);
    AttackStep.allAttackSteps.remove(nTDS);
    nTDS = new NTDS(name);
    AttackStep.allAttackSteps.remove(attemptWindowsService);
    attemptWindowsService = new AttemptWindowsService(name);
    AttackStep.allAttackSteps.remove(windowsService);
    windowsService = new WindowsService(name);
    AttackStep.allAttackSteps.remove(ntfsFileAttributes);
    ntfsFileAttributes = new NtfsFileAttributes(name);
    AttackStep.allAttackSteps.remove(officeApplicationStartup);
    officeApplicationStartup = new OfficeApplicationStartup(name);
    AttackStep.allAttackSteps.remove(attemptPasswordFilterDLL);
    attemptPasswordFilterDLL = new AttemptPasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(passwordFilterDLL);
    passwordFilterDLL = new PasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(attemptPassTheHash);
    attemptPassTheHash = new AttemptPassTheHash(name);
    AttackStep.allAttackSteps.remove(passTheHash);
    passTheHash = new PassTheHash(name);
    AttackStep.allAttackSteps.remove(attemptPassTheTicket);
    attemptPassTheTicket = new AttemptPassTheTicket(name);
    AttackStep.allAttackSteps.remove(passTheTicket);
    passTheTicket = new PassTheTicket(name);
    AttackStep.allAttackSteps.remove(parentPIDSpoofing);
    parentPIDSpoofing = new ParentPIDSpoofing(name);
    AttackStep.allAttackSteps.remove(executableInstallerFilePermissionsWeakness);
    executableInstallerFilePermissionsWeakness = new ExecutableInstallerFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(pathInterception);
    pathInterception = new PathInterception(name);
    AttackStep.allAttackSteps.remove(pathInterceptionByPATHEnvironmentVariable);
    pathInterceptionByPATHEnvironmentVariable = new PathInterceptionByPATHEnvironmentVariable(name);
    AttackStep.allAttackSteps.remove(pathInterceptionBySearchOrderHijacking);
    pathInterceptionBySearchOrderHijacking = new PathInterceptionBySearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(pathInterceptionByUnquotedPath);
    pathInterceptionByUnquotedPath = new PathInterceptionByUnquotedPath(name);
    AttackStep.allAttackSteps.remove(preOSBoot);
    preOSBoot = new PreOSBoot(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(securityAccountManager);
    securityAccountManager = new SecurityAccountManager(name);
    AttackStep.allAttackSteps.remove(serverSoftwareComponent);
    serverSoftwareComponent = new ServerSoftwareComponent(name);
    AttackStep.allAttackSteps.remove(attemptServicesFilePermissionsWeakness);
    attemptServicesFilePermissionsWeakness = new AttemptServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(servicesFilePermissionsWeakness);
    servicesFilePermissionsWeakness = new ServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(servicesRegistryPermissionsWeakness);
    servicesRegistryPermissionsWeakness = new ServicesRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptSQLStoredProcedures);
    attemptSQLStoredProcedures = new AttemptSQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(sQLStoredProcedures);
    sQLStoredProcedures = new SQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(subvertTrustControls);
    subvertTrustControls = new SubvertTrustControls(name);
    AttackStep.allAttackSteps.remove(systemServices);
    systemServices = new SystemServices(name);
    AttackStep.allAttackSteps.remove(attemptTransportAgent);
    attemptTransportAgent = new AttemptTransportAgent(name);
    AttackStep.allAttackSteps.remove(transportAgent);
    transportAgent = new TransportAgent(name);
    AttackStep.allAttackSteps.remove(attemptPowerShell);
    attemptPowerShell = new AttemptPowerShell(name);
    AttackStep.allAttackSteps.remove(powerShell);
    powerShell = new PowerShell(name);
    AttackStep.allAttackSteps.remove(attemptPowerShellUserProfile);
    attemptPowerShellUserProfile = new AttemptPowerShellUserProfile(name);
    AttackStep.allAttackSteps.remove(powerShellUserProfile);
    powerShellUserProfile = new PowerShellUserProfile(name);
    AttackStep.allAttackSteps.remove(attemptPowerShellAdminProfile);
    attemptPowerShellAdminProfile = new AttemptPowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(powerShellAdminProfile);
    powerShellAdminProfile = new PowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(processDoppelganging);
    processDoppelganging = new ProcessDoppelganging(name);
    AttackStep.allAttackSteps.remove(processHollowing);
    processHollowing = new ProcessHollowing(name);
    AttackStep.allAttackSteps.remove(processInjection);
    processInjection = new ProcessInjection(name);
    AttackStep.allAttackSteps.remove(codeProxyExecution);
    codeProxyExecution = new CodeProxyExecution(name);
    AttackStep.allAttackSteps.remove(fileProxyExecution);
    fileProxyExecution = new FileProxyExecution(name);
    AttackStep.allAttackSteps.remove(rDPHijacking);
    rDPHijacking = new RDPHijacking(name);
    AttackStep.allAttackSteps.remove(rDPSessionHijacking);
    rDPSessionHijacking = new RDPSessionHijacking(name);
    AttackStep.allAttackSteps.remove(registryRunKeysOrStartupFolder);
    registryRunKeysOrStartupFolder = new RegistryRunKeysOrStartupFolder(name);
    AttackStep.allAttackSteps.remove(regsvcsOrRegasm);
    regsvcsOrRegasm = new RegsvcsOrRegasm(name);
    AttackStep.allAttackSteps.remove(regsvr32);
    regsvr32 = new Regsvr32(name);
    AttackStep.allAttackSteps.remove(attemptRemoteDesktopProtocol);
    attemptRemoteDesktopProtocol = new AttemptRemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(remoteDesktopProtocol);
    remoteDesktopProtocol = new RemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(replicationThroughRemovableMedia);
    replicationThroughRemovableMedia = new ReplicationThroughRemovableMedia(name);
    AttackStep.allAttackSteps.remove(rootkit);
    rootkit = new Rootkit(name);
    AttackStep.allAttackSteps.remove(rundll32);
    rundll32 = new Rundll32(name);
    AttackStep.allAttackSteps.remove(screensaver);
    screensaver = new Screensaver(name);
    AttackStep.allAttackSteps.remove(searchOrderHijacking);
    searchOrderHijacking = new SearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(securitySupportProvider);
    securitySupportProvider = new SecuritySupportProvider(name);
    AttackStep.allAttackSteps.remove(attemptServiceExecution);
    attemptServiceExecution = new AttemptServiceExecution(name);
    AttackStep.allAttackSteps.remove(serviceExecution);
    serviceExecution = new ServiceExecution(name);
    AttackStep.allAttackSteps.remove(attemptServiceRegistryPermissionsWeakness);
    attemptServiceRegistryPermissionsWeakness = new AttemptServiceRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(serviceRegistryPermissionsWeakness);
    serviceRegistryPermissionsWeakness = new ServiceRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptShortcutModification);
    attemptShortcutModification = new AttemptShortcutModification(name);
    AttackStep.allAttackSteps.remove(shortcutModification);
    shortcutModification = new ShortcutModification(name);
    AttackStep.allAttackSteps.remove(attemptSIDHistoryInjection);
    attemptSIDHistoryInjection = new AttemptSIDHistoryInjection(name);
    AttackStep.allAttackSteps.remove(sIDHistoryInjection);
    sIDHistoryInjection = new SIDHistoryInjection(name);
    AttackStep.allAttackSteps.remove(signedBinaryProxyExecution);
    signedBinaryProxyExecution = new SignedBinaryProxyExecution(name);
    AttackStep.allAttackSteps.remove(signedScriptProxyExecution);
    signedScriptProxyExecution = new SignedScriptProxyExecution(name);
    AttackStep.allAttackSteps.remove(pubPrn);
    pubPrn = new PubPrn(name);
    AttackStep.allAttackSteps.remove(attemptSIPAndTrustProviderHijacking);
    attemptSIPAndTrustProviderHijacking = new AttemptSIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(sIPAndTrustProviderHijacking);
    sIPAndTrustProviderHijacking = new SIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(attemptSoftwarePacking);
    attemptSoftwarePacking = new AttemptSoftwarePacking(name);
    AttackStep.allAttackSteps.remove(softwarePacking);
    softwarePacking = new SoftwarePacking(name);
    AttackStep.allAttackSteps.remove(systemServiceDiscovery);
    systemServiceDiscovery = new SystemServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptTaintSharedContent);
    attemptTaintSharedContent = new AttemptTaintSharedContent(name);
    AttackStep.allAttackSteps.remove(templateInjection);
    templateInjection = new TemplateInjection(name);
    AttackStep.allAttackSteps.remove(attemptTimeProviders);
    attemptTimeProviders = new AttemptTimeProviders(name);
    AttackStep.allAttackSteps.remove(timeProviders);
    timeProviders = new TimeProviders(name);
    AttackStep.allAttackSteps.remove(trustedDeveloperUtilities);
    trustedDeveloperUtilities = new TrustedDeveloperUtilities(name);
    AttackStep.allAttackSteps.remove(mSBuild);
    mSBuild = new MSBuild(name);
    AttackStep.allAttackSteps.remove(unquotedPaths);
    unquotedPaths = new UnquotedPaths(name);
    AttackStep.allAttackSteps.remove(attemptServiceStop);
    attemptServiceStop = new AttemptServiceStop(name);
    AttackStep.allAttackSteps.remove(serviceStop);
    serviceStop = new ServiceStop(name);
    AttackStep.allAttackSteps.remove(attemptScheduledTask);
    attemptScheduledTask = new AttemptScheduledTask(name);
    AttackStep.allAttackSteps.remove(scheduledTask);
    scheduledTask = new ScheduledTask(name);
    AttackStep.allAttackSteps.remove(remoteScheduledTask);
    remoteScheduledTask = new RemoteScheduledTask(name);
    AttackStep.allAttackSteps.remove(attemptSystemTimeDiscovery);
    attemptSystemTimeDiscovery = new AttemptSystemTimeDiscovery(name);
    AttackStep.allAttackSteps.remove(systemTimeDiscovery);
    systemTimeDiscovery = new SystemTimeDiscovery(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(attemptWindowsAdminShares);
    attemptWindowsAdminShares = new AttemptWindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(windowsAdminShares);
    windowsAdminShares = new WindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(windowsCommandShell);
    windowsCommandShell = new WindowsCommandShell(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentation);
    windowsManagementInstrumentation = new WindowsManagementInstrumentation(name);
    AttackStep.allAttackSteps.remove(attemptWindowsManagementInstrumentationEventSubscription);
    attemptWindowsManagementInstrumentationEventSubscription = new AttemptWindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentationEventSubscription);
    windowsManagementInstrumentationEventSubscription = new WindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(attemptWindowsRemoteManagement);
    attemptWindowsRemoteManagement = new AttemptWindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(windowsRemoteManagement);
    windowsRemoteManagement = new WindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(attemptWinlogonHelperDLL);
    attemptWinlogonHelperDLL = new AttemptWinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(winlogonHelperDLL);
    winlogonHelperDLL = new WinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(remoteFileCopy);
    remoteFileCopy = new RemoteFileCopy(name);
    AttackStep.allAttackSteps.remove(attemptRegistryKeysEnabled);
    attemptRegistryKeysEnabled = new AttemptRegistryKeysEnabled(name);
    AttackStep.allAttackSteps.remove(registryKeysEnabled);
    registryKeysEnabled = new RegistryKeysEnabled(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(attemptDynamicDataExchange);
    attemptDynamicDataExchange = new AttemptDynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(dynamicDataExchange);
    dynamicDataExchange = new DynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(captureAPICalls);
    captureAPICalls = new CaptureAPICalls(name);
    AttackStep.allAttackSteps.remove(attemptLogonScripts);
    attemptLogonScripts = new AttemptLogonScripts(name);
    AttackStep.allAttackSteps.remove(logonScripts);
    logonScripts = new LogonScripts(name);
    AttackStep.allAttackSteps.remove(attemptSystemFirmware);
    attemptSystemFirmware = new AttemptSystemFirmware(name);
    AttackStep.allAttackSteps.remove(systemFirmware);
    systemFirmware = new SystemFirmware(name);
    AttackStep.allAttackSteps.remove(systemShutdownOrReboot);
    systemShutdownOrReboot = new SystemShutdownOrReboot(name);
    AttackStep.allAttackSteps.remove(queryRegistry);
    queryRegistry = new QueryRegistry(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptAccessTokenManipulation);
    attemptAccessTokenManipulation = new AttemptAccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(accessTokenManipulation);
    accessTokenManipulation = new AccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(tokenImpersonationOrTheft);
    tokenImpersonationOrTheft = new TokenImpersonationOrTheft(name);
    AttackStep.allAttackSteps.remove(createProcessWithAToken);
    createProcessWithAToken = new CreateProcessWithAToken(name);
    AttackStep.allAttackSteps.remove(makeAndImpersonateToken);
    makeAndImpersonateToken = new MakeAndImpersonateToken(name);
    AttackStep.allAttackSteps.remove(attemptBypassUserAccessControl);
    attemptBypassUserAccessControl = new AttemptBypassUserAccessControl(name);
    AttackStep.allAttackSteps.remove(bypassUserAccessControl);
    bypassUserAccessControl = new BypassUserAccessControl(name);
    AttackStep.allAttackSteps.remove(obfuscatedFilesOrInformation);
    obfuscatedFilesOrInformation = new ObfuscatedFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(oSCredentialDumping);
    oSCredentialDumping = new OSCredentialDumping(name);
    AttackStep.allAttackSteps.remove(peripheralDeviceDiscovery);
    peripheralDeviceDiscovery = new PeripheralDeviceDiscovery(name);
    AttackStep.allAttackSteps.remove(portMonitors);
    portMonitors = new PortMonitors(name);
    AttackStep.allAttackSteps.remove(emailCollection);
    emailCollection = new EmailCollection(name);
    AttackStep.allAttackSteps.remove(localEmailCollection);
    localEmailCollection = new LocalEmailCollection(name);
    AttackStep.allAttackSteps.remove(remoteEmailCollection);
    remoteEmailCollection = new RemoteEmailCollection(name);
    AttackStep.allAttackSteps.remove(emailForwardingRule);
    emailForwardingRule = new EmailForwardingRule(name);
    AttackStep.allAttackSteps.remove(attemptApplicationShimming);
    attemptApplicationShimming = new AttemptApplicationShimming(name);
    AttackStep.allAttackSteps.remove(applicationShimming);
    applicationShimming = new ApplicationShimming(name);
    AttackStep.allAttackSteps.remove(authenticationPackage);
    authenticationPackage = new AuthenticationPackage(name);
    AttackStep.allAttackSteps.remove(changeDefaultFileAssociation);
    changeDefaultFileAssociation = new ChangeDefaultFileAssociation(name);
    AttackStep.allAttackSteps.remove(trustedDomainInfo);
    trustedDomainInfo = new TrustedDomainInfo(name);
    AttackStep.allAttackSteps.remove(domainTrustDiscovery);
    domainTrustDiscovery = new DomainTrustDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptBootkit);
    attemptBootkit = new AttemptBootkit(name);
    AttackStep.allAttackSteps.remove(bootkit);
    bootkit = new Bootkit(name);
    AttackStep.allAttackSteps.remove(videoCapture);
    videoCapture = new VideoCapture(name);
    AttackStep.allAttackSteps.remove(xslScriptProcessing);
    xslScriptProcessing = new XslScriptProcessing(name);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, isActiveDirectoryConfigurationEnabled);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, isAntivirusEnabled);
    if (applicationIsolationAndSandboxing != null) {
      AttackStep.allAttackSteps.remove(applicationIsolationAndSandboxing.disable);
    }
    Defense.allDefenses.remove(applicationIsolationAndSandboxing);
    applicationIsolationAndSandboxing = new ApplicationIsolationAndSandboxing(name, isApplicationIsolationAndSandboxingEnabled);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, isAuditEnabled);
    if (behaviorPreventionOnEndpoint != null) {
      AttackStep.allAttackSteps.remove(behaviorPreventionOnEndpoint.disable);
    }
    Defense.allDefenses.remove(behaviorPreventionOnEndpoint);
    behaviorPreventionOnEndpoint = new BehaviorPreventionOnEndpoint(name, isBehaviorPreventionOnEndpointEnabled);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, isCodeSigningEnabled);
    if (credentialAccessProtection != null) {
      AttackStep.allAttackSteps.remove(credentialAccessProtection.disable);
    }
    Defense.allDefenses.remove(credentialAccessProtection);
    credentialAccessProtection = new CredentialAccessProtection(name, isCredentialAccessProtectionEnabled);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, isExecutionPreventionEnabled);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, isExploitProtectionEnabled);
    if (limitHardwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitHardwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitHardwareInstallation);
    limitHardwareInstallation = new LimitHardwareInstallation(name, isLimitHardwareInstallationEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, isOperatingSystemConfigurationEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
    if (privilegedProcessIntegrity != null) {
      AttackStep.allAttackSteps.remove(privilegedProcessIntegrity.disable);
    }
    Defense.allDefenses.remove(privilegedProcessIntegrity);
    privilegedProcessIntegrity = new PrivilegedProcessIntegrity(name, isPrivilegedProcessIntegrityEnabled);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, isPrivilegedAccountManagementEnabled);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, isRestrictFileAndDirectoryPermissionsEnabled);
    if (restrictRegistryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictRegistryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictRegistryPermissions);
    restrictRegistryPermissions = new RestrictRegistryPermissions(name, isRestrictRegistryPermissionsEnabled);
    if (restrictLibraryLoading != null) {
      AttackStep.allAttackSteps.remove(restrictLibraryLoading.disable);
    }
    Defense.allDefenses.remove(restrictLibraryLoading);
    restrictLibraryLoading = new RestrictLibraryLoading(name, isRestrictLibraryLoadingEnabled);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, isRemoteDataStorageEnabled);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, isSoftwareConfigurationEnabled);
    if (bootIntegrity != null) {
      AttackStep.allAttackSteps.remove(bootIntegrity.disable);
    }
    Defense.allDefenses.remove(bootIntegrity);
    bootIntegrity = new BootIntegrity(name, isBootIntegrityEnabled);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, isEncryptSensitiveInformationEnabled);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, isDisableOrRemoveFeatureOrProgramEnabled);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, isUpdateSoftwareEnabled);
    if (userAccountControl != null) {
      AttackStep.allAttackSteps.remove(userAccountControl.disable);
    }
    Defense.allDefenses.remove(userAccountControl);
    userAccountControl = new UserAccountControl(name, isUserAccountControlEnabled);
  }

  public Windows(String name) {
    super(name);
    assetClassName = "Windows";
    AttackStep.allAttackSteps.remove(abuseElevationControlMechanism);
    abuseElevationControlMechanism = new AbuseElevationControlMechanism(name);
    AttackStep.allAttackSteps.remove(accountManipulation);
    accountManipulation = new AccountManipulation(name);
    AttackStep.allAttackSteps.remove(at);
    at = new At(name);
    AttackStep.allAttackSteps.remove(attemptAppCertDLLs);
    attemptAppCertDLLs = new AttemptAppCertDLLs(name);
    AttackStep.allAttackSteps.remove(appCertDLLs);
    appCertDLLs = new AppCertDLLs(name);
    AttackStep.allAttackSteps.remove(attemptAppInitDLLs);
    attemptAppInitDLLs = new AttemptAppInitDLLs(name);
    AttackStep.allAttackSteps.remove(appInitDLLs);
    appInitDLLs = new AppInitDLLs(name);
    AttackStep.allAttackSteps.remove(attemptAccessibilityFeatures);
    attemptAccessibilityFeatures = new AttemptAccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(accessibilityFeatures);
    accessibilityFeatures = new AccessibilityFeatures(name);
    AttackStep.allAttackSteps.remove(attemptBITSJobs);
    attemptBITSJobs = new AttemptBITSJobs(name);
    AttackStep.allAttackSteps.remove(bITSJobs);
    bITSJobs = new BITSJobs(name);
    AttackStep.allAttackSteps.remove(bootOrLogonAutostartExecution);
    bootOrLogonAutostartExecution = new BootOrLogonAutostartExecution(name);
    AttackStep.allAttackSteps.remove(attemptBootOrLogonInitializationScripts);
    attemptBootOrLogonInitializationScripts = new AttemptBootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(bootOrLogonInitializationScripts);
    bootOrLogonInitializationScripts = new BootOrLogonInitializationScripts(name);
    AttackStep.allAttackSteps.remove(networkLogonScripts);
    networkLogonScripts = new NetworkLogonScripts(name);
    AttackStep.allAttackSteps.remove(clearWindowsEventLogs);
    clearWindowsEventLogs = new ClearWindowsEventLogs(name);
    AttackStep.allAttackSteps.remove(cmstp);
    cmstp = new Cmstp(name);
    AttackStep.allAttackSteps.remove(codeSigningCertificate);
    codeSigningCertificate = new CodeSigningCertificate(name);
    AttackStep.allAttackSteps.remove(collectHashInformation);
    collectHashInformation = new CollectHashInformation(name);
    AttackStep.allAttackSteps.remove(commandAndScriptingInterpreter);
    commandAndScriptingInterpreter = new CommandAndScriptingInterpreter(name);
    AttackStep.allAttackSteps.remove(attemptComponentObjectModel);
    attemptComponentObjectModel = new AttemptComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(componentObjectModel);
    componentObjectModel = new ComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(createOrModifySystemProcess);
    createOrModifySystemProcess = new CreateOrModifySystemProcess(name);
    AttackStep.allAttackSteps.remove(attemptDistributedComponentObjectModel);
    attemptDistributedComponentObjectModel = new AttemptDistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(distributedComponentObjectModel);
    distributedComponentObjectModel = new DistributedComponentObjectModel(name);
    AttackStep.allAttackSteps.remove(attemptControlPanel);
    attemptControlPanel = new AttemptControlPanel(name);
    AttackStep.allAttackSteps.remove(controlPanel);
    controlPanel = new ControlPanel(name);
    AttackStep.allAttackSteps.remove(componentObjectModelHijacking);
    componentObjectModelHijacking = new ComponentObjectModelHijacking(name);
    AttackStep.allAttackSteps.remove(componentFirmware);
    componentFirmware = new ComponentFirmware(name);
    AttackStep.allAttackSteps.remove(compiledHTMLFile);
    compiledHTMLFile = new CompiledHTMLFile(name);
    AttackStep.allAttackSteps.remove(attemptCOR_PROFILER);
    attemptCOR_PROFILER = new AttemptCOR_PROFILER(name);
    AttackStep.allAttackSteps.remove(cOR_PROFILER);
    cOR_PROFILER = new COR_PROFILER(name);
    AttackStep.allAttackSteps.remove(credentialAPIHooking);
    credentialAPIHooking = new CredentialAPIHooking(name);
    AttackStep.allAttackSteps.remove(credentialsInRegistry);
    credentialsInRegistry = new CredentialsInRegistry(name);
    AttackStep.allAttackSteps.remove(dCShadow);
    dCShadow = new DCShadow(name);
    AttackStep.allAttackSteps.remove(dCSync);
    dCSync = new DCSync(name);
    AttackStep.allAttackSteps.remove(dynamicLinkLibraryInjection);
    dynamicLinkLibraryInjection = new DynamicLinkLibraryInjection(name);
    AttackStep.allAttackSteps.remove(portableExecutableInjection);
    portableExecutableInjection = new PortableExecutableInjection(name);
    AttackStep.allAttackSteps.remove(threadExecutionHijacking);
    threadExecutionHijacking = new ThreadExecutionHijacking(name);
    AttackStep.allAttackSteps.remove(asynchronousProcedureCall);
    asynchronousProcedureCall = new AsynchronousProcedureCall(name);
    AttackStep.allAttackSteps.remove(threadLocalStorage);
    threadLocalStorage = new ThreadLocalStorage(name);
    AttackStep.allAttackSteps.remove(deobfuscateOrDecodeFilesOrInformation);
    deobfuscateOrDecodeFilesOrInformation = new DeobfuscateOrDecodeFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(disableWindowsEventLogging);
    disableWindowsEventLogging = new DisableWindowsEventLogging(name);
    AttackStep.allAttackSteps.remove(attemptDLLSearchOrderHijacking);
    attemptDLLSearchOrderHijacking = new AttemptDLLSearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(dLLSearchOrderHijacking);
    dLLSearchOrderHijacking = new DLLSearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(dLLSideLoading);
    dLLSideLoading = new DLLSideLoading(name);
    AttackStep.allAttackSteps.remove(domainControllerAuthentication);
    domainControllerAuthentication = new DomainControllerAuthentication(name);
    AttackStep.allAttackSteps.remove(attemptLSASSDriver);
    attemptLSASSDriver = new AttemptLSASSDriver(name);
    AttackStep.allAttackSteps.remove(lSASSDriver);
    lSASSDriver = new LSASSDriver(name);
    AttackStep.allAttackSteps.remove(cachedDomainCredentials);
    cachedDomainCredentials = new CachedDomainCredentials(name);
    AttackStep.allAttackSteps.remove(eventTriggeredExecution);
    eventTriggeredExecution = new EventTriggeredExecution(name);
    AttackStep.allAttackSteps.remove(hideArtifacts);
    hideArtifacts = new HideArtifacts(name);
    AttackStep.allAttackSteps.remove(lSASecrets);
    lSASecrets = new LSASecrets(name);
    AttackStep.allAttackSteps.remove(hijackExecutionFlow);
    hijackExecutionFlow = new HijackExecutionFlow(name);
    AttackStep.allAttackSteps.remove(impareDefenses);
    impareDefenses = new ImpareDefenses(name);
    AttackStep.allAttackSteps.remove(indicatorRemovalOnHost);
    indicatorRemovalOnHost = new IndicatorRemovalOnHost(name);
    AttackStep.allAttackSteps.remove(inputCapture);
    inputCapture = new InputCapture(name);
    AttackStep.allAttackSteps.remove(lateralToolTransfer);
    lateralToolTransfer = new LateralToolTransfer(name);
    AttackStep.allAttackSteps.remove(manInTheMiddle);
    manInTheMiddle = new ManInTheMiddle(name);
    AttackStep.allAttackSteps.remove(masquerading);
    masquerading = new Masquerading(name);
    AttackStep.allAttackSteps.remove(modifyAuthenticationProcess);
    modifyAuthenticationProcess = new ModifyAuthenticationProcess(name);
    AttackStep.allAttackSteps.remove(mshta);
    mshta = new Mshta(name);
    AttackStep.allAttackSteps.remove(msiexec);
    msiexec = new Msiexec(name);
    AttackStep.allAttackSteps.remove(odbcconf);
    odbcconf = new Odbcconf(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(executeCode);
    executeCode = new ExecuteCode(name);
    AttackStep.allAttackSteps.remove(attemptExecutionThroughAPI);
    attemptExecutionThroughAPI = new AttemptExecutionThroughAPI(name);
    AttackStep.allAttackSteps.remove(executionThroughAPI);
    executionThroughAPI = new ExecutionThroughAPI(name);
    AttackStep.allAttackSteps.remove(executionThroughModuleLoad);
    executionThroughModuleLoad = new ExecutionThroughModuleLoad(name);
    AttackStep.allAttackSteps.remove(extraWindowMemoryInjection);
    extraWindowMemoryInjection = new ExtraWindowMemoryInjection(name);
    AttackStep.allAttackSteps.remove(fileAndDirectoryPermissionsModification);
    fileAndDirectoryPermissionsModification = new FileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(windowsFileAndDirectoryPermissionsModification);
    windowsFileAndDirectoryPermissionsModification = new WindowsFileAndDirectoryPermissionsModification(name);
    AttackStep.allAttackSteps.remove(fileSystemLogicalOffsets);
    fileSystemLogicalOffsets = new FileSystemLogicalOffsets(name);
    AttackStep.allAttackSteps.remove(attemptFileSystemPermissionsWeakness);
    attemptFileSystemPermissionsWeakness = new AttemptFileSystemPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(fileSystemPermissionsWeakness);
    fileSystemPermissionsWeakness = new FileSystemPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(forcedAuthentication);
    forcedAuthentication = new ForcedAuthentication(name);
    AttackStep.allAttackSteps.remove(groupPolicyModification);
    groupPolicyModification = new GroupPolicyModification(name);
    AttackStep.allAttackSteps.remove(groupPolicyPreferences);
    groupPolicyPreferences = new GroupPolicyPreferences(name);
    AttackStep.allAttackSteps.remove(attemptGUIInputCapture);
    attemptGUIInputCapture = new AttemptGUIInputCapture(name);
    AttackStep.allAttackSteps.remove(gUIInputCapture);
    gUIInputCapture = new GUIInputCapture(name);
    AttackStep.allAttackSteps.remove(attemptHiddenWindow);
    attemptHiddenWindow = new AttemptHiddenWindow(name);
    AttackStep.allAttackSteps.remove(hiddenWindow);
    hiddenWindow = new HiddenWindow(name);
    AttackStep.allAttackSteps.remove(imageFileExecutionOptionsInjection);
    imageFileExecutionOptionsInjection = new ImageFileExecutionOptionsInjection(name);
    AttackStep.allAttackSteps.remove(indirectCommandExecution);
    indirectCommandExecution = new IndirectCommandExecution(name);
    AttackStep.allAttackSteps.remove(installUtil);
    installUtil = new InstallUtil(name);
    AttackStep.allAttackSteps.remove(interProcessCommunication);
    interProcessCommunication = new InterProcessCommunication(name);
    AttackStep.allAttackSteps.remove(invalidCodeSignature);
    invalidCodeSignature = new InvalidCodeSignature(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(stealOrForgeKerberosTickets);
    stealOrForgeKerberosTickets = new StealOrForgeKerberosTickets(name);
    AttackStep.allAttackSteps.remove(attemptGoldenTicket);
    attemptGoldenTicket = new AttemptGoldenTicket(name);
    AttackStep.allAttackSteps.remove(goldenTicket);
    goldenTicket = new GoldenTicket(name);
    AttackStep.allAttackSteps.remove(attemptSilverTicket);
    attemptSilverTicket = new AttemptSilverTicket(name);
    AttackStep.allAttackSteps.remove(silverTicket);
    silverTicket = new SilverTicket(name);
    AttackStep.allAttackSteps.remove(visualBasic);
    visualBasic = new VisualBasic(name);
    AttackStep.allAttackSteps.remove(javaScriptOrJScript);
    javaScriptOrJScript = new JavaScriptOrJScript(name);
    AttackStep.allAttackSteps.remove(kerberoasting);
    kerberoasting = new Kerberoasting(name);
    AttackStep.allAttackSteps.remove(attemptLLMNR_NBT_NS_PoisoningAndSMBRelay);
    attemptLLMNR_NBT_NS_PoisoningAndSMBRelay = new AttemptLLMNR_NBT_NS_PoisoningAndSMBRelay(name);
    AttackStep.allAttackSteps.remove(lLMNR_NBT_NS_PoisoningAndSMBRelay);
    lLMNR_NBT_NS_PoisoningAndSMBRelay = new LLMNR_NBT_NS_PoisoningAndSMBRelay(name);
    AttackStep.allAttackSteps.remove(attemptLSASSMemory);
    attemptLSASSMemory = new AttemptLSASSMemory(name);
    AttackStep.allAttackSteps.remove(lSASSMemory);
    lSASSMemory = new LSASSMemory(name);
    AttackStep.allAttackSteps.remove(useAlternateAuthenticationMaterial);
    useAlternateAuthenticationMaterial = new UseAlternateAuthenticationMaterial(name);
    AttackStep.allAttackSteps.remove(manInTheBrowser);
    manInTheBrowser = new ManInTheBrowser(name);
    AttackStep.allAttackSteps.remove(masqueradeTaskOrService);
    masqueradeTaskOrService = new MasqueradeTaskOrService(name);
    AttackStep.allAttackSteps.remove(modifyRegistry);
    modifyRegistry = new ModifyRegistry(name);
    AttackStep.allAttackSteps.remove(netshHelperDLL);
    netshHelperDLL = new NetshHelperDLL(name);
    AttackStep.allAttackSteps.remove(networkShareConnectionRemoval);
    networkShareConnectionRemoval = new NetworkShareConnectionRemoval(name);
    AttackStep.allAttackSteps.remove(nTDS);
    nTDS = new NTDS(name);
    AttackStep.allAttackSteps.remove(attemptWindowsService);
    attemptWindowsService = new AttemptWindowsService(name);
    AttackStep.allAttackSteps.remove(windowsService);
    windowsService = new WindowsService(name);
    AttackStep.allAttackSteps.remove(ntfsFileAttributes);
    ntfsFileAttributes = new NtfsFileAttributes(name);
    AttackStep.allAttackSteps.remove(officeApplicationStartup);
    officeApplicationStartup = new OfficeApplicationStartup(name);
    AttackStep.allAttackSteps.remove(attemptPasswordFilterDLL);
    attemptPasswordFilterDLL = new AttemptPasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(passwordFilterDLL);
    passwordFilterDLL = new PasswordFilterDLL(name);
    AttackStep.allAttackSteps.remove(attemptPassTheHash);
    attemptPassTheHash = new AttemptPassTheHash(name);
    AttackStep.allAttackSteps.remove(passTheHash);
    passTheHash = new PassTheHash(name);
    AttackStep.allAttackSteps.remove(attemptPassTheTicket);
    attemptPassTheTicket = new AttemptPassTheTicket(name);
    AttackStep.allAttackSteps.remove(passTheTicket);
    passTheTicket = new PassTheTicket(name);
    AttackStep.allAttackSteps.remove(parentPIDSpoofing);
    parentPIDSpoofing = new ParentPIDSpoofing(name);
    AttackStep.allAttackSteps.remove(executableInstallerFilePermissionsWeakness);
    executableInstallerFilePermissionsWeakness = new ExecutableInstallerFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(pathInterception);
    pathInterception = new PathInterception(name);
    AttackStep.allAttackSteps.remove(pathInterceptionByPATHEnvironmentVariable);
    pathInterceptionByPATHEnvironmentVariable = new PathInterceptionByPATHEnvironmentVariable(name);
    AttackStep.allAttackSteps.remove(pathInterceptionBySearchOrderHijacking);
    pathInterceptionBySearchOrderHijacking = new PathInterceptionBySearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(pathInterceptionByUnquotedPath);
    pathInterceptionByUnquotedPath = new PathInterceptionByUnquotedPath(name);
    AttackStep.allAttackSteps.remove(preOSBoot);
    preOSBoot = new PreOSBoot(name);
    AttackStep.allAttackSteps.remove(scheduledTaskOrJob);
    scheduledTaskOrJob = new ScheduledTaskOrJob(name);
    AttackStep.allAttackSteps.remove(securityAccountManager);
    securityAccountManager = new SecurityAccountManager(name);
    AttackStep.allAttackSteps.remove(serverSoftwareComponent);
    serverSoftwareComponent = new ServerSoftwareComponent(name);
    AttackStep.allAttackSteps.remove(attemptServicesFilePermissionsWeakness);
    attemptServicesFilePermissionsWeakness = new AttemptServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(servicesFilePermissionsWeakness);
    servicesFilePermissionsWeakness = new ServicesFilePermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(servicesRegistryPermissionsWeakness);
    servicesRegistryPermissionsWeakness = new ServicesRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptSQLStoredProcedures);
    attemptSQLStoredProcedures = new AttemptSQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(sQLStoredProcedures);
    sQLStoredProcedures = new SQLStoredProcedures(name);
    AttackStep.allAttackSteps.remove(subvertTrustControls);
    subvertTrustControls = new SubvertTrustControls(name);
    AttackStep.allAttackSteps.remove(systemServices);
    systemServices = new SystemServices(name);
    AttackStep.allAttackSteps.remove(attemptTransportAgent);
    attemptTransportAgent = new AttemptTransportAgent(name);
    AttackStep.allAttackSteps.remove(transportAgent);
    transportAgent = new TransportAgent(name);
    AttackStep.allAttackSteps.remove(attemptPowerShell);
    attemptPowerShell = new AttemptPowerShell(name);
    AttackStep.allAttackSteps.remove(powerShell);
    powerShell = new PowerShell(name);
    AttackStep.allAttackSteps.remove(attemptPowerShellUserProfile);
    attemptPowerShellUserProfile = new AttemptPowerShellUserProfile(name);
    AttackStep.allAttackSteps.remove(powerShellUserProfile);
    powerShellUserProfile = new PowerShellUserProfile(name);
    AttackStep.allAttackSteps.remove(attemptPowerShellAdminProfile);
    attemptPowerShellAdminProfile = new AttemptPowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(powerShellAdminProfile);
    powerShellAdminProfile = new PowerShellAdminProfile(name);
    AttackStep.allAttackSteps.remove(processDoppelganging);
    processDoppelganging = new ProcessDoppelganging(name);
    AttackStep.allAttackSteps.remove(processHollowing);
    processHollowing = new ProcessHollowing(name);
    AttackStep.allAttackSteps.remove(processInjection);
    processInjection = new ProcessInjection(name);
    AttackStep.allAttackSteps.remove(codeProxyExecution);
    codeProxyExecution = new CodeProxyExecution(name);
    AttackStep.allAttackSteps.remove(fileProxyExecution);
    fileProxyExecution = new FileProxyExecution(name);
    AttackStep.allAttackSteps.remove(rDPHijacking);
    rDPHijacking = new RDPHijacking(name);
    AttackStep.allAttackSteps.remove(rDPSessionHijacking);
    rDPSessionHijacking = new RDPSessionHijacking(name);
    AttackStep.allAttackSteps.remove(registryRunKeysOrStartupFolder);
    registryRunKeysOrStartupFolder = new RegistryRunKeysOrStartupFolder(name);
    AttackStep.allAttackSteps.remove(regsvcsOrRegasm);
    regsvcsOrRegasm = new RegsvcsOrRegasm(name);
    AttackStep.allAttackSteps.remove(regsvr32);
    regsvr32 = new Regsvr32(name);
    AttackStep.allAttackSteps.remove(attemptRemoteDesktopProtocol);
    attemptRemoteDesktopProtocol = new AttemptRemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(remoteDesktopProtocol);
    remoteDesktopProtocol = new RemoteDesktopProtocol(name);
    AttackStep.allAttackSteps.remove(replicationThroughRemovableMedia);
    replicationThroughRemovableMedia = new ReplicationThroughRemovableMedia(name);
    AttackStep.allAttackSteps.remove(rootkit);
    rootkit = new Rootkit(name);
    AttackStep.allAttackSteps.remove(rundll32);
    rundll32 = new Rundll32(name);
    AttackStep.allAttackSteps.remove(screensaver);
    screensaver = new Screensaver(name);
    AttackStep.allAttackSteps.remove(searchOrderHijacking);
    searchOrderHijacking = new SearchOrderHijacking(name);
    AttackStep.allAttackSteps.remove(securitySupportProvider);
    securitySupportProvider = new SecuritySupportProvider(name);
    AttackStep.allAttackSteps.remove(attemptServiceExecution);
    attemptServiceExecution = new AttemptServiceExecution(name);
    AttackStep.allAttackSteps.remove(serviceExecution);
    serviceExecution = new ServiceExecution(name);
    AttackStep.allAttackSteps.remove(attemptServiceRegistryPermissionsWeakness);
    attemptServiceRegistryPermissionsWeakness = new AttemptServiceRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(serviceRegistryPermissionsWeakness);
    serviceRegistryPermissionsWeakness = new ServiceRegistryPermissionsWeakness(name);
    AttackStep.allAttackSteps.remove(attemptShortcutModification);
    attemptShortcutModification = new AttemptShortcutModification(name);
    AttackStep.allAttackSteps.remove(shortcutModification);
    shortcutModification = new ShortcutModification(name);
    AttackStep.allAttackSteps.remove(attemptSIDHistoryInjection);
    attemptSIDHistoryInjection = new AttemptSIDHistoryInjection(name);
    AttackStep.allAttackSteps.remove(sIDHistoryInjection);
    sIDHistoryInjection = new SIDHistoryInjection(name);
    AttackStep.allAttackSteps.remove(signedBinaryProxyExecution);
    signedBinaryProxyExecution = new SignedBinaryProxyExecution(name);
    AttackStep.allAttackSteps.remove(signedScriptProxyExecution);
    signedScriptProxyExecution = new SignedScriptProxyExecution(name);
    AttackStep.allAttackSteps.remove(pubPrn);
    pubPrn = new PubPrn(name);
    AttackStep.allAttackSteps.remove(attemptSIPAndTrustProviderHijacking);
    attemptSIPAndTrustProviderHijacking = new AttemptSIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(sIPAndTrustProviderHijacking);
    sIPAndTrustProviderHijacking = new SIPAndTrustProviderHijacking(name);
    AttackStep.allAttackSteps.remove(attemptSoftwarePacking);
    attemptSoftwarePacking = new AttemptSoftwarePacking(name);
    AttackStep.allAttackSteps.remove(softwarePacking);
    softwarePacking = new SoftwarePacking(name);
    AttackStep.allAttackSteps.remove(systemServiceDiscovery);
    systemServiceDiscovery = new SystemServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptTaintSharedContent);
    attemptTaintSharedContent = new AttemptTaintSharedContent(name);
    AttackStep.allAttackSteps.remove(templateInjection);
    templateInjection = new TemplateInjection(name);
    AttackStep.allAttackSteps.remove(attemptTimeProviders);
    attemptTimeProviders = new AttemptTimeProviders(name);
    AttackStep.allAttackSteps.remove(timeProviders);
    timeProviders = new TimeProviders(name);
    AttackStep.allAttackSteps.remove(trustedDeveloperUtilities);
    trustedDeveloperUtilities = new TrustedDeveloperUtilities(name);
    AttackStep.allAttackSteps.remove(mSBuild);
    mSBuild = new MSBuild(name);
    AttackStep.allAttackSteps.remove(unquotedPaths);
    unquotedPaths = new UnquotedPaths(name);
    AttackStep.allAttackSteps.remove(attemptServiceStop);
    attemptServiceStop = new AttemptServiceStop(name);
    AttackStep.allAttackSteps.remove(serviceStop);
    serviceStop = new ServiceStop(name);
    AttackStep.allAttackSteps.remove(attemptScheduledTask);
    attemptScheduledTask = new AttemptScheduledTask(name);
    AttackStep.allAttackSteps.remove(scheduledTask);
    scheduledTask = new ScheduledTask(name);
    AttackStep.allAttackSteps.remove(remoteScheduledTask);
    remoteScheduledTask = new RemoteScheduledTask(name);
    AttackStep.allAttackSteps.remove(attemptSystemTimeDiscovery);
    attemptSystemTimeDiscovery = new AttemptSystemTimeDiscovery(name);
    AttackStep.allAttackSteps.remove(systemTimeDiscovery);
    systemTimeDiscovery = new SystemTimeDiscovery(name);
    AttackStep.allAttackSteps.remove(unsecuredCredentials);
    unsecuredCredentials = new UnsecuredCredentials(name);
    AttackStep.allAttackSteps.remove(attemptWindowsAdminShares);
    attemptWindowsAdminShares = new AttemptWindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(windowsAdminShares);
    windowsAdminShares = new WindowsAdminShares(name);
    AttackStep.allAttackSteps.remove(windowsCommandShell);
    windowsCommandShell = new WindowsCommandShell(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentation);
    windowsManagementInstrumentation = new WindowsManagementInstrumentation(name);
    AttackStep.allAttackSteps.remove(attemptWindowsManagementInstrumentationEventSubscription);
    attemptWindowsManagementInstrumentationEventSubscription = new AttemptWindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(windowsManagementInstrumentationEventSubscription);
    windowsManagementInstrumentationEventSubscription = new WindowsManagementInstrumentationEventSubscription(name);
    AttackStep.allAttackSteps.remove(attemptWindowsRemoteManagement);
    attemptWindowsRemoteManagement = new AttemptWindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(windowsRemoteManagement);
    windowsRemoteManagement = new WindowsRemoteManagement(name);
    AttackStep.allAttackSteps.remove(attemptWinlogonHelperDLL);
    attemptWinlogonHelperDLL = new AttemptWinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(winlogonHelperDLL);
    winlogonHelperDLL = new WinlogonHelperDLL(name);
    AttackStep.allAttackSteps.remove(remoteFileCopy);
    remoteFileCopy = new RemoteFileCopy(name);
    AttackStep.allAttackSteps.remove(attemptRegistryKeysEnabled);
    attemptRegistryKeysEnabled = new AttemptRegistryKeysEnabled(name);
    AttackStep.allAttackSteps.remove(registryKeysEnabled);
    registryKeysEnabled = new RegistryKeysEnabled(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(attemptDynamicDataExchange);
    attemptDynamicDataExchange = new AttemptDynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(dynamicDataExchange);
    dynamicDataExchange = new DynamicDataExchange(name);
    AttackStep.allAttackSteps.remove(captureAPICalls);
    captureAPICalls = new CaptureAPICalls(name);
    AttackStep.allAttackSteps.remove(attemptLogonScripts);
    attemptLogonScripts = new AttemptLogonScripts(name);
    AttackStep.allAttackSteps.remove(logonScripts);
    logonScripts = new LogonScripts(name);
    AttackStep.allAttackSteps.remove(attemptSystemFirmware);
    attemptSystemFirmware = new AttemptSystemFirmware(name);
    AttackStep.allAttackSteps.remove(systemFirmware);
    systemFirmware = new SystemFirmware(name);
    AttackStep.allAttackSteps.remove(systemShutdownOrReboot);
    systemShutdownOrReboot = new SystemShutdownOrReboot(name);
    AttackStep.allAttackSteps.remove(queryRegistry);
    queryRegistry = new QueryRegistry(name);
    AttackStep.allAttackSteps.remove(networkShareDiscovery);
    networkShareDiscovery = new NetworkShareDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptAccessTokenManipulation);
    attemptAccessTokenManipulation = new AttemptAccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(accessTokenManipulation);
    accessTokenManipulation = new AccessTokenManipulation(name);
    AttackStep.allAttackSteps.remove(tokenImpersonationOrTheft);
    tokenImpersonationOrTheft = new TokenImpersonationOrTheft(name);
    AttackStep.allAttackSteps.remove(createProcessWithAToken);
    createProcessWithAToken = new CreateProcessWithAToken(name);
    AttackStep.allAttackSteps.remove(makeAndImpersonateToken);
    makeAndImpersonateToken = new MakeAndImpersonateToken(name);
    AttackStep.allAttackSteps.remove(attemptBypassUserAccessControl);
    attemptBypassUserAccessControl = new AttemptBypassUserAccessControl(name);
    AttackStep.allAttackSteps.remove(bypassUserAccessControl);
    bypassUserAccessControl = new BypassUserAccessControl(name);
    AttackStep.allAttackSteps.remove(obfuscatedFilesOrInformation);
    obfuscatedFilesOrInformation = new ObfuscatedFilesOrInformation(name);
    AttackStep.allAttackSteps.remove(oSCredentialDumping);
    oSCredentialDumping = new OSCredentialDumping(name);
    AttackStep.allAttackSteps.remove(peripheralDeviceDiscovery);
    peripheralDeviceDiscovery = new PeripheralDeviceDiscovery(name);
    AttackStep.allAttackSteps.remove(portMonitors);
    portMonitors = new PortMonitors(name);
    AttackStep.allAttackSteps.remove(emailCollection);
    emailCollection = new EmailCollection(name);
    AttackStep.allAttackSteps.remove(localEmailCollection);
    localEmailCollection = new LocalEmailCollection(name);
    AttackStep.allAttackSteps.remove(remoteEmailCollection);
    remoteEmailCollection = new RemoteEmailCollection(name);
    AttackStep.allAttackSteps.remove(emailForwardingRule);
    emailForwardingRule = new EmailForwardingRule(name);
    AttackStep.allAttackSteps.remove(attemptApplicationShimming);
    attemptApplicationShimming = new AttemptApplicationShimming(name);
    AttackStep.allAttackSteps.remove(applicationShimming);
    applicationShimming = new ApplicationShimming(name);
    AttackStep.allAttackSteps.remove(authenticationPackage);
    authenticationPackage = new AuthenticationPackage(name);
    AttackStep.allAttackSteps.remove(changeDefaultFileAssociation);
    changeDefaultFileAssociation = new ChangeDefaultFileAssociation(name);
    AttackStep.allAttackSteps.remove(trustedDomainInfo);
    trustedDomainInfo = new TrustedDomainInfo(name);
    AttackStep.allAttackSteps.remove(domainTrustDiscovery);
    domainTrustDiscovery = new DomainTrustDiscovery(name);
    AttackStep.allAttackSteps.remove(attemptBootkit);
    attemptBootkit = new AttemptBootkit(name);
    AttackStep.allAttackSteps.remove(bootkit);
    bootkit = new Bootkit(name);
    AttackStep.allAttackSteps.remove(videoCapture);
    videoCapture = new VideoCapture(name);
    AttackStep.allAttackSteps.remove(xslScriptProcessing);
    xslScriptProcessing = new XslScriptProcessing(name);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, false);
    if (antivirus != null) {
      AttackStep.allAttackSteps.remove(antivirus.disable);
    }
    Defense.allDefenses.remove(antivirus);
    antivirus = new Antivirus(name, false);
    if (applicationIsolationAndSandboxing != null) {
      AttackStep.allAttackSteps.remove(applicationIsolationAndSandboxing.disable);
    }
    Defense.allDefenses.remove(applicationIsolationAndSandboxing);
    applicationIsolationAndSandboxing = new ApplicationIsolationAndSandboxing(name, false);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, false);
    if (behaviorPreventionOnEndpoint != null) {
      AttackStep.allAttackSteps.remove(behaviorPreventionOnEndpoint.disable);
    }
    Defense.allDefenses.remove(behaviorPreventionOnEndpoint);
    behaviorPreventionOnEndpoint = new BehaviorPreventionOnEndpoint(name, false);
    if (codeSigning != null) {
      AttackStep.allAttackSteps.remove(codeSigning.disable);
    }
    Defense.allDefenses.remove(codeSigning);
    codeSigning = new CodeSigning(name, false);
    if (credentialAccessProtection != null) {
      AttackStep.allAttackSteps.remove(credentialAccessProtection.disable);
    }
    Defense.allDefenses.remove(credentialAccessProtection);
    credentialAccessProtection = new CredentialAccessProtection(name, false);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, false);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, false);
    if (limitHardwareInstallation != null) {
      AttackStep.allAttackSteps.remove(limitHardwareInstallation.disable);
    }
    Defense.allDefenses.remove(limitHardwareInstallation);
    limitHardwareInstallation = new LimitHardwareInstallation(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (operatingSystemConfiguration != null) {
      AttackStep.allAttackSteps.remove(operatingSystemConfiguration.disable);
    }
    Defense.allDefenses.remove(operatingSystemConfiguration);
    operatingSystemConfiguration = new OperatingSystemConfiguration(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
    if (privilegedProcessIntegrity != null) {
      AttackStep.allAttackSteps.remove(privilegedProcessIntegrity.disable);
    }
    Defense.allDefenses.remove(privilegedProcessIntegrity);
    privilegedProcessIntegrity = new PrivilegedProcessIntegrity(name, false);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, false);
    if (restrictFileAndDirectoryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictFileAndDirectoryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictFileAndDirectoryPermissions);
    restrictFileAndDirectoryPermissions = new RestrictFileAndDirectoryPermissions(name, false);
    if (restrictRegistryPermissions != null) {
      AttackStep.allAttackSteps.remove(restrictRegistryPermissions.disable);
    }
    Defense.allDefenses.remove(restrictRegistryPermissions);
    restrictRegistryPermissions = new RestrictRegistryPermissions(name, false);
    if (restrictLibraryLoading != null) {
      AttackStep.allAttackSteps.remove(restrictLibraryLoading.disable);
    }
    Defense.allDefenses.remove(restrictLibraryLoading);
    restrictLibraryLoading = new RestrictLibraryLoading(name, false);
    if (remoteDataStorage != null) {
      AttackStep.allAttackSteps.remove(remoteDataStorage.disable);
    }
    Defense.allDefenses.remove(remoteDataStorage);
    remoteDataStorage = new RemoteDataStorage(name, false);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, false);
    if (bootIntegrity != null) {
      AttackStep.allAttackSteps.remove(bootIntegrity.disable);
    }
    Defense.allDefenses.remove(bootIntegrity);
    bootIntegrity = new BootIntegrity(name, false);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, false);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, false);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, false);
    if (userAccountControl != null) {
      AttackStep.allAttackSteps.remove(userAccountControl.disable);
    }
    Defense.allDefenses.remove(userAccountControl);
    userAccountControl = new UserAccountControl(name, false);
  }

  public Windows(boolean isAntivirusEnabled, boolean isRestrictFileAndDirectoryPermissionsEnabled,
      boolean isRestrictRegistryPermissionsEnabled, boolean isAccountUsePoliciesEnabled,
      boolean isBehaviorPreventionOnEndpointEnabled, boolean isBootIntegrityEnabled,
      boolean isDataBackupEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isPasswordPoliciesEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isDoNotMitigateEnabled, boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isAuditEnabled,
      boolean isApplicationDeveloperGuidanceEnabled, boolean isCodeSigningEnabled,
      boolean isLimitHardwareInstallationEnabled, boolean isOperatingSystemConfigurationEnabled,
      boolean isSoftwareConfigurationEnabled, boolean isExecutionPreventionEnabled,
      boolean isPrivilegedAccountManagementEnabled, boolean isEncryptSensitiveInformationEnabled,
      boolean isRemoteDataStorageEnabled, boolean isLimitSoftwareInstallationEnabled,
      boolean isUpdateSoftwareEnabled, boolean isUserAccountControlEnabled,
      boolean isExploitProtectionEnabled, boolean isCredentialAccessProtectionEnabled,
      boolean isPrivilegedProcessIntegrityEnabled, boolean isRestrictLibraryLoadingEnabled) {
    this("Anonymous", isAntivirusEnabled, isRestrictFileAndDirectoryPermissionsEnabled, isRestrictRegistryPermissionsEnabled, isAccountUsePoliciesEnabled, isBehaviorPreventionOnEndpointEnabled, isBootIntegrityEnabled, isDataBackupEnabled, isMultiFactorAuthenticationEnabled, isPasswordPoliciesEnabled, isApplicationIsolationAndSandboxingEnabled, isDoNotMitigateEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isActiveDirectoryConfigurationEnabled, isAuditEnabled, isApplicationDeveloperGuidanceEnabled, isCodeSigningEnabled, isLimitHardwareInstallationEnabled, isOperatingSystemConfigurationEnabled, isSoftwareConfigurationEnabled, isExecutionPreventionEnabled, isPrivilegedAccountManagementEnabled, isEncryptSensitiveInformationEnabled, isRemoteDataStorageEnabled, isLimitSoftwareInstallationEnabled, isUpdateSoftwareEnabled, isUserAccountControlEnabled, isExploitProtectionEnabled, isCredentialAccessProtectionEnabled, isPrivilegedProcessIntegrityEnabled, isRestrictLibraryLoadingEnabled);
  }

  public Windows() {
    this("Anonymous");
  }

  public class AbuseElevationControlMechanism extends OS.AbuseElevationControlMechanism {
    private Set<AttackStep> _cacheChildrenAbuseElevationControlMechanism;

    public AbuseElevationControlMechanism(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAbuseElevationControlMechanism == null) {
        _cacheChildrenAbuseElevationControlMechanism = new HashSet<>();
        _cacheChildrenAbuseElevationControlMechanism.add(attemptBypassUserAccessControl);
      }
      for (AttackStep attackStep : _cacheChildrenAbuseElevationControlMechanism) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.abuseElevationControlMechanism");
    }
  }

  public class AccountManipulation extends OS.AccountManipulation {
    private Set<AttackStep> _cacheChildrenAccountManipulation;

    private Set<AttackStep> _cacheParentAccountManipulation;

    public AccountManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAccountManipulation == null) {
        _cacheChildrenAccountManipulation = new HashSet<>();
        _cacheChildrenAccountManipulation.add(exchangeEmailDelegatePermissions);
      }
      for (AttackStep attackStep : _cacheChildrenAccountManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccountManipulation == null) {
        _cacheParentAccountManipulation = new HashSet<>();
        _cacheParentAccountManipulation.add(dCSync);
      }
      for (AttackStep attackStep : _cacheParentAccountManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.accountManipulation");
    }
  }

  public class At extends OS.At {
    private Set<AttackStep> _cacheChildrenAt;

    private Set<AttackStep> _cacheParentAt;

    public At(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAt == null) {
        _cacheChildrenAt = new HashSet<>();
        _cacheChildrenAt.add(attemptScheduledTask);
        _cacheChildrenAt.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenAt) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAt == null) {
        _cacheParentAt = new HashSet<>();
        _cacheParentAt.add(scheduledTaskOrJob);
        _cacheParentAt.add(audit.disable);
        _cacheParentAt.add(operatingSystemConfiguration.disable);
        _cacheParentAt.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentAt) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.at");
    }
  }

  public class AttemptAppCertDLLs extends OS.AttemptAppCertDLLs {
    private Set<AttackStep> _cacheChildrenAttemptAppCertDLLs;

    private Set<AttackStep> _cacheParentAttemptAppCertDLLs;

    public AttemptAppCertDLLs(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptAppCertDLLs == null) {
        _cacheChildrenAttemptAppCertDLLs = new HashSet<>();
        _cacheChildrenAttemptAppCertDLLs.add(appCertDLLs);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptAppCertDLLs) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptAppCertDLLs == null) {
        _cacheParentAttemptAppCertDLLs = new HashSet<>();
        _cacheParentAttemptAppCertDLLs.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptAppCertDLLs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptAppCertDLLs");
    }
  }

  public class AppCertDLLs extends OS.AppCertDLLs {
    private Set<AttackStep> _cacheChildrenAppCertDLLs;

    private Set<AttackStep> _cacheParentAppCertDLLs;

    public AppCertDLLs(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAppCertDLLs == null) {
        _cacheChildrenAppCertDLLs = new HashSet<>();
        _cacheChildrenAppCertDLLs.add(processInjection);
      }
      for (AttackStep attackStep : _cacheChildrenAppCertDLLs) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAppCertDLLs == null) {
        _cacheParentAppCertDLLs = new HashSet<>();
        _cacheParentAppCertDLLs.add(attemptAppCertDLLs);
        _cacheParentAppCertDLLs.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentAppCertDLLs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.appCertDLLs");
    }
  }

  public class AttemptAppInitDLLs extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptAppInitDLLs;

    private Set<AttackStep> _cacheParentAttemptAppInitDLLs;

    public AttemptAppInitDLLs(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptAppInitDLLs == null) {
        _cacheChildrenAttemptAppInitDLLs = new HashSet<>();
        _cacheChildrenAttemptAppInitDLLs.add(appInitDLLs);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptAppInitDLLs) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptAppInitDLLs == null) {
        _cacheParentAttemptAppInitDLLs = new HashSet<>();
        _cacheParentAttemptAppInitDLLs.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptAppInitDLLs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptAppInitDLLs");
    }
  }

  public class AppInitDLLs extends OS.AppInitDLLs {
    private Set<AttackStep> _cacheChildrenAppInitDLLs;

    private Set<AttackStep> _cacheParentAppInitDLLs;

    public AppInitDLLs(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAppInitDLLs == null) {
        _cacheChildrenAppInitDLLs = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenAppInitDLLs.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenAppInitDLLs) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAppInitDLLs == null) {
        _cacheParentAppInitDLLs = new HashSet<>();
        _cacheParentAppInitDLLs.add(attemptAppInitDLLs);
        _cacheParentAppInitDLLs.add(executionPrevention.disable);
        _cacheParentAppInitDLLs.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentAppInitDLLs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.appInitDLLs");
    }
  }

  public class AttemptAccessibilityFeatures extends OS.AttemptAccessibilityFeatures {
    private Set<AttackStep> _cacheChildrenAttemptAccessibilityFeatures;

    private Set<AttackStep> _cacheParentAttemptAccessibilityFeatures;

    public AttemptAccessibilityFeatures(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptAccessibilityFeatures == null) {
        _cacheChildrenAttemptAccessibilityFeatures = new HashSet<>();
        _cacheChildrenAttemptAccessibilityFeatures.add(accessibilityFeatures);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptAccessibilityFeatures) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptAccessibilityFeatures == null) {
        _cacheParentAttemptAccessibilityFeatures = new HashSet<>();
        _cacheParentAttemptAccessibilityFeatures.add(eventTriggeredExecution);
        _cacheParentAttemptAccessibilityFeatures.add(windowsFileAndDirectoryPermissionsModification);
        _cacheParentAttemptAccessibilityFeatures.add(remoteDesktopProtocol);
      }
      for (AttackStep attackStep : _cacheParentAttemptAccessibilityFeatures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptAccessibilityFeatures");
    }
  }

  public class AccessibilityFeatures extends OS.AccessibilityFeatures {
    private Set<AttackStep> _cacheChildrenAccessibilityFeatures;

    private Set<AttackStep> _cacheParentAccessibilityFeatures;

    public AccessibilityFeatures(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAccessibilityFeatures == null) {
        _cacheChildrenAccessibilityFeatures = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenAccessibilityFeatures.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenAccessibilityFeatures) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccessibilityFeatures == null) {
        _cacheParentAccessibilityFeatures = new HashSet<>();
        _cacheParentAccessibilityFeatures.add(attemptAccessibilityFeatures);
        _cacheParentAccessibilityFeatures.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentAccessibilityFeatures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.accessibilityFeatures");
    }
  }

  public class AttemptBITSJobs extends OS.AttemptBITSJobs {
    private Set<AttackStep> _cacheChildrenAttemptBITSJobs;

    public AttemptBITSJobs(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptBITSJobs == null) {
        _cacheChildrenAttemptBITSJobs = new HashSet<>();
        _cacheChildrenAttemptBITSJobs.add(bITSJobs);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBITSJobs) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptBITSJobs");
    }
  }

  public class BITSJobs extends OS.BITSJobs {
    private Set<AttackStep> _cacheChildrenBITSJobs;

    private Set<AttackStep> _cacheParentBITSJobs;

    public BITSJobs(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBITSJobs == null) {
        _cacheChildrenBITSJobs = new HashSet<>();
        _cacheChildrenBITSJobs.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenBITSJobs.add(((asset.Windows) Windows.this).persistence);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenBITSJobs.add(((asset.Windows) Windows.this).attemptExfiltrationOverAternativeProtocol);
        }
      }
      for (AttackStep attackStep : _cacheChildrenBITSJobs) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBITSJobs == null) {
        _cacheParentBITSJobs = new HashSet<>();
        _cacheParentBITSJobs.add(attemptBITSJobs);
        _cacheParentBITSJobs.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentBITSJobs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.bITSJobs");
    }
  }

  public class BootOrLogonAutostartExecution extends OS.BootOrLogonAutostartExecution {
    private Set<AttackStep> _cacheChildrenBootOrLogonAutostartExecution;

    public BootOrLogonAutostartExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBootOrLogonAutostartExecution == null) {
        _cacheChildrenBootOrLogonAutostartExecution = new HashSet<>();
        _cacheChildrenBootOrLogonAutostartExecution.add(registryRunKeysOrStartupFolder);
        _cacheChildrenBootOrLogonAutostartExecution.add(authenticationPackage);
        _cacheChildrenBootOrLogonAutostartExecution.add(attemptTimeProviders);
        _cacheChildrenBootOrLogonAutostartExecution.add(attemptWinlogonHelperDLL);
        _cacheChildrenBootOrLogonAutostartExecution.add(attemptLSASSDriver);
        _cacheChildrenBootOrLogonAutostartExecution.add(attemptShortcutModification);
        _cacheChildrenBootOrLogonAutostartExecution.add(securitySupportProvider);
        _cacheChildrenBootOrLogonAutostartExecution.add(portMonitors);
      }
      for (AttackStep attackStep : _cacheChildrenBootOrLogonAutostartExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.bootOrLogonAutostartExecution");
    }
  }

  public class AttemptBootOrLogonInitializationScripts extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBootOrLogonInitializationScripts;

    public AttemptBootOrLogonInitializationScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBootOrLogonInitializationScripts == null) {
        _cacheChildrenAttemptBootOrLogonInitializationScripts = new HashSet<>();
        _cacheChildrenAttemptBootOrLogonInitializationScripts.add(bootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBootOrLogonInitializationScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptBootOrLogonInitializationScripts");
    }
  }

  public class BootOrLogonInitializationScripts extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenBootOrLogonInitializationScripts;

    private Set<AttackStep> _cacheParentBootOrLogonInitializationScripts;

    public BootOrLogonInitializationScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBootOrLogonInitializationScripts == null) {
        _cacheChildrenBootOrLogonInitializationScripts = new HashSet<>();
        _cacheChildrenBootOrLogonInitializationScripts.add(attemptLogonScripts);
        _cacheChildrenBootOrLogonInitializationScripts.add(networkLogonScripts);
      }
      for (AttackStep attackStep : _cacheChildrenBootOrLogonInitializationScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBootOrLogonInitializationScripts == null) {
        _cacheParentBootOrLogonInitializationScripts = new HashSet<>();
        _cacheParentBootOrLogonInitializationScripts.add(attemptBootOrLogonInitializationScripts);
        _cacheParentBootOrLogonInitializationScripts.add(windowsFileAndDirectoryPermissionsModification);
        _cacheParentBootOrLogonInitializationScripts.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentBootOrLogonInitializationScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.bootOrLogonInitializationScripts");
    }
  }

  public class NetworkLogonScripts extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenNetworkLogonScripts;

    private Set<AttackStep> _cacheParentNetworkLogonScripts;

    public NetworkLogonScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNetworkLogonScripts == null) {
        _cacheChildrenNetworkLogonScripts = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenNetworkLogonScripts.add(_2.persistence);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenNetworkLogonScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkLogonScripts == null) {
        _cacheParentNetworkLogonScripts = new HashSet<>();
        _cacheParentNetworkLogonScripts.add(bootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheParentNetworkLogonScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.networkLogonScripts");
    }
  }

  public class ClearWindowsEventLogs extends OS.ClearWindowsEventLogs {
    private Set<AttackStep> _cacheChildrenClearWindowsEventLogs;

    private Set<AttackStep> _cacheParentClearWindowsEventLogs;

    public ClearWindowsEventLogs(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenClearWindowsEventLogs == null) {
        _cacheChildrenClearWindowsEventLogs = new HashSet<>();
        _cacheChildrenClearWindowsEventLogs.add(attemptPowerShell);
        if (Windows.this instanceof Windows) {
          _cacheChildrenClearWindowsEventLogs.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenClearWindowsEventLogs.add(((asset.Windows) Windows.this).bypassHostIntrusionPrevention);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenClearWindowsEventLogs.add(((asset.Windows) Windows.this).bypassLogAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenClearWindowsEventLogs) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentClearWindowsEventLogs == null) {
        _cacheParentClearWindowsEventLogs = new HashSet<>();
        _cacheParentClearWindowsEventLogs.add(indicatorRemovalOnHost);
        _cacheParentClearWindowsEventLogs.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentClearWindowsEventLogs.add(remoteDataStorage.disable);
        _cacheParentClearWindowsEventLogs.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentClearWindowsEventLogs) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.clearWindowsEventLogs");
    }
  }

  public class Cmstp extends OS.Cmstp {
    private Set<AttackStep> _cacheChildrenCmstp;

    private Set<AttackStep> _cacheParentCmstp;

    public Cmstp(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCmstp == null) {
        _cacheChildrenCmstp = new HashSet<>();
        _cacheChildrenCmstp.add(attemptBypassUserAccessControl);
        _cacheChildrenCmstp.add(codeProxyExecution);
        if (Windows.this instanceof Windows) {
          _cacheChildrenCmstp.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCmstp) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCmstp == null) {
        _cacheParentCmstp = new HashSet<>();
        _cacheParentCmstp.add(signedBinaryProxyExecution);
        _cacheParentCmstp.add(executionPrevention.disable);
        _cacheParentCmstp.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentCmstp) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.cmstp");
    }
  }

  public class CodeSigningCertificate extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCodeSigningCertificate;

    private Set<AttackStep> _cacheParentCodeSigningCertificate;

    public CodeSigningCertificate(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCodeSigningCertificate == null) {
        _cacheChildrenCodeSigningCertificate = new HashSet<>();
        _cacheChildrenCodeSigningCertificate.add(attemptBypassUserAccessControl);
      }
      for (AttackStep attackStep : _cacheChildrenCodeSigningCertificate) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCodeSigningCertificate == null) {
        _cacheParentCodeSigningCertificate = new HashSet<>();
        _cacheParentCodeSigningCertificate.add(subvertTrustControls);
      }
      for (AttackStep attackStep : _cacheParentCodeSigningCertificate) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.codeSigningCertificate");
    }
  }

  public class CollectHashInformation extends OS.CollectHashInformation {
    private Set<AttackStep> _cacheChildrenCollectHashInformation;

    private Set<AttackStep> _cacheParentCollectHashInformation;

    public CollectHashInformation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCollectHashInformation == null) {
        _cacheChildrenCollectHashInformation = new HashSet<>();
        _cacheChildrenCollectHashInformation.add(attemptPassTheHash);
        if (Windows.this instanceof Windows) {
          _cacheChildrenCollectHashInformation.add(((asset.Windows) Windows.this).networkSniffing);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCollectHashInformation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCollectHashInformation == null) {
        _cacheParentCollectHashInformation = new HashSet<>();
        _cacheParentCollectHashInformation.add(cachedDomainCredentials);
        _cacheParentCollectHashInformation.add(nTDS);
        _cacheParentCollectHashInformation.add(securityAccountManager);
      }
      for (AttackStep attackStep : _cacheParentCollectHashInformation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.collectHashInformation");
    }
  }

  public class CommandAndScriptingInterpreter extends OS.CommandAndScriptingInterpreter {
    private Set<AttackStep> _cacheChildrenCommandAndScriptingInterpreter;

    private Set<AttackStep> _cacheParentCommandAndScriptingInterpreter;

    public CommandAndScriptingInterpreter(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCommandAndScriptingInterpreter == null) {
        _cacheChildrenCommandAndScriptingInterpreter = new HashSet<>();
        _cacheChildrenCommandAndScriptingInterpreter.add(windowsCommandShell);
        _cacheChildrenCommandAndScriptingInterpreter.add(attemptPowerShell);
      }
      for (AttackStep attackStep : _cacheChildrenCommandAndScriptingInterpreter) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCommandAndScriptingInterpreter == null) {
        _cacheParentCommandAndScriptingInterpreter = new HashSet<>();
        _cacheParentCommandAndScriptingInterpreter.add(parentPIDSpoofing);
        _cacheParentCommandAndScriptingInterpreter.add(attemptPowerShell);
        _cacheParentCommandAndScriptingInterpreter.add(dynamicDataExchange);
        _cacheParentCommandAndScriptingInterpreter.add(queryRegistry);
      }
      for (AttackStep attackStep : _cacheParentCommandAndScriptingInterpreter) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.commandAndScriptingInterpreter");
    }
  }

  public class AttemptComponentObjectModel extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptComponentObjectModel;

    private Set<AttackStep> _cacheParentAttemptComponentObjectModel;

    public AttemptComponentObjectModel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptComponentObjectModel == null) {
        _cacheChildrenAttemptComponentObjectModel = new HashSet<>();
        _cacheChildrenAttemptComponentObjectModel.add(componentObjectModel);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptComponentObjectModel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptComponentObjectModel == null) {
        _cacheParentAttemptComponentObjectModel = new HashSet<>();
        _cacheParentAttemptComponentObjectModel.add(cOR_PROFILER);
        _cacheParentAttemptComponentObjectModel.add(interProcessCommunication);
        _cacheParentAttemptComponentObjectModel.add(regsvcsOrRegasm);
      }
      for (AttackStep attackStep : _cacheParentAttemptComponentObjectModel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptComponentObjectModel");
    }
  }

  public class ComponentObjectModel extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenComponentObjectModel;

    private Set<AttackStep> _cacheParentComponentObjectModel;

    public ComponentObjectModel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenComponentObjectModel == null) {
        _cacheChildrenComponentObjectModel = new HashSet<>();
        _cacheChildrenComponentObjectModel.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenComponentObjectModel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentComponentObjectModel == null) {
        _cacheParentComponentObjectModel = new HashSet<>();
        _cacheParentComponentObjectModel.add(attemptComponentObjectModel);
        _cacheParentComponentObjectModel.add(applicationIsolationAndSandboxing.disable);
        _cacheParentComponentObjectModel.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentComponentObjectModel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.componentObjectModel");
    }
  }

  public class CreateOrModifySystemProcess extends OS.CreateOrModifySystemProcess {
    private Set<AttackStep> _cacheChildrenCreateOrModifySystemProcess;

    public CreateOrModifySystemProcess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCreateOrModifySystemProcess == null) {
        _cacheChildrenCreateOrModifySystemProcess = new HashSet<>();
        _cacheChildrenCreateOrModifySystemProcess.add(attemptWindowsService);
      }
      for (AttackStep attackStep : _cacheChildrenCreateOrModifySystemProcess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.createOrModifySystemProcess");
    }
  }

  public class AttemptDistributedComponentObjectModel extends OS.AttemptDistributedComponentObjectModel {
    private Set<AttackStep> _cacheChildrenAttemptDistributedComponentObjectModel;

    public AttemptDistributedComponentObjectModel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptDistributedComponentObjectModel == null) {
        _cacheChildrenAttemptDistributedComponentObjectModel = new HashSet<>();
        _cacheChildrenAttemptDistributedComponentObjectModel.add(distributedComponentObjectModel);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDistributedComponentObjectModel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptDistributedComponentObjectModel");
    }
  }

  public class DistributedComponentObjectModel extends OS.DistributedComponentObjectModel {
    private Set<AttackStep> _cacheChildrenDistributedComponentObjectModel;

    private Set<AttackStep> _cacheParentDistributedComponentObjectModel;

    public DistributedComponentObjectModel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDistributedComponentObjectModel == null) {
        _cacheChildrenDistributedComponentObjectModel = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenDistributedComponentObjectModel.add(_2.remoteCOMExecution);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDistributedComponentObjectModel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDistributedComponentObjectModel == null) {
        _cacheParentDistributedComponentObjectModel = new HashSet<>();
        _cacheParentDistributedComponentObjectModel.add(attemptDistributedComponentObjectModel);
        _cacheParentDistributedComponentObjectModel.add(applicationIsolationAndSandboxing.disable);
        _cacheParentDistributedComponentObjectModel.add(privilegedAccountManagement.disable);
        _cacheParentDistributedComponentObjectModel.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentDistributedComponentObjectModel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.distributedComponentObjectModel");
    }
  }

  public class AttemptControlPanel extends OS.AttemptControlPanel {
    private Set<AttackStep> _cacheChildrenAttemptControlPanel;

    private Set<AttackStep> _cacheParentAttemptControlPanel;

    public AttemptControlPanel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptControlPanel == null) {
        _cacheChildrenAttemptControlPanel = new HashSet<>();
        _cacheChildrenAttemptControlPanel.add(controlPanel);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptControlPanel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptControlPanel == null) {
        _cacheParentAttemptControlPanel = new HashSet<>();
        _cacheParentAttemptControlPanel.add(rundll32);
        _cacheParentAttemptControlPanel.add(signedBinaryProxyExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptControlPanel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptControlPanel");
    }
  }

  public class ControlPanel extends OS.ControlPanel {
    private Set<AttackStep> _cacheChildrenControlPanel;

    private Set<AttackStep> _cacheParentControlPanel;

    public ControlPanel(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenControlPanel == null) {
        _cacheChildrenControlPanel = new HashSet<>();
        _cacheChildrenControlPanel.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenControlPanel.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenControlPanel.add(_1.phishing);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenControlPanel) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentControlPanel == null) {
        _cacheParentControlPanel = new HashSet<>();
        _cacheParentControlPanel.add(attemptControlPanel);
        _cacheParentControlPanel.add(executionPrevention.disable);
        _cacheParentControlPanel.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentControlPanel) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.controlPanel");
    }
  }

  public class ComponentObjectModelHijacking extends OS.ComponentObjectModelHijacking {
    private Set<AttackStep> _cacheChildrenComponentObjectModelHijacking;

    private Set<AttackStep> _cacheParentComponentObjectModelHijacking;

    public ComponentObjectModelHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenComponentObjectModelHijacking == null) {
        _cacheChildrenComponentObjectModelHijacking = new HashSet<>();
        _cacheChildrenComponentObjectModelHijacking.add(processInjection);
        if (Windows.this instanceof Windows) {
          _cacheChildrenComponentObjectModelHijacking.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenComponentObjectModelHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentComponentObjectModelHijacking == null) {
        _cacheParentComponentObjectModelHijacking = new HashSet<>();
        _cacheParentComponentObjectModelHijacking.add(eventTriggeredExecution);
        _cacheParentComponentObjectModelHijacking.add(regsvr32);
      }
      for (AttackStep attackStep : _cacheParentComponentObjectModelHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.componentObjectModelHijacking");
    }
  }

  public class ComponentFirmware extends OS.ComponentFirmware {
    private Set<AttackStep> _cacheChildrenComponentFirmware;

    private Set<AttackStep> _cacheParentComponentFirmware;

    public ComponentFirmware(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenComponentFirmware == null) {
        _cacheChildrenComponentFirmware = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenComponentFirmware.add(((asset.Windows) Windows.this).bypassFileMonitoring);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenComponentFirmware.add(((asset.Windows) Windows.this).bypassHostIntrusionPrevention);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenComponentFirmware.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
      }
      for (AttackStep attackStep : _cacheChildrenComponentFirmware) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentComponentFirmware == null) {
        _cacheParentComponentFirmware = new HashSet<>();
        _cacheParentComponentFirmware.add(executeCode);
        _cacheParentComponentFirmware.add(preOSBoot);
      }
      for (AttackStep attackStep : _cacheParentComponentFirmware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.componentFirmware");
    }
  }

  public class CompiledHTMLFile extends OS.CompiledHTMLFile {
    private Set<AttackStep> _cacheChildrenCompiledHTMLFile;

    private Set<AttackStep> _cacheParentCompiledHTMLFile;

    public CompiledHTMLFile(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCompiledHTMLFile == null) {
        _cacheChildrenCompiledHTMLFile = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (User _1 : _0.user) {
              _cacheChildrenCompiledHTMLFile.add(_1.attemptUserExecution);
            }
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenCompiledHTMLFile.add(((asset.Windows) Windows.this).bypassApplicationWhitelisting);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenCompiledHTMLFile.add(((asset.Windows) Windows.this).bypassDigitalCertificateValidation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCompiledHTMLFile) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCompiledHTMLFile == null) {
        _cacheParentCompiledHTMLFile = new HashSet<>();
        _cacheParentCompiledHTMLFile.add(signedBinaryProxyExecution);
        _cacheParentCompiledHTMLFile.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentCompiledHTMLFile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.compiledHTMLFile");
    }
  }

  public class AttemptCOR_PROFILER extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptCOR_PROFILER;

    private Set<AttackStep> _cacheParentAttemptCOR_PROFILER;

    public AttemptCOR_PROFILER(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptCOR_PROFILER == null) {
        _cacheChildrenAttemptCOR_PROFILER = new HashSet<>();
        _cacheChildrenAttemptCOR_PROFILER.add(cOR_PROFILER);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptCOR_PROFILER) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptCOR_PROFILER == null) {
        _cacheParentAttemptCOR_PROFILER = new HashSet<>();
        _cacheParentAttemptCOR_PROFILER.add(hijackExecutionFlow);
      }
      for (AttackStep attackStep : _cacheParentAttemptCOR_PROFILER) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptCOR_PROFILER");
    }
  }

  public class COR_PROFILER extends OS.COR_PROFILER {
    private Set<AttackStep> _cacheChildrenCOR_PROFILER;

    private Set<AttackStep> _cacheParentCOR_PROFILER;

    public COR_PROFILER(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCOR_PROFILER == null) {
        _cacheChildrenCOR_PROFILER = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenCOR_PROFILER.add(((asset.Windows) Windows.this).persistence);
        }
        _cacheChildrenCOR_PROFILER.add(attemptBypassUserAccessControl);
        _cacheChildrenCOR_PROFILER.add(attemptComponentObjectModel);
        _cacheChildrenCOR_PROFILER.add(impareDefenses);
      }
      for (AttackStep attackStep : _cacheChildrenCOR_PROFILER) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCOR_PROFILER == null) {
        _cacheParentCOR_PROFILER = new HashSet<>();
        _cacheParentCOR_PROFILER.add(attemptCOR_PROFILER);
        _cacheParentCOR_PROFILER.add(executionPrevention.disable);
        _cacheParentCOR_PROFILER.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentCOR_PROFILER) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.cOR_PROFILER");
    }
  }

  public class CredentialAPIHooking extends OS.CredentialAPIHooking {
    private Set<AttackStep> _cacheChildrenCredentialAPIHooking;

    private Set<AttackStep> _cacheParentCredentialAPIHooking;

    public CredentialAPIHooking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCredentialAPIHooking == null) {
        _cacheChildrenCredentialAPIHooking = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenCredentialAPIHooking.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCredentialAPIHooking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialAPIHooking == null) {
        _cacheParentCredentialAPIHooking = new HashSet<>();
        _cacheParentCredentialAPIHooking.add(inputCapture);
        _cacheParentCredentialAPIHooking.add(rootkit);
        _cacheParentCredentialAPIHooking.add(applicationShimming);
      }
      for (AttackStep attackStep : _cacheParentCredentialAPIHooking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.credentialAPIHooking");
    }
  }

  public class CredentialsInRegistry extends OS.CredentialsInRegistry {
    private Set<AttackStep> _cacheChildrenCredentialsInRegistry;

    private Set<AttackStep> _cacheParentCredentialsInRegistry;

    public CredentialsInRegistry(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCredentialsInRegistry == null) {
        _cacheChildrenCredentialsInRegistry = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenCredentialsInRegistry.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCredentialsInRegistry) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCredentialsInRegistry == null) {
        _cacheParentCredentialsInRegistry = new HashSet<>();
        _cacheParentCredentialsInRegistry.add(unsecuredCredentials);
        _cacheParentCredentialsInRegistry.add(audit.disable);
        _cacheParentCredentialsInRegistry.add(passwordPolicies.disable);
        _cacheParentCredentialsInRegistry.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentCredentialsInRegistry) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.credentialsInRegistry");
    }
  }

  public class DCShadow extends OS.DCShadow {
    private Set<AttackStep> _cacheChildrenDCShadow;

    private Set<AttackStep> _cacheParentDCShadow;

    public DCShadow(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDCShadow == null) {
        _cacheChildrenDCShadow = new HashSet<>();
        _cacheChildrenDCShadow.add(attemptSIDHistoryInjection);
        if (Windows.this instanceof Windows) {
          _cacheChildrenDCShadow.add(((asset.Windows) Windows.this).bypassLogAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenDCShadow) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDCShadow == null) {
        _cacheParentDCShadow = new HashSet<>();
        _cacheParentDCShadow.add(goldenTicket);
      }
      for (AttackStep attackStep : _cacheParentDCShadow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.dCShadow");
    }
  }

  public class DCSync extends OS.DCSync {
    private Set<AttackStep> _cacheChildrenDCSync;

    private Set<AttackStep> _cacheParentDCSync;

    public DCSync(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDCSync == null) {
        _cacheChildrenDCSync = new HashSet<>();
        _cacheChildrenDCSync.add(attemptGoldenTicket);
        _cacheChildrenDCSync.add(attemptSilverTicket);
        _cacheChildrenDCSync.add(accountManipulation);
      }
      for (AttackStep attackStep : _cacheChildrenDCSync) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDCSync == null) {
        _cacheParentDCSync = new HashSet<>();
        _cacheParentDCSync.add(oSCredentialDumping);
        _cacheParentDCSync.add(activeDirectoryConfiguration.disable);
        _cacheParentDCSync.add(passwordPolicies.disable);
        _cacheParentDCSync.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentDCSync) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.dCSync");
    }
  }

  public class DynamicLinkLibraryInjection extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDynamicLinkLibraryInjection;

    private Set<AttackStep> _cacheParentDynamicLinkLibraryInjection;

    public DynamicLinkLibraryInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDynamicLinkLibraryInjection == null) {
        _cacheChildrenDynamicLinkLibraryInjection = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenDynamicLinkLibraryInjection.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenDynamicLinkLibraryInjection.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenDynamicLinkLibraryInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDynamicLinkLibraryInjection == null) {
        _cacheParentDynamicLinkLibraryInjection = new HashSet<>();
        _cacheParentDynamicLinkLibraryInjection.add(processInjection);
        _cacheParentDynamicLinkLibraryInjection.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentDynamicLinkLibraryInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.dynamicLinkLibraryInjection");
    }
  }

  public class PortableExecutableInjection extends OS.PortableExecutableInjection {
    private Set<AttackStep> _cacheChildrenPortableExecutableInjection;

    private Set<AttackStep> _cacheParentPortableExecutableInjection;

    public PortableExecutableInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPortableExecutableInjection == null) {
        _cacheChildrenPortableExecutableInjection = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenPortableExecutableInjection.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenPortableExecutableInjection.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPortableExecutableInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPortableExecutableInjection == null) {
        _cacheParentPortableExecutableInjection = new HashSet<>();
        _cacheParentPortableExecutableInjection.add(processInjection);
        _cacheParentPortableExecutableInjection.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentPortableExecutableInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.portableExecutableInjection");
    }
  }

  public class ThreadExecutionHijacking extends OS.ThreadExecutionHijacking {
    private Set<AttackStep> _cacheChildrenThreadExecutionHijacking;

    private Set<AttackStep> _cacheParentThreadExecutionHijacking;

    public ThreadExecutionHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenThreadExecutionHijacking == null) {
        _cacheChildrenThreadExecutionHijacking = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenThreadExecutionHijacking.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenThreadExecutionHijacking.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenThreadExecutionHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentThreadExecutionHijacking == null) {
        _cacheParentThreadExecutionHijacking = new HashSet<>();
        _cacheParentThreadExecutionHijacking.add(processInjection);
        _cacheParentThreadExecutionHijacking.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentThreadExecutionHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.threadExecutionHijacking");
    }
  }

  public class AsynchronousProcedureCall extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenAsynchronousProcedureCall;

    private Set<AttackStep> _cacheParentAsynchronousProcedureCall;

    public AsynchronousProcedureCall(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAsynchronousProcedureCall == null) {
        _cacheChildrenAsynchronousProcedureCall = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenAsynchronousProcedureCall.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenAsynchronousProcedureCall.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenAsynchronousProcedureCall) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAsynchronousProcedureCall == null) {
        _cacheParentAsynchronousProcedureCall = new HashSet<>();
        _cacheParentAsynchronousProcedureCall.add(processInjection);
        _cacheParentAsynchronousProcedureCall.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentAsynchronousProcedureCall) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.asynchronousProcedureCall");
    }
  }

  public class ThreadLocalStorage extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenThreadLocalStorage;

    private Set<AttackStep> _cacheParentThreadLocalStorage;

    public ThreadLocalStorage(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenThreadLocalStorage == null) {
        _cacheChildrenThreadLocalStorage = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenThreadLocalStorage.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenThreadLocalStorage.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenThreadLocalStorage) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentThreadLocalStorage == null) {
        _cacheParentThreadLocalStorage = new HashSet<>();
        _cacheParentThreadLocalStorage.add(processInjection);
        _cacheParentThreadLocalStorage.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentThreadLocalStorage) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.threadLocalStorage");
    }
  }

  public class DeobfuscateOrDecodeFilesOrInformation extends OS.DeobfuscateOrDecodeFilesOrInformation {
    private Set<AttackStep> _cacheChildrenDeobfuscateOrDecodeFilesOrInformation;

    public DeobfuscateOrDecodeFilesOrInformation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDeobfuscateOrDecodeFilesOrInformation == null) {
        _cacheChildrenDeobfuscateOrDecodeFilesOrInformation = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenDeobfuscateOrDecodeFilesOrInformation.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenDeobfuscateOrDecodeFilesOrInformation.add(((asset.Windows) Windows.this).bypassHostIntrusionPrevention);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenDeobfuscateOrDecodeFilesOrInformation.add(((asset.Windows) Windows.this).bypassSignatureBasedDetection);
        }
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (ExternalNetwork _2 : _1.externalNetwork) {
                _cacheChildrenDeobfuscateOrDecodeFilesOrInformation.add(_2.bypassNetworkIntrusionDetection);
              }
            }
          }
        }
        if (Windows.this instanceof Windows) {
          for (Computer _3 : ((asset.Windows) Windows.this).computer) {
            for (Router _4 : _3.router) {
              for (InternalNetwork _5 : _4.internalNetwork) {
                _cacheChildrenDeobfuscateOrDecodeFilesOrInformation.add(_5.bypassNetworkIntrusionDetection);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDeobfuscateOrDecodeFilesOrInformation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.deobfuscateOrDecodeFilesOrInformation");
    }
  }

  public class DisableWindowsEventLogging extends OS.DisableWindowsEventLogging {
    private Set<AttackStep> _cacheChildrenDisableWindowsEventLogging;

    private Set<AttackStep> _cacheParentDisableWindowsEventLogging;

    public DisableWindowsEventLogging(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDisableWindowsEventLogging == null) {
        _cacheChildrenDisableWindowsEventLogging = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenDisableWindowsEventLogging.add(((asset.Windows) Windows.this).bypassLogAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenDisableWindowsEventLogging) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDisableWindowsEventLogging == null) {
        _cacheParentDisableWindowsEventLogging = new HashSet<>();
        _cacheParentDisableWindowsEventLogging.add(impareDefenses);
        _cacheParentDisableWindowsEventLogging.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentDisableWindowsEventLogging) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.disableWindowsEventLogging");
    }
  }

  public class AttemptDLLSearchOrderHijacking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDLLSearchOrderHijacking;

    private Set<AttackStep> _cacheParentAttemptDLLSearchOrderHijacking;

    public AttemptDLLSearchOrderHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDLLSearchOrderHijacking == null) {
        _cacheChildrenAttemptDLLSearchOrderHijacking = new HashSet<>();
        _cacheChildrenAttemptDLLSearchOrderHijacking.add(dLLSearchOrderHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDLLSearchOrderHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDLLSearchOrderHijacking == null) {
        _cacheParentAttemptDLLSearchOrderHijacking = new HashSet<>();
        _cacheParentAttemptDLLSearchOrderHijacking.add(hijackExecutionFlow);
        _cacheParentAttemptDLLSearchOrderHijacking.add(fileSystemPermissionsWeakness);
        _cacheParentAttemptDLLSearchOrderHijacking.add(executableInstallerFilePermissionsWeakness);
        _cacheParentAttemptDLLSearchOrderHijacking.add(pathInterceptionBySearchOrderHijacking);
        _cacheParentAttemptDLLSearchOrderHijacking.add(searchOrderHijacking);
      }
      for (AttackStep attackStep : _cacheParentAttemptDLLSearchOrderHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptDLLSearchOrderHijacking");
    }
  }

  public class DLLSearchOrderHijacking extends OS.DLLSearchOrderHijacking {
    private Set<AttackStep> _cacheChildrenDLLSearchOrderHijacking;

    private Set<AttackStep> _cacheParentDLLSearchOrderHijacking;

    public DLLSearchOrderHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDLLSearchOrderHijacking == null) {
        _cacheChildrenDLLSearchOrderHijacking = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenDLLSearchOrderHijacking.add(((asset.Windows) Windows.this).bypassProcessWhitelisting);
        }
        _cacheChildrenDLLSearchOrderHijacking.add(attemptBypassUserAccessControl);
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenDLLSearchOrderHijacking.add(_0.userRights);
          }
        }
        _cacheChildrenDLLSearchOrderHijacking.add(attemptLSASSDriver);
        if (Windows.this instanceof Windows) {
          for (Service _1 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenDLLSearchOrderHijacking.add(_1.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDLLSearchOrderHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDLLSearchOrderHijacking == null) {
        _cacheParentDLLSearchOrderHijacking = new HashSet<>();
        _cacheParentDLLSearchOrderHijacking.add(attemptDLLSearchOrderHijacking);
        _cacheParentDLLSearchOrderHijacking.add(audit.disable);
        _cacheParentDLLSearchOrderHijacking.add(executionPrevention.disable);
        _cacheParentDLLSearchOrderHijacking.add(restrictLibraryLoading.disable);
      }
      for (AttackStep attackStep : _cacheParentDLLSearchOrderHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.dLLSearchOrderHijacking");
    }
  }

  public class DLLSideLoading extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenDLLSideLoading;

    private Set<AttackStep> _cacheParentDLLSideLoading;

    public DLLSideLoading(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDLLSideLoading == null) {
        _cacheChildrenDLLSideLoading = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenDLLSideLoading.add(((asset.Windows) Windows.this).bypassProcessWhitelisting);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenDLLSideLoading.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        _cacheChildrenDLLSideLoading.add(attemptLSASSDriver);
      }
      for (AttackStep attackStep : _cacheChildrenDLLSideLoading) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDLLSideLoading == null) {
        _cacheParentDLLSideLoading = new HashSet<>();
        _cacheParentDLLSideLoading.add(hijackExecutionFlow);
        _cacheParentDLLSideLoading.add(audit.disable);
        _cacheParentDLLSideLoading.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentDLLSideLoading.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentDLLSideLoading) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.dLLSideLoading");
    }
  }

  public class DomainControllerAuthentication extends OS.DomainControllerAuthentication {
    private Set<AttackStep> _cacheParentDomainControllerAuthentication;

    public DomainControllerAuthentication(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainControllerAuthentication == null) {
        _cacheParentDomainControllerAuthentication = new HashSet<>();
        _cacheParentDomainControllerAuthentication.add(modifyAuthenticationProcess);
        _cacheParentDomainControllerAuthentication.add(multiFactorAuthentication.disable);
        _cacheParentDomainControllerAuthentication.add(privilegedProcessIntegrity.disable);
        _cacheParentDomainControllerAuthentication.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentDomainControllerAuthentication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.domainControllerAuthentication");
    }
  }

  public class AttemptLSASSDriver extends OS.AttemptLSASSDriver {
    private Set<AttackStep> _cacheChildrenAttemptLSASSDriver;

    private Set<AttackStep> _cacheParentAttemptLSASSDriver;

    public AttemptLSASSDriver(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptLSASSDriver == null) {
        _cacheChildrenAttemptLSASSDriver = new HashSet<>();
        _cacheChildrenAttemptLSASSDriver.add(lSASSDriver);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLSASSDriver) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLSASSDriver == null) {
        _cacheParentAttemptLSASSDriver = new HashSet<>();
        _cacheParentAttemptLSASSDriver.add(bootOrLogonAutostartExecution);
        _cacheParentAttemptLSASSDriver.add(dLLSearchOrderHijacking);
        _cacheParentAttemptLSASSDriver.add(dLLSideLoading);
      }
      for (AttackStep attackStep : _cacheParentAttemptLSASSDriver) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptLSASSDriver");
    }
  }

  public class LSASSDriver extends OS.LSASSDriver {
    private Set<AttackStep> _cacheChildrenLSASSDriver;

    private Set<AttackStep> _cacheParentLSASSDriver;

    public LSASSDriver(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLSASSDriver == null) {
        _cacheChildrenLSASSDriver = new HashSet<>();
        _cacheChildrenLSASSDriver.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenLSASSDriver.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenLSASSDriver) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLSASSDriver == null) {
        _cacheParentLSASSDriver = new HashSet<>();
        _cacheParentLSASSDriver.add(attemptLSASSDriver);
        _cacheParentLSASSDriver.add(credentialAccessProtection.disable);
        _cacheParentLSASSDriver.add(privilegedProcessIntegrity.disable);
        _cacheParentLSASSDriver.add(restrictLibraryLoading.disable);
      }
      for (AttackStep attackStep : _cacheParentLSASSDriver) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.lSASSDriver");
    }
  }

  public class CachedDomainCredentials extends OS.CachedDomainCredentials {
    private Set<AttackStep> _cacheChildrenCachedDomainCredentials;

    private Set<AttackStep> _cacheParentCachedDomainCredentials;

    public CachedDomainCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCachedDomainCredentials == null) {
        _cacheChildrenCachedDomainCredentials = new HashSet<>();
        _cacheChildrenCachedDomainCredentials.add(collectHashInformation);
        if (Windows.this instanceof Windows) {
          _cacheChildrenCachedDomainCredentials.add(((asset.Windows) Windows.this).attemptDomainAccounts);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCachedDomainCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCachedDomainCredentials == null) {
        _cacheParentCachedDomainCredentials = new HashSet<>();
        _cacheParentCachedDomainCredentials.add(oSCredentialDumping);
        _cacheParentCachedDomainCredentials.add(activeDirectoryConfiguration.disable);
        _cacheParentCachedDomainCredentials.add(operatingSystemConfiguration.disable);
        _cacheParentCachedDomainCredentials.add(passwordPolicies.disable);
        _cacheParentCachedDomainCredentials.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentCachedDomainCredentials) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.cachedDomainCredentials");
    }
  }

  public class EventTriggeredExecution extends OS.EventTriggeredExecution {
    private Set<AttackStep> _cacheChildrenEventTriggeredExecution;

    public EventTriggeredExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenEventTriggeredExecution == null) {
        _cacheChildrenEventTriggeredExecution = new HashSet<>();
        _cacheChildrenEventTriggeredExecution.add(changeDefaultFileAssociation);
        _cacheChildrenEventTriggeredExecution.add(screensaver);
        _cacheChildrenEventTriggeredExecution.add(attemptWindowsManagementInstrumentationEventSubscription);
        _cacheChildrenEventTriggeredExecution.add(netshHelperDLL);
        _cacheChildrenEventTriggeredExecution.add(attemptAccessibilityFeatures);
        _cacheChildrenEventTriggeredExecution.add(attemptAppCertDLLs);
        _cacheChildrenEventTriggeredExecution.add(attemptAppInitDLLs);
        _cacheChildrenEventTriggeredExecution.add(attemptApplicationShimming);
        _cacheChildrenEventTriggeredExecution.add(imageFileExecutionOptionsInjection);
        _cacheChildrenEventTriggeredExecution.add(powerShellUserProfile);
        _cacheChildrenEventTriggeredExecution.add(powerShellAdminProfile);
        _cacheChildrenEventTriggeredExecution.add(componentObjectModelHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenEventTriggeredExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.eventTriggeredExecution");
    }
  }

  public class HideArtifacts extends OS.HideArtifacts {
    private Set<AttackStep> _cacheChildrenHideArtifacts;

    public HideArtifacts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHideArtifacts == null) {
        _cacheChildrenHideArtifacts = new HashSet<>();
        _cacheChildrenHideArtifacts.add(ntfsFileAttributes);
        _cacheChildrenHideArtifacts.add(attemptHiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenHideArtifacts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.hideArtifacts");
    }
  }

  public class LSASecrets extends OS.LSASecrets {
    private Set<AttackStep> _cacheChildrenLSASecrets;

    private Set<AttackStep> _cacheParentLSASecrets;

    public LSASecrets(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLSASecrets == null) {
        _cacheChildrenLSASecrets = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenLSASecrets.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenLSASecrets) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLSASecrets == null) {
        _cacheParentLSASecrets = new HashSet<>();
        _cacheParentLSASecrets.add(oSCredentialDumping);
        _cacheParentLSASecrets.add(passwordPolicies.disable);
        _cacheParentLSASecrets.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentLSASecrets) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.lSASecrets");
    }
  }

  public class HijackExecutionFlow extends OS.HijackExecutionFlow {
    private Set<AttackStep> _cacheChildrenHijackExecutionFlow;

    private Set<AttackStep> _cacheParentHijackExecutionFlow;

    public HijackExecutionFlow(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHijackExecutionFlow == null) {
        _cacheChildrenHijackExecutionFlow = new HashSet<>();
        _cacheChildrenHijackExecutionFlow.add(attemptCOR_PROFILER);
        _cacheChildrenHijackExecutionFlow.add(attemptDLLSearchOrderHijacking);
        _cacheChildrenHijackExecutionFlow.add(dLLSideLoading);
        _cacheChildrenHijackExecutionFlow.add(executableInstallerFilePermissionsWeakness);
        _cacheChildrenHijackExecutionFlow.add(pathInterception);
        _cacheChildrenHijackExecutionFlow.add(attemptServicesFilePermissionsWeakness);
        _cacheChildrenHijackExecutionFlow.add(servicesRegistryPermissionsWeakness);
      }
      for (AttackStep attackStep : _cacheChildrenHijackExecutionFlow) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHijackExecutionFlow == null) {
        _cacheParentHijackExecutionFlow = new HashSet<>();
        _cacheParentHijackExecutionFlow.add(windowsFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheParentHijackExecutionFlow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.hijackExecutionFlow");
    }
  }

  public class ImpareDefenses extends OS.ImpareDefenses {
    private Set<AttackStep> _cacheChildrenImpareDefenses;

    private Set<AttackStep> _cacheParentImpareDefenses;

    public ImpareDefenses(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenImpareDefenses == null) {
        _cacheChildrenImpareDefenses = new HashSet<>();
        _cacheChildrenImpareDefenses.add(disableWindowsEventLogging);
      }
      for (AttackStep attackStep : _cacheChildrenImpareDefenses) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentImpareDefenses == null) {
        _cacheParentImpareDefenses = new HashSet<>();
        _cacheParentImpareDefenses.add(cOR_PROFILER);
      }
      for (AttackStep attackStep : _cacheParentImpareDefenses) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.impareDefenses");
    }
  }

  public class IndicatorRemovalOnHost extends OS.IndicatorRemovalOnHost {
    private Set<AttackStep> _cacheChildrenIndicatorRemovalOnHost;

    public IndicatorRemovalOnHost(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenIndicatorRemovalOnHost == null) {
        _cacheChildrenIndicatorRemovalOnHost = new HashSet<>();
        _cacheChildrenIndicatorRemovalOnHost.add(clearWindowsEventLogs);
        _cacheChildrenIndicatorRemovalOnHost.add(networkShareConnectionRemoval);
      }
      for (AttackStep attackStep : _cacheChildrenIndicatorRemovalOnHost) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.indicatorRemovalOnHost");
    }
  }

  public class InputCapture extends OS.InputCapture {
    private Set<AttackStep> _cacheChildrenInputCapture;

    public InputCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenInputCapture == null) {
        _cacheChildrenInputCapture = new HashSet<>();
        _cacheChildrenInputCapture.add(credentialAPIHooking);
        _cacheChildrenInputCapture.add(attemptGUIInputCapture);
      }
      for (AttackStep attackStep : _cacheChildrenInputCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.inputCapture");
    }
  }

  public class LateralToolTransfer extends OS.LateralToolTransfer {
    private Set<AttackStep> _cacheChildrenLateralToolTransfer;

    public LateralToolTransfer(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLateralToolTransfer == null) {
        _cacheChildrenLateralToolTransfer = new HashSet<>();
        _cacheChildrenLateralToolTransfer.add(attemptWindowsAdminShares);
        _cacheChildrenLateralToolTransfer.add(attemptRemoteDesktopProtocol);
      }
      for (AttackStep attackStep : _cacheChildrenLateralToolTransfer) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.lateralToolTransfer");
    }
  }

  public class ManInTheMiddle extends OS.ManInTheMiddle {
    private Set<AttackStep> _cacheChildrenManInTheMiddle;

    public ManInTheMiddle(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenManInTheMiddle == null) {
        _cacheChildrenManInTheMiddle = new HashSet<>();
        _cacheChildrenManInTheMiddle.add(attemptLLMNR_NBT_NS_PoisoningAndSMBRelay);
      }
      for (AttackStep attackStep : _cacheChildrenManInTheMiddle) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.manInTheMiddle");
    }
  }

  public class Masquerading extends OS.Masquerading {
    private Set<AttackStep> _cacheChildrenMasquerading;

    private Set<AttackStep> _cacheParentMasquerading;

    public Masquerading(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenMasquerading == null) {
        _cacheChildrenMasquerading = new HashSet<>();
        _cacheChildrenMasquerading.add(invalidCodeSignature);
        _cacheChildrenMasquerading.add(masqueradeTaskOrService);
      }
      for (AttackStep attackStep : _cacheChildrenMasquerading) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMasquerading == null) {
        _cacheParentMasquerading = new HashSet<>();
        _cacheParentMasquerading.add(windowsService);
        _cacheParentMasquerading.add(registryRunKeysOrStartupFolder);
        _cacheParentMasquerading.add(shortcutModification);
      }
      for (AttackStep attackStep : _cacheParentMasquerading) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.masquerading");
    }
  }

  public class ModifyAuthenticationProcess extends OS.ModifyAuthenticationProcess {
    private Set<AttackStep> _cacheChildrenModifyAuthenticationProcess;

    public ModifyAuthenticationProcess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenModifyAuthenticationProcess == null) {
        _cacheChildrenModifyAuthenticationProcess = new HashSet<>();
        _cacheChildrenModifyAuthenticationProcess.add(domainControllerAuthentication);
        _cacheChildrenModifyAuthenticationProcess.add(attemptPasswordFilterDLL);
      }
      for (AttackStep attackStep : _cacheChildrenModifyAuthenticationProcess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.modifyAuthenticationProcess");
    }
  }

  public class Mshta extends OS.Mshta {
    private Set<AttackStep> _cacheChildrenMshta;

    private Set<AttackStep> _cacheParentMshta;

    public Mshta(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenMshta == null) {
        _cacheChildrenMshta = new HashSet<>();
        _cacheChildrenMshta.add(fileProxyExecution);
        if (Windows.this instanceof Windows) {
          _cacheChildrenMshta.add(((asset.Windows) Windows.this).bypassDigitalCertificateValidation);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenMshta.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenMshta) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMshta == null) {
        _cacheParentMshta = new HashSet<>();
        _cacheParentMshta.add(signedBinaryProxyExecution);
        _cacheParentMshta.add(executionPrevention.disable);
        _cacheParentMshta.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentMshta) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.mshta");
    }
  }

  public class Msiexec extends OS.Msiexec {
    private Set<AttackStep> _cacheChildrenMsiexec;

    private Set<AttackStep> _cacheParentMsiexec;

    public Msiexec(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenMsiexec == null) {
        _cacheChildrenMsiexec = new HashSet<>();
        _cacheChildrenMsiexec.add(codeProxyExecution);
      }
      for (AttackStep attackStep : _cacheChildrenMsiexec) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMsiexec == null) {
        _cacheParentMsiexec = new HashSet<>();
        _cacheParentMsiexec.add(signedBinaryProxyExecution);
        _cacheParentMsiexec.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentMsiexec) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.msiexec");
    }
  }

  public class Odbcconf extends OS.Odbcconf {
    private Set<AttackStep> _cacheChildrenOdbcconf;

    private Set<AttackStep> _cacheParentOdbcconf;

    public Odbcconf(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOdbcconf == null) {
        _cacheChildrenOdbcconf = new HashSet<>();
        _cacheChildrenOdbcconf.add(codeProxyExecution);
      }
      for (AttackStep attackStep : _cacheChildrenOdbcconf) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOdbcconf == null) {
        _cacheParentOdbcconf = new HashSet<>();
        _cacheParentOdbcconf.add(signedBinaryProxyExecution);
        _cacheParentOdbcconf.add(executionPrevention.disable);
        _cacheParentOdbcconf.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentOdbcconf) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.odbcconf");
    }
  }

  public class ExchangeEmailDelegatePermissions extends OS.ExchangeEmailDelegatePermissions {
    private Set<AttackStep> _cacheChildrenExchangeEmailDelegatePermissions;

    private Set<AttackStep> _cacheParentExchangeEmailDelegatePermissions;

    public ExchangeEmailDelegatePermissions(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenExchangeEmailDelegatePermissions == null) {
        _cacheChildrenExchangeEmailDelegatePermissions = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenExchangeEmailDelegatePermissions.add(((asset.Windows) Windows.this).internalSpearphishing);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExchangeEmailDelegatePermissions) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExchangeEmailDelegatePermissions == null) {
        _cacheParentExchangeEmailDelegatePermissions = new HashSet<>();
        _cacheParentExchangeEmailDelegatePermissions.add(accountManipulation);
      }
      for (AttackStep attackStep : _cacheParentExchangeEmailDelegatePermissions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.exchangeEmailDelegatePermissions");
    }
  }

  public class ExecuteCode extends OS.ExecuteCode {
    private Set<AttackStep> _cacheChildrenExecuteCode;

    private Set<AttackStep> _cacheParentExecuteCode;

    public ExecuteCode(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenExecuteCode == null) {
        _cacheChildrenExecuteCode = new HashSet<>();
        _cacheChildrenExecuteCode.add(componentFirmware);
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenExecuteCode.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Windows.this instanceof Windows) {
          for (Computer _1 : ((asset.Windows) Windows.this).computer) {
            _cacheChildrenExecuteCode.add(_1.infectedWindowsComputer);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExecuteCode) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecuteCode == null) {
        _cacheParentExecuteCode = new HashSet<>();
        _cacheParentExecuteCode.add(at);
        _cacheParentExecuteCode.add(bITSJobs);
        _cacheParentExecuteCode.add(componentObjectModel);
        _cacheParentExecuteCode.add(controlPanel);
        _cacheParentExecuteCode.add(lSASSDriver);
        _cacheParentExecuteCode.add(executionThroughAPI);
        _cacheParentExecuteCode.add(executionThroughModuleLoad);
        _cacheParentExecuteCode.add(fileSystemPermissionsWeakness);
        _cacheParentExecuteCode.add(indirectCommandExecution);
        _cacheParentExecuteCode.add(pathInterceptionByUnquotedPath);
        _cacheParentExecuteCode.add(shortcutModification);
        _cacheParentExecuteCode.add(unquotedPaths);
        _cacheParentExecuteCode.add(scheduledTask);
        _cacheParentExecuteCode.add(windowsCommandShell);
        _cacheParentExecuteCode.add(windowsManagementInstrumentation);
        _cacheParentExecuteCode.add(dynamicDataExchange);
        _cacheParentExecuteCode.add(portMonitors);
        _cacheParentExecuteCode.add(xslScriptProcessing);
      }
      for (AttackStep attackStep : _cacheParentExecuteCode) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.executeCode");
    }
  }

  public class AttemptExecutionThroughAPI extends OS.AttemptExecutionThroughAPI {
    private Set<AttackStep> _cacheChildrenAttemptExecutionThroughAPI;

    public AttemptExecutionThroughAPI(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptExecutionThroughAPI == null) {
        _cacheChildrenAttemptExecutionThroughAPI = new HashSet<>();
        _cacheChildrenAttemptExecutionThroughAPI.add(executionThroughAPI);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExecutionThroughAPI) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptExecutionThroughAPI");
    }
  }

  public class ExecutionThroughAPI extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExecutionThroughAPI;

    private Set<AttackStep> _cacheParentExecutionThroughAPI;

    public ExecutionThroughAPI(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExecutionThroughAPI == null) {
        _cacheChildrenExecutionThroughAPI = new HashSet<>();
        _cacheChildrenExecutionThroughAPI.add(executeCode);
        _cacheChildrenExecutionThroughAPI.add(processInjection);
      }
      for (AttackStep attackStep : _cacheChildrenExecutionThroughAPI) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecutionThroughAPI == null) {
        _cacheParentExecutionThroughAPI = new HashSet<>();
        _cacheParentExecutionThroughAPI.add(attemptExecutionThroughAPI);
        _cacheParentExecutionThroughAPI.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentExecutionThroughAPI) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.executionThroughAPI");
    }
  }

  public class ExecutionThroughModuleLoad extends OS.ExecutionThroughModuleLoad {
    private Set<AttackStep> _cacheChildrenExecutionThroughModuleLoad;

    private Set<AttackStep> _cacheParentExecutionThroughModuleLoad;

    public ExecutionThroughModuleLoad(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenExecutionThroughModuleLoad == null) {
        _cacheChildrenExecutionThroughModuleLoad = new HashSet<>();
        _cacheChildrenExecutionThroughModuleLoad.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenExecutionThroughModuleLoad) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecutionThroughModuleLoad == null) {
        _cacheParentExecutionThroughModuleLoad = new HashSet<>();
        _cacheParentExecutionThroughModuleLoad.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentExecutionThroughModuleLoad) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.executionThroughModuleLoad");
    }
  }

  public class ExtraWindowMemoryInjection extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExtraWindowMemoryInjection;

    private Set<AttackStep> _cacheParentExtraWindowMemoryInjection;

    public ExtraWindowMemoryInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExtraWindowMemoryInjection == null) {
        _cacheChildrenExtraWindowMemoryInjection = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenExtraWindowMemoryInjection.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenExtraWindowMemoryInjection.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExtraWindowMemoryInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExtraWindowMemoryInjection == null) {
        _cacheParentExtraWindowMemoryInjection = new HashSet<>();
        _cacheParentExtraWindowMemoryInjection.add(processInjection);
        _cacheParentExtraWindowMemoryInjection.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentExtraWindowMemoryInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.extraWindowMemoryInjection");
    }
  }

  public class FileAndDirectoryPermissionsModification extends OS.FileAndDirectoryPermissionsModification {
    private Set<AttackStep> _cacheChildrenFileAndDirectoryPermissionsModification;

    public FileAndDirectoryPermissionsModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenFileAndDirectoryPermissionsModification == null) {
        _cacheChildrenFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheChildrenFileAndDirectoryPermissionsModification.add(windowsFileAndDirectoryPermissionsModification);
      }
      for (AttackStep attackStep : _cacheChildrenFileAndDirectoryPermissionsModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.fileAndDirectoryPermissionsModification");
    }
  }

  public class WindowsFileAndDirectoryPermissionsModification extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenWindowsFileAndDirectoryPermissionsModification;

    private Set<AttackStep> _cacheParentWindowsFileAndDirectoryPermissionsModification;

    public WindowsFileAndDirectoryPermissionsModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWindowsFileAndDirectoryPermissionsModification == null) {
        _cacheChildrenWindowsFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheChildrenWindowsFileAndDirectoryPermissionsModification.add(attemptAccessibilityFeatures);
        _cacheChildrenWindowsFileAndDirectoryPermissionsModification.add(bootOrLogonInitializationScripts);
        _cacheChildrenWindowsFileAndDirectoryPermissionsModification.add(hijackExecutionFlow);
      }
      for (AttackStep attackStep : _cacheChildrenWindowsFileAndDirectoryPermissionsModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsFileAndDirectoryPermissionsModification == null) {
        _cacheParentWindowsFileAndDirectoryPermissionsModification = new HashSet<>();
        _cacheParentWindowsFileAndDirectoryPermissionsModification.add(fileAndDirectoryPermissionsModification);
        _cacheParentWindowsFileAndDirectoryPermissionsModification.add(privilegedAccountManagement.disable);
        _cacheParentWindowsFileAndDirectoryPermissionsModification.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentWindowsFileAndDirectoryPermissionsModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.windowsFileAndDirectoryPermissionsModification");
    }
  }

  public class FileSystemLogicalOffsets extends OS.FileSystemLogicalOffsets {
    private Set<AttackStep> _cacheChildrenFileSystemLogicalOffsets;

    public FileSystemLogicalOffsets(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenFileSystemLogicalOffsets == null) {
        _cacheChildrenFileSystemLogicalOffsets = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenFileSystemLogicalOffsets.add(((asset.Windows) Windows.this).bypassFileMonitoring);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenFileSystemLogicalOffsets.add(((asset.Windows) Windows.this).bypassFileSystemAccessControls);
        }
      }
      for (AttackStep attackStep : _cacheChildrenFileSystemLogicalOffsets) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.fileSystemLogicalOffsets");
    }
  }

  public class AttemptFileSystemPermissionsWeakness extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptFileSystemPermissionsWeakness;

    public AttemptFileSystemPermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptFileSystemPermissionsWeakness == null) {
        _cacheChildrenAttemptFileSystemPermissionsWeakness = new HashSet<>();
        _cacheChildrenAttemptFileSystemPermissionsWeakness.add(fileSystemPermissionsWeakness);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptFileSystemPermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptFileSystemPermissionsWeakness");
    }
  }

  public class FileSystemPermissionsWeakness extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenFileSystemPermissionsWeakness;

    private Set<AttackStep> _cacheParentFileSystemPermissionsWeakness;

    public FileSystemPermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenFileSystemPermissionsWeakness == null) {
        _cacheChildrenFileSystemPermissionsWeakness = new HashSet<>();
        _cacheChildrenFileSystemPermissionsWeakness.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenFileSystemPermissionsWeakness.add(((asset.Windows) Windows.this).persistence);
        }
        _cacheChildrenFileSystemPermissionsWeakness.add(attemptDLLSearchOrderHijacking);
        _cacheChildrenFileSystemPermissionsWeakness.add(attemptBypassUserAccessControl);
      }
      for (AttackStep attackStep : _cacheChildrenFileSystemPermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFileSystemPermissionsWeakness == null) {
        _cacheParentFileSystemPermissionsWeakness = new HashSet<>();
        _cacheParentFileSystemPermissionsWeakness.add(attemptFileSystemPermissionsWeakness);
      }
      for (AttackStep attackStep : _cacheParentFileSystemPermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.fileSystemPermissionsWeakness");
    }
  }

  public class ForcedAuthentication extends OS.ForcedAuthentication {
    private Set<AttackStep> _cacheChildrenForcedAuthentication;

    private Set<AttackStep> _cacheParentForcedAuthentication;

    public ForcedAuthentication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenForcedAuthentication == null) {
        _cacheChildrenForcedAuthentication = new HashSet<>();
        _cacheChildrenForcedAuthentication.add(templateInjection);
        if (Windows.this instanceof Windows) {
          _cacheChildrenForcedAuthentication.add(((asset.Windows) Windows.this).bruteForce);
        }
      }
      for (AttackStep attackStep : _cacheChildrenForcedAuthentication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentForcedAuthentication == null) {
        _cacheParentForcedAuthentication = new HashSet<>();
        _cacheParentForcedAuthentication.add(templateInjection);
      }
      for (AttackStep attackStep : _cacheParentForcedAuthentication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.forcedAuthentication");
    }
  }

  public class GroupPolicyModification extends OS.GroupPolicyModification {
    private Set<AttackStep> _cacheChildrenGroupPolicyModification;

    public GroupPolicyModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenGroupPolicyModification == null) {
        _cacheChildrenGroupPolicyModification = new HashSet<>();
        _cacheChildrenGroupPolicyModification.add(attemptScheduledTask);
        if (Windows.this instanceof Windows) {
          _cacheChildrenGroupPolicyModification.add(((asset.Windows) Windows.this).attemptDisableOrModifyTools);
        }
        _cacheChildrenGroupPolicyModification.add(remoteFileCopy);
        _cacheChildrenGroupPolicyModification.add(attemptServiceExecution);
        if (Windows.this instanceof Windows) {
          for (AdminAccount _0 : ((asset.Windows) Windows.this).adminAccount) {
            _cacheChildrenGroupPolicyModification.add(_0.attemptCreateAccount);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenGroupPolicyModification.add(((asset.Windows) Windows.this).bypassSystemAccessControls);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenGroupPolicyModification.add(((asset.Windows) Windows.this).bypassFileSystemAccessControls);
        }
      }
      for (AttackStep attackStep : _cacheChildrenGroupPolicyModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.groupPolicyModification");
    }
  }

  public class GroupPolicyPreferences extends OS.GroupPolicyPreferences {
    private Set<AttackStep> _cacheChildrenGroupPolicyPreferences;

    private Set<AttackStep> _cacheParentGroupPolicyPreferences;

    public GroupPolicyPreferences(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenGroupPolicyPreferences == null) {
        _cacheChildrenGroupPolicyPreferences = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenGroupPolicyPreferences.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenGroupPolicyPreferences) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGroupPolicyPreferences == null) {
        _cacheParentGroupPolicyPreferences = new HashSet<>();
        _cacheParentGroupPolicyPreferences.add(unsecuredCredentials);
        _cacheParentGroupPolicyPreferences.add(activeDirectoryConfiguration.disable);
        _cacheParentGroupPolicyPreferences.add(audit.disable);
        _cacheParentGroupPolicyPreferences.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentGroupPolicyPreferences) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.groupPolicyPreferences");
    }
  }

  public class AttemptGUIInputCapture extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptGUIInputCapture;

    private Set<AttackStep> _cacheParentAttemptGUIInputCapture;

    public AttemptGUIInputCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptGUIInputCapture == null) {
        _cacheChildrenAttemptGUIInputCapture = new HashSet<>();
        _cacheChildrenAttemptGUIInputCapture.add(gUIInputCapture);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptGUIInputCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptGUIInputCapture == null) {
        _cacheParentAttemptGUIInputCapture = new HashSet<>();
        _cacheParentAttemptGUIInputCapture.add(inputCapture);
        _cacheParentAttemptGUIInputCapture.add(powerShell);
      }
      for (AttackStep attackStep : _cacheParentAttemptGUIInputCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptGUIInputCapture");
    }
  }

  public class GUIInputCapture extends OS.GUIInputCapture {
    private Set<AttackStep> _cacheChildrenGUIInputCapture;

    private Set<AttackStep> _cacheParentGUIInputCapture;

    public GUIInputCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenGUIInputCapture == null) {
        _cacheChildrenGUIInputCapture = new HashSet<>();
        _cacheChildrenGUIInputCapture.add(bypassUserAccessControl);
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenGUIInputCapture.add(_0.userCredentials);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenGUIInputCapture.add(((asset.Windows) Windows.this).privateKeysWithPassphrase);
        }
      }
      for (AttackStep attackStep : _cacheChildrenGUIInputCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGUIInputCapture == null) {
        _cacheParentGUIInputCapture = new HashSet<>();
        _cacheParentGUIInputCapture.add(attemptGUIInputCapture);
      }
      for (AttackStep attackStep : _cacheParentGUIInputCapture) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.gUIInputCapture");
    }
  }

  public class AttemptHiddenWindow extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptHiddenWindow;

    private Set<AttackStep> _cacheParentAttemptHiddenWindow;

    public AttemptHiddenWindow(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptHiddenWindow == null) {
        _cacheChildrenAttemptHiddenWindow = new HashSet<>();
        _cacheChildrenAttemptHiddenWindow.add(hiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptHiddenWindow) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptHiddenWindow == null) {
        _cacheParentAttemptHiddenWindow = new HashSet<>();
        _cacheParentAttemptHiddenWindow.add(hideArtifacts);
        _cacheParentAttemptHiddenWindow.add(visualBasic);
        _cacheParentAttemptHiddenWindow.add(javaScriptOrJScript);
        _cacheParentAttemptHiddenWindow.add(powerShell);
      }
      for (AttackStep attackStep : _cacheParentAttemptHiddenWindow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptHiddenWindow");
    }
  }

  public class HiddenWindow extends OS.HiddenWindow {
    private Set<AttackStep> _cacheParentHiddenWindow;

    public HiddenWindow(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHiddenWindow == null) {
        _cacheParentHiddenWindow = new HashSet<>();
        _cacheParentHiddenWindow.add(attemptHiddenWindow);
      }
      for (AttackStep attackStep : _cacheParentHiddenWindow) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.hiddenWindow");
    }
  }

  public class ImageFileExecutionOptionsInjection extends OS.ImageFileExecutionOptionsInjection {
    private Set<AttackStep> _cacheChildrenImageFileExecutionOptionsInjection;

    private Set<AttackStep> _cacheParentImageFileExecutionOptionsInjection;

    public ImageFileExecutionOptionsInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenImageFileExecutionOptionsInjection == null) {
        _cacheChildrenImageFileExecutionOptionsInjection = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenImageFileExecutionOptionsInjection.add(((asset.Windows) Windows.this).bypassAutorunsAnalysis);
        }
        _cacheChildrenImageFileExecutionOptionsInjection.add(processInjection);
      }
      for (AttackStep attackStep : _cacheChildrenImageFileExecutionOptionsInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentImageFileExecutionOptionsInjection == null) {
        _cacheParentImageFileExecutionOptionsInjection = new HashSet<>();
        _cacheParentImageFileExecutionOptionsInjection.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentImageFileExecutionOptionsInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.imageFileExecutionOptionsInjection");
    }
  }

  public class IndirectCommandExecution extends OS.IndirectCommandExecution {
    private Set<AttackStep> _cacheChildrenIndirectCommandExecution;

    public IndirectCommandExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenIndirectCommandExecution == null) {
        _cacheChildrenIndirectCommandExecution = new HashSet<>();
        _cacheChildrenIndirectCommandExecution.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenIndirectCommandExecution.add(((asset.Windows) Windows.this).bypassStaticFileAnalysis);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenIndirectCommandExecution.add(((asset.Windows) Windows.this).bypassApplicationWhitelisting);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenIndirectCommandExecution.add(((asset.Windows) Windows.this).bypassProcessWhitelisting);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenIndirectCommandExecution.add(((asset.Windows) Windows.this).bypassFileOrPathWhitelisting);
        }
      }
      for (AttackStep attackStep : _cacheChildrenIndirectCommandExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.indirectCommandExecution");
    }
  }

  public class InstallUtil extends OS.InstallUtil {
    private Set<AttackStep> _cacheChildrenInstallUtil;

    private Set<AttackStep> _cacheParentInstallUtil;

    public InstallUtil(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenInstallUtil == null) {
        _cacheChildrenInstallUtil = new HashSet<>();
        _cacheChildrenInstallUtil.add(codeProxyExecution);
      }
      for (AttackStep attackStep : _cacheChildrenInstallUtil) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInstallUtil == null) {
        _cacheParentInstallUtil = new HashSet<>();
        _cacheParentInstallUtil.add(signedBinaryProxyExecution);
        _cacheParentInstallUtil.add(executionPrevention.disable);
        _cacheParentInstallUtil.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentInstallUtil) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.installUtil");
    }
  }

  public class InterProcessCommunication extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenInterProcessCommunication;

    public InterProcessCommunication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInterProcessCommunication == null) {
        _cacheChildrenInterProcessCommunication = new HashSet<>();
        _cacheChildrenInterProcessCommunication.add(attemptComponentObjectModel);
        _cacheChildrenInterProcessCommunication.add(attemptDynamicDataExchange);
      }
      for (AttackStep attackStep : _cacheChildrenInterProcessCommunication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.interProcessCommunication");
    }
  }

  public class InvalidCodeSignature extends AttackStepMax {
    private Set<AttackStep> _cacheParentInvalidCodeSignature;

    public InvalidCodeSignature(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInvalidCodeSignature == null) {
        _cacheParentInvalidCodeSignature = new HashSet<>();
        _cacheParentInvalidCodeSignature.add(masquerading);
        _cacheParentInvalidCodeSignature.add(codeSigning.disable);
      }
      for (AttackStep attackStep : _cacheParentInvalidCodeSignature) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.invalidCodeSignature");
    }
  }

  public class ServiceExhaustionFlood extends OS.ServiceExhaustionFlood {
    private Set<AttackStep> _cacheChildrenServiceExhaustionFlood;

    public ServiceExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServiceExhaustionFlood == null) {
        _cacheChildrenServiceExhaustionFlood = new HashSet<>();
        _cacheChildrenServiceExhaustionFlood.add(attemptServiceStop);
      }
      for (AttackStep attackStep : _cacheChildrenServiceExhaustionFlood) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.serviceExhaustionFlood");
    }
  }

  public class StealOrForgeKerberosTickets extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenStealOrForgeKerberosTickets;

    private Set<AttackStep> _cacheParentStealOrForgeKerberosTickets;

    public StealOrForgeKerberosTickets(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenStealOrForgeKerberosTickets == null) {
        _cacheChildrenStealOrForgeKerberosTickets = new HashSet<>();
        _cacheChildrenStealOrForgeKerberosTickets.add(goldenTicket);
        _cacheChildrenStealOrForgeKerberosTickets.add(silverTicket);
        _cacheChildrenStealOrForgeKerberosTickets.add(kerberoasting);
      }
      for (AttackStep attackStep : _cacheChildrenStealOrForgeKerberosTickets) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentStealOrForgeKerberosTickets == null) {
        _cacheParentStealOrForgeKerberosTickets = new HashSet<>();
        _cacheParentStealOrForgeKerberosTickets.add(oSCredentialDumping);
      }
      for (AttackStep attackStep : _cacheParentStealOrForgeKerberosTickets) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.stealOrForgeKerberosTickets");
    }
  }

  public class AttemptGoldenTicket extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptGoldenTicket;

    private Set<AttackStep> _cacheParentAttemptGoldenTicket;

    public AttemptGoldenTicket(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptGoldenTicket == null) {
        _cacheChildrenAttemptGoldenTicket = new HashSet<>();
        _cacheChildrenAttemptGoldenTicket.add(goldenTicket);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptGoldenTicket) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptGoldenTicket == null) {
        _cacheParentAttemptGoldenTicket = new HashSet<>();
        _cacheParentAttemptGoldenTicket.add(dCSync);
      }
      for (AttackStep attackStep : _cacheParentAttemptGoldenTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptGoldenTicket");
    }
  }

  public class GoldenTicket extends OS.GoldenTicket {
    private Set<AttackStep> _cacheChildrenGoldenTicket;

    private Set<AttackStep> _cacheParentGoldenTicket;

    public GoldenTicket(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenGoldenTicket == null) {
        _cacheChildrenGoldenTicket = new HashSet<>();
        _cacheChildrenGoldenTicket.add(attemptPassTheTicket);
        _cacheChildrenGoldenTicket.add(dCShadow);
      }
      for (AttackStep attackStep : _cacheChildrenGoldenTicket) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentGoldenTicket == null) {
        _cacheParentGoldenTicket = new HashSet<>();
        _cacheParentGoldenTicket.add(stealOrForgeKerberosTickets);
        _cacheParentGoldenTicket.add(attemptGoldenTicket);
        _cacheParentGoldenTicket.add(activeDirectoryConfiguration.disable);
        _cacheParentGoldenTicket.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentGoldenTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.goldenTicket");
    }
  }

  public class AttemptSilverTicket extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSilverTicket;

    private Set<AttackStep> _cacheParentAttemptSilverTicket;

    public AttemptSilverTicket(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSilverTicket == null) {
        _cacheChildrenAttemptSilverTicket = new HashSet<>();
        _cacheChildrenAttemptSilverTicket.add(silverTicket);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSilverTicket) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSilverTicket == null) {
        _cacheParentAttemptSilverTicket = new HashSet<>();
        _cacheParentAttemptSilverTicket.add(dCSync);
        _cacheParentAttemptSilverTicket.add(kerberoasting);
      }
      for (AttackStep attackStep : _cacheParentAttemptSilverTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptSilverTicket");
    }
  }

  public class SilverTicket extends OS.SilverTicket {
    private Set<AttackStep> _cacheChildrenSilverTicket;

    private Set<AttackStep> _cacheParentSilverTicket;

    public SilverTicket(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSilverTicket == null) {
        _cacheChildrenSilverTicket = new HashSet<>();
        _cacheChildrenSilverTicket.add(attemptPassTheTicket);
      }
      for (AttackStep attackStep : _cacheChildrenSilverTicket) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSilverTicket == null) {
        _cacheParentSilverTicket = new HashSet<>();
        _cacheParentSilverTicket.add(stealOrForgeKerberosTickets);
        _cacheParentSilverTicket.add(attemptSilverTicket);
        _cacheParentSilverTicket.add(passwordPolicies.disable);
        _cacheParentSilverTicket.add(privilegedAccountManagement.disable);
        _cacheParentSilverTicket.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentSilverTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.silverTicket");
    }
  }

  public class VisualBasic extends OS.VisualBasic {
    private Set<AttackStep> _cacheChildrenVisualBasic;

    public VisualBasic(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenVisualBasic == null) {
        _cacheChildrenVisualBasic = new HashSet<>();
        _cacheChildrenVisualBasic.add(attemptHiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenVisualBasic) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.visualBasic");
    }
  }

  public class JavaScriptOrJScript extends OS.JavaScriptOrJScript {
    private Set<AttackStep> _cacheChildrenJavaScriptOrJScript;

    public JavaScriptOrJScript(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenJavaScriptOrJScript == null) {
        _cacheChildrenJavaScriptOrJScript = new HashSet<>();
        _cacheChildrenJavaScriptOrJScript.add(attemptHiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenJavaScriptOrJScript) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.javaScriptOrJScript");
    }
  }

  public class Kerberoasting extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenKerberoasting;

    private Set<AttackStep> _cacheParentKerberoasting;

    public Kerberoasting(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenKerberoasting == null) {
        _cacheChildrenKerberoasting = new HashSet<>();
        _cacheChildrenKerberoasting.add(attemptSilverTicket);
        if (Windows.this instanceof Windows) {
          _cacheChildrenKerberoasting.add(((asset.Windows) Windows.this).bruteForce);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenKerberoasting.add(((asset.Windows) Windows.this).persistence);
        }
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenKerberoasting.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenKerberoasting.add(((asset.Windows) Windows.this).validAccounts);
        }
      }
      for (AttackStep attackStep : _cacheChildrenKerberoasting) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentKerberoasting == null) {
        _cacheParentKerberoasting = new HashSet<>();
        _cacheParentKerberoasting.add(stealOrForgeKerberosTickets);
        _cacheParentKerberoasting.add(passwordPolicies.disable);
        _cacheParentKerberoasting.add(privilegedAccountManagement.disable);
        _cacheParentKerberoasting.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentKerberoasting) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.kerberoasting");
    }
  }

  public class AttemptLLMNR_NBT_NS_PoisoningAndSMBRelay extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay;

    private Set<AttackStep> _cacheParentAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay;

    public AttemptLLMNR_NBT_NS_PoisoningAndSMBRelay(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay == null) {
        _cacheChildrenAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay = new HashSet<>();
        _cacheChildrenAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay.add(lLMNR_NBT_NS_PoisoningAndSMBRelay);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay == null) {
        _cacheParentAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay = new HashSet<>();
        _cacheParentAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay.add(manInTheMiddle);
      }
      for (AttackStep attackStep : _cacheParentAttemptLLMNR_NBT_NS_PoisoningAndSMBRelay) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptLLMNR_NBT_NS_PoisoningAndSMBRelay");
    }
  }

  public class LLMNR_NBT_NS_PoisoningAndSMBRelay extends OS.LLMNR_NBT_NS_PoisoningAndSMBRelay {
    private Set<AttackStep> _cacheChildrenLLMNR_NBT_NS_PoisoningAndSMBRelay;

    private Set<AttackStep> _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay;

    public LLMNR_NBT_NS_PoisoningAndSMBRelay(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLLMNR_NBT_NS_PoisoningAndSMBRelay == null) {
        _cacheChildrenLLMNR_NBT_NS_PoisoningAndSMBRelay = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenLLMNR_NBT_NS_PoisoningAndSMBRelay.add(((asset.Windows) Windows.this).networkSniffing);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenLLMNR_NBT_NS_PoisoningAndSMBRelay.add(((asset.Windows) Windows.this).bruteForce);
        }
      }
      for (AttackStep attackStep : _cacheChildrenLLMNR_NBT_NS_PoisoningAndSMBRelay) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay == null) {
        _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay = new HashSet<>();
        _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay.add(attemptLLMNR_NBT_NS_PoisoningAndSMBRelay);
        _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentLLMNR_NBT_NS_PoisoningAndSMBRelay) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.lLMNR_NBT_NS_PoisoningAndSMBRelay");
    }
  }

  public class AttemptLSASSMemory extends OS.AttemptLSASSMemory {
    private Set<AttackStep> _cacheChildrenAttemptLSASSMemory;

    private Set<AttackStep> _cacheParentAttemptLSASSMemory;

    public AttemptLSASSMemory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptLSASSMemory == null) {
        _cacheChildrenAttemptLSASSMemory = new HashSet<>();
        _cacheChildrenAttemptLSASSMemory.add(lSASSMemory);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLSASSMemory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLSASSMemory == null) {
        _cacheParentAttemptLSASSMemory = new HashSet<>();
        _cacheParentAttemptLSASSMemory.add(oSCredentialDumping);
      }
      for (AttackStep attackStep : _cacheParentAttemptLSASSMemory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptLSASSMemory");
    }
  }

  public class LSASSMemory extends OS.LSASSMemory {
    private Set<AttackStep> _cacheChildrenLSASSMemory;

    private Set<AttackStep> _cacheParentLSASSMemory;

    public LSASSMemory(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenLSASSMemory == null) {
        _cacheChildrenLSASSMemory = new HashSet<>();
        _cacheChildrenLSASSMemory.add(useAlternateAuthenticationMaterial);
      }
      for (AttackStep attackStep : _cacheChildrenLSASSMemory) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLSASSMemory == null) {
        _cacheParentLSASSMemory = new HashSet<>();
        _cacheParentLSASSMemory.add(attemptLSASSMemory);
        _cacheParentLSASSMemory.add(credentialAccessProtection.disable);
        _cacheParentLSASSMemory.add(operatingSystemConfiguration.disable);
        _cacheParentLSASSMemory.add(passwordPolicies.disable);
        _cacheParentLSASSMemory.add(privilegedProcessIntegrity.disable);
        _cacheParentLSASSMemory.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentLSASSMemory) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.lSASSMemory");
    }
  }

  public class UseAlternateAuthenticationMaterial extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenUseAlternateAuthenticationMaterial;

    private Set<AttackStep> _cacheParentUseAlternateAuthenticationMaterial;

    public UseAlternateAuthenticationMaterial(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUseAlternateAuthenticationMaterial == null) {
        _cacheChildrenUseAlternateAuthenticationMaterial = new HashSet<>();
        _cacheChildrenUseAlternateAuthenticationMaterial.add(passTheHash);
        _cacheChildrenUseAlternateAuthenticationMaterial.add(passTheTicket);
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenUseAlternateAuthenticationMaterial.add(_1.webSessionCookie);
            }
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _2 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenUseAlternateAuthenticationMaterial.add(_2.applicationAccessToken);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenUseAlternateAuthenticationMaterial) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUseAlternateAuthenticationMaterial == null) {
        _cacheParentUseAlternateAuthenticationMaterial = new HashSet<>();
        _cacheParentUseAlternateAuthenticationMaterial.add(lSASSMemory);
      }
      for (AttackStep attackStep : _cacheParentUseAlternateAuthenticationMaterial) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.useAlternateAuthenticationMaterial");
    }
  }

  public class ManInTheBrowser extends OS.ManInTheBrowser {
    private Set<AttackStep> _cacheChildrenManInTheBrowser;

    public ManInTheBrowser(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenManInTheBrowser == null) {
        _cacheChildrenManInTheBrowser = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenManInTheBrowser.add(_1.driveByCompromise);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenManInTheBrowser) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.manInTheBrowser");
    }
  }

  public class MasqueradeTaskOrService extends OS.MasqueradeTaskOrService {
    private Set<AttackStep> _cacheChildrenMasqueradeTaskOrService;

    private Set<AttackStep> _cacheParentMasqueradeTaskOrService;

    public MasqueradeTaskOrService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenMasqueradeTaskOrService == null) {
        _cacheChildrenMasqueradeTaskOrService = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenMasqueradeTaskOrService.add(((asset.Windows) Windows.this).bypassHostIntrusionPrevention);
        }
      }
      for (AttackStep attackStep : _cacheChildrenMasqueradeTaskOrService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMasqueradeTaskOrService == null) {
        _cacheParentMasqueradeTaskOrService = new HashSet<>();
        _cacheParentMasqueradeTaskOrService.add(masquerading);
      }
      for (AttackStep attackStep : _cacheParentMasqueradeTaskOrService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.masqueradeTaskOrService");
    }
  }

  public class ModifyRegistry extends OS.ModifyRegistry {
    private Set<AttackStep> _cacheChildrenModifyRegistry;

    private Set<AttackStep> _cacheParentModifyRegistry;

    public ModifyRegistry(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenModifyRegistry == null) {
        _cacheChildrenModifyRegistry = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenModifyRegistry.add(((asset.Windows) Windows.this).persistence);
        }
        _cacheChildrenModifyRegistry.add(securitySupportProvider);
        if (Windows.this instanceof Windows) {
          _cacheChildrenModifyRegistry.add(((asset.Windows) Windows.this).bypassHostForensicAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenModifyRegistry) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentModifyRegistry == null) {
        _cacheParentModifyRegistry = new HashSet<>();
        _cacheParentModifyRegistry.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentModifyRegistry) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.modifyRegistry");
    }
  }

  public class NetshHelperDLL extends OS.NetshHelperDLL {
    private Set<AttackStep> _cacheChildrenNetshHelperDLL;

    private Set<AttackStep> _cacheParentNetshHelperDLL;

    public NetshHelperDLL(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenNetshHelperDLL == null) {
        _cacheChildrenNetshHelperDLL = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenNetshHelperDLL.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenNetshHelperDLL) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetshHelperDLL == null) {
        _cacheParentNetshHelperDLL = new HashSet<>();
        _cacheParentNetshHelperDLL.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentNetshHelperDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.netshHelperDLL");
    }
  }

  public class NetworkShareConnectionRemoval extends OS.NetworkShareConnectionRemoval {
    private Set<AttackStep> _cacheChildrenNetworkShareConnectionRemoval;

    private Set<AttackStep> _cacheParentNetworkShareConnectionRemoval;

    public NetworkShareConnectionRemoval(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenNetworkShareConnectionRemoval == null) {
        _cacheChildrenNetworkShareConnectionRemoval = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenNetworkShareConnectionRemoval.add(((asset.Windows) Windows.this).bypassHostForensicAnalysis);
        }
      }
      for (AttackStep attackStep : _cacheChildrenNetworkShareConnectionRemoval) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkShareConnectionRemoval == null) {
        _cacheParentNetworkShareConnectionRemoval = new HashSet<>();
        _cacheParentNetworkShareConnectionRemoval.add(indicatorRemovalOnHost);
        _cacheParentNetworkShareConnectionRemoval.add(windowsAdminShares);
      }
      for (AttackStep attackStep : _cacheParentNetworkShareConnectionRemoval) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.networkShareConnectionRemoval");
    }
  }

  public class NTDS extends OS.NTDS {
    private Set<AttackStep> _cacheChildrenNTDS;

    private Set<AttackStep> _cacheParentNTDS;

    public NTDS(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenNTDS == null) {
        _cacheChildrenNTDS = new HashSet<>();
        _cacheChildrenNTDS.add(collectHashInformation);
      }
      for (AttackStep attackStep : _cacheChildrenNTDS) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNTDS == null) {
        _cacheParentNTDS = new HashSet<>();
        _cacheParentNTDS.add(oSCredentialDumping);
        _cacheParentNTDS.add(passwordPolicies.disable);
        _cacheParentNTDS.add(privilegedAccountManagement.disable);
        _cacheParentNTDS.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentNTDS) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.nTDS");
    }
  }

  public class AttemptWindowsService extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptWindowsService;

    private Set<AttackStep> _cacheParentAttemptWindowsService;

    public AttemptWindowsService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptWindowsService == null) {
        _cacheChildrenAttemptWindowsService = new HashSet<>();
        _cacheChildrenAttemptWindowsService.add(windowsService);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptWindowsService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWindowsService == null) {
        _cacheParentAttemptWindowsService = new HashSet<>();
        _cacheParentAttemptWindowsService.add(createOrModifySystemProcess);
        _cacheParentAttemptWindowsService.add(serviceExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptWindowsService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptWindowsService");
    }
  }

  public class WindowsService extends OS.WindowsService {
    private Set<AttackStep> _cacheChildrenWindowsService;

    private Set<AttackStep> _cacheParentWindowsService;

    public WindowsService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenWindowsService == null) {
        _cacheChildrenWindowsService = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenWindowsService.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        _cacheChildrenWindowsService.add(masquerading);
        if (Windows.this instanceof Windows) {
          _cacheChildrenWindowsService.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenWindowsService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsService == null) {
        _cacheParentWindowsService = new HashSet<>();
        _cacheParentWindowsService.add(attemptWindowsService);
        _cacheParentWindowsService.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentWindowsService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.windowsService");
    }
  }

  public class NtfsFileAttributes extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenNtfsFileAttributes;

    private Set<AttackStep> _cacheParentNtfsFileAttributes;

    public NtfsFileAttributes(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenNtfsFileAttributes == null) {
        _cacheChildrenNtfsFileAttributes = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenNtfsFileAttributes.add(((asset.Windows) Windows.this).bypassSignatureBasedDetection);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenNtfsFileAttributes.add(((asset.Windows) Windows.this).bypassHostForensicAnalysis);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenNtfsFileAttributes.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
      }
      for (AttackStep attackStep : _cacheChildrenNtfsFileAttributes) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNtfsFileAttributes == null) {
        _cacheParentNtfsFileAttributes = new HashSet<>();
        _cacheParentNtfsFileAttributes.add(hideArtifacts);
        _cacheParentNtfsFileAttributes.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentNtfsFileAttributes) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.ntfsFileAttributes");
    }
  }

  public class OfficeApplicationStartup extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenOfficeApplicationStartup;

    public OfficeApplicationStartup(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenOfficeApplicationStartup == null) {
        _cacheChildrenOfficeApplicationStartup = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenOfficeApplicationStartup.add(_0.officeTemplateMacros);
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _1 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenOfficeApplicationStartup.add(_1.officeTest);
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _2 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenOfficeApplicationStartup.add(_2.outlookForms);
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _3 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenOfficeApplicationStartup.add(_3.outlookHomePage);
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _4 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenOfficeApplicationStartup.add(_4.outlookRules);
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _5 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenOfficeApplicationStartup.add(_5.addIns);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenOfficeApplicationStartup) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.officeApplicationStartup");
    }
  }

  public class AttemptPasswordFilterDLL extends OS.AttemptPasswordFilterDLL {
    private Set<AttackStep> _cacheChildrenAttemptPasswordFilterDLL;

    private Set<AttackStep> _cacheParentAttemptPasswordFilterDLL;

    public AttemptPasswordFilterDLL(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptPasswordFilterDLL == null) {
        _cacheChildrenAttemptPasswordFilterDLL = new HashSet<>();
        _cacheChildrenAttemptPasswordFilterDLL.add(passwordFilterDLL);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPasswordFilterDLL) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPasswordFilterDLL == null) {
        _cacheParentAttemptPasswordFilterDLL = new HashSet<>();
        _cacheParentAttemptPasswordFilterDLL.add(modifyAuthenticationProcess);
      }
      for (AttackStep attackStep : _cacheParentAttemptPasswordFilterDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptPasswordFilterDLL");
    }
  }

  public class PasswordFilterDLL extends OS.PasswordFilterDLL {
    private Set<AttackStep> _cacheChildrenPasswordFilterDLL;

    private Set<AttackStep> _cacheParentPasswordFilterDLL;

    public PasswordFilterDLL(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPasswordFilterDLL == null) {
        _cacheChildrenPasswordFilterDLL = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (AdminAccount _0 : ((asset.Windows) Windows.this).adminAccount) {
            _cacheChildrenPasswordFilterDLL.add(_0.adminCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenPasswordFilterDLL) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPasswordFilterDLL == null) {
        _cacheParentPasswordFilterDLL = new HashSet<>();
        _cacheParentPasswordFilterDLL.add(attemptPasswordFilterDLL);
        _cacheParentPasswordFilterDLL.add(operatingSystemConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentPasswordFilterDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.passwordFilterDLL");
    }
  }

  public class AttemptPassTheHash extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptPassTheHash;

    private Set<AttackStep> _cacheParentAttemptPassTheHash;

    public AttemptPassTheHash(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptPassTheHash == null) {
        _cacheChildrenAttemptPassTheHash = new HashSet<>();
        _cacheChildrenAttemptPassTheHash.add(passTheHash);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPassTheHash) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPassTheHash == null) {
        _cacheParentAttemptPassTheHash = new HashSet<>();
        _cacheParentAttemptPassTheHash.add(collectHashInformation);
      }
      for (AttackStep attackStep : _cacheParentAttemptPassTheHash) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptPassTheHash");
    }
  }

  public class PassTheHash extends OS.PassTheHash {
    private Set<AttackStep> _cacheChildrenPassTheHash;

    private Set<AttackStep> _cacheParentPassTheHash;

    public PassTheHash(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPassTheHash == null) {
        _cacheChildrenPassTheHash = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenPassTheHash.add(_2.remoteSystemsConnection);
              }
            }
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenPassTheHash.add(((asset.Windows) Windows.this).bypassSystemAccessControls);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPassTheHash) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPassTheHash == null) {
        _cacheParentPassTheHash = new HashSet<>();
        _cacheParentPassTheHash.add(useAlternateAuthenticationMaterial);
        _cacheParentPassTheHash.add(attemptPassTheHash);
        _cacheParentPassTheHash.add(passwordPolicies.disable);
        _cacheParentPassTheHash.add(privilegedAccountManagement.disable);
        _cacheParentPassTheHash.add(updateSoftware.disable);
        _cacheParentPassTheHash.add(userAccountControl.disable);
      }
      for (AttackStep attackStep : _cacheParentPassTheHash) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.passTheHash");
    }
  }

  public class AttemptPassTheTicket extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptPassTheTicket;

    private Set<AttackStep> _cacheParentAttemptPassTheTicket;

    public AttemptPassTheTicket(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptPassTheTicket == null) {
        _cacheChildrenAttemptPassTheTicket = new HashSet<>();
        _cacheChildrenAttemptPassTheTicket.add(passTheTicket);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPassTheTicket) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPassTheTicket == null) {
        _cacheParentAttemptPassTheTicket = new HashSet<>();
        _cacheParentAttemptPassTheTicket.add(goldenTicket);
        _cacheParentAttemptPassTheTicket.add(silverTicket);
      }
      for (AttackStep attackStep : _cacheParentAttemptPassTheTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptPassTheTicket");
    }
  }

  public class PassTheTicket extends OS.PassTheTicket {
    private Set<AttackStep> _cacheChildrenPassTheTicket;

    private Set<AttackStep> _cacheParentPassTheTicket;

    public PassTheTicket(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPassTheTicket == null) {
        _cacheChildrenPassTheTicket = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenPassTheTicket.add(_2.remoteAccess);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenPassTheTicket) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPassTheTicket == null) {
        _cacheParentPassTheTicket = new HashSet<>();
        _cacheParentPassTheTicket.add(useAlternateAuthenticationMaterial);
        _cacheParentPassTheTicket.add(attemptPassTheTicket);
        _cacheParentPassTheTicket.add(activeDirectoryConfiguration.disable);
        _cacheParentPassTheTicket.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentPassTheTicket) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.passTheTicket");
    }
  }

  public class ParentPIDSpoofing extends OS.ParentPIDSpoofing {
    private Set<AttackStep> _cacheChildrenParentPIDSpoofing;

    private Set<AttackStep> _cacheParentParentPIDSpoofing;

    public ParentPIDSpoofing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenParentPIDSpoofing == null) {
        _cacheChildrenParentPIDSpoofing = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenParentPIDSpoofing.add(((asset.Windows) Windows.this).bypassHostForensicAnalysis);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenParentPIDSpoofing.add(((asset.Windows) Windows.this).bypassHeuristicDetection);
        }
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenParentPIDSpoofing.add(_1.attemptSpearphishingAttachment);
            }
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _2 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenParentPIDSpoofing.add(_2.attemptExploitationForPrivilegeEscalation);
          }
        }
        _cacheChildrenParentPIDSpoofing.add(commandAndScriptingInterpreter);
      }
      for (AttackStep attackStep : _cacheChildrenParentPIDSpoofing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentParentPIDSpoofing == null) {
        _cacheParentParentPIDSpoofing = new HashSet<>();
        _cacheParentParentPIDSpoofing.add(powerShell);
        _cacheParentParentPIDSpoofing.add(rundll32);
        _cacheParentParentPIDSpoofing.add(accessTokenManipulation);
      }
      for (AttackStep attackStep : _cacheParentParentPIDSpoofing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.parentPIDSpoofing");
    }
  }

  public class ExecutableInstallerFilePermissionsWeakness extends OS.ExecutableInstallerFilePermissionsWeakness {
    private Set<AttackStep> _cacheChildrenExecutableInstallerFilePermissionsWeakness;

    private Set<AttackStep> _cacheParentExecutableInstallerFilePermissionsWeakness;

    public ExecutableInstallerFilePermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenExecutableInstallerFilePermissionsWeakness == null) {
        _cacheChildrenExecutableInstallerFilePermissionsWeakness = new HashSet<>();
        _cacheChildrenExecutableInstallerFilePermissionsWeakness.add(attemptDLLSearchOrderHijacking);
        _cacheChildrenExecutableInstallerFilePermissionsWeakness.add(attemptBypassUserAccessControl);
      }
      for (AttackStep attackStep : _cacheChildrenExecutableInstallerFilePermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExecutableInstallerFilePermissionsWeakness == null) {
        _cacheParentExecutableInstallerFilePermissionsWeakness = new HashSet<>();
        _cacheParentExecutableInstallerFilePermissionsWeakness.add(hijackExecutionFlow);
        _cacheParentExecutableInstallerFilePermissionsWeakness.add(audit.disable);
        _cacheParentExecutableInstallerFilePermissionsWeakness.add(userAccountControl.disable);
      }
      for (AttackStep attackStep : _cacheParentExecutableInstallerFilePermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.executableInstallerFilePermissionsWeakness");
    }
  }

  public class PathInterception extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenPathInterception;

    private Set<AttackStep> _cacheParentPathInterception;

    public PathInterception(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPathInterception == null) {
        _cacheChildrenPathInterception = new HashSet<>();
        _cacheChildrenPathInterception.add(pathInterceptionByPATHEnvironmentVariable);
        _cacheChildrenPathInterception.add(pathInterceptionBySearchOrderHijacking);
        _cacheChildrenPathInterception.add(pathInterceptionByUnquotedPath);
      }
      for (AttackStep attackStep : _cacheChildrenPathInterception) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPathInterception == null) {
        _cacheParentPathInterception = new HashSet<>();
        _cacheParentPathInterception.add(hijackExecutionFlow);
        _cacheParentPathInterception.add(audit.disable);
        _cacheParentPathInterception.add(executionPrevention.disable);
        _cacheParentPathInterception.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentPathInterception) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.pathInterception");
    }
  }

  public class PathInterceptionByPATHEnvironmentVariable extends AttackStepMin {
    private Set<AttackStep> _cacheParentPathInterceptionByPATHEnvironmentVariable;

    public PathInterceptionByPATHEnvironmentVariable(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPathInterceptionByPATHEnvironmentVariable == null) {
        _cacheParentPathInterceptionByPATHEnvironmentVariable = new HashSet<>();
        _cacheParentPathInterceptionByPATHEnvironmentVariable.add(pathInterception);
      }
      for (AttackStep attackStep : _cacheParentPathInterceptionByPATHEnvironmentVariable) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.pathInterceptionByPATHEnvironmentVariable");
    }
  }

  public class PathInterceptionBySearchOrderHijacking extends OS.PathInterceptionBySearchOrderHijacking {
    private Set<AttackStep> _cacheChildrenPathInterceptionBySearchOrderHijacking;

    private Set<AttackStep> _cacheParentPathInterceptionBySearchOrderHijacking;

    public PathInterceptionBySearchOrderHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPathInterceptionBySearchOrderHijacking == null) {
        _cacheChildrenPathInterceptionBySearchOrderHijacking = new HashSet<>();
        _cacheChildrenPathInterceptionBySearchOrderHijacking.add(attemptDLLSearchOrderHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenPathInterceptionBySearchOrderHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPathInterceptionBySearchOrderHijacking == null) {
        _cacheParentPathInterceptionBySearchOrderHijacking = new HashSet<>();
        _cacheParentPathInterceptionBySearchOrderHijacking.add(pathInterception);
      }
      for (AttackStep attackStep : _cacheParentPathInterceptionBySearchOrderHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.pathInterceptionBySearchOrderHijacking");
    }
  }

  public class PathInterceptionByUnquotedPath extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenPathInterceptionByUnquotedPath;

    private Set<AttackStep> _cacheParentPathInterceptionByUnquotedPath;

    public PathInterceptionByUnquotedPath(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPathInterceptionByUnquotedPath == null) {
        _cacheChildrenPathInterceptionByUnquotedPath = new HashSet<>();
        _cacheChildrenPathInterceptionByUnquotedPath.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenPathInterceptionByUnquotedPath.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPathInterceptionByUnquotedPath) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPathInterceptionByUnquotedPath == null) {
        _cacheParentPathInterceptionByUnquotedPath = new HashSet<>();
        _cacheParentPathInterceptionByUnquotedPath.add(pathInterception);
      }
      for (AttackStep attackStep : _cacheParentPathInterceptionByUnquotedPath) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.pathInterceptionByUnquotedPath");
    }
  }

  public class PreOSBoot extends OS.PreOSBoot {
    private Set<AttackStep> _cacheChildrenPreOSBoot;

    public PreOSBoot(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPreOSBoot == null) {
        _cacheChildrenPreOSBoot = new HashSet<>();
        _cacheChildrenPreOSBoot.add(attemptSystemFirmware);
        _cacheChildrenPreOSBoot.add(componentFirmware);
        _cacheChildrenPreOSBoot.add(bootkit);
      }
      for (AttackStep attackStep : _cacheChildrenPreOSBoot) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.preOSBoot");
    }
  }

  public class ScheduledTaskOrJob extends OS.ScheduledTaskOrJob {
    private Set<AttackStep> _cacheChildrenScheduledTaskOrJob;

    public ScheduledTaskOrJob(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenScheduledTaskOrJob == null) {
        _cacheChildrenScheduledTaskOrJob = new HashSet<>();
        _cacheChildrenScheduledTaskOrJob.add(attemptScheduledTask);
        _cacheChildrenScheduledTaskOrJob.add(at);
      }
      for (AttackStep attackStep : _cacheChildrenScheduledTaskOrJob) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.scheduledTaskOrJob");
    }
  }

  public class SecurityAccountManager extends OS.SecurityAccountManager {
    private Set<AttackStep> _cacheChildrenSecurityAccountManager;

    private Set<AttackStep> _cacheParentSecurityAccountManager;

    public SecurityAccountManager(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSecurityAccountManager == null) {
        _cacheChildrenSecurityAccountManager = new HashSet<>();
        _cacheChildrenSecurityAccountManager.add(collectHashInformation);
        if (Windows.this instanceof Windows) {
          _cacheChildrenSecurityAccountManager.add(((asset.Windows) Windows.this).attemptLocalAccounts);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSecurityAccountManager) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSecurityAccountManager == null) {
        _cacheParentSecurityAccountManager = new HashSet<>();
        _cacheParentSecurityAccountManager.add(oSCredentialDumping);
        _cacheParentSecurityAccountManager.add(operatingSystemConfiguration.disable);
        _cacheParentSecurityAccountManager.add(passwordPolicies.disable);
        _cacheParentSecurityAccountManager.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentSecurityAccountManager) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.securityAccountManager");
    }
  }

  public class ServerSoftwareComponent extends OS.ServerSoftwareComponent {
    private Set<AttackStep> _cacheChildrenServerSoftwareComponent;

    public ServerSoftwareComponent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServerSoftwareComponent == null) {
        _cacheChildrenServerSoftwareComponent = new HashSet<>();
        _cacheChildrenServerSoftwareComponent.add(attemptSQLStoredProcedures);
        _cacheChildrenServerSoftwareComponent.add(attemptTransportAgent);
      }
      for (AttackStep attackStep : _cacheChildrenServerSoftwareComponent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.serverSoftwareComponent");
    }
  }

  public class AttemptServicesFilePermissionsWeakness extends OS.AttemptServicesFilePermissionsWeakness {
    private Set<AttackStep> _cacheChildrenAttemptServicesFilePermissionsWeakness;

    private Set<AttackStep> _cacheParentAttemptServicesFilePermissionsWeakness;

    public AttemptServicesFilePermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptServicesFilePermissionsWeakness == null) {
        _cacheChildrenAttemptServicesFilePermissionsWeakness = new HashSet<>();
        _cacheChildrenAttemptServicesFilePermissionsWeakness.add(servicesFilePermissionsWeakness);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptServicesFilePermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptServicesFilePermissionsWeakness == null) {
        _cacheParentAttemptServicesFilePermissionsWeakness = new HashSet<>();
        _cacheParentAttemptServicesFilePermissionsWeakness.add(hijackExecutionFlow);
      }
      for (AttackStep attackStep : _cacheParentAttemptServicesFilePermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptServicesFilePermissionsWeakness");
    }
  }

  public class ServicesFilePermissionsWeakness extends OS.ServicesFilePermissionsWeakness {
    private Set<AttackStep> _cacheChildrenServicesFilePermissionsWeakness;

    private Set<AttackStep> _cacheParentServicesFilePermissionsWeakness;

    public ServicesFilePermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServicesFilePermissionsWeakness == null) {
        _cacheChildrenServicesFilePermissionsWeakness = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenServicesFilePermissionsWeakness.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenServicesFilePermissionsWeakness.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenServicesFilePermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServicesFilePermissionsWeakness == null) {
        _cacheParentServicesFilePermissionsWeakness = new HashSet<>();
        _cacheParentServicesFilePermissionsWeakness.add(attemptServicesFilePermissionsWeakness);
        _cacheParentServicesFilePermissionsWeakness.add(audit.disable);
        _cacheParentServicesFilePermissionsWeakness.add(userAccountControl.disable);
      }
      for (AttackStep attackStep : _cacheParentServicesFilePermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.servicesFilePermissionsWeakness");
    }
  }

  public class ServicesRegistryPermissionsWeakness extends OS.ServicesRegistryPermissionsWeakness {
    private Set<AttackStep> _cacheChildrenServicesRegistryPermissionsWeakness;

    private Set<AttackStep> _cacheParentServicesRegistryPermissionsWeakness;

    public ServicesRegistryPermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServicesRegistryPermissionsWeakness == null) {
        _cacheChildrenServicesRegistryPermissionsWeakness = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenServicesRegistryPermissionsWeakness.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenServicesRegistryPermissionsWeakness.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenServicesRegistryPermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServicesRegistryPermissionsWeakness == null) {
        _cacheParentServicesRegistryPermissionsWeakness = new HashSet<>();
        _cacheParentServicesRegistryPermissionsWeakness.add(hijackExecutionFlow);
        _cacheParentServicesRegistryPermissionsWeakness.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentServicesRegistryPermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.servicesRegistryPermissionsWeakness");
    }
  }

  public class AttemptSQLStoredProcedures extends OS.AttemptSQLStoredProcedures {
    private Set<AttackStep> _cacheChildrenAttemptSQLStoredProcedures;

    private Set<AttackStep> _cacheParentAttemptSQLStoredProcedures;

    public AttemptSQLStoredProcedures(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSQLStoredProcedures == null) {
        _cacheChildrenAttemptSQLStoredProcedures = new HashSet<>();
        _cacheChildrenAttemptSQLStoredProcedures.add(sQLStoredProcedures);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSQLStoredProcedures) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSQLStoredProcedures == null) {
        _cacheParentAttemptSQLStoredProcedures = new HashSet<>();
        _cacheParentAttemptSQLStoredProcedures.add(serverSoftwareComponent);
      }
      for (AttackStep attackStep : _cacheParentAttemptSQLStoredProcedures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptSQLStoredProcedures");
    }
  }

  public class SQLStoredProcedures extends OS.SQLStoredProcedures {
    private Set<AttackStep> _cacheChildrenSQLStoredProcedures;

    private Set<AttackStep> _cacheParentSQLStoredProcedures;

    public SQLStoredProcedures(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSQLStoredProcedures == null) {
        _cacheChildrenSQLStoredProcedures = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenSQLStoredProcedures.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSQLStoredProcedures) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSQLStoredProcedures == null) {
        _cacheParentSQLStoredProcedures = new HashSet<>();
        _cacheParentSQLStoredProcedures.add(attemptSQLStoredProcedures);
        _cacheParentSQLStoredProcedures.add(audit.disable);
        _cacheParentSQLStoredProcedures.add(codeSigning.disable);
        _cacheParentSQLStoredProcedures.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentSQLStoredProcedures) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.sQLStoredProcedures");
    }
  }

  public class SubvertTrustControls extends OS.SubvertTrustControls {
    private Set<AttackStep> _cacheChildrenSubvertTrustControls;

    public SubvertTrustControls(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSubvertTrustControls == null) {
        _cacheChildrenSubvertTrustControls = new HashSet<>();
        _cacheChildrenSubvertTrustControls.add(codeSigningCertificate);
        _cacheChildrenSubvertTrustControls.add(sIPAndTrustProviderHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenSubvertTrustControls) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.subvertTrustControls");
    }
  }

  public class SystemServices extends OS.SystemServices {
    private Set<AttackStep> _cacheChildrenSystemServices;

    public SystemServices(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSystemServices == null) {
        _cacheChildrenSystemServices = new HashSet<>();
        _cacheChildrenSystemServices.add(serviceExecution);
      }
      for (AttackStep attackStep : _cacheChildrenSystemServices) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.systemServices");
    }
  }

  public class AttemptTransportAgent extends OS.AttemptTransportAgent {
    private Set<AttackStep> _cacheChildrenAttemptTransportAgent;

    private Set<AttackStep> _cacheParentAttemptTransportAgent;

    public AttemptTransportAgent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptTransportAgent == null) {
        _cacheChildrenAttemptTransportAgent = new HashSet<>();
        _cacheChildrenAttemptTransportAgent.add(transportAgent);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptTransportAgent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTransportAgent == null) {
        _cacheParentAttemptTransportAgent = new HashSet<>();
        _cacheParentAttemptTransportAgent.add(serverSoftwareComponent);
      }
      for (AttackStep attackStep : _cacheParentAttemptTransportAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptTransportAgent");
    }
  }

  public class TransportAgent extends OS.TransportAgent {
    private Set<AttackStep> _cacheChildrenTransportAgent;

    private Set<AttackStep> _cacheParentTransportAgent;

    public TransportAgent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTransportAgent == null) {
        _cacheChildrenTransportAgent = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenTransportAgent.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenTransportAgent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTransportAgent == null) {
        _cacheParentTransportAgent = new HashSet<>();
        _cacheParentTransportAgent.add(attemptTransportAgent);
        _cacheParentTransportAgent.add(audit.disable);
        _cacheParentTransportAgent.add(codeSigning.disable);
        _cacheParentTransportAgent.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentTransportAgent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.transportAgent");
    }
  }

  public class AttemptPowerShell extends OS.AttemptPowerShell {
    private Set<AttackStep> _cacheChildrenAttemptPowerShell;

    private Set<AttackStep> _cacheParentAttemptPowerShell;

    public AttemptPowerShell(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptPowerShell == null) {
        _cacheChildrenAttemptPowerShell = new HashSet<>();
        _cacheChildrenAttemptPowerShell.add(powerShell);
        _cacheChildrenAttemptPowerShell.add(windowsRemoteManagement);
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (User _1 : _0.user) {
              _cacheChildrenAttemptPowerShell.add(_1.attemptUserExecution);
            }
          }
        }
        _cacheChildrenAttemptPowerShell.add(commandAndScriptingInterpreter);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPowerShell) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptPowerShell == null) {
        _cacheParentAttemptPowerShell = new HashSet<>();
        _cacheParentAttemptPowerShell.add(clearWindowsEventLogs);
        _cacheParentAttemptPowerShell.add(commandAndScriptingInterpreter);
      }
      for (AttackStep attackStep : _cacheParentAttemptPowerShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptPowerShell");
    }
  }

  public class PowerShell extends OS.PowerShell {
    private Set<AttackStep> _cacheChildrenPowerShell;

    private Set<AttackStep> _cacheParentPowerShell;

    public PowerShell(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPowerShell == null) {
        _cacheChildrenPowerShell = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenPowerShell.add(_2.remoteSystemsConnection);
              }
            }
          }
        }
        if (Windows.this instanceof Windows) {
          for (Computer _3 : ((asset.Windows) Windows.this).computer) {
            for (Router _4 : _3.router) {
              for (ExternalNetwork _5 : _4.externalNetwork) {
                _cacheChildrenPowerShell.add(_5.attemptTransmittedDataManipulation);
              }
            }
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenPowerShell.add(((asset.Windows) Windows.this).attemptIndicatorBlocking);
        }
        _cacheChildrenPowerShell.add(attemptGUIInputCapture);
        _cacheChildrenPowerShell.add(parentPIDSpoofing);
        if (Windows.this instanceof Windows) {
          _cacheChildrenPowerShell.add(((asset.Windows) Windows.this).systemChecks);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenPowerShell.add(((asset.Windows) Windows.this).persistence);
        }
        _cacheChildrenPowerShell.add(attemptHiddenWindow);
      }
      for (AttackStep attackStep : _cacheChildrenPowerShell) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPowerShell == null) {
        _cacheParentPowerShell = new HashSet<>();
        _cacheParentPowerShell.add(attemptPowerShell);
        _cacheParentPowerShell.add(antivirus.disable);
        _cacheParentPowerShell.add(codeSigning.disable);
        _cacheParentPowerShell.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentPowerShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.powerShell");
    }
  }

  public class AttemptPowerShellUserProfile extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptPowerShellUserProfile;

    public AttemptPowerShellUserProfile(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptPowerShellUserProfile == null) {
        _cacheChildrenAttemptPowerShellUserProfile = new HashSet<>();
        _cacheChildrenAttemptPowerShellUserProfile.add(powerShellUserProfile);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPowerShellUserProfile) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptPowerShellUserProfile");
    }
  }

  public class PowerShellUserProfile extends OS.PowerShellUserProfile {
    private Set<AttackStep> _cacheChildrenPowerShellUserProfile;

    private Set<AttackStep> _cacheParentPowerShellUserProfile;

    public PowerShellUserProfile(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPowerShellUserProfile == null) {
        _cacheChildrenPowerShellUserProfile = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenPowerShellUserProfile.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPowerShellUserProfile) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPowerShellUserProfile == null) {
        _cacheParentPowerShellUserProfile = new HashSet<>();
        _cacheParentPowerShellUserProfile.add(eventTriggeredExecution);
        _cacheParentPowerShellUserProfile.add(attemptPowerShellUserProfile);
        _cacheParentPowerShellUserProfile.add(codeSigning.disable);
        _cacheParentPowerShellUserProfile.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentPowerShellUserProfile.add(softwareConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentPowerShellUserProfile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.powerShellUserProfile");
    }
  }

  public class AttemptPowerShellAdminProfile extends OS.AttemptPowerShellAdminProfile {
    private Set<AttackStep> _cacheChildrenAttemptPowerShellAdminProfile;

    public AttemptPowerShellAdminProfile(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptPowerShellAdminProfile == null) {
        _cacheChildrenAttemptPowerShellAdminProfile = new HashSet<>();
        _cacheChildrenAttemptPowerShellAdminProfile.add(powerShellAdminProfile);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptPowerShellAdminProfile) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptPowerShellAdminProfile");
    }
  }

  public class PowerShellAdminProfile extends OS.PowerShellAdminProfile {
    private Set<AttackStep> _cacheChildrenPowerShellAdminProfile;

    private Set<AttackStep> _cacheParentPowerShellAdminProfile;

    public PowerShellAdminProfile(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPowerShellAdminProfile == null) {
        _cacheChildrenPowerShellAdminProfile = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenPowerShellAdminProfile.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenPowerShellAdminProfile.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPowerShellAdminProfile) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPowerShellAdminProfile == null) {
        _cacheParentPowerShellAdminProfile = new HashSet<>();
        _cacheParentPowerShellAdminProfile.add(eventTriggeredExecution);
        _cacheParentPowerShellAdminProfile.add(attemptPowerShellAdminProfile);
        _cacheParentPowerShellAdminProfile.add(codeSigning.disable);
        _cacheParentPowerShellAdminProfile.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentPowerShellAdminProfile.add(softwareConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentPowerShellAdminProfile) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.powerShellAdminProfile");
    }
  }

  public class ProcessDoppelganging extends OS.ProcessDoppelganging {
    private Set<AttackStep> _cacheChildrenProcessDoppelganging;

    private Set<AttackStep> _cacheParentProcessDoppelganging;

    public ProcessDoppelganging(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenProcessDoppelganging == null) {
        _cacheChildrenProcessDoppelganging = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenProcessDoppelganging.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenProcessDoppelganging.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenProcessDoppelganging) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcessDoppelganging == null) {
        _cacheParentProcessDoppelganging = new HashSet<>();
        _cacheParentProcessDoppelganging.add(processInjection);
        _cacheParentProcessDoppelganging.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentProcessDoppelganging) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.processDoppelganging");
    }
  }

  public class ProcessHollowing extends OS.ProcessHollowing {
    private Set<AttackStep> _cacheChildrenProcessHollowing;

    private Set<AttackStep> _cacheParentProcessHollowing;

    public ProcessHollowing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenProcessHollowing == null) {
        _cacheChildrenProcessHollowing = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenProcessHollowing.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenProcessHollowing.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
      }
      for (AttackStep attackStep : _cacheChildrenProcessHollowing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcessHollowing == null) {
        _cacheParentProcessHollowing = new HashSet<>();
        _cacheParentProcessHollowing.add(processInjection);
        _cacheParentProcessHollowing.add(behaviorPreventionOnEndpoint.disable);
      }
      for (AttackStep attackStep : _cacheParentProcessHollowing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.processHollowing");
    }
  }

  public class ProcessInjection extends OS.ProcessInjection {
    private Set<AttackStep> _cacheChildrenProcessInjection;

    private Set<AttackStep> _cacheParentProcessInjection;

    public ProcessInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenProcessInjection == null) {
        _cacheChildrenProcessInjection = new HashSet<>();
        _cacheChildrenProcessInjection.add(dynamicLinkLibraryInjection);
        _cacheChildrenProcessInjection.add(portableExecutableInjection);
        _cacheChildrenProcessInjection.add(threadExecutionHijacking);
        _cacheChildrenProcessInjection.add(asynchronousProcedureCall);
        _cacheChildrenProcessInjection.add(threadLocalStorage);
        _cacheChildrenProcessInjection.add(extraWindowMemoryInjection);
        _cacheChildrenProcessInjection.add(processHollowing);
        _cacheChildrenProcessInjection.add(processDoppelganging);
      }
      for (AttackStep attackStep : _cacheChildrenProcessInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentProcessInjection == null) {
        _cacheParentProcessInjection = new HashSet<>();
        _cacheParentProcessInjection.add(appCertDLLs);
        _cacheParentProcessInjection.add(componentObjectModelHijacking);
        _cacheParentProcessInjection.add(executionThroughAPI);
        _cacheParentProcessInjection.add(imageFileExecutionOptionsInjection);
        _cacheParentProcessInjection.add(applicationShimming);
      }
      for (AttackStep attackStep : _cacheParentProcessInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.processInjection");
    }
  }

  public class CodeProxyExecution extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCodeProxyExecution;

    private Set<AttackStep> _cacheParentCodeProxyExecution;

    public CodeProxyExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCodeProxyExecution == null) {
        _cacheChildrenCodeProxyExecution = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenCodeProxyExecution.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenCodeProxyExecution.add(((asset.Windows) Windows.this).bypassDigitalCertificateValidation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCodeProxyExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCodeProxyExecution == null) {
        _cacheParentCodeProxyExecution = new HashSet<>();
        _cacheParentCodeProxyExecution.add(cmstp);
        _cacheParentCodeProxyExecution.add(msiexec);
        _cacheParentCodeProxyExecution.add(odbcconf);
        _cacheParentCodeProxyExecution.add(installUtil);
        _cacheParentCodeProxyExecution.add(regsvcsOrRegasm);
        _cacheParentCodeProxyExecution.add(regsvr32);
        _cacheParentCodeProxyExecution.add(rundll32);
        _cacheParentCodeProxyExecution.add(mSBuild);
      }
      for (AttackStep attackStep : _cacheParentCodeProxyExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.codeProxyExecution");
    }
  }

  public class FileProxyExecution extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenFileProxyExecution;

    private Set<AttackStep> _cacheParentFileProxyExecution;

    public FileProxyExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenFileProxyExecution == null) {
        _cacheChildrenFileProxyExecution = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenFileProxyExecution.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenFileProxyExecution.add(((asset.Windows) Windows.this).bypassDigitalCertificateValidation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenFileProxyExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentFileProxyExecution == null) {
        _cacheParentFileProxyExecution = new HashSet<>();
        _cacheParentFileProxyExecution.add(mshta);
        _cacheParentFileProxyExecution.add(pubPrn);
      }
      for (AttackStep attackStep : _cacheParentFileProxyExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.fileProxyExecution");
    }
  }

  public class RDPHijacking extends OS.RDPHijacking {
    private Set<AttackStep> _cacheChildrenRDPHijacking;

    private Set<AttackStep> _cacheParentRDPHijacking;

    public RDPHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRDPHijacking == null) {
        _cacheChildrenRDPHijacking = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenRDPHijacking.add(_0.userCredentials);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenRDPHijacking.add(((asset.Windows) Windows.this).remoteSystemDiscovery);
        }
      }
      for (AttackStep attackStep : _cacheChildrenRDPHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRDPHijacking == null) {
        _cacheParentRDPHijacking = new HashSet<>();
        _cacheParentRDPHijacking.add(audit.disable);
        _cacheParentRDPHijacking.add(operatingSystemConfiguration.disable);
        _cacheParentRDPHijacking.add(privilegedAccountManagement.disable);
        _cacheParentRDPHijacking.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentRDPHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.rDPHijacking");
    }
  }

  public class RDPSessionHijacking extends AttackStepMin {
    private Set<AttackStep> _cacheParentRDPSessionHijacking;

    public RDPSessionHijacking(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRDPSessionHijacking == null) {
        _cacheParentRDPSessionHijacking = new HashSet<>();
        _cacheParentRDPSessionHijacking.add(remoteDesktopProtocol);
      }
      for (AttackStep attackStep : _cacheParentRDPSessionHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.rDPSessionHijacking");
    }
  }

  public class RegistryRunKeysOrStartupFolder extends OS.RegistryRunKeysOrStartupFolder {
    private Set<AttackStep> _cacheChildrenRegistryRunKeysOrStartupFolder;

    private Set<AttackStep> _cacheParentRegistryRunKeysOrStartupFolder;

    public RegistryRunKeysOrStartupFolder(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRegistryRunKeysOrStartupFolder == null) {
        _cacheChildrenRegistryRunKeysOrStartupFolder = new HashSet<>();
        _cacheChildrenRegistryRunKeysOrStartupFolder.add(masquerading);
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenRegistryRunKeysOrStartupFolder.add(_0.remoteAccessSoftware);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenRegistryRunKeysOrStartupFolder.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenRegistryRunKeysOrStartupFolder) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRegistryRunKeysOrStartupFolder == null) {
        _cacheParentRegistryRunKeysOrStartupFolder = new HashSet<>();
        _cacheParentRegistryRunKeysOrStartupFolder.add(bootOrLogonAutostartExecution);
      }
      for (AttackStep attackStep : _cacheParentRegistryRunKeysOrStartupFolder) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.registryRunKeysOrStartupFolder");
    }
  }

  public class RegsvcsOrRegasm extends OS.RegsvcsOrRegasm {
    private Set<AttackStep> _cacheChildrenRegsvcsOrRegasm;

    private Set<AttackStep> _cacheParentRegsvcsOrRegasm;

    public RegsvcsOrRegasm(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRegsvcsOrRegasm == null) {
        _cacheChildrenRegsvcsOrRegasm = new HashSet<>();
        _cacheChildrenRegsvcsOrRegasm.add(codeProxyExecution);
        _cacheChildrenRegsvcsOrRegasm.add(attemptComponentObjectModel);
      }
      for (AttackStep attackStep : _cacheChildrenRegsvcsOrRegasm) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRegsvcsOrRegasm == null) {
        _cacheParentRegsvcsOrRegasm = new HashSet<>();
        _cacheParentRegsvcsOrRegasm.add(signedBinaryProxyExecution);
        _cacheParentRegsvcsOrRegasm.add(executionPrevention.disable);
        _cacheParentRegsvcsOrRegasm.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentRegsvcsOrRegasm) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.regsvcsOrRegasm");
    }
  }

  public class Regsvr32 extends OS.Regsvr32 {
    private Set<AttackStep> _cacheChildrenRegsvr32;

    private Set<AttackStep> _cacheParentRegsvr32;

    public Regsvr32(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRegsvr32 == null) {
        _cacheChildrenRegsvr32 = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenRegsvr32.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        _cacheChildrenRegsvr32.add(codeProxyExecution);
        _cacheChildrenRegsvr32.add(componentObjectModelHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenRegsvr32) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRegsvr32 == null) {
        _cacheParentRegsvr32 = new HashSet<>();
        _cacheParentRegsvr32.add(signedBinaryProxyExecution);
        _cacheParentRegsvr32.add(exploitProtection.disable);
      }
      for (AttackStep attackStep : _cacheParentRegsvr32) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.regsvr32");
    }
  }

  public class AttemptRemoteDesktopProtocol extends OS.AttemptRemoteDesktopProtocol {
    private Set<AttackStep> _cacheChildrenAttemptRemoteDesktopProtocol;

    private Set<AttackStep> _cacheParentAttemptRemoteDesktopProtocol;

    public AttemptRemoteDesktopProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptRemoteDesktopProtocol == null) {
        _cacheChildrenAttemptRemoteDesktopProtocol = new HashSet<>();
        _cacheChildrenAttemptRemoteDesktopProtocol.add(remoteDesktopProtocol);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptRemoteDesktopProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptRemoteDesktopProtocol == null) {
        _cacheParentAttemptRemoteDesktopProtocol = new HashSet<>();
        _cacheParentAttemptRemoteDesktopProtocol.add(lateralToolTransfer);
        _cacheParentAttemptRemoteDesktopProtocol.add(remoteFileCopy);
        _cacheParentAttemptRemoteDesktopProtocol.add(remoteEmailCollection);
      }
      for (AttackStep attackStep : _cacheParentAttemptRemoteDesktopProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptRemoteDesktopProtocol");
    }
  }

  public class RemoteDesktopProtocol extends OS.RemoteDesktopProtocol {
    private Set<AttackStep> _cacheChildrenRemoteDesktopProtocol;

    private Set<AttackStep> _cacheParentRemoteDesktopProtocol;

    public RemoteDesktopProtocol(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRemoteDesktopProtocol == null) {
        _cacheChildrenRemoteDesktopProtocol = new HashSet<>();
        _cacheChildrenRemoteDesktopProtocol.add(attemptAccessibilityFeatures);
        if (Windows.this instanceof Windows) {
          _cacheChildrenRemoteDesktopProtocol.add(((asset.Windows) Windows.this).remoteSystemDiscovery);
        }
        _cacheChildrenRemoteDesktopProtocol.add(rDPSessionHijacking);
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenRemoteDesktopProtocol.add(_2.attemptExfiltrationOverC2Channel);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenRemoteDesktopProtocol) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteDesktopProtocol == null) {
        _cacheParentRemoteDesktopProtocol = new HashSet<>();
        _cacheParentRemoteDesktopProtocol.add(attemptRemoteDesktopProtocol);
        _cacheParentRemoteDesktopProtocol.add(audit.disable);
        _cacheParentRemoteDesktopProtocol.add(operatingSystemConfiguration.disable);
        _cacheParentRemoteDesktopProtocol.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentRemoteDesktopProtocol) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.remoteDesktopProtocol");
    }
  }

  public class ReplicationThroughRemovableMedia extends OS.ReplicationThroughRemovableMedia {
    private Set<AttackStep> _cacheChildrenReplicationThroughRemovableMedia;

    private Set<AttackStep> _cacheParentReplicationThroughRemovableMedia;

    public ReplicationThroughRemovableMedia(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenReplicationThroughRemovableMedia == null) {
        _cacheChildrenReplicationThroughRemovableMedia = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenReplicationThroughRemovableMedia.add(((asset.Windows) Windows.this).communicationThroughRemovableMedia);
        }
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (PeripheralDevice _1 : _0.peripheralDevice) {
              _cacheChildrenReplicationThroughRemovableMedia.add(_1.infectedMedia);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenReplicationThroughRemovableMedia) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentReplicationThroughRemovableMedia == null) {
        _cacheParentReplicationThroughRemovableMedia = new HashSet<>();
        _cacheParentReplicationThroughRemovableMedia.add(limitHardwareInstallation.disable);
        _cacheParentReplicationThroughRemovableMedia.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentReplicationThroughRemovableMedia) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.replicationThroughRemovableMedia");
    }
  }

  public class Rootkit extends OS.Rootkit {
    private Set<AttackStep> _cacheChildrenRootkit;

    public Rootkit(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRootkit == null) {
        _cacheChildrenRootkit = new HashSet<>();
        _cacheChildrenRootkit.add(credentialAPIHooking);
        _cacheChildrenRootkit.add(attemptSystemFirmware);
      }
      for (AttackStep attackStep : _cacheChildrenRootkit) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.rootkit");
    }
  }

  public class Rundll32 extends OS.Rundll32 {
    private Set<AttackStep> _cacheChildrenRundll32;

    private Set<AttackStep> _cacheParentRundll32;

    public Rundll32(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRundll32 == null) {
        _cacheChildrenRundll32 = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenRundll32.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        _cacheChildrenRundll32.add(parentPIDSpoofing);
        _cacheChildrenRundll32.add(codeProxyExecution);
        _cacheChildrenRundll32.add(attemptControlPanel);
      }
      for (AttackStep attackStep : _cacheChildrenRundll32) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRundll32 == null) {
        _cacheParentRundll32 = new HashSet<>();
        _cacheParentRundll32.add(signedBinaryProxyExecution);
        _cacheParentRundll32.add(exploitProtection.disable);
      }
      for (AttackStep attackStep : _cacheParentRundll32) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.rundll32");
    }
  }

  public class Screensaver extends OS.Screensaver {
    private Set<AttackStep> _cacheChildrenScreensaver;

    private Set<AttackStep> _cacheParentScreensaver;

    public Screensaver(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenScreensaver == null) {
        _cacheChildrenScreensaver = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenScreensaver.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenScreensaver) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentScreensaver == null) {
        _cacheParentScreensaver = new HashSet<>();
        _cacheParentScreensaver.add(eventTriggeredExecution);
        _cacheParentScreensaver.add(executionPrevention.disable);
        _cacheParentScreensaver.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentScreensaver) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.screensaver");
    }
  }

  public class SearchOrderHijacking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSearchOrderHijacking;

    public SearchOrderHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSearchOrderHijacking == null) {
        _cacheChildrenSearchOrderHijacking = new HashSet<>();
        _cacheChildrenSearchOrderHijacking.add(attemptDLLSearchOrderHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenSearchOrderHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.searchOrderHijacking");
    }
  }

  public class SecuritySupportProvider extends OS.SecuritySupportProvider {
    private Set<AttackStep> _cacheChildrenSecuritySupportProvider;

    private Set<AttackStep> _cacheParentSecuritySupportProvider;

    public SecuritySupportProvider(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSecuritySupportProvider == null) {
        _cacheChildrenSecuritySupportProvider = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenSecuritySupportProvider.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSecuritySupportProvider) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSecuritySupportProvider == null) {
        _cacheParentSecuritySupportProvider = new HashSet<>();
        _cacheParentSecuritySupportProvider.add(bootOrLogonAutostartExecution);
        _cacheParentSecuritySupportProvider.add(modifyRegistry);
        _cacheParentSecuritySupportProvider.add(privilegedProcessIntegrity.disable);
      }
      for (AttackStep attackStep : _cacheParentSecuritySupportProvider) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.securitySupportProvider");
    }
  }

  public class AttemptServiceExecution extends OS.AttemptServiceExecution {
    private Set<AttackStep> _cacheChildrenAttemptServiceExecution;

    private Set<AttackStep> _cacheParentAttemptServiceExecution;

    public AttemptServiceExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptServiceExecution == null) {
        _cacheChildrenAttemptServiceExecution = new HashSet<>();
        _cacheChildrenAttemptServiceExecution.add(serviceExecution);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptServiceExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptServiceExecution == null) {
        _cacheParentAttemptServiceExecution = new HashSet<>();
        _cacheParentAttemptServiceExecution.add(groupPolicyModification);
      }
      for (AttackStep attackStep : _cacheParentAttemptServiceExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptServiceExecution");
    }
  }

  public class ServiceExecution extends OS.ServiceExecution {
    private Set<AttackStep> _cacheChildrenServiceExecution;

    private Set<AttackStep> _cacheParentServiceExecution;

    public ServiceExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServiceExecution == null) {
        _cacheChildrenServiceExecution = new HashSet<>();
        _cacheChildrenServiceExecution.add(attemptWindowsService);
      }
      for (AttackStep attackStep : _cacheChildrenServiceExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceExecution == null) {
        _cacheParentServiceExecution = new HashSet<>();
        _cacheParentServiceExecution.add(systemServices);
        _cacheParentServiceExecution.add(attemptServiceExecution);
        _cacheParentServiceExecution.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentServiceExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.serviceExecution");
    }
  }

  public class AttemptServiceRegistryPermissionsWeakness extends OS.AttemptServiceRegistryPermissionsWeakness {
    private Set<AttackStep> _cacheChildrenAttemptServiceRegistryPermissionsWeakness;

    public AttemptServiceRegistryPermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptServiceRegistryPermissionsWeakness == null) {
        _cacheChildrenAttemptServiceRegistryPermissionsWeakness = new HashSet<>();
        _cacheChildrenAttemptServiceRegistryPermissionsWeakness.add(serviceRegistryPermissionsWeakness);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptServiceRegistryPermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptServiceRegistryPermissionsWeakness");
    }
  }

  public class ServiceRegistryPermissionsWeakness extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenServiceRegistryPermissionsWeakness;

    private Set<AttackStep> _cacheParentServiceRegistryPermissionsWeakness;

    public ServiceRegistryPermissionsWeakness(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenServiceRegistryPermissionsWeakness == null) {
        _cacheChildrenServiceRegistryPermissionsWeakness = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenServiceRegistryPermissionsWeakness.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenServiceRegistryPermissionsWeakness) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceRegistryPermissionsWeakness == null) {
        _cacheParentServiceRegistryPermissionsWeakness = new HashSet<>();
        _cacheParentServiceRegistryPermissionsWeakness.add(attemptServiceRegistryPermissionsWeakness);
        _cacheParentServiceRegistryPermissionsWeakness.add(restrictRegistryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentServiceRegistryPermissionsWeakness) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.serviceRegistryPermissionsWeakness");
    }
  }

  public class AttemptShortcutModification extends OS.AttemptShortcutModification {
    private Set<AttackStep> _cacheChildrenAttemptShortcutModification;

    private Set<AttackStep> _cacheParentAttemptShortcutModification;

    public AttemptShortcutModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptShortcutModification == null) {
        _cacheChildrenAttemptShortcutModification = new HashSet<>();
        _cacheChildrenAttemptShortcutModification.add(shortcutModification);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptShortcutModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptShortcutModification == null) {
        _cacheParentAttemptShortcutModification = new HashSet<>();
        _cacheParentAttemptShortcutModification.add(bootOrLogonAutostartExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptShortcutModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptShortcutModification");
    }
  }

  public class ShortcutModification extends OS.ShortcutModification {
    private Set<AttackStep> _cacheChildrenShortcutModification;

    private Set<AttackStep> _cacheParentShortcutModification;

    public ShortcutModification(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenShortcutModification == null) {
        _cacheChildrenShortcutModification = new HashSet<>();
        _cacheChildrenShortcutModification.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenShortcutModification.add(((asset.Windows) Windows.this).persistence);
        }
        _cacheChildrenShortcutModification.add(masquerading);
      }
      for (AttackStep attackStep : _cacheChildrenShortcutModification) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentShortcutModification == null) {
        _cacheParentShortcutModification = new HashSet<>();
        _cacheParentShortcutModification.add(attemptShortcutModification);
      }
      for (AttackStep attackStep : _cacheParentShortcutModification) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.shortcutModification");
    }
  }

  public class AttemptSIDHistoryInjection extends OS.AttemptSIDHistoryInjection {
    private Set<AttackStep> _cacheChildrenAttemptSIDHistoryInjection;

    private Set<AttackStep> _cacheParentAttemptSIDHistoryInjection;

    public AttemptSIDHistoryInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSIDHistoryInjection == null) {
        _cacheChildrenAttemptSIDHistoryInjection = new HashSet<>();
        _cacheChildrenAttemptSIDHistoryInjection.add(sIDHistoryInjection);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSIDHistoryInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSIDHistoryInjection == null) {
        _cacheParentAttemptSIDHistoryInjection = new HashSet<>();
        _cacheParentAttemptSIDHistoryInjection.add(dCShadow);
        _cacheParentAttemptSIDHistoryInjection.add(accessTokenManipulation);
      }
      for (AttackStep attackStep : _cacheParentAttemptSIDHistoryInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptSIDHistoryInjection");
    }
  }

  public class SIDHistoryInjection extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSIDHistoryInjection;

    private Set<AttackStep> _cacheParentSIDHistoryInjection;

    public SIDHistoryInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSIDHistoryInjection == null) {
        _cacheChildrenSIDHistoryInjection = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenSIDHistoryInjection.add(((asset.Windows) Windows.this).persistence);
        }
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenSIDHistoryInjection.add(_0.remoteServices);
          }
        }
        _cacheChildrenSIDHistoryInjection.add(attemptWindowsAdminShares);
        _cacheChildrenSIDHistoryInjection.add(windowsRemoteManagement);
      }
      for (AttackStep attackStep : _cacheChildrenSIDHistoryInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSIDHistoryInjection == null) {
        _cacheParentSIDHistoryInjection = new HashSet<>();
        _cacheParentSIDHistoryInjection.add(attemptSIDHistoryInjection);
        _cacheParentSIDHistoryInjection.add(activeDirectoryConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentSIDHistoryInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.sIDHistoryInjection");
    }
  }

  public class SignedBinaryProxyExecution extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSignedBinaryProxyExecution;

    public SignedBinaryProxyExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSignedBinaryProxyExecution == null) {
        _cacheChildrenSignedBinaryProxyExecution = new HashSet<>();
        _cacheChildrenSignedBinaryProxyExecution.add(compiledHTMLFile);
        _cacheChildrenSignedBinaryProxyExecution.add(attemptControlPanel);
        _cacheChildrenSignedBinaryProxyExecution.add(cmstp);
        _cacheChildrenSignedBinaryProxyExecution.add(installUtil);
        _cacheChildrenSignedBinaryProxyExecution.add(mshta);
        _cacheChildrenSignedBinaryProxyExecution.add(msiexec);
        _cacheChildrenSignedBinaryProxyExecution.add(odbcconf);
        _cacheChildrenSignedBinaryProxyExecution.add(regsvcsOrRegasm);
        _cacheChildrenSignedBinaryProxyExecution.add(regsvr32);
        _cacheChildrenSignedBinaryProxyExecution.add(rundll32);
      }
      for (AttackStep attackStep : _cacheChildrenSignedBinaryProxyExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.signedBinaryProxyExecution");
    }
  }

  public class SignedScriptProxyExecution extends OS.SignedScriptProxyExecution {
    private Set<AttackStep> _cacheChildrenSignedScriptProxyExecution;

    public SignedScriptProxyExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSignedScriptProxyExecution == null) {
        _cacheChildrenSignedScriptProxyExecution = new HashSet<>();
        _cacheChildrenSignedScriptProxyExecution.add(pubPrn);
      }
      for (AttackStep attackStep : _cacheChildrenSignedScriptProxyExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.signedScriptProxyExecution");
    }
  }

  public class PubPrn extends OS.PubPrn {
    private Set<AttackStep> _cacheChildrenPubPrn;

    private Set<AttackStep> _cacheParentPubPrn;

    public PubPrn(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPubPrn == null) {
        _cacheChildrenPubPrn = new HashSet<>();
        _cacheChildrenPubPrn.add(fileProxyExecution);
      }
      for (AttackStep attackStep : _cacheChildrenPubPrn) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPubPrn == null) {
        _cacheParentPubPrn = new HashSet<>();
        _cacheParentPubPrn.add(signedScriptProxyExecution);
        _cacheParentPubPrn.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentPubPrn) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.pubPrn");
    }
  }

  public class AttemptSIPAndTrustProviderHijacking extends OS.AttemptSIPAndTrustProviderHijacking {
    private Set<AttackStep> _cacheChildrenAttemptSIPAndTrustProviderHijacking;

    public AttemptSIPAndTrustProviderHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSIPAndTrustProviderHijacking == null) {
        _cacheChildrenAttemptSIPAndTrustProviderHijacking = new HashSet<>();
        _cacheChildrenAttemptSIPAndTrustProviderHijacking.add(sIPAndTrustProviderHijacking);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSIPAndTrustProviderHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptSIPAndTrustProviderHijacking");
    }
  }

  public class SIPAndTrustProviderHijacking extends OS.SIPAndTrustProviderHijacking {
    private Set<AttackStep> _cacheChildrenSIPAndTrustProviderHijacking;

    private Set<AttackStep> _cacheParentSIPAndTrustProviderHijacking;

    public SIPAndTrustProviderHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSIPAndTrustProviderHijacking == null) {
        _cacheChildrenSIPAndTrustProviderHijacking = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenSIPAndTrustProviderHijacking.add(((asset.Windows) Windows.this).bypassApplicationControl);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenSIPAndTrustProviderHijacking.add(((asset.Windows) Windows.this).bypassAutorunsAnalysis);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenSIPAndTrustProviderHijacking.add(((asset.Windows) Windows.this).bypassDigitalCertificateValidation);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenSIPAndTrustProviderHijacking.add(((asset.Windows) Windows.this).bypassUserModeSignatureValidation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSIPAndTrustProviderHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSIPAndTrustProviderHijacking == null) {
        _cacheParentSIPAndTrustProviderHijacking = new HashSet<>();
        _cacheParentSIPAndTrustProviderHijacking.add(subvertTrustControls);
        _cacheParentSIPAndTrustProviderHijacking.add(attemptSIPAndTrustProviderHijacking);
        _cacheParentSIPAndTrustProviderHijacking.add(executionPrevention.disable);
        _cacheParentSIPAndTrustProviderHijacking.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentSIPAndTrustProviderHijacking.add(restrictRegistryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentSIPAndTrustProviderHijacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.sIPAndTrustProviderHijacking");
    }
  }

  public class AttemptSoftwarePacking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSoftwarePacking;

    private Set<AttackStep> _cacheParentAttemptSoftwarePacking;

    public AttemptSoftwarePacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSoftwarePacking == null) {
        _cacheChildrenAttemptSoftwarePacking = new HashSet<>();
        _cacheChildrenAttemptSoftwarePacking.add(softwarePacking);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSoftwarePacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSoftwarePacking == null) {
        _cacheParentAttemptSoftwarePacking = new HashSet<>();
        _cacheParentAttemptSoftwarePacking.add(obfuscatedFilesOrInformation);
      }
      for (AttackStep attackStep : _cacheParentAttemptSoftwarePacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptSoftwarePacking");
    }
  }

  public class SoftwarePacking extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSoftwarePacking;

    private Set<AttackStep> _cacheParentSoftwarePacking;

    public SoftwarePacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSoftwarePacking == null) {
        _cacheChildrenSoftwarePacking = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenSoftwarePacking.add(((asset.Windows) Windows.this).indicatorRemovalFromTools);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenSoftwarePacking.add(((asset.Windows) Windows.this).bypassSignatureBasedDetection);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenSoftwarePacking.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenSoftwarePacking.add(((asset.Windows) Windows.this).bypassHeuristicDetection);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSoftwarePacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSoftwarePacking == null) {
        _cacheParentSoftwarePacking = new HashSet<>();
        _cacheParentSoftwarePacking.add(attemptSoftwarePacking);
        _cacheParentSoftwarePacking.add(antivirus.disable);
      }
      for (AttackStep attackStep : _cacheParentSoftwarePacking) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.softwarePacking");
    }
  }

  public class SystemServiceDiscovery extends OS.SystemServiceDiscovery {
    private Set<AttackStep> _cacheChildrenSystemServiceDiscovery;

    public SystemServiceDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSystemServiceDiscovery == null) {
        _cacheChildrenSystemServiceDiscovery = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenSystemServiceDiscovery.add(_0.serviceInformation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenSystemServiceDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.systemServiceDiscovery");
    }
  }

  public class AttemptTaintSharedContent extends OS.AttemptTaintSharedContent {
    private Set<AttackStep> _cacheChildrenAttemptTaintSharedContent;

    private Set<AttackStep> _cacheParentAttemptTaintSharedContent;

    public AttemptTaintSharedContent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptTaintSharedContent == null) {
        _cacheChildrenAttemptTaintSharedContent = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenAttemptTaintSharedContent.add(_2.taintSharedContent);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenAttemptTaintSharedContent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTaintSharedContent == null) {
        _cacheParentAttemptTaintSharedContent = new HashSet<>();
        _cacheParentAttemptTaintSharedContent.add(templateInjection);
      }
      for (AttackStep attackStep : _cacheParentAttemptTaintSharedContent) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptTaintSharedContent");
    }
  }

  public class TemplateInjection extends OS.TemplateInjection {
    private Set<AttackStep> _cacheChildrenTemplateInjection;

    private Set<AttackStep> _cacheParentTemplateInjection;

    public TemplateInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTemplateInjection == null) {
        _cacheChildrenTemplateInjection = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenTemplateInjection.add(((asset.Windows) Windows.this).bypassStaticFileAnalysis);
        }
        _cacheChildrenTemplateInjection.add(forcedAuthentication);
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            for (Browser _1 : _0.browser) {
              _cacheChildrenTemplateInjection.add(_1.spearphishingAttachment);
            }
          }
        }
        _cacheChildrenTemplateInjection.add(attemptTaintSharedContent);
      }
      for (AttackStep attackStep : _cacheChildrenTemplateInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTemplateInjection == null) {
        _cacheParentTemplateInjection = new HashSet<>();
        _cacheParentTemplateInjection.add(forcedAuthentication);
        _cacheParentTemplateInjection.add(antivirus.disable);
        _cacheParentTemplateInjection.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentTemplateInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.templateInjection");
    }
  }

  public class AttemptTimeProviders extends OS.AttemptTimeProviders {
    private Set<AttackStep> _cacheChildrenAttemptTimeProviders;

    private Set<AttackStep> _cacheParentAttemptTimeProviders;

    public AttemptTimeProviders(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptTimeProviders == null) {
        _cacheChildrenAttemptTimeProviders = new HashSet<>();
        _cacheChildrenAttemptTimeProviders.add(timeProviders);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptTimeProviders) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTimeProviders == null) {
        _cacheParentAttemptTimeProviders = new HashSet<>();
        _cacheParentAttemptTimeProviders.add(bootOrLogonAutostartExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptTimeProviders) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptTimeProviders");
    }
  }

  public class TimeProviders extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenTimeProviders;

    private Set<AttackStep> _cacheParentTimeProviders;

    public TimeProviders(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenTimeProviders == null) {
        _cacheChildrenTimeProviders = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenTimeProviders.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenTimeProviders) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTimeProviders == null) {
        _cacheParentTimeProviders = new HashSet<>();
        _cacheParentTimeProviders.add(attemptTimeProviders);
        _cacheParentTimeProviders.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentTimeProviders.add(restrictRegistryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentTimeProviders) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.timeProviders");
    }
  }

  public class TrustedDeveloperUtilities extends OS.TrustedDeveloperUtilities {
    private Set<AttackStep> _cacheChildrenTrustedDeveloperUtilities;

    public TrustedDeveloperUtilities(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTrustedDeveloperUtilities == null) {
        _cacheChildrenTrustedDeveloperUtilities = new HashSet<>();
        _cacheChildrenTrustedDeveloperUtilities.add(mSBuild);
      }
      for (AttackStep attackStep : _cacheChildrenTrustedDeveloperUtilities) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.trustedDeveloperUtilities");
    }
  }

  public class MSBuild extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenMSBuild;

    private Set<AttackStep> _cacheParentMSBuild;

    public MSBuild(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMSBuild == null) {
        _cacheChildrenMSBuild = new HashSet<>();
        _cacheChildrenMSBuild.add(codeProxyExecution);
      }
      for (AttackStep attackStep : _cacheChildrenMSBuild) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMSBuild == null) {
        _cacheParentMSBuild = new HashSet<>();
        _cacheParentMSBuild.add(trustedDeveloperUtilities);
        _cacheParentMSBuild.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentMSBuild) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.mSBuild");
    }
  }

  public class UnquotedPaths extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenUnquotedPaths;

    public UnquotedPaths(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUnquotedPaths == null) {
        _cacheChildrenUnquotedPaths = new HashSet<>();
        _cacheChildrenUnquotedPaths.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenUnquotedPaths) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.unquotedPaths");
    }
  }

  public class AttemptServiceStop extends OS.AttemptServiceStop {
    private Set<AttackStep> _cacheChildrenAttemptServiceStop;

    private Set<AttackStep> _cacheParentAttemptServiceStop;

    public AttemptServiceStop(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptServiceStop == null) {
        _cacheChildrenAttemptServiceStop = new HashSet<>();
        _cacheChildrenAttemptServiceStop.add(serviceStop);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptServiceStop) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptServiceStop == null) {
        _cacheParentAttemptServiceStop = new HashSet<>();
        _cacheParentAttemptServiceStop.add(serviceExhaustionFlood);
      }
      for (AttackStep attackStep : _cacheParentAttemptServiceStop) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptServiceStop");
    }
  }

  public class ServiceStop extends OS.ServiceStop {
    private Set<AttackStep> _cacheChildrenServiceStop;

    private Set<AttackStep> _cacheParentServiceStop;

    public ServiceStop(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServiceStop == null) {
        _cacheChildrenServiceStop = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenServiceStop.add(((asset.Windows) Windows.this).attemptDataDestruction);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenServiceStop.add(((asset.Windows) Windows.this).attemptDataEncryptedForImpact);
        }
      }
      for (AttackStep attackStep : _cacheChildrenServiceStop) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceStop == null) {
        _cacheParentServiceStop = new HashSet<>();
        _cacheParentServiceStop.add(attemptServiceStop);
        _cacheParentServiceStop.add(restrictFileAndDirectoryPermissions.disable);
        _cacheParentServiceStop.add(restrictRegistryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentServiceStop) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.serviceStop");
    }
  }

  public class AttemptScheduledTask extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptScheduledTask;

    private Set<AttackStep> _cacheParentAttemptScheduledTask;

    public AttemptScheduledTask(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptScheduledTask == null) {
        _cacheChildrenAttemptScheduledTask = new HashSet<>();
        _cacheChildrenAttemptScheduledTask.add(scheduledTask);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptScheduledTask) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptScheduledTask == null) {
        _cacheParentAttemptScheduledTask = new HashSet<>();
        _cacheParentAttemptScheduledTask.add(at);
        _cacheParentAttemptScheduledTask.add(groupPolicyModification);
        _cacheParentAttemptScheduledTask.add(scheduledTaskOrJob);
        _cacheParentAttemptScheduledTask.add(systemTimeDiscovery);
      }
      for (AttackStep attackStep : _cacheParentAttemptScheduledTask) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptScheduledTask");
    }
  }

  public class ScheduledTask extends OS.ScheduledTask {
    private Set<AttackStep> _cacheChildrenScheduledTask;

    private Set<AttackStep> _cacheParentScheduledTask;

    public ScheduledTask(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenScheduledTask == null) {
        _cacheChildrenScheduledTask = new HashSet<>();
        _cacheChildrenScheduledTask.add(executeCode);
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenScheduledTask.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenScheduledTask.add(((asset.Windows) Windows.this).persistence);
        }
        _cacheChildrenScheduledTask.add(remoteScheduledTask);
      }
      for (AttackStep attackStep : _cacheChildrenScheduledTask) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentScheduledTask == null) {
        _cacheParentScheduledTask = new HashSet<>();
        _cacheParentScheduledTask.add(attemptScheduledTask);
        _cacheParentScheduledTask.add(audit.disable);
        _cacheParentScheduledTask.add(operatingSystemConfiguration.disable);
        _cacheParentScheduledTask.add(privilegedAccountManagement.disable);
      }
      for (AttackStep attackStep : _cacheParentScheduledTask) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.scheduledTask");
    }
  }

  public class RemoteScheduledTask extends OS.RemoteScheduledTask {
    private Set<AttackStep> _cacheChildrenRemoteScheduledTask;

    private Set<AttackStep> _cacheParentRemoteScheduledTask;

    public RemoteScheduledTask(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRemoteScheduledTask == null) {
        _cacheChildrenRemoteScheduledTask = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenRemoteScheduledTask.add(_2.remoteExecution);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenRemoteScheduledTask) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteScheduledTask == null) {
        _cacheParentRemoteScheduledTask = new HashSet<>();
        _cacheParentRemoteScheduledTask.add(scheduledTask);
      }
      for (AttackStep attackStep : _cacheParentRemoteScheduledTask) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.remoteScheduledTask");
    }
  }

  public class AttemptSystemTimeDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSystemTimeDiscovery;

    public AttemptSystemTimeDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSystemTimeDiscovery == null) {
        _cacheChildrenAttemptSystemTimeDiscovery = new HashSet<>();
        _cacheChildrenAttemptSystemTimeDiscovery.add(systemTimeDiscovery);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSystemTimeDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptSystemTimeDiscovery");
    }
  }

  public class SystemTimeDiscovery extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSystemTimeDiscovery;

    private Set<AttackStep> _cacheParentSystemTimeDiscovery;

    public SystemTimeDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSystemTimeDiscovery == null) {
        _cacheChildrenSystemTimeDiscovery = new HashSet<>();
        _cacheChildrenSystemTimeDiscovery.add(attemptScheduledTask);
      }
      for (AttackStep attackStep : _cacheChildrenSystemTimeDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemTimeDiscovery == null) {
        _cacheParentSystemTimeDiscovery = new HashSet<>();
        _cacheParentSystemTimeDiscovery.add(attemptSystemTimeDiscovery);
        _cacheParentSystemTimeDiscovery.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentSystemTimeDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.systemTimeDiscovery");
    }
  }

  public class UnsecuredCredentials extends OS.UnsecuredCredentials {
    private Set<AttackStep> _cacheChildrenUnsecuredCredentials;

    public UnsecuredCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenUnsecuredCredentials == null) {
        _cacheChildrenUnsecuredCredentials = new HashSet<>();
        _cacheChildrenUnsecuredCredentials.add(credentialsInRegistry);
        _cacheChildrenUnsecuredCredentials.add(groupPolicyPreferences);
      }
      for (AttackStep attackStep : _cacheChildrenUnsecuredCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.unsecuredCredentials");
    }
  }

  public class AttemptWindowsAdminShares extends OS.AttemptWindowsAdminShares {
    private Set<AttackStep> _cacheChildrenAttemptWindowsAdminShares;

    private Set<AttackStep> _cacheParentAttemptWindowsAdminShares;

    public AttemptWindowsAdminShares(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptWindowsAdminShares == null) {
        _cacheChildrenAttemptWindowsAdminShares = new HashSet<>();
        _cacheChildrenAttemptWindowsAdminShares.add(windowsAdminShares);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptWindowsAdminShares) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWindowsAdminShares == null) {
        _cacheParentAttemptWindowsAdminShares = new HashSet<>();
        _cacheParentAttemptWindowsAdminShares.add(lateralToolTransfer);
        _cacheParentAttemptWindowsAdminShares.add(sIDHistoryInjection);
        _cacheParentAttemptWindowsAdminShares.add(remoteFileCopy);
        _cacheParentAttemptWindowsAdminShares.add(dataEncryptedForImpact);
      }
      for (AttackStep attackStep : _cacheParentAttemptWindowsAdminShares) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptWindowsAdminShares");
    }
  }

  public class WindowsAdminShares extends OS.WindowsAdminShares {
    private Set<AttackStep> _cacheChildrenWindowsAdminShares;

    private Set<AttackStep> _cacheParentWindowsAdminShares;

    public WindowsAdminShares(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenWindowsAdminShares == null) {
        _cacheChildrenWindowsAdminShares = new HashSet<>();
        _cacheChildrenWindowsAdminShares.add(networkShareConnectionRemoval);
        _cacheChildrenWindowsAdminShares.add(windowsManagementInstrumentation);
      }
      for (AttackStep attackStep : _cacheChildrenWindowsAdminShares) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsAdminShares == null) {
        _cacheParentWindowsAdminShares = new HashSet<>();
        _cacheParentWindowsAdminShares.add(attemptWindowsAdminShares);
        _cacheParentWindowsAdminShares.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentWindowsAdminShares) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.windowsAdminShares");
    }
  }

  public class WindowsCommandShell extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenWindowsCommandShell;

    private Set<AttackStep> _cacheParentWindowsCommandShell;

    public WindowsCommandShell(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWindowsCommandShell == null) {
        _cacheChildrenWindowsCommandShell = new HashSet<>();
        _cacheChildrenWindowsCommandShell.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenWindowsCommandShell) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsCommandShell == null) {
        _cacheParentWindowsCommandShell = new HashSet<>();
        _cacheParentWindowsCommandShell.add(commandAndScriptingInterpreter);
        _cacheParentWindowsCommandShell.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentWindowsCommandShell) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.windowsCommandShell");
    }
  }

  public class WindowsManagementInstrumentation extends OS.WindowsManagementInstrumentation {
    private Set<AttackStep> _cacheChildrenWindowsManagementInstrumentation;

    private Set<AttackStep> _cacheParentWindowsManagementInstrumentation;

    public WindowsManagementInstrumentation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenWindowsManagementInstrumentation == null) {
        _cacheChildrenWindowsManagementInstrumentation = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenWindowsManagementInstrumentation.add(((asset.Windows) Windows.this).systemInformationDiscovery);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenWindowsManagementInstrumentation.add(((asset.Windows) Windows.this).systemChecks);
        }
        _cacheChildrenWindowsManagementInstrumentation.add(executeCode);
        if (Windows.this instanceof Windows) {
          _cacheChildrenWindowsManagementInstrumentation.add(((asset.Windows) Windows.this).inhibitSystemRecovery);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenWindowsManagementInstrumentation.add(((asset.Windows) Windows.this).attemptIndicatorBlocking);
        }
      }
      for (AttackStep attackStep : _cacheChildrenWindowsManagementInstrumentation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsManagementInstrumentation == null) {
        _cacheParentWindowsManagementInstrumentation = new HashSet<>();
        _cacheParentWindowsManagementInstrumentation.add(windowsAdminShares);
        _cacheParentWindowsManagementInstrumentation.add(xslScriptProcessing);
      }
      for (AttackStep attackStep : _cacheParentWindowsManagementInstrumentation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.windowsManagementInstrumentation");
    }
  }

  public class AttemptWindowsManagementInstrumentationEventSubscription extends OS.AttemptWindowsManagementInstrumentationEventSubscription {
    private Set<AttackStep> _cacheChildrenAttemptWindowsManagementInstrumentationEventSubscription;

    private Set<AttackStep> _cacheParentAttemptWindowsManagementInstrumentationEventSubscription;

    public AttemptWindowsManagementInstrumentationEventSubscription(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptWindowsManagementInstrumentationEventSubscription == null) {
        _cacheChildrenAttemptWindowsManagementInstrumentationEventSubscription = new HashSet<>();
        _cacheChildrenAttemptWindowsManagementInstrumentationEventSubscription.add(windowsManagementInstrumentationEventSubscription);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptWindowsManagementInstrumentationEventSubscription) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWindowsManagementInstrumentationEventSubscription == null) {
        _cacheParentAttemptWindowsManagementInstrumentationEventSubscription = new HashSet<>();
        _cacheParentAttemptWindowsManagementInstrumentationEventSubscription.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptWindowsManagementInstrumentationEventSubscription) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptWindowsManagementInstrumentationEventSubscription");
    }
  }

  public class WindowsManagementInstrumentationEventSubscription extends OS.WindowsManagementInstrumentationEventSubscription {
    private Set<AttackStep> _cacheChildrenWindowsManagementInstrumentationEventSubscription;

    private Set<AttackStep> _cacheParentWindowsManagementInstrumentationEventSubscription;

    public WindowsManagementInstrumentationEventSubscription(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenWindowsManagementInstrumentationEventSubscription == null) {
        _cacheChildrenWindowsManagementInstrumentationEventSubscription = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenWindowsManagementInstrumentationEventSubscription.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenWindowsManagementInstrumentationEventSubscription) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsManagementInstrumentationEventSubscription == null) {
        _cacheParentWindowsManagementInstrumentationEventSubscription = new HashSet<>();
        _cacheParentWindowsManagementInstrumentationEventSubscription.add(attemptWindowsManagementInstrumentationEventSubscription);
      }
      for (AttackStep attackStep : _cacheParentWindowsManagementInstrumentationEventSubscription) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.windowsManagementInstrumentationEventSubscription");
    }
  }

  public class AttemptWindowsRemoteManagement extends OS.AttemptWindowsRemoteManagement {
    private Set<AttackStep> _cacheChildrenAttemptWindowsRemoteManagement;

    public AttemptWindowsRemoteManagement(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptWindowsRemoteManagement == null) {
        _cacheChildrenAttemptWindowsRemoteManagement = new HashSet<>();
        _cacheChildrenAttemptWindowsRemoteManagement.add(windowsRemoteManagement);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptWindowsRemoteManagement) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptWindowsRemoteManagement");
    }
  }

  public class WindowsRemoteManagement extends OS.WindowsRemoteManagement {
    private Set<AttackStep> _cacheChildrenWindowsRemoteManagement;

    private Set<AttackStep> _cacheParentWindowsRemoteManagement;

    public WindowsRemoteManagement(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenWindowsRemoteManagement == null) {
        _cacheChildrenWindowsRemoteManagement = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenWindowsRemoteManagement.add(_2.remoteExecution);
              }
            }
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _3 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenWindowsRemoteManagement.add(_3.externalRemoteServices);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenWindowsRemoteManagement) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWindowsRemoteManagement == null) {
        _cacheParentWindowsRemoteManagement = new HashSet<>();
        _cacheParentWindowsRemoteManagement.add(attemptPowerShell);
        _cacheParentWindowsRemoteManagement.add(sIDHistoryInjection);
        _cacheParentWindowsRemoteManagement.add(attemptWindowsRemoteManagement);
        _cacheParentWindowsRemoteManagement.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentWindowsRemoteManagement) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.windowsRemoteManagement");
    }
  }

  public class AttemptWinlogonHelperDLL extends OS.AttemptWinlogonHelperDLL {
    private Set<AttackStep> _cacheChildrenAttemptWinlogonHelperDLL;

    private Set<AttackStep> _cacheParentAttemptWinlogonHelperDLL;

    public AttemptWinlogonHelperDLL(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptWinlogonHelperDLL == null) {
        _cacheChildrenAttemptWinlogonHelperDLL = new HashSet<>();
        _cacheChildrenAttemptWinlogonHelperDLL.add(winlogonHelperDLL);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptWinlogonHelperDLL) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptWinlogonHelperDLL == null) {
        _cacheParentAttemptWinlogonHelperDLL = new HashSet<>();
        _cacheParentAttemptWinlogonHelperDLL.add(bootOrLogonAutostartExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptWinlogonHelperDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptWinlogonHelperDLL");
    }
  }

  public class WinlogonHelperDLL extends OS.WinlogonHelperDLL {
    private Set<AttackStep> _cacheChildrenWinlogonHelperDLL;

    private Set<AttackStep> _cacheParentWinlogonHelperDLL;

    public WinlogonHelperDLL(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenWinlogonHelperDLL == null) {
        _cacheChildrenWinlogonHelperDLL = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenWinlogonHelperDLL.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenWinlogonHelperDLL) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentWinlogonHelperDLL == null) {
        _cacheParentWinlogonHelperDLL = new HashSet<>();
        _cacheParentWinlogonHelperDLL.add(attemptWinlogonHelperDLL);
        _cacheParentWinlogonHelperDLL.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentWinlogonHelperDLL) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.winlogonHelperDLL");
    }
  }

  public class RemoteFileCopy extends OS.RemoteFileCopy {
    private Set<AttackStep> _cacheChildrenRemoteFileCopy;

    private Set<AttackStep> _cacheParentRemoteFileCopy;

    public RemoteFileCopy(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRemoteFileCopy == null) {
        _cacheChildrenRemoteFileCopy = new HashSet<>();
        _cacheChildrenRemoteFileCopy.add(attemptWindowsAdminShares);
        _cacheChildrenRemoteFileCopy.add(attemptRemoteDesktopProtocol);
      }
      for (AttackStep attackStep : _cacheChildrenRemoteFileCopy) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteFileCopy == null) {
        _cacheParentRemoteFileCopy = new HashSet<>();
        _cacheParentRemoteFileCopy.add(groupPolicyModification);
      }
      for (AttackStep attackStep : _cacheParentRemoteFileCopy) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.remoteFileCopy");
    }
  }

  public class AttemptRegistryKeysEnabled extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptRegistryKeysEnabled;

    public AttemptRegistryKeysEnabled(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptRegistryKeysEnabled == null) {
        _cacheChildrenAttemptRegistryKeysEnabled = new HashSet<>();
        _cacheChildrenAttemptRegistryKeysEnabled.add(registryKeysEnabled);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptRegistryKeysEnabled) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptRegistryKeysEnabled");
    }
  }

  public class RegistryKeysEnabled extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenRegistryKeysEnabled;

    private Set<AttackStep> _cacheParentRegistryKeysEnabled;

    public RegistryKeysEnabled(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRegistryKeysEnabled == null) {
        _cacheChildrenRegistryKeysEnabled = new HashSet<>();
        _cacheChildrenRegistryKeysEnabled.add(attemptDynamicDataExchange);
      }
      for (AttackStep attackStep : _cacheChildrenRegistryKeysEnabled) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRegistryKeysEnabled == null) {
        _cacheParentRegistryKeysEnabled = new HashSet<>();
        _cacheParentRegistryKeysEnabled.add(attemptRegistryKeysEnabled);
        _cacheParentRegistryKeysEnabled.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentRegistryKeysEnabled) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.registryKeysEnabled");
    }
  }

  public class DataEncryptedForImpact extends OS.DataEncryptedForImpact {
    private Set<AttackStep> _cacheChildrenDataEncryptedForImpact;

    public DataEncryptedForImpact(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDataEncryptedForImpact == null) {
        _cacheChildrenDataEncryptedForImpact = new HashSet<>();
        _cacheChildrenDataEncryptedForImpact.add(attemptWindowsAdminShares);
      }
      for (AttackStep attackStep : _cacheChildrenDataEncryptedForImpact) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.dataEncryptedForImpact");
    }
  }

  public class AttemptDynamicDataExchange extends OS.AttemptDynamicDataExchange {
    private Set<AttackStep> _cacheChildrenAttemptDynamicDataExchange;

    private Set<AttackStep> _cacheParentAttemptDynamicDataExchange;

    public AttemptDynamicDataExchange(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptDynamicDataExchange == null) {
        _cacheChildrenAttemptDynamicDataExchange = new HashSet<>();
        _cacheChildrenAttemptDynamicDataExchange.add(dynamicDataExchange);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDynamicDataExchange) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDynamicDataExchange == null) {
        _cacheParentAttemptDynamicDataExchange = new HashSet<>();
        _cacheParentAttemptDynamicDataExchange.add(interProcessCommunication);
        _cacheParentAttemptDynamicDataExchange.add(registryKeysEnabled);
      }
      for (AttackStep attackStep : _cacheParentAttemptDynamicDataExchange) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptDynamicDataExchange");
    }
  }

  public class DynamicDataExchange extends OS.DynamicDataExchange {
    private Set<AttackStep> _cacheChildrenDynamicDataExchange;

    private Set<AttackStep> _cacheParentDynamicDataExchange;

    public DynamicDataExchange(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDynamicDataExchange == null) {
        _cacheChildrenDynamicDataExchange = new HashSet<>();
        _cacheChildrenDynamicDataExchange.add(commandAndScriptingInterpreter);
        _cacheChildrenDynamicDataExchange.add(executeCode);
      }
      for (AttackStep attackStep : _cacheChildrenDynamicDataExchange) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDynamicDataExchange == null) {
        _cacheParentDynamicDataExchange = new HashSet<>();
        _cacheParentDynamicDataExchange.add(attemptDynamicDataExchange);
        _cacheParentDynamicDataExchange.add(applicationIsolationAndSandboxing.disable);
        _cacheParentDynamicDataExchange.add(behaviorPreventionOnEndpoint.disable);
        _cacheParentDynamicDataExchange.add(softwareConfiguration.disable);
        _cacheParentDynamicDataExchange.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentDynamicDataExchange) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.dynamicDataExchange");
    }
  }

  public class CaptureAPICalls extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCaptureAPICalls;

    public CaptureAPICalls(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCaptureAPICalls == null) {
        _cacheChildrenCaptureAPICalls = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (UserAccount _0 : ((asset.Windows) Windows.this).userAccount) {
            _cacheChildrenCaptureAPICalls.add(_0.userCredentials);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCaptureAPICalls) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.captureAPICalls");
    }
  }

  public class AttemptLogonScripts extends OS.AttemptLogonScripts {
    private Set<AttackStep> _cacheChildrenAttemptLogonScripts;

    private Set<AttackStep> _cacheParentAttemptLogonScripts;

    public AttemptLogonScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptLogonScripts == null) {
        _cacheChildrenAttemptLogonScripts = new HashSet<>();
        _cacheChildrenAttemptLogonScripts.add(logonScripts);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptLogonScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptLogonScripts == null) {
        _cacheParentAttemptLogonScripts = new HashSet<>();
        _cacheParentAttemptLogonScripts.add(bootOrLogonInitializationScripts);
      }
      for (AttackStep attackStep : _cacheParentAttemptLogonScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptLogonScripts");
    }
  }

  public class LogonScripts extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenLogonScripts;

    private Set<AttackStep> _cacheParentLogonScripts;

    public LogonScripts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLogonScripts == null) {
        _cacheChildrenLogonScripts = new HashSet<>();
        _cacheChildrenLogonScripts.add(attemptAccessTokenManipulation);
        if (Windows.this instanceof Windows) {
          for (AdminAccount _0 : ((asset.Windows) Windows.this).adminAccount) {
            _cacheChildrenLogonScripts.add(_0.adminRights);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenLogonScripts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLogonScripts == null) {
        _cacheParentLogonScripts = new HashSet<>();
        _cacheParentLogonScripts.add(attemptLogonScripts);
        _cacheParentLogonScripts.add(restrictFileAndDirectoryPermissions.disable);
      }
      for (AttackStep attackStep : _cacheParentLogonScripts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.logonScripts");
    }
  }

  public class AttemptSystemFirmware extends OS.AttemptSystemFirmware {
    private Set<AttackStep> _cacheChildrenAttemptSystemFirmware;

    private Set<AttackStep> _cacheParentAttemptSystemFirmware;

    public AttemptSystemFirmware(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptSystemFirmware == null) {
        _cacheChildrenAttemptSystemFirmware = new HashSet<>();
        _cacheChildrenAttemptSystemFirmware.add(systemFirmware);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSystemFirmware) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSystemFirmware == null) {
        _cacheParentAttemptSystemFirmware = new HashSet<>();
        _cacheParentAttemptSystemFirmware.add(preOSBoot);
        _cacheParentAttemptSystemFirmware.add(rootkit);
      }
      for (AttackStep attackStep : _cacheParentAttemptSystemFirmware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptSystemFirmware");
    }
  }

  public class SystemFirmware extends OS.SystemFirmware {
    private Set<AttackStep> _cacheChildrenSystemFirmware;

    private Set<AttackStep> _cacheParentSystemFirmware;

    public SystemFirmware(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenSystemFirmware == null) {
        _cacheChildrenSystemFirmware = new HashSet<>();
        _cacheChildrenSystemFirmware.add(systemShutdownOrReboot);
        if (Windows.this instanceof Windows) {
          _cacheChildrenSystemFirmware.add(((asset.Windows) Windows.this).attemptDataDestruction);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSystemFirmware) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemFirmware == null) {
        _cacheParentSystemFirmware = new HashSet<>();
        _cacheParentSystemFirmware.add(attemptSystemFirmware);
        _cacheParentSystemFirmware.add(bootIntegrity.disable);
        _cacheParentSystemFirmware.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentSystemFirmware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.systemFirmware");
    }
  }

  public class SystemShutdownOrReboot extends OS.SystemShutdownOrReboot {
    private Set<AttackStep> _cacheParentSystemShutdownOrReboot;

    public SystemShutdownOrReboot(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSystemShutdownOrReboot == null) {
        _cacheParentSystemShutdownOrReboot = new HashSet<>();
        _cacheParentSystemShutdownOrReboot.add(systemFirmware);
      }
      for (AttackStep attackStep : _cacheParentSystemShutdownOrReboot) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.systemShutdownOrReboot");
    }
  }

  public class QueryRegistry extends OS.QueryRegistry {
    private Set<AttackStep> _cacheChildrenQueryRegistry;

    private Set<AttackStep> _cacheParentQueryRegistry;

    public QueryRegistry(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenQueryRegistry == null) {
        _cacheChildrenQueryRegistry = new HashSet<>();
        _cacheChildrenQueryRegistry.add(commandAndScriptingInterpreter);
        if (Windows.this instanceof Windows) {
          _cacheChildrenQueryRegistry.add(((asset.Windows) Windows.this).systemChecks);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenQueryRegistry.add(((asset.Windows) Windows.this).systemInformationDiscovery);
        }
      }
      for (AttackStep attackStep : _cacheChildrenQueryRegistry) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentQueryRegistry == null) {
        _cacheParentQueryRegistry = new HashSet<>();
        _cacheParentQueryRegistry.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentQueryRegistry) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.queryRegistry");
    }
  }

  public class NetworkShareDiscovery extends OS.NetworkShareDiscovery {
    private Set<AttackStep> _cacheChildrenNetworkShareDiscovery;

    private Set<AttackStep> _cacheParentNetworkShareDiscovery;

    public NetworkShareDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenNetworkShareDiscovery == null) {
        _cacheChildrenNetworkShareDiscovery = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenNetworkShareDiscovery.add(_2.networkShareDiscovery);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenNetworkShareDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentNetworkShareDiscovery == null) {
        _cacheParentNetworkShareDiscovery = new HashSet<>();
        _cacheParentNetworkShareDiscovery.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentNetworkShareDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.networkShareDiscovery");
    }
  }

  public class AttemptAccessTokenManipulation extends OS.AttemptAccessTokenManipulation {
    private Set<AttackStep> _cacheChildrenAttemptAccessTokenManipulation;

    private Set<AttackStep> _cacheParentAttemptAccessTokenManipulation;

    public AttemptAccessTokenManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptAccessTokenManipulation == null) {
        _cacheChildrenAttemptAccessTokenManipulation = new HashSet<>();
        _cacheChildrenAttemptAccessTokenManipulation.add(accessTokenManipulation);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptAccessTokenManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptAccessTokenManipulation == null) {
        _cacheParentAttemptAccessTokenManipulation = new HashSet<>();
        _cacheParentAttemptAccessTokenManipulation.add(logonScripts);
      }
      for (AttackStep attackStep : _cacheParentAttemptAccessTokenManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptAccessTokenManipulation");
    }
  }

  public class AccessTokenManipulation extends OS.AccessTokenManipulation {
    private Set<AttackStep> _cacheChildrenAccessTokenManipulation;

    private Set<AttackStep> _cacheParentAccessTokenManipulation;

    public AccessTokenManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAccessTokenManipulation == null) {
        _cacheChildrenAccessTokenManipulation = new HashSet<>();
        _cacheChildrenAccessTokenManipulation.add(tokenImpersonationOrTheft);
        _cacheChildrenAccessTokenManipulation.add(createProcessWithAToken);
        _cacheChildrenAccessTokenManipulation.add(makeAndImpersonateToken);
        _cacheChildrenAccessTokenManipulation.add(parentPIDSpoofing);
        _cacheChildrenAccessTokenManipulation.add(attemptSIDHistoryInjection);
      }
      for (AttackStep attackStep : _cacheChildrenAccessTokenManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccessTokenManipulation == null) {
        _cacheParentAccessTokenManipulation = new HashSet<>();
        _cacheParentAccessTokenManipulation.add(attemptAccessTokenManipulation);
      }
      for (AttackStep attackStep : _cacheParentAccessTokenManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.accessTokenManipulation");
    }
  }

  public class TokenImpersonationOrTheft extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenTokenImpersonationOrTheft;

    private Set<AttackStep> _cacheParentTokenImpersonationOrTheft;

    public TokenImpersonationOrTheft(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenTokenImpersonationOrTheft == null) {
        _cacheChildrenTokenImpersonationOrTheft = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenTokenImpersonationOrTheft.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenTokenImpersonationOrTheft) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTokenImpersonationOrTheft == null) {
        _cacheParentTokenImpersonationOrTheft = new HashSet<>();
        _cacheParentTokenImpersonationOrTheft.add(accessTokenManipulation);
      }
      for (AttackStep attackStep : _cacheParentTokenImpersonationOrTheft) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.tokenImpersonationOrTheft");
    }
  }

  public class CreateProcessWithAToken extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCreateProcessWithAToken;

    private Set<AttackStep> _cacheParentCreateProcessWithAToken;

    public CreateProcessWithAToken(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCreateProcessWithAToken == null) {
        _cacheChildrenCreateProcessWithAToken = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenCreateProcessWithAToken.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCreateProcessWithAToken) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCreateProcessWithAToken == null) {
        _cacheParentCreateProcessWithAToken = new HashSet<>();
        _cacheParentCreateProcessWithAToken.add(accessTokenManipulation);
      }
      for (AttackStep attackStep : _cacheParentCreateProcessWithAToken) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.createProcessWithAToken");
    }
  }

  public class MakeAndImpersonateToken extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenMakeAndImpersonateToken;

    private Set<AttackStep> _cacheParentMakeAndImpersonateToken;

    public MakeAndImpersonateToken(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenMakeAndImpersonateToken == null) {
        _cacheChildrenMakeAndImpersonateToken = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenMakeAndImpersonateToken.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenMakeAndImpersonateToken) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentMakeAndImpersonateToken == null) {
        _cacheParentMakeAndImpersonateToken = new HashSet<>();
        _cacheParentMakeAndImpersonateToken.add(accessTokenManipulation);
      }
      for (AttackStep attackStep : _cacheParentMakeAndImpersonateToken) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.makeAndImpersonateToken");
    }
  }

  public class AttemptBypassUserAccessControl extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptBypassUserAccessControl;

    private Set<AttackStep> _cacheParentAttemptBypassUserAccessControl;

    public AttemptBypassUserAccessControl(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptBypassUserAccessControl == null) {
        _cacheChildrenAttemptBypassUserAccessControl = new HashSet<>();
        _cacheChildrenAttemptBypassUserAccessControl.add(bypassUserAccessControl);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBypassUserAccessControl) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptBypassUserAccessControl == null) {
        _cacheParentAttemptBypassUserAccessControl = new HashSet<>();
        _cacheParentAttemptBypassUserAccessControl.add(abuseElevationControlMechanism);
        _cacheParentAttemptBypassUserAccessControl.add(cmstp);
        _cacheParentAttemptBypassUserAccessControl.add(codeSigningCertificate);
        _cacheParentAttemptBypassUserAccessControl.add(cOR_PROFILER);
        _cacheParentAttemptBypassUserAccessControl.add(dLLSearchOrderHijacking);
        _cacheParentAttemptBypassUserAccessControl.add(fileSystemPermissionsWeakness);
        _cacheParentAttemptBypassUserAccessControl.add(executableInstallerFilePermissionsWeakness);
        _cacheParentAttemptBypassUserAccessControl.add(applicationShimming);
      }
      for (AttackStep attackStep : _cacheParentAttemptBypassUserAccessControl) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptBypassUserAccessControl");
    }
  }

  public class BypassUserAccessControl extends OS.BypassUserAccessControl {
    private Set<AttackStep> _cacheChildrenBypassUserAccessControl;

    private Set<AttackStep> _cacheParentBypassUserAccessControl;

    public BypassUserAccessControl(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBypassUserAccessControl == null) {
        _cacheChildrenBypassUserAccessControl = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenBypassUserAccessControl.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenBypassUserAccessControl) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassUserAccessControl == null) {
        _cacheParentBypassUserAccessControl = new HashSet<>();
        _cacheParentBypassUserAccessControl.add(gUIInputCapture);
        _cacheParentBypassUserAccessControl.add(attemptBypassUserAccessControl);
        _cacheParentBypassUserAccessControl.add(audit.disable);
        _cacheParentBypassUserAccessControl.add(privilegedAccountManagement.disable);
        _cacheParentBypassUserAccessControl.add(updateSoftware.disable);
        _cacheParentBypassUserAccessControl.add(userAccountControl.disable);
      }
      for (AttackStep attackStep : _cacheParentBypassUserAccessControl) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.bypassUserAccessControl");
    }
  }

  public class ObfuscatedFilesOrInformation extends OS.ObfuscatedFilesOrInformation {
    private Set<AttackStep> _cacheChildrenObfuscatedFilesOrInformation;

    public ObfuscatedFilesOrInformation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenObfuscatedFilesOrInformation == null) {
        _cacheChildrenObfuscatedFilesOrInformation = new HashSet<>();
        _cacheChildrenObfuscatedFilesOrInformation.add(attemptSoftwarePacking);
      }
      for (AttackStep attackStep : _cacheChildrenObfuscatedFilesOrInformation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.obfuscatedFilesOrInformation");
    }
  }

  public class OSCredentialDumping extends OS.OSCredentialDumping {
    private Set<AttackStep> _cacheChildrenOSCredentialDumping;

    public OSCredentialDumping(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOSCredentialDumping == null) {
        _cacheChildrenOSCredentialDumping = new HashSet<>();
        _cacheChildrenOSCredentialDumping.add(attemptLSASSMemory);
        _cacheChildrenOSCredentialDumping.add(securityAccountManager);
        _cacheChildrenOSCredentialDumping.add(nTDS);
        _cacheChildrenOSCredentialDumping.add(lSASecrets);
        _cacheChildrenOSCredentialDumping.add(cachedDomainCredentials);
        _cacheChildrenOSCredentialDumping.add(dCSync);
        _cacheChildrenOSCredentialDumping.add(stealOrForgeKerberosTickets);
      }
      for (AttackStep attackStep : _cacheChildrenOSCredentialDumping) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.oSCredentialDumping");
    }
  }

  public class PeripheralDeviceDiscovery extends OS.PeripheralDeviceDiscovery {
    private Set<AttackStep> _cacheChildrenPeripheralDeviceDiscovery;

    public PeripheralDeviceDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPeripheralDeviceDiscovery == null) {
        _cacheChildrenPeripheralDeviceDiscovery = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            _cacheChildrenPeripheralDeviceDiscovery.add(_0.peripheralDeviceDiscovery);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenPeripheralDeviceDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.peripheralDeviceDiscovery");
    }
  }

  public class PortMonitors extends OS.PortMonitors {
    private Set<AttackStep> _cacheChildrenPortMonitors;

    private Set<AttackStep> _cacheParentPortMonitors;

    public PortMonitors(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenPortMonitors == null) {
        _cacheChildrenPortMonitors = new HashSet<>();
        _cacheChildrenPortMonitors.add(executeCode);
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenPortMonitors.add(_0.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenPortMonitors.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenPortMonitors) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPortMonitors == null) {
        _cacheParentPortMonitors = new HashSet<>();
        _cacheParentPortMonitors.add(bootOrLogonAutostartExecution);
      }
      for (AttackStep attackStep : _cacheParentPortMonitors) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.portMonitors");
    }
  }

  public class EmailCollection extends OS.EmailCollection {
    private Set<AttackStep> _cacheChildrenEmailCollection;

    public EmailCollection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenEmailCollection == null) {
        _cacheChildrenEmailCollection = new HashSet<>();
        _cacheChildrenEmailCollection.add(localEmailCollection);
        _cacheChildrenEmailCollection.add(remoteEmailCollection);
        _cacheChildrenEmailCollection.add(emailForwardingRule);
        if (Windows.this instanceof Windows) {
          for (Service _0 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenEmailCollection.add(_0.remoteEmailCollection);
          }
        }
        if (Windows.this instanceof Windows) {
          for (Service _1 : ((asset.Windows) Windows.this).service) {
            _cacheChildrenEmailCollection.add(_1.emailForwardingRule);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenEmailCollection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.emailCollection");
    }
  }

  public class LocalEmailCollection extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenLocalEmailCollection;

    private Set<AttackStep> _cacheParentLocalEmailCollection;

    public LocalEmailCollection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenLocalEmailCollection == null) {
        _cacheChildrenLocalEmailCollection = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenLocalEmailCollection.add(((asset.Windows) Windows.this).sensitiveDataCollected);
        }
      }
      for (AttackStep attackStep : _cacheChildrenLocalEmailCollection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentLocalEmailCollection == null) {
        _cacheParentLocalEmailCollection = new HashSet<>();
        _cacheParentLocalEmailCollection.add(emailCollection);
        _cacheParentLocalEmailCollection.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentLocalEmailCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.localEmailCollection");
    }
  }

  public class RemoteEmailCollection extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenRemoteEmailCollection;

    private Set<AttackStep> _cacheParentRemoteEmailCollection;

    public RemoteEmailCollection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRemoteEmailCollection == null) {
        _cacheChildrenRemoteEmailCollection = new HashSet<>();
        _cacheChildrenRemoteEmailCollection.add(attemptRemoteDesktopProtocol);
        if (Windows.this instanceof Windows) {
          _cacheChildrenRemoteEmailCollection.add(((asset.Windows) Windows.this).sensitiveDataCollected);
        }
      }
      for (AttackStep attackStep : _cacheChildrenRemoteEmailCollection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteEmailCollection == null) {
        _cacheParentRemoteEmailCollection = new HashSet<>();
        _cacheParentRemoteEmailCollection.add(emailCollection);
        _cacheParentRemoteEmailCollection.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentRemoteEmailCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.remoteEmailCollection");
    }
  }

  public class EmailForwardingRule extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenEmailForwardingRule;

    private Set<AttackStep> _cacheParentEmailForwardingRule;

    public EmailForwardingRule(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenEmailForwardingRule == null) {
        _cacheChildrenEmailForwardingRule = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenEmailForwardingRule.add(((asset.Windows) Windows.this).sensitiveDataCollected);
        }
      }
      for (AttackStep attackStep : _cacheChildrenEmailForwardingRule) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEmailForwardingRule == null) {
        _cacheParentEmailForwardingRule = new HashSet<>();
        _cacheParentEmailForwardingRule.add(emailCollection);
        _cacheParentEmailForwardingRule.add(audit.disable);
        _cacheParentEmailForwardingRule.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentEmailForwardingRule) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.emailForwardingRule");
    }
  }

  public class AttemptApplicationShimming extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptApplicationShimming;

    private Set<AttackStep> _cacheParentAttemptApplicationShimming;

    public AttemptApplicationShimming(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptApplicationShimming == null) {
        _cacheChildrenAttemptApplicationShimming = new HashSet<>();
        _cacheChildrenAttemptApplicationShimming.add(applicationShimming);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptApplicationShimming) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptApplicationShimming == null) {
        _cacheParentAttemptApplicationShimming = new HashSet<>();
        _cacheParentAttemptApplicationShimming.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentAttemptApplicationShimming) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptApplicationShimming");
    }
  }

  public class ApplicationShimming extends OS.ApplicationShimming {
    private Set<AttackStep> _cacheChildrenApplicationShimming;

    private Set<AttackStep> _cacheParentApplicationShimming;

    public ApplicationShimming(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenApplicationShimming == null) {
        _cacheChildrenApplicationShimming = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenApplicationShimming.add(((asset.Windows) Windows.this).persistence);
        }
        _cacheChildrenApplicationShimming.add(processInjection);
        _cacheChildrenApplicationShimming.add(credentialAPIHooking);
        _cacheChildrenApplicationShimming.add(attemptBypassUserAccessControl);
      }
      for (AttackStep attackStep : _cacheChildrenApplicationShimming) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationShimming == null) {
        _cacheParentApplicationShimming = new HashSet<>();
        _cacheParentApplicationShimming.add(attemptApplicationShimming);
        _cacheParentApplicationShimming.add(updateSoftware.disable);
        _cacheParentApplicationShimming.add(userAccountControl.disable);
      }
      for (AttackStep attackStep : _cacheParentApplicationShimming) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.applicationShimming");
    }
  }

  public class AuthenticationPackage extends OS.AuthenticationPackage {
    private Set<AttackStep> _cacheChildrenAuthenticationPackage;

    private Set<AttackStep> _cacheParentAuthenticationPackage;

    public AuthenticationPackage(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAuthenticationPackage == null) {
        _cacheChildrenAuthenticationPackage = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenAuthenticationPackage.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenAuthenticationPackage) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAuthenticationPackage == null) {
        _cacheParentAuthenticationPackage = new HashSet<>();
        _cacheParentAuthenticationPackage.add(bootOrLogonAutostartExecution);
        _cacheParentAuthenticationPackage.add(privilegedProcessIntegrity.disable);
      }
      for (AttackStep attackStep : _cacheParentAuthenticationPackage) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.authenticationPackage");
    }
  }

  public class ChangeDefaultFileAssociation extends OS.ChangeDefaultFileAssociation {
    private Set<AttackStep> _cacheChildrenChangeDefaultFileAssociation;

    private Set<AttackStep> _cacheParentChangeDefaultFileAssociation;

    public ChangeDefaultFileAssociation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenChangeDefaultFileAssociation == null) {
        _cacheChildrenChangeDefaultFileAssociation = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenChangeDefaultFileAssociation.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenChangeDefaultFileAssociation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentChangeDefaultFileAssociation == null) {
        _cacheParentChangeDefaultFileAssociation = new HashSet<>();
        _cacheParentChangeDefaultFileAssociation.add(eventTriggeredExecution);
      }
      for (AttackStep attackStep : _cacheParentChangeDefaultFileAssociation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.changeDefaultFileAssociation");
    }
  }

  public class TrustedDomainInfo extends AttackStepMin {
    private Set<AttackStep> _cacheParentTrustedDomainInfo;

    public TrustedDomainInfo(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTrustedDomainInfo == null) {
        _cacheParentTrustedDomainInfo = new HashSet<>();
        _cacheParentTrustedDomainInfo.add(domainTrustDiscovery);
      }
      for (AttackStep attackStep : _cacheParentTrustedDomainInfo) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.trustedDomainInfo");
    }
  }

  public class DomainTrustDiscovery extends OS.DomainTrustDiscovery {
    private Set<AttackStep> _cacheChildrenDomainTrustDiscovery;

    private Set<AttackStep> _cacheParentDomainTrustDiscovery;

    public DomainTrustDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDomainTrustDiscovery == null) {
        _cacheChildrenDomainTrustDiscovery = new HashSet<>();
        _cacheChildrenDomainTrustDiscovery.add(trustedDomainInfo);
      }
      for (AttackStep attackStep : _cacheChildrenDomainTrustDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDomainTrustDiscovery == null) {
        _cacheParentDomainTrustDiscovery = new HashSet<>();
        _cacheParentDomainTrustDiscovery.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentDomainTrustDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.domainTrustDiscovery");
    }
  }

  public class AttemptBootkit extends OS.AttemptBootkit {
    private Set<AttackStep> _cacheChildrenAttemptBootkit;

    public AttemptBootkit(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptBootkit == null) {
        _cacheChildrenAttemptBootkit = new HashSet<>();
        _cacheChildrenAttemptBootkit.add(bootkit);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptBootkit) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.attemptBootkit");
    }
  }

  public class Bootkit extends OS.Bootkit {
    private Set<AttackStep> _cacheChildrenBootkit;

    private Set<AttackStep> _cacheParentBootkit;

    public Bootkit(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenBootkit == null) {
        _cacheChildrenBootkit = new HashSet<>();
        if (Windows.this instanceof Windows) {
          _cacheChildrenBootkit.add(((asset.Windows) Windows.this).persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenBootkit) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBootkit == null) {
        _cacheParentBootkit = new HashSet<>();
        _cacheParentBootkit.add(preOSBoot);
        _cacheParentBootkit.add(attemptBootkit);
        _cacheParentBootkit.add(privilegedAccountManagement.disable);
        _cacheParentBootkit.add(bootIntegrity.disable);
      }
      for (AttackStep attackStep : _cacheParentBootkit) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.bootkit");
    }
  }

  public class VideoCapture extends OS.VideoCapture {
    private Set<AttackStep> _cacheChildrenVideoCapture;

    public VideoCapture(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenVideoCapture == null) {
        _cacheChildrenVideoCapture = new HashSet<>();
        if (Windows.this instanceof Windows) {
          for (Computer _0 : ((asset.Windows) Windows.this).computer) {
            _cacheChildrenVideoCapture.add(_0.collectVideo);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenVideoCapture) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.videoCapture");
    }
  }

  public class XslScriptProcessing extends OS.XslScriptProcessing {
    private Set<AttackStep> _cacheChildrenXslScriptProcessing;

    private Set<AttackStep> _cacheParentXslScriptProcessing;

    public XslScriptProcessing(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenXslScriptProcessing == null) {
        _cacheChildrenXslScriptProcessing = new HashSet<>();
        _cacheChildrenXslScriptProcessing.add(executeCode);
        _cacheChildrenXslScriptProcessing.add(windowsManagementInstrumentation);
        if (Windows.this instanceof Windows) {
          _cacheChildrenXslScriptProcessing.add(((asset.Windows) Windows.this).bypassAntivirus);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenXslScriptProcessing.add(((asset.Windows) Windows.this).bypassApplicationWhitelisting);
        }
        if (Windows.this instanceof Windows) {
          _cacheChildrenXslScriptProcessing.add(((asset.Windows) Windows.this).bypassDigitalCertificateValidation);
        }
      }
      for (AttackStep attackStep : _cacheChildrenXslScriptProcessing) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentXslScriptProcessing == null) {
        _cacheParentXslScriptProcessing = new HashSet<>();
        _cacheParentXslScriptProcessing.add(executionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentXslScriptProcessing) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Windows.xslScriptProcessing");
    }
  }

  public class ActiveDirectoryConfiguration extends OS.ActiveDirectoryConfiguration {
    public ActiveDirectoryConfiguration(String name) {
      this(name, false);
    }

    public ActiveDirectoryConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.ActiveDirectoryConfiguration.Disable {
      private Set<AttackStep> _cacheChildrenActiveDirectoryConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenActiveDirectoryConfiguration == null) {
          _cacheChildrenActiveDirectoryConfiguration = new HashSet<>();
          _cacheChildrenActiveDirectoryConfiguration.add(cachedDomainCredentials);
          _cacheChildrenActiveDirectoryConfiguration.add(dCSync);
          _cacheChildrenActiveDirectoryConfiguration.add(goldenTicket);
          _cacheChildrenActiveDirectoryConfiguration.add(groupPolicyPreferences);
          _cacheChildrenActiveDirectoryConfiguration.add(passTheTicket);
          _cacheChildrenActiveDirectoryConfiguration.add(sIDHistoryInjection);
        }
        for (AttackStep attackStep : _cacheChildrenActiveDirectoryConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.activeDirectoryConfiguration";
      }
    }
  }

  public class Antivirus extends OS.Antivirus {
    public Antivirus(String name) {
      this(name, false);
    }

    public Antivirus(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.Antivirus.Disable {
      private Set<AttackStep> _cacheChildrenAntivirus;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenAntivirus == null) {
          _cacheChildrenAntivirus = new HashSet<>();
          _cacheChildrenAntivirus.add(powerShell);
          _cacheChildrenAntivirus.add(softwarePacking);
          _cacheChildrenAntivirus.add(templateInjection);
        }
        for (AttackStep attackStep : _cacheChildrenAntivirus) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.antivirus";
      }
    }
  }

  public class ApplicationIsolationAndSandboxing extends OS.ApplicationIsolationAndSandboxing {
    public ApplicationIsolationAndSandboxing(String name) {
      this(name, false);
    }

    public ApplicationIsolationAndSandboxing(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.ApplicationIsolationAndSandboxing.Disable {
      private Set<AttackStep> _cacheChildrenApplicationIsolationAndSandboxing;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenApplicationIsolationAndSandboxing == null) {
          _cacheChildrenApplicationIsolationAndSandboxing = new HashSet<>();
          _cacheChildrenApplicationIsolationAndSandboxing.add(distributedComponentObjectModel);
          _cacheChildrenApplicationIsolationAndSandboxing.add(componentObjectModel);
          _cacheChildrenApplicationIsolationAndSandboxing.add(dynamicDataExchange);
        }
        for (AttackStep attackStep : _cacheChildrenApplicationIsolationAndSandboxing) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.applicationIsolationAndSandboxing";
      }
    }
  }

  public class Audit extends OS.Audit {
    public Audit(String name) {
      this(name, false);
    }

    public Audit(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.Audit.Disable {
      private Set<AttackStep> _cacheChildrenAudit;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenAudit == null) {
          _cacheChildrenAudit = new HashSet<>();
          _cacheChildrenAudit.add(at);
          _cacheChildrenAudit.add(credentialsInRegistry);
          _cacheChildrenAudit.add(domainTrustDiscovery);
          _cacheChildrenAudit.add(bypassUserAccessControl);
          _cacheChildrenAudit.add(dLLSearchOrderHijacking);
          _cacheChildrenAudit.add(dLLSideLoading);
          _cacheChildrenAudit.add(emailForwardingRule);
          _cacheChildrenAudit.add(executableInstallerFilePermissionsWeakness);
          _cacheChildrenAudit.add(groupPolicyPreferences);
          _cacheChildrenAudit.add(pathInterception);
          _cacheChildrenAudit.add(remoteDesktopProtocol);
          _cacheChildrenAudit.add(rDPHijacking);
          _cacheChildrenAudit.add(servicesFilePermissionsWeakness);
          _cacheChildrenAudit.add(scheduledTask);
          _cacheChildrenAudit.add(sQLStoredProcedures);
          _cacheChildrenAudit.add(transportAgent);
          _cacheChildrenAudit.add(windowsService);
        }
        for (AttackStep attackStep : _cacheChildrenAudit) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.audit";
      }
    }
  }

  public class BehaviorPreventionOnEndpoint extends OS.BehaviorPreventionOnEndpoint {
    public BehaviorPreventionOnEndpoint(String name) {
      this(name, false);
    }

    public BehaviorPreventionOnEndpoint(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.BehaviorPreventionOnEndpoint.Disable {
      private Set<AttackStep> _cacheChildrenBehaviorPreventionOnEndpoint;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenBehaviorPreventionOnEndpoint == null) {
          _cacheChildrenBehaviorPreventionOnEndpoint = new HashSet<>();
          _cacheChildrenBehaviorPreventionOnEndpoint.add(dynamicDataExchange);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(dynamicLinkLibraryInjection);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(extraWindowMemoryInjection);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(portableExecutableInjection);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(threadExecutionHijacking);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(asynchronousProcedureCall);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(threadLocalStorage);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(processHollowing);
          _cacheChildrenBehaviorPreventionOnEndpoint.add(processDoppelganging);
        }
        for (AttackStep attackStep : _cacheChildrenBehaviorPreventionOnEndpoint) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.behaviorPreventionOnEndpoint";
      }
    }
  }

  public class CodeSigning extends OS.CodeSigning {
    public CodeSigning(String name) {
      this(name, false);
    }

    public CodeSigning(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.CodeSigning.Disable {
      private Set<AttackStep> _cacheChildrenCodeSigning;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenCodeSigning == null) {
          _cacheChildrenCodeSigning = new HashSet<>();
          _cacheChildrenCodeSigning.add(invalidCodeSignature);
          _cacheChildrenCodeSigning.add(powerShell);
          _cacheChildrenCodeSigning.add(powerShellUserProfile);
          _cacheChildrenCodeSigning.add(powerShellAdminProfile);
          _cacheChildrenCodeSigning.add(sQLStoredProcedures);
          _cacheChildrenCodeSigning.add(transportAgent);
        }
        for (AttackStep attackStep : _cacheChildrenCodeSigning) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.codeSigning";
      }
    }
  }

  public class CredentialAccessProtection extends Defense {
    public CredentialAccessProtection(String name) {
      this(name, false);
    }

    public CredentialAccessProtection(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenCredentialAccessProtection;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenCredentialAccessProtection == null) {
          _cacheChildrenCredentialAccessProtection = new HashSet<>();
          _cacheChildrenCredentialAccessProtection.add(lSASSDriver);
          _cacheChildrenCredentialAccessProtection.add(lSASSMemory);
        }
        for (AttackStep attackStep : _cacheChildrenCredentialAccessProtection) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.credentialAccessProtection";
      }
    }
  }

  public class ExecutionPrevention extends OS.ExecutionPrevention {
    public ExecutionPrevention(String name) {
      this(name, false);
    }

    public ExecutionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.ExecutionPrevention.Disable {
      private Set<AttackStep> _cacheChildrenExecutionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenExecutionPrevention == null) {
          _cacheChildrenExecutionPrevention = new HashSet<>();
          _cacheChildrenExecutionPrevention.add(accessibilityFeatures);
          _cacheChildrenExecutionPrevention.add(appCertDLLs);
          _cacheChildrenExecutionPrevention.add(appInitDLLs);
          _cacheChildrenExecutionPrevention.add(cmstp);
          _cacheChildrenExecutionPrevention.add(controlPanel);
          _cacheChildrenExecutionPrevention.add(compiledHTMLFile);
          _cacheChildrenExecutionPrevention.add(cOR_PROFILER);
          _cacheChildrenExecutionPrevention.add(dLLSearchOrderHijacking);
          _cacheChildrenExecutionPrevention.add(executionThroughAPI);
          _cacheChildrenExecutionPrevention.add(executionThroughModuleLoad);
          _cacheChildrenExecutionPrevention.add(installUtil);
          _cacheChildrenExecutionPrevention.add(mshta);
          _cacheChildrenExecutionPrevention.add(networkShareDiscovery);
          _cacheChildrenExecutionPrevention.add(odbcconf);
          _cacheChildrenExecutionPrevention.add(pathInterception);
          _cacheChildrenExecutionPrevention.add(pubPrn);
          _cacheChildrenExecutionPrevention.add(queryRegistry);
          _cacheChildrenExecutionPrevention.add(regsvcsOrRegasm);
          _cacheChildrenExecutionPrevention.add(screensaver);
          _cacheChildrenExecutionPrevention.add(sIPAndTrustProviderHijacking);
          _cacheChildrenExecutionPrevention.add(systemTimeDiscovery);
          _cacheChildrenExecutionPrevention.add(windowsCommandShell);
          _cacheChildrenExecutionPrevention.add(winlogonHelperDLL);
          _cacheChildrenExecutionPrevention.add(xslScriptProcessing);
          if (Windows.this instanceof Windows) {
            for (Computer _0 : ((asset.Windows) Windows.this).computer) {
              for (Router _1 : _0.router) {
                for (InternalNetwork _2 : _1.internalNetwork) {
                  _cacheChildrenExecutionPrevention.add(_2.taintSharedContent);
                }
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenExecutionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.executionPrevention";
      }
    }
  }

  public class ExploitProtection extends OS.ExploitProtection {
    public ExploitProtection(String name) {
      this(name, false);
    }

    public ExploitProtection(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.ExploitProtection.Disable {
      private Set<AttackStep> _cacheChildrenExploitProtection;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenExploitProtection == null) {
          _cacheChildrenExploitProtection = new HashSet<>();
          _cacheChildrenExploitProtection.add(regsvr32);
          _cacheChildrenExploitProtection.add(rundll32);
          if (Windows.this instanceof Windows) {
            for (Computer _0 : ((asset.Windows) Windows.this).computer) {
              for (Router _1 : _0.router) {
                for (InternalNetwork _2 : _1.internalNetwork) {
                  _cacheChildrenExploitProtection.add(_2.taintSharedContent);
                }
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenExploitProtection) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.exploitProtection";
      }
    }
  }

  public class LimitHardwareInstallation extends OS.LimitHardwareInstallation {
    public LimitHardwareInstallation(String name) {
      this(name, false);
    }

    public LimitHardwareInstallation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.LimitHardwareInstallation.Disable {
      private Set<AttackStep> _cacheChildrenLimitHardwareInstallation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenLimitHardwareInstallation == null) {
          _cacheChildrenLimitHardwareInstallation = new HashSet<>();
          _cacheChildrenLimitHardwareInstallation.add(replicationThroughRemovableMedia);
        }
        for (AttackStep attackStep : _cacheChildrenLimitHardwareInstallation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.limitHardwareInstallation";
      }
    }
  }

  public class MultiFactorAuthentication extends OS.MultiFactorAuthentication {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.MultiFactorAuthentication.Disable {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(domainControllerAuthentication);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.multiFactorAuthentication";
      }
    }
  }

  public class OperatingSystemConfiguration extends OS.OperatingSystemConfiguration {
    public OperatingSystemConfiguration(String name) {
      this(name, false);
    }

    public OperatingSystemConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.OperatingSystemConfiguration.Disable {
      private Set<AttackStep> _cacheChildrenOperatingSystemConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenOperatingSystemConfiguration == null) {
          _cacheChildrenOperatingSystemConfiguration = new HashSet<>();
          _cacheChildrenOperatingSystemConfiguration.add(at);
          _cacheChildrenOperatingSystemConfiguration.add(passwordFilterDLL);
          _cacheChildrenOperatingSystemConfiguration.add(bITSJobs);
          _cacheChildrenOperatingSystemConfiguration.add(cachedDomainCredentials);
          _cacheChildrenOperatingSystemConfiguration.add(lSASSMemory);
          _cacheChildrenOperatingSystemConfiguration.add(rDPHijacking);
          _cacheChildrenOperatingSystemConfiguration.add(remoteDesktopProtocol);
          _cacheChildrenOperatingSystemConfiguration.add(scheduledTask);
          _cacheChildrenOperatingSystemConfiguration.add(securityAccountManager);
        }
        for (AttackStep attackStep : _cacheChildrenOperatingSystemConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.operatingSystemConfiguration";
      }
    }
  }

  public class PasswordPolicies extends OS.PasswordPolicies {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.PasswordPolicies.Disable {
      private Set<AttackStep> _cacheChildrenPasswordPolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPasswordPolicies == null) {
          _cacheChildrenPasswordPolicies = new HashSet<>();
          _cacheChildrenPasswordPolicies.add(cachedDomainCredentials);
          _cacheChildrenPasswordPolicies.add(credentialsInRegistry);
          _cacheChildrenPasswordPolicies.add(dCSync);
          _cacheChildrenPasswordPolicies.add(kerberoasting);
          _cacheChildrenPasswordPolicies.add(lSASSMemory);
          _cacheChildrenPasswordPolicies.add(lSASecrets);
          _cacheChildrenPasswordPolicies.add(nTDS);
          _cacheChildrenPasswordPolicies.add(passTheHash);
          _cacheChildrenPasswordPolicies.add(passTheTicket);
          _cacheChildrenPasswordPolicies.add(securityAccountManager);
          _cacheChildrenPasswordPolicies.add(silverTicket);
          _cacheChildrenPasswordPolicies.add(windowsAdminShares);
        }
        for (AttackStep attackStep : _cacheChildrenPasswordPolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.passwordPolicies";
      }
    }
  }

  public class PrivilegedProcessIntegrity extends Defense {
    public PrivilegedProcessIntegrity(String name) {
      this(name, false);
    }

    public PrivilegedProcessIntegrity(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenPrivilegedProcessIntegrity;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenPrivilegedProcessIntegrity == null) {
          _cacheChildrenPrivilegedProcessIntegrity = new HashSet<>();
          _cacheChildrenPrivilegedProcessIntegrity.add(authenticationPackage);
          _cacheChildrenPrivilegedProcessIntegrity.add(domainControllerAuthentication);
          _cacheChildrenPrivilegedProcessIntegrity.add(lSASSDriver);
          _cacheChildrenPrivilegedProcessIntegrity.add(lSASSMemory);
          _cacheChildrenPrivilegedProcessIntegrity.add(securitySupportProvider);
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedProcessIntegrity) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.privilegedProcessIntegrity";
      }
    }
  }

  public class PrivilegedAccountManagement extends OS.PrivilegedAccountManagement {
    public PrivilegedAccountManagement(String name) {
      this(name, false);
    }

    public PrivilegedAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.PrivilegedAccountManagement.Disable {
      private Set<AttackStep> _cacheChildrenPrivilegedAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPrivilegedAccountManagement == null) {
          _cacheChildrenPrivilegedAccountManagement = new HashSet<>();
          _cacheChildrenPrivilegedAccountManagement.add(at);
          _cacheChildrenPrivilegedAccountManagement.add(bootkit);
          _cacheChildrenPrivilegedAccountManagement.add(bypassUserAccessControl);
          _cacheChildrenPrivilegedAccountManagement.add(cachedDomainCredentials);
          _cacheChildrenPrivilegedAccountManagement.add(componentObjectModel);
          _cacheChildrenPrivilegedAccountManagement.add(credentialsInRegistry);
          _cacheChildrenPrivilegedAccountManagement.add(dCSync);
          _cacheChildrenPrivilegedAccountManagement.add(distributedComponentObjectModel);
          _cacheChildrenPrivilegedAccountManagement.add(domainControllerAuthentication);
          _cacheChildrenPrivilegedAccountManagement.add(goldenTicket);
          _cacheChildrenPrivilegedAccountManagement.add(kerberoasting);
          _cacheChildrenPrivilegedAccountManagement.add(lSASSMemory);
          _cacheChildrenPrivilegedAccountManagement.add(lSASecrets);
          _cacheChildrenPrivilegedAccountManagement.add(msiexec);
          _cacheChildrenPrivilegedAccountManagement.add(nTDS);
          _cacheChildrenPrivilegedAccountManagement.add(passTheHash);
          _cacheChildrenPrivilegedAccountManagement.add(rDPHijacking);
          _cacheChildrenPrivilegedAccountManagement.add(scheduledTask);
          _cacheChildrenPrivilegedAccountManagement.add(securityAccountManager);
          _cacheChildrenPrivilegedAccountManagement.add(silverTicket);
          _cacheChildrenPrivilegedAccountManagement.add(sQLStoredProcedures);
          _cacheChildrenPrivilegedAccountManagement.add(transportAgent);
          _cacheChildrenPrivilegedAccountManagement.add(windowsFileAndDirectoryPermissionsModification);
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.privilegedAccountManagement";
      }
    }
  }

  public class RestrictFileAndDirectoryPermissions extends OS.RestrictFileAndDirectoryPermissions {
    public RestrictFileAndDirectoryPermissions(String name) {
      this(name, false);
    }

    public RestrictFileAndDirectoryPermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.RestrictFileAndDirectoryPermissions.Disable {
      private Set<AttackStep> _cacheChildrenRestrictFileAndDirectoryPermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenRestrictFileAndDirectoryPermissions == null) {
          _cacheChildrenRestrictFileAndDirectoryPermissions = new HashSet<>();
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(clearWindowsEventLogs);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(controlPanel);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(cOR_PROFILER);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(dLLSideLoading);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(bootOrLogonInitializationScripts);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(logonScripts);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(modifyRegistry);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(ntfsFileAttributes);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(pathInterception);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(powerShellUserProfile);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(powerShellAdminProfile);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(sIPAndTrustProviderHijacking);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(serviceStop);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(serviceExecution);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(servicesRegistryPermissionsWeakness);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(timeProviders);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(disableWindowsEventLogging);
          _cacheChildrenRestrictFileAndDirectoryPermissions.add(windowsFileAndDirectoryPermissionsModification);
        }
        for (AttackStep attackStep : _cacheChildrenRestrictFileAndDirectoryPermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.restrictFileAndDirectoryPermissions";
      }
    }
  }

  public class RestrictRegistryPermissions extends OS.RestrictRegistryPermissions {
    public RestrictRegistryPermissions(String name) {
      this(name, false);
    }

    public RestrictRegistryPermissions(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.RestrictRegistryPermissions.Disable {
      private Set<AttackStep> _cacheChildrenRestrictRegistryPermissions;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenRestrictRegistryPermissions == null) {
          _cacheChildrenRestrictRegistryPermissions = new HashSet<>();
          _cacheChildrenRestrictRegistryPermissions.add(sIPAndTrustProviderHijacking);
          _cacheChildrenRestrictRegistryPermissions.add(serviceStop);
          _cacheChildrenRestrictRegistryPermissions.add(serviceRegistryPermissionsWeakness);
          _cacheChildrenRestrictRegistryPermissions.add(timeProviders);
        }
        for (AttackStep attackStep : _cacheChildrenRestrictRegistryPermissions) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.restrictRegistryPermissions";
      }
    }
  }

  public class RestrictLibraryLoading extends Defense {
    public RestrictLibraryLoading(String name) {
      this(name, false);
    }

    public RestrictLibraryLoading(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenRestrictLibraryLoading;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenRestrictLibraryLoading == null) {
          _cacheChildrenRestrictLibraryLoading = new HashSet<>();
          _cacheChildrenRestrictLibraryLoading.add(dLLSearchOrderHijacking);
          _cacheChildrenRestrictLibraryLoading.add(lSASSDriver);
        }
        for (AttackStep attackStep : _cacheChildrenRestrictLibraryLoading) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.restrictLibraryLoading";
      }
    }
  }

  public class RemoteDataStorage extends OS.RemoteDataStorage {
    public RemoteDataStorage(String name) {
      this(name, false);
    }

    public RemoteDataStorage(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.RemoteDataStorage.Disable {
      private Set<AttackStep> _cacheChildrenRemoteDataStorage;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenRemoteDataStorage == null) {
          _cacheChildrenRemoteDataStorage = new HashSet<>();
          _cacheChildrenRemoteDataStorage.add(clearWindowsEventLogs);
        }
        for (AttackStep attackStep : _cacheChildrenRemoteDataStorage) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.remoteDataStorage";
      }
    }
  }

  public class SoftwareConfiguration extends OS.SoftwareConfiguration {
    public SoftwareConfiguration(String name) {
      this(name, false);
    }

    public SoftwareConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.SoftwareConfiguration.Disable {
      private Set<AttackStep> _cacheChildrenSoftwareConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenSoftwareConfiguration == null) {
          _cacheChildrenSoftwareConfiguration = new HashSet<>();
          _cacheChildrenSoftwareConfiguration.add(powerShellUserProfile);
          _cacheChildrenSoftwareConfiguration.add(powerShellAdminProfile);
          _cacheChildrenSoftwareConfiguration.add(dynamicDataExchange);
        }
        for (AttackStep attackStep : _cacheChildrenSoftwareConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.softwareConfiguration";
      }
    }
  }

  public class BootIntegrity extends OS.BootIntegrity {
    public BootIntegrity(String name) {
      this(name, false);
    }

    public BootIntegrity(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.BootIntegrity.Disable {
      private Set<AttackStep> _cacheChildrenBootIntegrity;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenBootIntegrity == null) {
          _cacheChildrenBootIntegrity = new HashSet<>();
          _cacheChildrenBootIntegrity.add(bootkit);
          _cacheChildrenBootIntegrity.add(systemFirmware);
        }
        for (AttackStep attackStep : _cacheChildrenBootIntegrity) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.bootIntegrity";
      }
    }
  }

  public class EncryptSensitiveInformation extends OS.EncryptSensitiveInformation {
    public EncryptSensitiveInformation(String name) {
      this(name, false);
    }

    public EncryptSensitiveInformation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.EncryptSensitiveInformation.Disable {
      private Set<AttackStep> _cacheChildrenEncryptSensitiveInformation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenEncryptSensitiveInformation == null) {
          _cacheChildrenEncryptSensitiveInformation = new HashSet<>();
          _cacheChildrenEncryptSensitiveInformation.add(kerberoasting);
          _cacheChildrenEncryptSensitiveInformation.add(localEmailCollection);
          _cacheChildrenEncryptSensitiveInformation.add(nTDS);
          _cacheChildrenEncryptSensitiveInformation.add(remoteEmailCollection);
          _cacheChildrenEncryptSensitiveInformation.add(silverTicket);
          _cacheChildrenEncryptSensitiveInformation.add(emailForwardingRule);
          _cacheChildrenEncryptSensitiveInformation.add(clearWindowsEventLogs);
        }
        for (AttackStep attackStep : _cacheChildrenEncryptSensitiveInformation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.encryptSensitiveInformation";
      }
    }
  }

  public class DisableOrRemoveFeatureOrProgram extends OS.DisableOrRemoveFeatureOrProgram {
    public DisableOrRemoveFeatureOrProgram(String name) {
      this(name, false);
    }

    public DisableOrRemoveFeatureOrProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.DisableOrRemoveFeatureOrProgram.Disable {
      private Set<AttackStep> _cacheChildrenDisableOrRemoveFeatureOrProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenDisableOrRemoveFeatureOrProgram == null) {
          _cacheChildrenDisableOrRemoveFeatureOrProgram = new HashSet<>();
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(cmstp);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(distributedComponentObjectModel);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(installUtil);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(lLMNR_NBT_NS_PoisoningAndSMBRelay);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(mshta);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(odbcconf);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(powerShell);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(rDPHijacking);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(registryKeysEnabled);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(regsvcsOrRegasm);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(remoteDesktopProtocol);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(replicationThroughRemovableMedia);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(screensaver);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(templateInjection);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(mSBuild);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(windowsRemoteManagement);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(dynamicDataExchange);
        }
        for (AttackStep attackStep : _cacheChildrenDisableOrRemoveFeatureOrProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.disableOrRemoveFeatureOrProgram";
      }
    }
  }

  public class UpdateSoftware extends OS.UpdateSoftware {
    public UpdateSoftware(String name) {
      this(name, false);
    }

    public UpdateSoftware(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.UpdateSoftware.Disable {
      private Set<AttackStep> _cacheChildrenUpdateSoftware;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenUpdateSoftware == null) {
          _cacheChildrenUpdateSoftware = new HashSet<>();
          _cacheChildrenUpdateSoftware.add(appInitDLLs);
          _cacheChildrenUpdateSoftware.add(applicationShimming);
          _cacheChildrenUpdateSoftware.add(bypassUserAccessControl);
          _cacheChildrenUpdateSoftware.add(dLLSideLoading);
          _cacheChildrenUpdateSoftware.add(groupPolicyPreferences);
          _cacheChildrenUpdateSoftware.add(passTheHash);
          _cacheChildrenUpdateSoftware.add(systemFirmware);
        }
        for (AttackStep attackStep : _cacheChildrenUpdateSoftware) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.updateSoftware";
      }
    }
  }

  public class UserAccountControl extends OS.UserAccountControl {
    public UserAccountControl(String name) {
      this(name, false);
    }

    public UserAccountControl(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends OS.UserAccountControl.Disable {
      private Set<AttackStep> _cacheChildrenUserAccountControl;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenUserAccountControl == null) {
          _cacheChildrenUserAccountControl = new HashSet<>();
          _cacheChildrenUserAccountControl.add(applicationShimming);
          _cacheChildrenUserAccountControl.add(bypassUserAccessControl);
          _cacheChildrenUserAccountControl.add(executableInstallerFilePermissionsWeakness);
          _cacheChildrenUserAccountControl.add(servicesFilePermissionsWeakness);
          _cacheChildrenUserAccountControl.add(passTheHash);
        }
        for (AttackStep attackStep : _cacheChildrenUserAccountControl) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Windows.userAccountControl";
      }
    }
  }
}
