package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class ExternalNetwork extends Asset {
  public ObfuscateNetworkTraffic obfuscateNetworkTraffic;

  public BypassNetworkIntrusionDetection bypassNetworkIntrusionDetection;

  public DataExfiltration dataExfiltration;

  public DataFromCloudStorageObject dataFromCloudStorageObject;

  public AttemptDataEncryptedForImpact attemptDataEncryptedForImpact;

  public DataEncryptedForImpact dataEncryptedForImpact;

  public ExternalDefacement externalDefacement;

  public ExfiltrationOverWebService exfiltrationOverWebService;

  public ExfiltrationToCodeRepository exfiltrationToCodeRepository;

  public ExfiltrationToCloudStorage exfiltrationToCloudStorage;

  public WebService webService;

  public DeadDropResolver deadDropResolver;

  public BidirectionaCommunication bidirectionaCommunication;

  public OneWayCommunication oneWayCommunication;

  public AttemptTransmittedDataManipulation attemptTransmittedDataManipulation;

  public TransmittedDataManipulation transmittedDataManipulation;

  public EncryptSensitiveInformation encryptSensitiveInformation;

  public FilterNetworkTraffic filterNetworkTraffic;

  public NetworkIntrusionPrevention networkIntrusionPrevention;

  public NetworkSegmentation networkSegmentation;

  public SSLOrTLSInspection sSLOrTLSInspection;

  public Set<Router> router = new HashSet<>();

  public ExternalNetwork(String name, boolean isEncryptSensitiveInformationEnabled,
      boolean isFilterNetworkTrafficEnabled, boolean isNetworkIntrusionPreventionEnabled,
      boolean isNetworkSegmentationEnabled, boolean isSSLOrTLSInspectionEnabled) {
    super(name);
    assetClassName = "ExternalNetwork";
    AttackStep.allAttackSteps.remove(obfuscateNetworkTraffic);
    obfuscateNetworkTraffic = new ObfuscateNetworkTraffic(name);
    AttackStep.allAttackSteps.remove(bypassNetworkIntrusionDetection);
    bypassNetworkIntrusionDetection = new BypassNetworkIntrusionDetection(name);
    AttackStep.allAttackSteps.remove(dataExfiltration);
    dataExfiltration = new DataExfiltration(name);
    AttackStep.allAttackSteps.remove(dataFromCloudStorageObject);
    dataFromCloudStorageObject = new DataFromCloudStorageObject(name);
    AttackStep.allAttackSteps.remove(attemptDataEncryptedForImpact);
    attemptDataEncryptedForImpact = new AttemptDataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(externalDefacement);
    externalDefacement = new ExternalDefacement(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverWebService);
    exfiltrationOverWebService = new ExfiltrationOverWebService(name);
    AttackStep.allAttackSteps.remove(exfiltrationToCodeRepository);
    exfiltrationToCodeRepository = new ExfiltrationToCodeRepository(name);
    AttackStep.allAttackSteps.remove(exfiltrationToCloudStorage);
    exfiltrationToCloudStorage = new ExfiltrationToCloudStorage(name);
    AttackStep.allAttackSteps.remove(webService);
    webService = new WebService(name);
    AttackStep.allAttackSteps.remove(deadDropResolver);
    deadDropResolver = new DeadDropResolver(name);
    AttackStep.allAttackSteps.remove(bidirectionaCommunication);
    bidirectionaCommunication = new BidirectionaCommunication(name);
    AttackStep.allAttackSteps.remove(oneWayCommunication);
    oneWayCommunication = new OneWayCommunication(name);
    AttackStep.allAttackSteps.remove(attemptTransmittedDataManipulation);
    attemptTransmittedDataManipulation = new AttemptTransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(transmittedDataManipulation);
    transmittedDataManipulation = new TransmittedDataManipulation(name);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, isEncryptSensitiveInformationEnabled);
    if (filterNetworkTraffic != null) {
      AttackStep.allAttackSteps.remove(filterNetworkTraffic.disable);
    }
    Defense.allDefenses.remove(filterNetworkTraffic);
    filterNetworkTraffic = new FilterNetworkTraffic(name, isFilterNetworkTrafficEnabled);
    if (networkIntrusionPrevention != null) {
      AttackStep.allAttackSteps.remove(networkIntrusionPrevention.disable);
    }
    Defense.allDefenses.remove(networkIntrusionPrevention);
    networkIntrusionPrevention = new NetworkIntrusionPrevention(name, isNetworkIntrusionPreventionEnabled);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, isNetworkSegmentationEnabled);
    if (sSLOrTLSInspection != null) {
      AttackStep.allAttackSteps.remove(sSLOrTLSInspection.disable);
    }
    Defense.allDefenses.remove(sSLOrTLSInspection);
    sSLOrTLSInspection = new SSLOrTLSInspection(name, isSSLOrTLSInspectionEnabled);
  }

  public ExternalNetwork(String name) {
    super(name);
    assetClassName = "ExternalNetwork";
    AttackStep.allAttackSteps.remove(obfuscateNetworkTraffic);
    obfuscateNetworkTraffic = new ObfuscateNetworkTraffic(name);
    AttackStep.allAttackSteps.remove(bypassNetworkIntrusionDetection);
    bypassNetworkIntrusionDetection = new BypassNetworkIntrusionDetection(name);
    AttackStep.allAttackSteps.remove(dataExfiltration);
    dataExfiltration = new DataExfiltration(name);
    AttackStep.allAttackSteps.remove(dataFromCloudStorageObject);
    dataFromCloudStorageObject = new DataFromCloudStorageObject(name);
    AttackStep.allAttackSteps.remove(attemptDataEncryptedForImpact);
    attemptDataEncryptedForImpact = new AttemptDataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(dataEncryptedForImpact);
    dataEncryptedForImpact = new DataEncryptedForImpact(name);
    AttackStep.allAttackSteps.remove(externalDefacement);
    externalDefacement = new ExternalDefacement(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverWebService);
    exfiltrationOverWebService = new ExfiltrationOverWebService(name);
    AttackStep.allAttackSteps.remove(exfiltrationToCodeRepository);
    exfiltrationToCodeRepository = new ExfiltrationToCodeRepository(name);
    AttackStep.allAttackSteps.remove(exfiltrationToCloudStorage);
    exfiltrationToCloudStorage = new ExfiltrationToCloudStorage(name);
    AttackStep.allAttackSteps.remove(webService);
    webService = new WebService(name);
    AttackStep.allAttackSteps.remove(deadDropResolver);
    deadDropResolver = new DeadDropResolver(name);
    AttackStep.allAttackSteps.remove(bidirectionaCommunication);
    bidirectionaCommunication = new BidirectionaCommunication(name);
    AttackStep.allAttackSteps.remove(oneWayCommunication);
    oneWayCommunication = new OneWayCommunication(name);
    AttackStep.allAttackSteps.remove(attemptTransmittedDataManipulation);
    attemptTransmittedDataManipulation = new AttemptTransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(transmittedDataManipulation);
    transmittedDataManipulation = new TransmittedDataManipulation(name);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, false);
    if (filterNetworkTraffic != null) {
      AttackStep.allAttackSteps.remove(filterNetworkTraffic.disable);
    }
    Defense.allDefenses.remove(filterNetworkTraffic);
    filterNetworkTraffic = new FilterNetworkTraffic(name, false);
    if (networkIntrusionPrevention != null) {
      AttackStep.allAttackSteps.remove(networkIntrusionPrevention.disable);
    }
    Defense.allDefenses.remove(networkIntrusionPrevention);
    networkIntrusionPrevention = new NetworkIntrusionPrevention(name, false);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, false);
    if (sSLOrTLSInspection != null) {
      AttackStep.allAttackSteps.remove(sSLOrTLSInspection.disable);
    }
    Defense.allDefenses.remove(sSLOrTLSInspection);
    sSLOrTLSInspection = new SSLOrTLSInspection(name, false);
  }

  public ExternalNetwork(boolean isEncryptSensitiveInformationEnabled,
      boolean isFilterNetworkTrafficEnabled, boolean isNetworkIntrusionPreventionEnabled,
      boolean isNetworkSegmentationEnabled, boolean isSSLOrTLSInspectionEnabled) {
    this("Anonymous", isEncryptSensitiveInformationEnabled, isFilterNetworkTrafficEnabled, isNetworkIntrusionPreventionEnabled, isNetworkSegmentationEnabled, isSSLOrTLSInspectionEnabled);
  }

  public ExternalNetwork() {
    this("Anonymous");
  }

  public void addRouter(Router router) {
    this.router.add(router);
    router.externalNetwork.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("router")) {
      return Router.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("router")) {
      assets.addAll(router);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(router);
    return assets;
  }

  public class ObfuscateNetworkTraffic extends AttackStepMin {
    private Set<AttackStep> _cacheParentObfuscateNetworkTraffic;

    public ObfuscateNetworkTraffic(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentObfuscateNetworkTraffic == null) {
        _cacheParentObfuscateNetworkTraffic = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentObfuscateNetworkTraffic.add(_2.domainFronting);
            }
          }
        }
        _cacheParentObfuscateNetworkTraffic.add(sSLOrTLSInspection.disable);
      }
      for (AttackStep attackStep : _cacheParentObfuscateNetworkTraffic) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.obfuscateNetworkTraffic");
    }
  }

  public class BypassNetworkIntrusionDetection extends AttackStepMin {
    private Set<AttackStep> _cacheParentBypassNetworkIntrusionDetection;

    public BypassNetworkIntrusionDetection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassNetworkIntrusionDetection == null) {
        _cacheParentBypassNetworkIntrusionDetection = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                if (_3 instanceof CloudService) {
                  _cacheParentBypassNetworkIntrusionDetection.add(((asset.CloudService) _3).createSnapshot);
                }
              }
            }
          }
        }
        for (Router _4 : router) {
          for (Computer _5 : _4.computer) {
            for (OS _6 : _5.os) {
              for (Service _7 : _6.service) {
                if (_7 instanceof CloudService) {
                  _cacheParentBypassNetworkIntrusionDetection.add(((asset.CloudService) _7).deleteCloudInstance);
                }
              }
            }
          }
        }
        for (Router _8 : router) {
          for (Computer _9 : _8.computer) {
            for (OS _a : _9.os) {
              for (Service _b : _a.service) {
                if (_b instanceof CloudService) {
                  _cacheParentBypassNetworkIntrusionDetection.add(((asset.CloudService) _b).revertCloudInstance);
                }
              }
            }
          }
        }
        for (Router _c : router) {
          for (Computer _d : _c.computer) {
            for (OS _e : _d.os) {
              if (_e instanceof Windows) {
                _cacheParentBypassNetworkIntrusionDetection.add(((asset.Windows) _e).deobfuscateOrDecodeFilesOrInformation);
              }
            }
          }
        }
        for (Router _f : router) {
          for (InternalNetwork _10 : _f.internalNetwork) {
            _cacheParentBypassNetworkIntrusionDetection.add(_10.applicationLayerConnexion);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentBypassNetworkIntrusionDetection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.bypassNetworkIntrusionDetection");
    }
  }

  public class DataExfiltration extends AttackStepMin {
    private Set<AttackStep> _cacheParentDataExfiltration;

    public DataExfiltration(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataExfiltration == null) {
        _cacheParentDataExfiltration = new HashSet<>();
        for (Router _0 : router) {
          for (InternalNetwork _1 : _0.internalNetwork) {
            _cacheParentDataExfiltration.add(_1.dataExfiltration);
          }
        }
        _cacheParentDataExfiltration.add(exfiltrationToCodeRepository);
        _cacheParentDataExfiltration.add(exfiltrationToCloudStorage);
      }
      for (AttackStep attackStep : _cacheParentDataExfiltration) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.dataExfiltration");
    }
  }

  public class DataFromCloudStorageObject extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDataFromCloudStorageObject;

    private Set<AttackStep> _cacheParentDataFromCloudStorageObject;

    public DataFromCloudStorageObject(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDataFromCloudStorageObject == null) {
        _cacheChildrenDataFromCloudStorageObject = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                _cacheChildrenDataFromCloudStorageObject.add(_3.sensitiveDataCollected);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDataFromCloudStorageObject) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataFromCloudStorageObject == null) {
        _cacheParentDataFromCloudStorageObject = new HashSet<>();
        for (Router _4 : router) {
          for (Computer _5 : _4.computer) {
            for (OS _6 : _5.os) {
              for (UserAccount _7 : _6.userAccount) {
                _cacheParentDataFromCloudStorageObject.add(_7.userRights);
              }
            }
          }
        }
        for (Router _8 : router) {
          for (Computer _9 : _8.computer) {
            for (OS _a : _9.os) {
              for (UserAccount _b : _a.userAccount) {
                _cacheParentDataFromCloudStorageObject.add(_b.userAccountManagement.disable);
              }
            }
          }
        }
        for (Router _c : router) {
          for (Computer _d : _c.computer) {
            for (OS _e : _d.os) {
              _cacheParentDataFromCloudStorageObject.add(_e.restrictFileAndDirectoryPermissions.disable);
            }
          }
        }
        for (Router _f : router) {
          for (Computer _10 : _f.computer) {
            for (OS _11 : _10.os) {
              _cacheParentDataFromCloudStorageObject.add(_11.audit.disable);
            }
          }
        }
        for (Router _12 : router) {
          for (Computer _13 : _12.computer) {
            for (OS _14 : _13.os) {
              _cacheParentDataFromCloudStorageObject.add(_14.encryptSensitiveInformation.disable);
            }
          }
        }
        for (Router _15 : router) {
          for (InternalNetwork _16 : _15.internalNetwork) {
            _cacheParentDataFromCloudStorageObject.add(_16.multiFactorAuthentication.disable);
          }
        }
        _cacheParentDataFromCloudStorageObject.add(filterNetworkTraffic.disable);
      }
      for (AttackStep attackStep : _cacheParentDataFromCloudStorageObject) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.dataFromCloudStorageObject");
    }
  }

  public class AttemptDataEncryptedForImpact extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptDataEncryptedForImpact;

    private Set<AttackStep> _cacheParentAttemptDataEncryptedForImpact;

    public AttemptDataEncryptedForImpact(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptDataEncryptedForImpact == null) {
        _cacheChildrenAttemptDataEncryptedForImpact = new HashSet<>();
        _cacheChildrenAttemptDataEncryptedForImpact.add(dataEncryptedForImpact);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptDataEncryptedForImpact) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptDataEncryptedForImpact == null) {
        _cacheParentAttemptDataEncryptedForImpact = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            _cacheParentAttemptDataEncryptedForImpact.add(_1.infectedComputer);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptDataEncryptedForImpact) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.attemptDataEncryptedForImpact");
    }
  }

  public class DataEncryptedForImpact extends AttackStepMax {
    private Set<AttackStep> _cacheParentDataEncryptedForImpact;

    public DataEncryptedForImpact(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataEncryptedForImpact == null) {
        _cacheParentDataEncryptedForImpact = new HashSet<>();
        _cacheParentDataEncryptedForImpact.add(attemptDataEncryptedForImpact);
      }
      for (AttackStep attackStep : _cacheParentDataEncryptedForImpact) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.dataEncryptedForImpact");
    }
  }

  public class ExternalDefacement extends AttackStepMax {
    private Set<AttackStep> _cacheParentExternalDefacement;

    public ExternalDefacement(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExternalDefacement == null) {
        _cacheParentExternalDefacement = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentExternalDefacement.add(_2.defacement);
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              _cacheParentExternalDefacement.add(_5.dataBackup.disable);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentExternalDefacement) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.externalDefacement");
    }
  }

  public class ExfiltrationOverWebService extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExfiltrationOverWebService;

    private Set<AttackStep> _cacheParentExfiltrationOverWebService;

    public ExfiltrationOverWebService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverWebService == null) {
        _cacheChildrenExfiltrationOverWebService = new HashSet<>();
        _cacheChildrenExfiltrationOverWebService.add(exfiltrationToCodeRepository);
        _cacheChildrenExfiltrationOverWebService.add(exfiltrationToCloudStorage);
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverWebService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverWebService == null) {
        _cacheParentExfiltrationOverWebService = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (Service _3 : _2.service) {
                for (Browser _4 : _3.browser) {
                  _cacheParentExfiltrationOverWebService.add(_4.restrictWebBasedContent.disable);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverWebService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.exfiltrationOverWebService");
    }
  }

  public class ExfiltrationToCodeRepository extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExfiltrationToCodeRepository;

    private Set<AttackStep> _cacheParentExfiltrationToCodeRepository;

    public ExfiltrationToCodeRepository(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationToCodeRepository == null) {
        _cacheChildrenExfiltrationToCodeRepository = new HashSet<>();
        _cacheChildrenExfiltrationToCodeRepository.add(dataExfiltration);
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationToCodeRepository) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationToCodeRepository == null) {
        _cacheParentExfiltrationToCodeRepository = new HashSet<>();
        _cacheParentExfiltrationToCodeRepository.add(exfiltrationOverWebService);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationToCodeRepository) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.exfiltrationToCodeRepository");
    }
  }

  public class ExfiltrationToCloudStorage extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExfiltrationToCloudStorage;

    private Set<AttackStep> _cacheParentExfiltrationToCloudStorage;

    public ExfiltrationToCloudStorage(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationToCloudStorage == null) {
        _cacheChildrenExfiltrationToCloudStorage = new HashSet<>();
        _cacheChildrenExfiltrationToCloudStorage.add(dataExfiltration);
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationToCloudStorage) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationToCloudStorage == null) {
        _cacheParentExfiltrationToCloudStorage = new HashSet<>();
        _cacheParentExfiltrationToCloudStorage.add(exfiltrationOverWebService);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationToCloudStorage) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.exfiltrationToCloudStorage");
    }
  }

  public class WebService extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenWebService;

    public WebService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenWebService == null) {
        _cacheChildrenWebService = new HashSet<>();
        _cacheChildrenWebService.add(deadDropResolver);
        _cacheChildrenWebService.add(bidirectionaCommunication);
        _cacheChildrenWebService.add(oneWayCommunication);
      }
      for (AttackStep attackStep : _cacheChildrenWebService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.webService");
    }
  }

  public class DeadDropResolver extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenDeadDropResolver;

    private Set<AttackStep> _cacheParentDeadDropResolver;

    public DeadDropResolver(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenDeadDropResolver == null) {
        _cacheChildrenDeadDropResolver = new HashSet<>();
        for (Router _0 : router) {
          for (InternalNetwork _1 : _0.internalNetwork) {
            _cacheChildrenDeadDropResolver.add(_1.c2Connected);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDeadDropResolver) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDeadDropResolver == null) {
        _cacheParentDeadDropResolver = new HashSet<>();
        for (Router _2 : router) {
          for (Computer _3 : _2.computer) {
            for (OS _4 : _3.os) {
              for (UserAccount _5 : _4.userAccount) {
                _cacheParentDeadDropResolver.add(_5.userRights);
              }
            }
          }
        }
        for (Router _6 : router) {
          for (Computer _7 : _6.computer) {
            for (OS _8 : _7.os) {
              for (Service _9 : _8.service) {
                for (Browser _a : _9.browser) {
                  _cacheParentDeadDropResolver.add(_a.restrictWebBasedContent.disable);
                }
              }
            }
          }
        }
        _cacheParentDeadDropResolver.add(webService);
        _cacheParentDeadDropResolver.add(networkIntrusionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentDeadDropResolver) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.deadDropResolver");
    }
  }

  public class BidirectionaCommunication extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenBidirectionaCommunication;

    private Set<AttackStep> _cacheParentBidirectionaCommunication;

    public BidirectionaCommunication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBidirectionaCommunication == null) {
        _cacheChildrenBidirectionaCommunication = new HashSet<>();
        for (Router _0 : router) {
          for (InternalNetwork _1 : _0.internalNetwork) {
            _cacheChildrenBidirectionaCommunication.add(_1.c2Connected);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenBidirectionaCommunication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBidirectionaCommunication == null) {
        _cacheParentBidirectionaCommunication = new HashSet<>();
        for (Router _2 : router) {
          for (Computer _3 : _2.computer) {
            for (OS _4 : _3.os) {
              for (UserAccount _5 : _4.userAccount) {
                _cacheParentBidirectionaCommunication.add(_5.userRights);
              }
            }
          }
        }
        for (Router _6 : router) {
          for (Computer _7 : _6.computer) {
            for (OS _8 : _7.os) {
              for (Service _9 : _8.service) {
                for (Browser _a : _9.browser) {
                  _cacheParentBidirectionaCommunication.add(_a.restrictWebBasedContent.disable);
                }
              }
            }
          }
        }
        _cacheParentBidirectionaCommunication.add(webService);
        _cacheParentBidirectionaCommunication.add(networkIntrusionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentBidirectionaCommunication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.bidirectionaCommunication");
    }
  }

  public class OneWayCommunication extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenOneWayCommunication;

    private Set<AttackStep> _cacheParentOneWayCommunication;

    public OneWayCommunication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenOneWayCommunication == null) {
        _cacheChildrenOneWayCommunication = new HashSet<>();
        for (Router _0 : router) {
          for (InternalNetwork _1 : _0.internalNetwork) {
            _cacheChildrenOneWayCommunication.add(_1.c2Connected);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenOneWayCommunication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOneWayCommunication == null) {
        _cacheParentOneWayCommunication = new HashSet<>();
        for (Router _2 : router) {
          for (Computer _3 : _2.computer) {
            for (OS _4 : _3.os) {
              for (UserAccount _5 : _4.userAccount) {
                _cacheParentOneWayCommunication.add(_5.userRights);
              }
            }
          }
        }
        for (Router _6 : router) {
          for (Computer _7 : _6.computer) {
            for (OS _8 : _7.os) {
              for (Service _9 : _8.service) {
                for (Browser _a : _9.browser) {
                  _cacheParentOneWayCommunication.add(_a.restrictWebBasedContent.disable);
                }
              }
            }
          }
        }
        _cacheParentOneWayCommunication.add(webService);
        _cacheParentOneWayCommunication.add(networkIntrusionPrevention.disable);
      }
      for (AttackStep attackStep : _cacheParentOneWayCommunication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.oneWayCommunication");
    }
  }

  public class AttemptTransmittedDataManipulation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptTransmittedDataManipulation;

    private Set<AttackStep> _cacheParentAttemptTransmittedDataManipulation;

    public AttemptTransmittedDataManipulation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptTransmittedDataManipulation == null) {
        _cacheChildrenAttemptTransmittedDataManipulation = new HashSet<>();
        _cacheChildrenAttemptTransmittedDataManipulation.add(transmittedDataManipulation);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptTransmittedDataManipulation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTransmittedDataManipulation == null) {
        _cacheParentAttemptTransmittedDataManipulation = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              _cacheParentAttemptTransmittedDataManipulation.add(_2.dataManipulation);
            }
          }
        }
        for (Router _3 : router) {
          for (Computer _4 : _3.computer) {
            for (OS _5 : _4.os) {
              _cacheParentAttemptTransmittedDataManipulation.add(_5.manInTheMiddle);
            }
          }
        }
        for (Router _6 : router) {
          for (Computer _7 : _6.computer) {
            for (OS _8 : _7.os) {
              if (_8 instanceof Windows) {
                _cacheParentAttemptTransmittedDataManipulation.add(((asset.Windows) _8).powerShell);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptTransmittedDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.attemptTransmittedDataManipulation");
    }
  }

  public class TransmittedDataManipulation extends AttackStepMax {
    private Set<AttackStep> _cacheParentTransmittedDataManipulation;

    public TransmittedDataManipulation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTransmittedDataManipulation == null) {
        _cacheParentTransmittedDataManipulation = new HashSet<>();
        for (Router _0 : router) {
          for (Computer _1 : _0.computer) {
            for (OS _2 : _1.os) {
              for (UserAccount _3 : _2.userAccount) {
                _cacheParentTransmittedDataManipulation.add(_3.userRights);
              }
            }
          }
        }
        _cacheParentTransmittedDataManipulation.add(attemptTransmittedDataManipulation);
        _cacheParentTransmittedDataManipulation.add(encryptSensitiveInformation.disable);
      }
      for (AttackStep attackStep : _cacheParentTransmittedDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ExternalNetwork.transmittedDataManipulation");
    }
  }

  public class EncryptSensitiveInformation extends Defense {
    public EncryptSensitiveInformation(String name) {
      this(name, false);
    }

    public EncryptSensitiveInformation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenEncryptSensitiveInformation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenEncryptSensitiveInformation == null) {
          _cacheChildrenEncryptSensitiveInformation = new HashSet<>();
          _cacheChildrenEncryptSensitiveInformation.add(transmittedDataManipulation);
        }
        for (AttackStep attackStep : _cacheChildrenEncryptSensitiveInformation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ExternalNetwork.encryptSensitiveInformation";
      }
    }
  }

  public class FilterNetworkTraffic extends Defense {
    public FilterNetworkTraffic(String name) {
      this(name, false);
    }

    public FilterNetworkTraffic(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenFilterNetworkTraffic;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenFilterNetworkTraffic == null) {
          _cacheChildrenFilterNetworkTraffic = new HashSet<>();
          _cacheChildrenFilterNetworkTraffic.add(dataFromCloudStorageObject);
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenFilterNetworkTraffic.add(_2.endpointDenialOfService);
              }
            }
          }
          for (Router _3 : router) {
            for (Computer _4 : _3.computer) {
              for (OS _5 : _4.os) {
                _cacheChildrenFilterNetworkTraffic.add(_5.multiHopProxy);
              }
            }
          }
          for (Router _6 : router) {
            for (Computer _7 : _6.computer) {
              for (OS _8 : _7.os) {
                _cacheChildrenFilterNetworkTraffic.add(_8.directNetworkFlood);
              }
            }
          }
          for (Router _9 : router) {
            for (Computer _a : _9.computer) {
              for (OS _b : _a.os) {
                _cacheChildrenFilterNetworkTraffic.add(_b.reflectionAmplification);
              }
            }
          }
          for (Router _c : router) {
            for (Computer _d : _c.computer) {
              for (OS _e : _d.os) {
                _cacheChildrenFilterNetworkTraffic.add(_e.bITSJobs);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenFilterNetworkTraffic) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ExternalNetwork.filterNetworkTraffic";
      }
    }
  }

  public class NetworkIntrusionPrevention extends Defense {
    public NetworkIntrusionPrevention(String name) {
      this(name, false);
    }

    public NetworkIntrusionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenNetworkIntrusionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenNetworkIntrusionPrevention == null) {
          _cacheChildrenNetworkIntrusionPrevention = new HashSet<>();
          _cacheChildrenNetworkIntrusionPrevention.add(bidirectionaCommunication);
          _cacheChildrenNetworkIntrusionPrevention.add(deadDropResolver);
          _cacheChildrenNetworkIntrusionPrevention.add(oneWayCommunication);
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                for (Service _3 : _2.service) {
                  for (Browser _4 : _3.browser) {
                    _cacheChildrenNetworkIntrusionPrevention.add(_4.spearphishingAttachment);
                  }
                }
              }
            }
          }
          for (Router _5 : router) {
            for (InternalNetwork _6 : _5.internalNetwork) {
              _cacheChildrenNetworkIntrusionPrevention.add(_6.dataObfuscation);
            }
          }
          for (Router _7 : router) {
            for (InternalNetwork _8 : _7.internalNetwork) {
              _cacheChildrenNetworkIntrusionPrevention.add(_8.exfiltrationOverC2Channel);
            }
          }
          for (Router _9 : router) {
            for (InternalNetwork _a : _9.internalNetwork) {
              _cacheChildrenNetworkIntrusionPrevention.add(_a.generateDomainNames);
            }
          }
          for (Router _b : router) {
            for (Computer _c : _b.computer) {
              for (OS _d : _c.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_d.nonStandardPort);
              }
            }
          }
          for (Router _e : router) {
            for (Computer _f : _e.computer) {
              for (OS _10 : _f.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_10.fallbackChannels);
              }
            }
          }
          for (Router _11 : router) {
            for (Computer _12 : _11.computer) {
              for (OS _13 : _12.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_13.multiStageChannels);
              }
            }
          }
          for (Router _14 : router) {
            for (Computer _15 : _14.computer) {
              for (OS _16 : _15.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_16.remoteFileCopy);
              }
            }
          }
          for (Router _17 : router) {
            for (Computer _18 : _17.computer) {
              for (OS _19 : _18.os) {
                _cacheChildrenNetworkIntrusionPrevention.add(_19.applicationLayerProtocol);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenNetworkIntrusionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ExternalNetwork.networkIntrusionPrevention";
      }
    }
  }

  public class NetworkSegmentation extends Defense {
    public NetworkSegmentation(String name) {
      this(name, false);
    }

    public NetworkSegmentation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenNetworkSegmentation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenNetworkSegmentation == null) {
          _cacheChildrenNetworkSegmentation = new HashSet<>();
          for (Router _0 : router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenNetworkSegmentation.add(_2.nonStandardPort);
              }
            }
          }
          for (Router _3 : router) {
            for (Computer _4 : _3.computer) {
              for (OS _5 : _4.os) {
                _cacheChildrenNetworkSegmentation.add(_5.privateKeys);
              }
            }
          }
          for (Router _6 : router) {
            for (Computer _7 : _6.computer) {
              for (OS _8 : _7.os) {
                _cacheChildrenNetworkSegmentation.add(_8.runtimeDataManipulation);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenNetworkSegmentation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ExternalNetwork.networkSegmentation";
      }
    }
  }

  public class SSLOrTLSInspection extends Defense {
    public SSLOrTLSInspection(String name) {
      this(name, false);
    }

    public SSLOrTLSInspection(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenSSLOrTLSInspection;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenSSLOrTLSInspection == null) {
          _cacheChildrenSSLOrTLSInspection = new HashSet<>();
          _cacheChildrenSSLOrTLSInspection.add(obfuscateNetworkTraffic);
        }
        for (AttackStep attackStep : _cacheChildrenSSLOrTLSInspection) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ExternalNetwork.sSLOrTLSInspection";
      }
    }
  }
}
