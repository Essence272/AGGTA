package asset;

import core.AttackStep;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class RemovableMedia extends PeripheralDevice {
  public RemovableMedia(String name) {
    super(name);
    assetClassName = "RemovableMedia";
    AttackStep.allAttackSteps.remove(dataFromRemovableMedia);
    dataFromRemovableMedia = new DataFromRemovableMedia(name);
    AttackStep.allAttackSteps.remove(infectedMedia);
    infectedMedia = new InfectedMedia(name);
    AttackStep.allAttackSteps.remove(dataExfiltration);
    dataExfiltration = new DataExfiltration(name);
  }

  public RemovableMedia() {
    this("Anonymous");
  }

  public class DataFromRemovableMedia extends PeripheralDevice.DataFromRemovableMedia {
    private Set<AttackStep> _cacheChildrenDataFromRemovableMedia;

    public DataFromRemovableMedia(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDataFromRemovableMedia == null) {
        _cacheChildrenDataFromRemovableMedia = new HashSet<>();
        if (RemovableMedia.this instanceof RemovableMedia) {
          for (Computer _0 : ((asset.RemovableMedia) RemovableMedia.this).computer) {
            for (OS _1 : _0.os) {
              _cacheChildrenDataFromRemovableMedia.add(_1.sensitiveDataCollected);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDataFromRemovableMedia) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("RemovableMedia.dataFromRemovableMedia");
    }
  }

  public class InfectedMedia extends PeripheralDevice.InfectedMedia {
    public InfectedMedia(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("RemovableMedia.infectedMedia");
    }
  }

  public class DataExfiltration extends PeripheralDevice.DataExfiltration {
    public DataExfiltration(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("RemovableMedia.dataExfiltration");
    }
  }
}
