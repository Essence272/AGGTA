package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Firewall extends Asset {
  public BypassFirewall bypassFirewall;

  public FilterNetworkTraffic filterNetworkTraffic;

  public NetworkSegmentation networkSegmentation;

  public Router router = null;

  public Firewall(String name, boolean isFilterNetworkTrafficEnabled,
      boolean isNetworkSegmentationEnabled) {
    super(name);
    assetClassName = "Firewall";
    AttackStep.allAttackSteps.remove(bypassFirewall);
    bypassFirewall = new BypassFirewall(name);
    if (filterNetworkTraffic != null) {
      AttackStep.allAttackSteps.remove(filterNetworkTraffic.disable);
    }
    Defense.allDefenses.remove(filterNetworkTraffic);
    filterNetworkTraffic = new FilterNetworkTraffic(name, isFilterNetworkTrafficEnabled);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, isNetworkSegmentationEnabled);
  }

  public Firewall(String name) {
    super(name);
    assetClassName = "Firewall";
    AttackStep.allAttackSteps.remove(bypassFirewall);
    bypassFirewall = new BypassFirewall(name);
    if (filterNetworkTraffic != null) {
      AttackStep.allAttackSteps.remove(filterNetworkTraffic.disable);
    }
    Defense.allDefenses.remove(filterNetworkTraffic);
    filterNetworkTraffic = new FilterNetworkTraffic(name, false);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, false);
  }

  public Firewall(boolean isFilterNetworkTrafficEnabled, boolean isNetworkSegmentationEnabled) {
    this("Anonymous", isFilterNetworkTrafficEnabled, isNetworkSegmentationEnabled);
  }

  public Firewall() {
    this("Anonymous");
  }

  public void addRouter(Router router) {
    this.router = router;
    router.firewall = this;
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("router")) {
      return Router.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("router")) {
      if (router != null) {
        assets.add(router);
      }
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    if (router != null) {
      assets.add(router);
    }
    return assets;
  }

  public class BypassFirewall extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenBypassFirewall;

    private Set<AttackStep> _cacheParentBypassFirewall;

    public BypassFirewall(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenBypassFirewall == null) {
        _cacheChildrenBypassFirewall = new HashSet<>();
        if (router != null) {
          for (InternalNetwork _0 : router.internalNetwork) {
            _cacheChildrenBypassFirewall.add(_0.dataExfiltration);
          }
        }
        if (router != null) {
          for (InternalNetwork _1 : router.internalNetwork) {
            _cacheChildrenBypassFirewall.add(_1.c2Connexion);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenBypassFirewall) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBypassFirewall == null) {
        _cacheParentBypassFirewall = new HashSet<>();
        if (router != null) {
          for (Computer _2 : router.computer) {
            for (OS _3 : _2.os) {
              for (Service _4 : _3.service) {
                if (_4 instanceof CloudService) {
                  _cacheParentBypassFirewall.add(((asset.CloudService) _4).cloudAccounts);
                }
              }
            }
          }
        }
        if (router != null) {
          for (Computer _5 : router.computer) {
            for (OS _6 : _5.os) {
              for (Service _7 : _6.service) {
                if (_7 instanceof CloudService) {
                  _cacheParentBypassFirewall.add(((asset.CloudService) _7).createCloudInstance);
                }
              }
            }
          }
        }
        if (router != null) {
          for (Computer _8 : router.computer) {
            for (OS _9 : _8.os) {
              _cacheParentBypassFirewall.add(_9.disableOrModifySystemFirewall);
            }
          }
        }
        if (router != null) {
          for (Computer _a : router.computer) {
            for (OS _b : _a.os) {
              _cacheParentBypassFirewall.add(_b.defaultAccounts);
            }
          }
        }
        if (router != null) {
          for (Computer _c : router.computer) {
            for (OS _d : _c.os) {
              _cacheParentBypassFirewall.add(_d.domainAccounts);
            }
          }
        }
        if (router != null) {
          for (Computer _e : router.computer) {
            for (OS _f : _e.os) {
              _cacheParentBypassFirewall.add(_f.localAccounts);
            }
          }
        }
        if (router != null) {
          for (InternalNetwork _10 : router.internalNetwork) {
            _cacheParentBypassFirewall.add(_10.firewallExists.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentBypassFirewall) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Firewall.bypassFirewall");
    }
  }

  public class FilterNetworkTraffic extends Defense {
    public FilterNetworkTraffic(String name) {
      this(name, false);
    }

    public FilterNetworkTraffic(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenFilterNetworkTraffic;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenFilterNetworkTraffic == null) {
          _cacheChildrenFilterNetworkTraffic = new HashSet<>();
          if (router != null) {
            for (Computer _0 : router.computer) {
              for (OS _1 : _0.os) {
                for (Service _2 : _1.service) {
                  _cacheChildrenFilterNetworkTraffic.add(_2.cloudInstanceMetadataAPI);
                }
              }
            }
          }
          if (router != null) {
            for (Computer _3 : router.computer) {
              for (OS _4 : _3.os) {
                _cacheChildrenFilterNetworkTraffic.add(_4.bITSJobs);
              }
            }
          }
          if (router != null) {
            for (Computer _5 : router.computer) {
              for (OS _6 : _5.os) {
                _cacheChildrenFilterNetworkTraffic.add(_6.portKnocking);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenFilterNetworkTraffic) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Firewall.filterNetworkTraffic";
      }
    }
  }

  public class NetworkSegmentation extends Defense {
    public NetworkSegmentation(String name) {
      this(name, false);
    }

    public NetworkSegmentation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenNetworkSegmentation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenNetworkSegmentation == null) {
          _cacheChildrenNetworkSegmentation = new HashSet<>();
          if (router != null) {
            for (Computer _0 : router.computer) {
              for (OS _1 : _0.os) {
                _cacheChildrenNetworkSegmentation.add(_1.nonStandardPort);
              }
            }
          }
          if (router != null) {
            for (Computer _2 : router.computer) {
              for (OS _3 : _2.os) {
                for (Service _4 : _3.service) {
                  _cacheChildrenNetworkSegmentation.add(_4.externalRemoteServices);
                }
              }
            }
          }
          if (router != null) {
            for (Computer _5 : router.computer) {
              for (OS _6 : _5.os) {
                _cacheChildrenNetworkSegmentation.add(_6.remoteDesktopProtocol);
              }
            }
          }
          if (router != null) {
            for (Computer _7 : router.computer) {
              for (OS _8 : _7.os) {
                _cacheChildrenNetworkSegmentation.add(_8.distributedComponentObjectModel);
              }
            }
          }
          if (router != null) {
            for (Computer _9 : router.computer) {
              for (OS _a : _9.os) {
                _cacheChildrenNetworkSegmentation.add(_a.windowsRemoteManagement);
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenNetworkSegmentation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Firewall.networkSegmentation";
      }
    }
  }
}
