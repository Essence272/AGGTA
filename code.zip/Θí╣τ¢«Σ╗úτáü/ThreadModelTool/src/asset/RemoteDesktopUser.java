package asset;

import core.AttackStep;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class RemoteDesktopUser extends UserAccount {
  public MultiFactorAuthentication multiFactorAuthentication;

  public RemoteDesktopUser(String name, boolean isUserTrainingEnabled,
      boolean isUserAccountManagementEnabled, boolean isMultiFactorAuthenticationEnabled) {
    super(name, isUserTrainingEnabled, isUserAccountManagementEnabled);
    assetClassName = "RemoteDesktopUser";
    AttackStep.allAttackSteps.remove(userCredentials);
    userCredentials = new UserCredentials(name);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
  }

  public RemoteDesktopUser(String name) {
    super(name);
    assetClassName = "RemoteDesktopUser";
    AttackStep.allAttackSteps.remove(userCredentials);
    userCredentials = new UserCredentials(name);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
  }

  public RemoteDesktopUser(boolean isUserTrainingEnabled, boolean isUserAccountManagementEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    this("Anonymous", isUserTrainingEnabled, isUserAccountManagementEnabled, isMultiFactorAuthenticationEnabled);
  }

  public RemoteDesktopUser() {
    this("Anonymous");
  }

  public class UserCredentials extends UserAccount.UserCredentials {
    public UserCredentials(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("RemoteDesktopUser.userCredentials");
    }
  }

  public class MultiFactorAuthentication extends Defense {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          if (RemoteDesktopUser.this instanceof RemoteDesktopUser) {
            if (((asset.RemoteDesktopUser) RemoteDesktopUser.this).os != null) {
              _cacheChildrenMultiFactorAuthentication.add(((asset.RemoteDesktopUser) RemoteDesktopUser.this).os.remoteDesktopProtocol);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "RemoteDesktopUser.multiFactorAuthentication";
      }
    }
  }
}
