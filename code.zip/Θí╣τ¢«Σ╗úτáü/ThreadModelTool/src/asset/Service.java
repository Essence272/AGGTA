package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Service extends Asset {
  public AttemptTrustedRelationship attemptTrustedRelationship;

  public TrustedRelationship trustedRelationship;

  public AttemptUseThirdpartySoftware attemptUseThirdpartySoftware;

  public UseThirdpartySoftware useThirdpartySoftware;

  public CollectVideo collectVideo;

  public ApplicationAccessToken applicationAccessToken;

  public AccessCloudBasedServiceResources accessCloudBasedServiceResources;

  public Persistence persistence;

  public SensitiveDataCollected sensitiveDataCollected;

  public CloudServiceInformationCollected cloudServiceInformationCollected;

  public CloudAccount cloudAccount;

  public CloudAccounts cloudAccounts;

  public CloudGroups cloudGroups;

  public CloudInstanceMetadataAPI cloudInstanceMetadataAPI;

  public CloudServiceDiscovery cloudServiceDiscovery;

  public CloudServiceDashboard cloudServiceDashboard;

  public DisableOrModifyCloudFirewall disableOrModifyCloudFirewall;

  public EmailAccount emailAccount;

  public EmailAddressCollected emailAddressCollected;

  public AdditionalAzureServicePrincipalCredentials additionalAzureServicePrincipalCredentials;

  public ExchangeEmailDelegatePermissions exchangeEmailDelegatePermissions;

  public AddOffice365GlobalAdministratorRole addOffice365GlobalAdministratorRole;

  public ModifyCloudComputeInfrastructure modifyCloudComputeInfrastructure;

  public CreateSnapshot createSnapshot;

  public CreateCloudInstance createCloudInstance;

  public DeleteCloudInstance deleteCloudInstance;

  public RevertCloudInstance revertCloudInstance;

  public RemoteEmailCollection remoteEmailCollection;

  public EmailForwardingRule emailForwardingRule;

  public ApplicationExhaustionFlood applicationExhaustionFlood;

  public ServiceExhaustionFlood serviceExhaustionFlood;

  public ApplicationOrSystemExploitation applicationOrSystemExploitation;

  public OfficeTemplateMacros officeTemplateMacros;

  public OfficeTest officeTest;

  public OutlookForms outlookForms;

  public OutlookHomePage outlookHomePage;

  public OutlookRules outlookRules;

  public AddIns addIns;

  public StealApplicationAccessToken stealApplicationAccessToken;

  public ApplicationDeploymentSoftware applicationDeploymentSoftware;

  public ApplicationHighVulnerability applicationHighVulnerability;

  public ApplicationMediumVulnerability applicationMediumVulnerability;

  public ApplicationLowVulnerability applicationLowVulnerability;

  public ExploitHighVulnerabilityPublicFacingApplication exploitHighVulnerabilityPublicFacingApplication;

  public ExploitMediumVulnerabilityPublicFacingApplication exploitMediumVulnerabilityPublicFacingApplication;

  public ExploitLowVulnerabilityPublicFacingApplication exploitLowVulnerabilityPublicFacingApplication;

  public BlockUserAccess blockUserAccess;

  public ImplantContainerImage implantContainerImage;

  public ServiceInformation serviceInformation;

  public RemoteServices remoteServices;

  public RemoteServiceSessionHijacking remoteServiceSessionHijacking;

  public TransmittedDataManipulation transmittedDataManipulation;

  public InformationRepositories informationRepositories;

  public RemoteAccessSoftware remoteAccessSoftware;

  public AttemptSpearphishingViaService attemptSpearphishingViaService;

  public SpearphishingViaService spearphishingViaService;

  public SpearphishingViaPersonalEmail spearphishingViaPersonalEmail;

  public SpearphishingViaSocialMedia spearphishingViaSocialMedia;

  public SupplyChainCompromise supplyChainCompromise;

  public CompromiseSoftwareDependenciesAndDevelopmentTools compromiseSoftwareDependenciesAndDevelopmentTools;

  public CompromiseSoftwareSupplyChain compromiseSoftwareSupplyChain;

  public CompromiseHardwareSupplyChain compromiseHardwareSupplyChain;

  public AttemptExploitationForClientExecution attemptExploitationForClientExecution;

  public ExploitationForClientExecution exploitationForClientExecution;

  public AttemptExploitationForCredentialAccess attemptExploitationForCredentialAccess;

  public ExploitationForCredentialAccess exploitationForCredentialAccess;

  public ExploitationOfSQLInjection exploitationOfSQLInjection;

  public ExploitationOfNTLMAuthentication exploitationOfNTLMAuthentication;

  public AttemptExploitationForDefenseEvasion attemptExploitationForDefenseEvasion;

  public ExploitationForDefenseEvasion exploitationForDefenseEvasion;

  public AttemptExploitationForPrivilegeEscalation attemptExploitationForPrivilegeEscalation;

  public ExploitationForPrivilegeEscalation exploitationForPrivilegeEscalation;

  public AttemptExploitationOfRemoteServices attemptExploitationOfRemoteServices;

  public ExploitationOfRemoteServices exploitationOfRemoteServices;

  public AttemptExternalRemoteServices attemptExternalRemoteServices;

  public ExternalRemoteServices externalRemoteServices;

  public Audit audit;

  public ApplicationIsolationAndSandboxing applicationIsolationAndSandboxing;

  public PrivilegedAccountManagement privilegedAccountManagement;

  public DisableOrRemoveFeatureOrProgram disableOrRemoveFeatureOrProgram;

  public EncryptSensitiveInformation encryptSensitiveInformation;

  public ExecutionPrevention executionPrevention;

  public ExploitProtection exploitProtection;

  public NetworkSegmentation networkSegmentation;

  public ThreatIntelligenceProgram threatIntelligenceProgram;

  public PasswordPolicies passwordPolicies;

  public UpdateSoftware updateSoftware;

  public SoftwareConfiguration softwareConfiguration;

  public ActiveDirectoryConfiguration activeDirectoryConfiguration;

  public VulnerabilityScanning vulnerabilityScanning;

  public MultiFactorAuthentication multiFactorAuthentication;

  public OS os = null;

  public Set<Browser> browser = new HashSet<>();

  public Service(String name, boolean isAuditEnabled,
      boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    super(name);
    assetClassName = "Service";
    AttackStep.allAttackSteps.remove(attemptTrustedRelationship);
    attemptTrustedRelationship = new AttemptTrustedRelationship(name);
    AttackStep.allAttackSteps.remove(trustedRelationship);
    trustedRelationship = new TrustedRelationship(name);
    AttackStep.allAttackSteps.remove(attemptUseThirdpartySoftware);
    attemptUseThirdpartySoftware = new AttemptUseThirdpartySoftware(name);
    AttackStep.allAttackSteps.remove(useThirdpartySoftware);
    useThirdpartySoftware = new UseThirdpartySoftware(name);
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
    AttackStep.allAttackSteps.remove(applicationAccessToken);
    applicationAccessToken = new ApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(accessCloudBasedServiceResources);
    accessCloudBasedServiceResources = new AccessCloudBasedServiceResources(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(sensitiveDataCollected);
    sensitiveDataCollected = new SensitiveDataCollected(name);
    AttackStep.allAttackSteps.remove(cloudServiceInformationCollected);
    cloudServiceInformationCollected = new CloudServiceInformationCollected(name);
    AttackStep.allAttackSteps.remove(cloudAccount);
    cloudAccount = new CloudAccount(name);
    AttackStep.allAttackSteps.remove(cloudAccounts);
    cloudAccounts = new CloudAccounts(name);
    AttackStep.allAttackSteps.remove(cloudGroups);
    cloudGroups = new CloudGroups(name);
    AttackStep.allAttackSteps.remove(cloudInstanceMetadataAPI);
    cloudInstanceMetadataAPI = new CloudInstanceMetadataAPI(name);
    AttackStep.allAttackSteps.remove(cloudServiceDiscovery);
    cloudServiceDiscovery = new CloudServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(cloudServiceDashboard);
    cloudServiceDashboard = new CloudServiceDashboard(name);
    AttackStep.allAttackSteps.remove(disableOrModifyCloudFirewall);
    disableOrModifyCloudFirewall = new DisableOrModifyCloudFirewall(name);
    AttackStep.allAttackSteps.remove(emailAccount);
    emailAccount = new EmailAccount(name);
    AttackStep.allAttackSteps.remove(emailAddressCollected);
    emailAddressCollected = new EmailAddressCollected(name);
    AttackStep.allAttackSteps.remove(additionalAzureServicePrincipalCredentials);
    additionalAzureServicePrincipalCredentials = new AdditionalAzureServicePrincipalCredentials(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(addOffice365GlobalAdministratorRole);
    addOffice365GlobalAdministratorRole = new AddOffice365GlobalAdministratorRole(name);
    AttackStep.allAttackSteps.remove(modifyCloudComputeInfrastructure);
    modifyCloudComputeInfrastructure = new ModifyCloudComputeInfrastructure(name);
    AttackStep.allAttackSteps.remove(createSnapshot);
    createSnapshot = new CreateSnapshot(name);
    AttackStep.allAttackSteps.remove(createCloudInstance);
    createCloudInstance = new CreateCloudInstance(name);
    AttackStep.allAttackSteps.remove(deleteCloudInstance);
    deleteCloudInstance = new DeleteCloudInstance(name);
    AttackStep.allAttackSteps.remove(revertCloudInstance);
    revertCloudInstance = new RevertCloudInstance(name);
    AttackStep.allAttackSteps.remove(remoteEmailCollection);
    remoteEmailCollection = new RemoteEmailCollection(name);
    AttackStep.allAttackSteps.remove(emailForwardingRule);
    emailForwardingRule = new EmailForwardingRule(name);
    AttackStep.allAttackSteps.remove(applicationExhaustionFlood);
    applicationExhaustionFlood = new ApplicationExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(applicationOrSystemExploitation);
    applicationOrSystemExploitation = new ApplicationOrSystemExploitation(name);
    AttackStep.allAttackSteps.remove(officeTemplateMacros);
    officeTemplateMacros = new OfficeTemplateMacros(name);
    AttackStep.allAttackSteps.remove(officeTest);
    officeTest = new OfficeTest(name);
    AttackStep.allAttackSteps.remove(outlookForms);
    outlookForms = new OutlookForms(name);
    AttackStep.allAttackSteps.remove(outlookHomePage);
    outlookHomePage = new OutlookHomePage(name);
    AttackStep.allAttackSteps.remove(outlookRules);
    outlookRules = new OutlookRules(name);
    AttackStep.allAttackSteps.remove(addIns);
    addIns = new AddIns(name);
    AttackStep.allAttackSteps.remove(stealApplicationAccessToken);
    stealApplicationAccessToken = new StealApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(applicationDeploymentSoftware);
    applicationDeploymentSoftware = new ApplicationDeploymentSoftware(name);
    AttackStep.allAttackSteps.remove(applicationHighVulnerability);
    applicationHighVulnerability = new ApplicationHighVulnerability(name);
    AttackStep.allAttackSteps.remove(applicationMediumVulnerability);
    applicationMediumVulnerability = new ApplicationMediumVulnerability(name);
    AttackStep.allAttackSteps.remove(applicationLowVulnerability);
    applicationLowVulnerability = new ApplicationLowVulnerability(name);
    AttackStep.allAttackSteps.remove(exploitHighVulnerabilityPublicFacingApplication);
    exploitHighVulnerabilityPublicFacingApplication = new ExploitHighVulnerabilityPublicFacingApplication(name);
    AttackStep.allAttackSteps.remove(exploitMediumVulnerabilityPublicFacingApplication);
    exploitMediumVulnerabilityPublicFacingApplication = new ExploitMediumVulnerabilityPublicFacingApplication(name);
    AttackStep.allAttackSteps.remove(exploitLowVulnerabilityPublicFacingApplication);
    exploitLowVulnerabilityPublicFacingApplication = new ExploitLowVulnerabilityPublicFacingApplication(name);
    AttackStep.allAttackSteps.remove(blockUserAccess);
    blockUserAccess = new BlockUserAccess(name);
    AttackStep.allAttackSteps.remove(implantContainerImage);
    implantContainerImage = new ImplantContainerImage(name);
    AttackStep.allAttackSteps.remove(serviceInformation);
    serviceInformation = new ServiceInformation(name);
    AttackStep.allAttackSteps.remove(remoteServices);
    remoteServices = new RemoteServices(name);
    AttackStep.allAttackSteps.remove(remoteServiceSessionHijacking);
    remoteServiceSessionHijacking = new RemoteServiceSessionHijacking(name);
    AttackStep.allAttackSteps.remove(transmittedDataManipulation);
    transmittedDataManipulation = new TransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(informationRepositories);
    informationRepositories = new InformationRepositories(name);
    AttackStep.allAttackSteps.remove(remoteAccessSoftware);
    remoteAccessSoftware = new RemoteAccessSoftware(name);
    AttackStep.allAttackSteps.remove(attemptSpearphishingViaService);
    attemptSpearphishingViaService = new AttemptSpearphishingViaService(name);
    AttackStep.allAttackSteps.remove(spearphishingViaService);
    spearphishingViaService = new SpearphishingViaService(name);
    AttackStep.allAttackSteps.remove(spearphishingViaPersonalEmail);
    spearphishingViaPersonalEmail = new SpearphishingViaPersonalEmail(name);
    AttackStep.allAttackSteps.remove(spearphishingViaSocialMedia);
    spearphishingViaSocialMedia = new SpearphishingViaSocialMedia(name);
    AttackStep.allAttackSteps.remove(supplyChainCompromise);
    supplyChainCompromise = new SupplyChainCompromise(name);
    AttackStep.allAttackSteps.remove(compromiseSoftwareDependenciesAndDevelopmentTools);
    compromiseSoftwareDependenciesAndDevelopmentTools = new CompromiseSoftwareDependenciesAndDevelopmentTools(name);
    AttackStep.allAttackSteps.remove(compromiseSoftwareSupplyChain);
    compromiseSoftwareSupplyChain = new CompromiseSoftwareSupplyChain(name);
    AttackStep.allAttackSteps.remove(compromiseHardwareSupplyChain);
    compromiseHardwareSupplyChain = new CompromiseHardwareSupplyChain(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForClientExecution);
    attemptExploitationForClientExecution = new AttemptExploitationForClientExecution(name);
    AttackStep.allAttackSteps.remove(exploitationForClientExecution);
    exploitationForClientExecution = new ExploitationForClientExecution(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForCredentialAccess);
    attemptExploitationForCredentialAccess = new AttemptExploitationForCredentialAccess(name);
    AttackStep.allAttackSteps.remove(exploitationForCredentialAccess);
    exploitationForCredentialAccess = new ExploitationForCredentialAccess(name);
    AttackStep.allAttackSteps.remove(exploitationOfSQLInjection);
    exploitationOfSQLInjection = new ExploitationOfSQLInjection(name);
    AttackStep.allAttackSteps.remove(exploitationOfNTLMAuthentication);
    exploitationOfNTLMAuthentication = new ExploitationOfNTLMAuthentication(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForDefenseEvasion);
    attemptExploitationForDefenseEvasion = new AttemptExploitationForDefenseEvasion(name);
    AttackStep.allAttackSteps.remove(exploitationForDefenseEvasion);
    exploitationForDefenseEvasion = new ExploitationForDefenseEvasion(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForPrivilegeEscalation);
    attemptExploitationForPrivilegeEscalation = new AttemptExploitationForPrivilegeEscalation(name);
    AttackStep.allAttackSteps.remove(exploitationForPrivilegeEscalation);
    exploitationForPrivilegeEscalation = new ExploitationForPrivilegeEscalation(name);
    AttackStep.allAttackSteps.remove(attemptExploitationOfRemoteServices);
    attemptExploitationOfRemoteServices = new AttemptExploitationOfRemoteServices(name);
    AttackStep.allAttackSteps.remove(exploitationOfRemoteServices);
    exploitationOfRemoteServices = new ExploitationOfRemoteServices(name);
    AttackStep.allAttackSteps.remove(attemptExternalRemoteServices);
    attemptExternalRemoteServices = new AttemptExternalRemoteServices(name);
    AttackStep.allAttackSteps.remove(externalRemoteServices);
    externalRemoteServices = new ExternalRemoteServices(name);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, isAuditEnabled);
    if (applicationIsolationAndSandboxing != null) {
      AttackStep.allAttackSteps.remove(applicationIsolationAndSandboxing.disable);
    }
    Defense.allDefenses.remove(applicationIsolationAndSandboxing);
    applicationIsolationAndSandboxing = new ApplicationIsolationAndSandboxing(name, isApplicationIsolationAndSandboxingEnabled);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, isPrivilegedAccountManagementEnabled);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, isDisableOrRemoveFeatureOrProgramEnabled);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, isEncryptSensitiveInformationEnabled);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, isExecutionPreventionEnabled);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, isExploitProtectionEnabled);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, isNetworkSegmentationEnabled);
    if (threatIntelligenceProgram != null) {
      AttackStep.allAttackSteps.remove(threatIntelligenceProgram.disable);
    }
    Defense.allDefenses.remove(threatIntelligenceProgram);
    threatIntelligenceProgram = new ThreatIntelligenceProgram(name, isThreatIntelligenceProgramEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, isUpdateSoftwareEnabled);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, isSoftwareConfigurationEnabled);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, isActiveDirectoryConfigurationEnabled);
    if (vulnerabilityScanning != null) {
      AttackStep.allAttackSteps.remove(vulnerabilityScanning.disable);
    }
    Defense.allDefenses.remove(vulnerabilityScanning);
    vulnerabilityScanning = new VulnerabilityScanning(name, isVulnerabilityScanningEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
  }

  public Service(String name) {
    super(name);
    assetClassName = "Service";
    AttackStep.allAttackSteps.remove(attemptTrustedRelationship);
    attemptTrustedRelationship = new AttemptTrustedRelationship(name);
    AttackStep.allAttackSteps.remove(trustedRelationship);
    trustedRelationship = new TrustedRelationship(name);
    AttackStep.allAttackSteps.remove(attemptUseThirdpartySoftware);
    attemptUseThirdpartySoftware = new AttemptUseThirdpartySoftware(name);
    AttackStep.allAttackSteps.remove(useThirdpartySoftware);
    useThirdpartySoftware = new UseThirdpartySoftware(name);
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
    AttackStep.allAttackSteps.remove(applicationAccessToken);
    applicationAccessToken = new ApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(accessCloudBasedServiceResources);
    accessCloudBasedServiceResources = new AccessCloudBasedServiceResources(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(sensitiveDataCollected);
    sensitiveDataCollected = new SensitiveDataCollected(name);
    AttackStep.allAttackSteps.remove(cloudServiceInformationCollected);
    cloudServiceInformationCollected = new CloudServiceInformationCollected(name);
    AttackStep.allAttackSteps.remove(cloudAccount);
    cloudAccount = new CloudAccount(name);
    AttackStep.allAttackSteps.remove(cloudAccounts);
    cloudAccounts = new CloudAccounts(name);
    AttackStep.allAttackSteps.remove(cloudGroups);
    cloudGroups = new CloudGroups(name);
    AttackStep.allAttackSteps.remove(cloudInstanceMetadataAPI);
    cloudInstanceMetadataAPI = new CloudInstanceMetadataAPI(name);
    AttackStep.allAttackSteps.remove(cloudServiceDiscovery);
    cloudServiceDiscovery = new CloudServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(cloudServiceDashboard);
    cloudServiceDashboard = new CloudServiceDashboard(name);
    AttackStep.allAttackSteps.remove(disableOrModifyCloudFirewall);
    disableOrModifyCloudFirewall = new DisableOrModifyCloudFirewall(name);
    AttackStep.allAttackSteps.remove(emailAccount);
    emailAccount = new EmailAccount(name);
    AttackStep.allAttackSteps.remove(emailAddressCollected);
    emailAddressCollected = new EmailAddressCollected(name);
    AttackStep.allAttackSteps.remove(additionalAzureServicePrincipalCredentials);
    additionalAzureServicePrincipalCredentials = new AdditionalAzureServicePrincipalCredentials(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(addOffice365GlobalAdministratorRole);
    addOffice365GlobalAdministratorRole = new AddOffice365GlobalAdministratorRole(name);
    AttackStep.allAttackSteps.remove(modifyCloudComputeInfrastructure);
    modifyCloudComputeInfrastructure = new ModifyCloudComputeInfrastructure(name);
    AttackStep.allAttackSteps.remove(createSnapshot);
    createSnapshot = new CreateSnapshot(name);
    AttackStep.allAttackSteps.remove(createCloudInstance);
    createCloudInstance = new CreateCloudInstance(name);
    AttackStep.allAttackSteps.remove(deleteCloudInstance);
    deleteCloudInstance = new DeleteCloudInstance(name);
    AttackStep.allAttackSteps.remove(revertCloudInstance);
    revertCloudInstance = new RevertCloudInstance(name);
    AttackStep.allAttackSteps.remove(remoteEmailCollection);
    remoteEmailCollection = new RemoteEmailCollection(name);
    AttackStep.allAttackSteps.remove(emailForwardingRule);
    emailForwardingRule = new EmailForwardingRule(name);
    AttackStep.allAttackSteps.remove(applicationExhaustionFlood);
    applicationExhaustionFlood = new ApplicationExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(applicationOrSystemExploitation);
    applicationOrSystemExploitation = new ApplicationOrSystemExploitation(name);
    AttackStep.allAttackSteps.remove(officeTemplateMacros);
    officeTemplateMacros = new OfficeTemplateMacros(name);
    AttackStep.allAttackSteps.remove(officeTest);
    officeTest = new OfficeTest(name);
    AttackStep.allAttackSteps.remove(outlookForms);
    outlookForms = new OutlookForms(name);
    AttackStep.allAttackSteps.remove(outlookHomePage);
    outlookHomePage = new OutlookHomePage(name);
    AttackStep.allAttackSteps.remove(outlookRules);
    outlookRules = new OutlookRules(name);
    AttackStep.allAttackSteps.remove(addIns);
    addIns = new AddIns(name);
    AttackStep.allAttackSteps.remove(stealApplicationAccessToken);
    stealApplicationAccessToken = new StealApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(applicationDeploymentSoftware);
    applicationDeploymentSoftware = new ApplicationDeploymentSoftware(name);
    AttackStep.allAttackSteps.remove(applicationHighVulnerability);
    applicationHighVulnerability = new ApplicationHighVulnerability(name);
    AttackStep.allAttackSteps.remove(applicationMediumVulnerability);
    applicationMediumVulnerability = new ApplicationMediumVulnerability(name);
    AttackStep.allAttackSteps.remove(applicationLowVulnerability);
    applicationLowVulnerability = new ApplicationLowVulnerability(name);
    AttackStep.allAttackSteps.remove(exploitHighVulnerabilityPublicFacingApplication);
    exploitHighVulnerabilityPublicFacingApplication = new ExploitHighVulnerabilityPublicFacingApplication(name);
    AttackStep.allAttackSteps.remove(exploitMediumVulnerabilityPublicFacingApplication);
    exploitMediumVulnerabilityPublicFacingApplication = new ExploitMediumVulnerabilityPublicFacingApplication(name);
    AttackStep.allAttackSteps.remove(exploitLowVulnerabilityPublicFacingApplication);
    exploitLowVulnerabilityPublicFacingApplication = new ExploitLowVulnerabilityPublicFacingApplication(name);
    AttackStep.allAttackSteps.remove(blockUserAccess);
    blockUserAccess = new BlockUserAccess(name);
    AttackStep.allAttackSteps.remove(implantContainerImage);
    implantContainerImage = new ImplantContainerImage(name);
    AttackStep.allAttackSteps.remove(serviceInformation);
    serviceInformation = new ServiceInformation(name);
    AttackStep.allAttackSteps.remove(remoteServices);
    remoteServices = new RemoteServices(name);
    AttackStep.allAttackSteps.remove(remoteServiceSessionHijacking);
    remoteServiceSessionHijacking = new RemoteServiceSessionHijacking(name);
    AttackStep.allAttackSteps.remove(transmittedDataManipulation);
    transmittedDataManipulation = new TransmittedDataManipulation(name);
    AttackStep.allAttackSteps.remove(informationRepositories);
    informationRepositories = new InformationRepositories(name);
    AttackStep.allAttackSteps.remove(remoteAccessSoftware);
    remoteAccessSoftware = new RemoteAccessSoftware(name);
    AttackStep.allAttackSteps.remove(attemptSpearphishingViaService);
    attemptSpearphishingViaService = new AttemptSpearphishingViaService(name);
    AttackStep.allAttackSteps.remove(spearphishingViaService);
    spearphishingViaService = new SpearphishingViaService(name);
    AttackStep.allAttackSteps.remove(spearphishingViaPersonalEmail);
    spearphishingViaPersonalEmail = new SpearphishingViaPersonalEmail(name);
    AttackStep.allAttackSteps.remove(spearphishingViaSocialMedia);
    spearphishingViaSocialMedia = new SpearphishingViaSocialMedia(name);
    AttackStep.allAttackSteps.remove(supplyChainCompromise);
    supplyChainCompromise = new SupplyChainCompromise(name);
    AttackStep.allAttackSteps.remove(compromiseSoftwareDependenciesAndDevelopmentTools);
    compromiseSoftwareDependenciesAndDevelopmentTools = new CompromiseSoftwareDependenciesAndDevelopmentTools(name);
    AttackStep.allAttackSteps.remove(compromiseSoftwareSupplyChain);
    compromiseSoftwareSupplyChain = new CompromiseSoftwareSupplyChain(name);
    AttackStep.allAttackSteps.remove(compromiseHardwareSupplyChain);
    compromiseHardwareSupplyChain = new CompromiseHardwareSupplyChain(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForClientExecution);
    attemptExploitationForClientExecution = new AttemptExploitationForClientExecution(name);
    AttackStep.allAttackSteps.remove(exploitationForClientExecution);
    exploitationForClientExecution = new ExploitationForClientExecution(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForCredentialAccess);
    attemptExploitationForCredentialAccess = new AttemptExploitationForCredentialAccess(name);
    AttackStep.allAttackSteps.remove(exploitationForCredentialAccess);
    exploitationForCredentialAccess = new ExploitationForCredentialAccess(name);
    AttackStep.allAttackSteps.remove(exploitationOfSQLInjection);
    exploitationOfSQLInjection = new ExploitationOfSQLInjection(name);
    AttackStep.allAttackSteps.remove(exploitationOfNTLMAuthentication);
    exploitationOfNTLMAuthentication = new ExploitationOfNTLMAuthentication(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForDefenseEvasion);
    attemptExploitationForDefenseEvasion = new AttemptExploitationForDefenseEvasion(name);
    AttackStep.allAttackSteps.remove(exploitationForDefenseEvasion);
    exploitationForDefenseEvasion = new ExploitationForDefenseEvasion(name);
    AttackStep.allAttackSteps.remove(attemptExploitationForPrivilegeEscalation);
    attemptExploitationForPrivilegeEscalation = new AttemptExploitationForPrivilegeEscalation(name);
    AttackStep.allAttackSteps.remove(exploitationForPrivilegeEscalation);
    exploitationForPrivilegeEscalation = new ExploitationForPrivilegeEscalation(name);
    AttackStep.allAttackSteps.remove(attemptExploitationOfRemoteServices);
    attemptExploitationOfRemoteServices = new AttemptExploitationOfRemoteServices(name);
    AttackStep.allAttackSteps.remove(exploitationOfRemoteServices);
    exploitationOfRemoteServices = new ExploitationOfRemoteServices(name);
    AttackStep.allAttackSteps.remove(attemptExternalRemoteServices);
    attemptExternalRemoteServices = new AttemptExternalRemoteServices(name);
    AttackStep.allAttackSteps.remove(externalRemoteServices);
    externalRemoteServices = new ExternalRemoteServices(name);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, false);
    if (applicationIsolationAndSandboxing != null) {
      AttackStep.allAttackSteps.remove(applicationIsolationAndSandboxing.disable);
    }
    Defense.allDefenses.remove(applicationIsolationAndSandboxing);
    applicationIsolationAndSandboxing = new ApplicationIsolationAndSandboxing(name, false);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, false);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, false);
    if (encryptSensitiveInformation != null) {
      AttackStep.allAttackSteps.remove(encryptSensitiveInformation.disable);
    }
    Defense.allDefenses.remove(encryptSensitiveInformation);
    encryptSensitiveInformation = new EncryptSensitiveInformation(name, false);
    if (executionPrevention != null) {
      AttackStep.allAttackSteps.remove(executionPrevention.disable);
    }
    Defense.allDefenses.remove(executionPrevention);
    executionPrevention = new ExecutionPrevention(name, false);
    if (exploitProtection != null) {
      AttackStep.allAttackSteps.remove(exploitProtection.disable);
    }
    Defense.allDefenses.remove(exploitProtection);
    exploitProtection = new ExploitProtection(name, false);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, false);
    if (threatIntelligenceProgram != null) {
      AttackStep.allAttackSteps.remove(threatIntelligenceProgram.disable);
    }
    Defense.allDefenses.remove(threatIntelligenceProgram);
    threatIntelligenceProgram = new ThreatIntelligenceProgram(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, false);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, false);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, false);
    if (vulnerabilityScanning != null) {
      AttackStep.allAttackSteps.remove(vulnerabilityScanning.disable);
    }
    Defense.allDefenses.remove(vulnerabilityScanning);
    vulnerabilityScanning = new VulnerabilityScanning(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
  }

  public Service(boolean isAuditEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    this("Anonymous", isAuditEnabled, isApplicationIsolationAndSandboxingEnabled, isPrivilegedAccountManagementEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isExploitProtectionEnabled, isNetworkSegmentationEnabled, isThreatIntelligenceProgramEnabled, isPasswordPoliciesEnabled, isUpdateSoftwareEnabled, isSoftwareConfigurationEnabled, isActiveDirectoryConfigurationEnabled, isVulnerabilityScanningEnabled, isMultiFactorAuthenticationEnabled);
  }

  public Service() {
    this("Anonymous");
  }

  public void addOs(OS os) {
    this.os = os;
    os.service.add(this);
  }

  public void addBrowser(Browser browser) {
    this.browser.add(browser);
    browser.service.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("os")) {
      return OS.class.getName();
    } else if (field.equals("browser")) {
      return Browser.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("os")) {
      if (os != null) {
        assets.add(os);
      }
    } else if (field.equals("browser")) {
      assets.addAll(browser);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    if (os != null) {
      assets.add(os);
    }
    assets.addAll(browser);
    return assets;
  }

  public class AttemptTrustedRelationship extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptTrustedRelationship;

    public AttemptTrustedRelationship(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptTrustedRelationship == null) {
        _cacheParentAttemptTrustedRelationship = new HashSet<>();
        if (Service.this instanceof CloudService) {
          _cacheParentAttemptTrustedRelationship.add(((asset.CloudService) Service.this).cloudAccounts);
        }
        if (os != null) {
          _cacheParentAttemptTrustedRelationship.add(os.compromisedDataOrSystem);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptTrustedRelationship) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptTrustedRelationship");
    }
  }

  public class TrustedRelationship extends AttackStepMax {
    private Set<AttackStep> _cacheParentTrustedRelationship;

    public TrustedRelationship(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTrustedRelationship == null) {
        _cacheParentTrustedRelationship = new HashSet<>();
        if (os != null) {
          _cacheParentTrustedRelationship.add(os.userAccountControl.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentTrustedRelationship) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.trustedRelationship");
    }
  }

  public class AttemptUseThirdpartySoftware extends AttackStepMin {
    private Set<AttackStep> _cacheParentAttemptUseThirdpartySoftware;

    public AttemptUseThirdpartySoftware(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptUseThirdpartySoftware == null) {
        _cacheParentAttemptUseThirdpartySoftware = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentAttemptUseThirdpartySoftware.add(_0.userRights);
          }
        }
        if (os != null) {
          for (AdminAccount _1 : os.adminAccount) {
            _cacheParentAttemptUseThirdpartySoftware.add(_1.adminRights);
          }
        }
        _cacheParentAttemptUseThirdpartySoftware.add(exploitationForPrivilegeEscalation);
      }
      for (AttackStep attackStep : _cacheParentAttemptUseThirdpartySoftware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptUseThirdpartySoftware");
    }
  }

  public class UseThirdpartySoftware extends AttackStepMax {
    private Set<AttackStep> _cacheParentUseThirdpartySoftware;

    public UseThirdpartySoftware(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUseThirdpartySoftware == null) {
        _cacheParentUseThirdpartySoftware = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentUseThirdpartySoftware.add(_0.userTraining.disable);
          }
        }
        if (os != null) {
          for (UserAccount _1 : os.userAccount) {
            _cacheParentUseThirdpartySoftware.add(_1.userAccountManagement.disable);
          }
        }
        if (os != null) {
          for (AdminAccount _2 : os.adminAccount) {
            _cacheParentUseThirdpartySoftware.add(_2.privilegedAccountManagement.disable);
          }
        }
        if (os != null) {
          _cacheParentUseThirdpartySoftware.add(os.remoteDataStorage.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentUseThirdpartySoftware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.useThirdpartySoftware");
    }
  }

  public class CollectVideo extends AttackStepMin {
    public CollectVideo(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.collectVideo");
    }
  }

  public class ApplicationAccessToken extends AttackStepMin {
    private Set<AttackStep> _cacheParentApplicationAccessToken;

    public ApplicationAccessToken(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationAccessToken == null) {
        _cacheParentApplicationAccessToken = new HashSet<>();
        if (os != null) {
          _cacheParentApplicationAccessToken.add(os.internalSpearphishing);
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentApplicationAccessToken.add(((asset.Windows) os).useAlternateAuthenticationMaterial);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentApplicationAccessToken) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.applicationAccessToken");
    }
  }

  public class AccessCloudBasedServiceResources extends AttackStepMin {
    public AccessCloudBasedServiceResources(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.accessCloudBasedServiceResources");
    }
  }

  public class Persistence extends AttackStepMin {
    public Persistence(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.persistence");
    }
  }

  public class SensitiveDataCollected extends AttackStepMin {
    private Set<AttackStep> _cacheParentSensitiveDataCollected;

    public SensitiveDataCollected(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSensitiveDataCollected == null) {
        _cacheParentSensitiveDataCollected = new HashSet<>();
        if (os != null) {
          for (Computer _0 : os.computer) {
            for (Router _1 : _0.router) {
              for (ExternalNetwork _2 : _1.externalNetwork) {
                _cacheParentSensitiveDataCollected.add(_2.dataFromCloudStorageObject);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentSensitiveDataCollected) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.sensitiveDataCollected");
    }
  }

  public class CloudServiceInformationCollected extends AttackStepMin {
    public CloudServiceInformationCollected(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.cloudServiceInformationCollected");
    }
  }

  public class CloudAccount extends AttackStepMin {
    private Set<AttackStep> _cacheParentCloudAccount;

    public CloudAccount(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudAccount == null) {
        _cacheParentCloudAccount = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentCloudAccount.add(_0.createAccount);
          }
        }
        if (os != null) {
          for (AdminAccount _1 : os.adminAccount) {
            _cacheParentCloudAccount.add(_1.privilegedAccountManagement.disable);
          }
        }
        _cacheParentCloudAccount.add(multiFactorAuthentication.disable);
        if (os != null) {
          _cacheParentCloudAccount.add(os.accountDiscovery);
        }
      }
      for (AttackStep attackStep : _cacheParentCloudAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.cloudAccount");
    }
  }

  public class CloudAccounts extends AttackStepMax {
    private Set<AttackStep> _cacheParentCloudAccounts;

    public CloudAccounts(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudAccounts == null) {
        _cacheParentCloudAccounts = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentCloudAccounts.add(_0.userRights);
          }
        }
        if (os != null) {
          _cacheParentCloudAccounts.add(os.validAccounts);
        }
      }
      for (AttackStep attackStep : _cacheParentCloudAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.cloudAccounts");
    }
  }

  public class CloudGroups extends AttackStepMax {
    private Set<AttackStep> _cacheParentCloudGroups;

    public CloudGroups(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudGroups == null) {
        _cacheParentCloudGroups = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentCloudGroups.add(_0.userRights);
          }
        }
        if (os != null) {
          _cacheParentCloudGroups.add(os.permissionGroupsDiscovery);
        }
      }
      for (AttackStep attackStep : _cacheParentCloudGroups) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.cloudGroups");
    }
  }

  public class CloudInstanceMetadataAPI extends AttackStepMax {
    private Set<AttackStep> _cacheParentCloudInstanceMetadataAPI;

    public CloudInstanceMetadataAPI(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudInstanceMetadataAPI == null) {
        _cacheParentCloudInstanceMetadataAPI = new HashSet<>();
        if (os != null) {
          _cacheParentCloudInstanceMetadataAPI.add(os.unsecuredCredentials);
        }
        if (os != null) {
          for (Computer _0 : os.computer) {
            for (Router _1 : _0.router) {
              if (_1.firewall != null) {
                _cacheParentCloudInstanceMetadataAPI.add(_1.firewall.filterNetworkTraffic.disable);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCloudInstanceMetadataAPI) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.cloudInstanceMetadataAPI");
    }
  }

  public class CloudServiceDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentCloudServiceDiscovery;

    public CloudServiceDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudServiceDiscovery == null) {
        _cacheParentCloudServiceDiscovery = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentCloudServiceDiscovery.add(_0.userRights);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCloudServiceDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.cloudServiceDiscovery");
    }
  }

  public class CloudServiceDashboard extends AttackStepMax {
    private Set<AttackStep> _cacheParentCloudServiceDashboard;

    public CloudServiceDashboard(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudServiceDashboard == null) {
        _cacheParentCloudServiceDashboard = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentCloudServiceDashboard.add(_0.userRights);
          }
        }
        if (os != null) {
          for (UserAccount _1 : os.userAccount) {
            _cacheParentCloudServiceDashboard.add(_1.userAccountManagement.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCloudServiceDashboard) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.cloudServiceDashboard");
    }
  }

  public class DisableOrModifyCloudFirewall extends AttackStepMax {
    private Set<AttackStep> _cacheParentDisableOrModifyCloudFirewall;

    public DisableOrModifyCloudFirewall(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDisableOrModifyCloudFirewall == null) {
        _cacheParentDisableOrModifyCloudFirewall = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentDisableOrModifyCloudFirewall.add(_0.userRights);
          }
        }
        if (os != null) {
          for (UserAccount _1 : os.userAccount) {
            _cacheParentDisableOrModifyCloudFirewall.add(_1.userAccountManagement.disable);
          }
        }
        if (os != null) {
          _cacheParentDisableOrModifyCloudFirewall.add(os.impareDefenses);
        }
      }
      for (AttackStep attackStep : _cacheParentDisableOrModifyCloudFirewall) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.disableOrModifyCloudFirewall");
    }
  }

  public class EmailAccount extends AttackStepMin {
    private Set<AttackStep> _cacheParentEmailAccount;

    public EmailAccount(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEmailAccount == null) {
        _cacheParentEmailAccount = new HashSet<>();
        if (os != null) {
          _cacheParentEmailAccount.add(os.accountDiscovery);
        }
      }
      for (AttackStep attackStep : _cacheParentEmailAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.emailAccount");
    }
  }

  public class EmailAddressCollected extends AttackStepMin {
    public EmailAddressCollected(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.emailAddressCollected");
    }
  }

  public class AdditionalAzureServicePrincipalCredentials extends AttackStepMax {
    private Set<AttackStep> _cacheParentAdditionalAzureServicePrincipalCredentials;

    public AdditionalAzureServicePrincipalCredentials(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAdditionalAzureServicePrincipalCredentials == null) {
        _cacheParentAdditionalAzureServicePrincipalCredentials = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentAdditionalAzureServicePrincipalCredentials.add(_0.adminRights);
          }
        }
        _cacheParentAdditionalAzureServicePrincipalCredentials.add(multiFactorAuthentication.disable);
        if (os != null) {
          _cacheParentAdditionalAzureServicePrincipalCredentials.add(os.accountManipulation);
        }
      }
      for (AttackStep attackStep : _cacheParentAdditionalAzureServicePrincipalCredentials) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.additionalAzureServicePrincipalCredentials");
    }
  }

  public class ExchangeEmailDelegatePermissions extends AttackStepMax {
    private Set<AttackStep> _cacheParentExchangeEmailDelegatePermissions;

    public ExchangeEmailDelegatePermissions(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExchangeEmailDelegatePermissions == null) {
        _cacheParentExchangeEmailDelegatePermissions = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentExchangeEmailDelegatePermissions.add(_0.adminRights);
          }
        }
        if (os != null) {
          _cacheParentExchangeEmailDelegatePermissions.add(os.accountManipulation);
        }
      }
      for (AttackStep attackStep : _cacheParentExchangeEmailDelegatePermissions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exchangeEmailDelegatePermissions");
    }
  }

  public class AddOffice365GlobalAdministratorRole extends AttackStepMax {
    private Set<AttackStep> _cacheParentAddOffice365GlobalAdministratorRole;

    public AddOffice365GlobalAdministratorRole(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAddOffice365GlobalAdministratorRole == null) {
        _cacheParentAddOffice365GlobalAdministratorRole = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentAddOffice365GlobalAdministratorRole.add(_0.adminRights);
          }
        }
        if (os != null) {
          _cacheParentAddOffice365GlobalAdministratorRole.add(os.accountManipulation);
        }
      }
      for (AttackStep attackStep : _cacheParentAddOffice365GlobalAdministratorRole) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.addOffice365GlobalAdministratorRole");
    }
  }

  public class ModifyCloudComputeInfrastructure extends AttackStepMin {
    private Set<AttackStep> _cacheParentModifyCloudComputeInfrastructure;

    public ModifyCloudComputeInfrastructure(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentModifyCloudComputeInfrastructure == null) {
        _cacheParentModifyCloudComputeInfrastructure = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentModifyCloudComputeInfrastructure.add(_0.userRights);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentModifyCloudComputeInfrastructure) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.modifyCloudComputeInfrastructure");
    }
  }

  public class CreateSnapshot extends AttackStepMax {
    private Set<AttackStep> _cacheParentCreateSnapshot;

    public CreateSnapshot(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCreateSnapshot == null) {
        _cacheParentCreateSnapshot = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentCreateSnapshot.add(_0.userAccountManagement.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCreateSnapshot) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.createSnapshot");
    }
  }

  public class CreateCloudInstance extends AttackStepMax {
    private Set<AttackStep> _cacheParentCreateCloudInstance;

    public CreateCloudInstance(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCreateCloudInstance == null) {
        _cacheParentCreateCloudInstance = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentCreateCloudInstance.add(_0.userAccountManagement.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCreateCloudInstance) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.createCloudInstance");
    }
  }

  public class DeleteCloudInstance extends AttackStepMax {
    private Set<AttackStep> _cacheParentDeleteCloudInstance;

    public DeleteCloudInstance(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDeleteCloudInstance == null) {
        _cacheParentDeleteCloudInstance = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentDeleteCloudInstance.add(_0.userAccountManagement.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentDeleteCloudInstance) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.deleteCloudInstance");
    }
  }

  public class RevertCloudInstance extends AttackStepMin {
    public RevertCloudInstance(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.revertCloudInstance");
    }
  }

  public class RemoteEmailCollection extends AttackStepMax {
    private Set<AttackStep> _cacheParentRemoteEmailCollection;

    public RemoteEmailCollection(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteEmailCollection == null) {
        _cacheParentRemoteEmailCollection = new HashSet<>();
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentRemoteEmailCollection.add(((asset.Windows) os).emailCollection);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteEmailCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.remoteEmailCollection");
    }
  }

  public class EmailForwardingRule extends AttackStepMax {
    private Set<AttackStep> _cacheParentEmailForwardingRule;

    public EmailForwardingRule(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEmailForwardingRule == null) {
        _cacheParentEmailForwardingRule = new HashSet<>();
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentEmailForwardingRule.add(((asset.Windows) os).emailCollection);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentEmailForwardingRule) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.emailForwardingRule");
    }
  }

  public class ApplicationExhaustionFlood extends AttackStepMin {
    private Set<AttackStep> _cacheParentApplicationExhaustionFlood;

    public ApplicationExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationExhaustionFlood == null) {
        _cacheParentApplicationExhaustionFlood = new HashSet<>();
        if (os != null) {
          _cacheParentApplicationExhaustionFlood.add(os.endpointDenialOfService);
        }
      }
      for (AttackStep attackStep : _cacheParentApplicationExhaustionFlood) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.applicationExhaustionFlood");
    }
  }

  public class ServiceExhaustionFlood extends AttackStepMin {
    private Set<AttackStep> _cacheParentServiceExhaustionFlood;

    public ServiceExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceExhaustionFlood == null) {
        _cacheParentServiceExhaustionFlood = new HashSet<>();
        if (os != null) {
          _cacheParentServiceExhaustionFlood.add(os.endpointDenialOfService);
        }
        if (os != null) {
          _cacheParentServiceExhaustionFlood.add(os.directNetworkFlood);
        }
        if (os != null) {
          _cacheParentServiceExhaustionFlood.add(os.reflectionAmplification);
        }
      }
      for (AttackStep attackStep : _cacheParentServiceExhaustionFlood) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.serviceExhaustionFlood");
    }
  }

  public class ApplicationOrSystemExploitation extends AttackStepMin {
    private Set<AttackStep> _cacheParentApplicationOrSystemExploitation;

    public ApplicationOrSystemExploitation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationOrSystemExploitation == null) {
        _cacheParentApplicationOrSystemExploitation = new HashSet<>();
        if (os != null) {
          _cacheParentApplicationOrSystemExploitation.add(os.endpointDenialOfService);
        }
      }
      for (AttackStep attackStep : _cacheParentApplicationOrSystemExploitation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.applicationOrSystemExploitation");
    }
  }

  public class OfficeTemplateMacros extends AttackStepMax {
    private Set<AttackStep> _cacheParentOfficeTemplateMacros;

    public OfficeTemplateMacros(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOfficeTemplateMacros == null) {
        _cacheParentOfficeTemplateMacros = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentOfficeTemplateMacros.add(_0.userRights);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentOfficeTemplateMacros.add(((asset.Windows) os).officeApplicationStartup);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentOfficeTemplateMacros) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.officeTemplateMacros");
    }
  }

  public class OfficeTest extends AttackStepMax {
    private Set<AttackStep> _cacheParentOfficeTest;

    public OfficeTest(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOfficeTest == null) {
        _cacheParentOfficeTest = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentOfficeTest.add(_0.userRights);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentOfficeTest.add(((asset.Windows) os).officeApplicationStartup);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentOfficeTest) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.officeTest");
    }
  }

  public class OutlookForms extends AttackStepMax {
    private Set<AttackStep> _cacheParentOutlookForms;

    public OutlookForms(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOutlookForms == null) {
        _cacheParentOutlookForms = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentOutlookForms.add(_0.userRights);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentOutlookForms.add(((asset.Windows) os).officeApplicationStartup);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentOutlookForms) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.outlookForms");
    }
  }

  public class OutlookHomePage extends AttackStepMax {
    private Set<AttackStep> _cacheParentOutlookHomePage;

    public OutlookHomePage(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOutlookHomePage == null) {
        _cacheParentOutlookHomePage = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentOutlookHomePage.add(_0.userRights);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentOutlookHomePage.add(((asset.Windows) os).officeApplicationStartup);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentOutlookHomePage) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.outlookHomePage");
    }
  }

  public class OutlookRules extends AttackStepMax {
    private Set<AttackStep> _cacheParentOutlookRules;

    public OutlookRules(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOutlookRules == null) {
        _cacheParentOutlookRules = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentOutlookRules.add(_0.userRights);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentOutlookRules.add(((asset.Windows) os).officeApplicationStartup);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentOutlookRules) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.outlookRules");
    }
  }

  public class AddIns extends AttackStepMin {
    private Set<AttackStep> _cacheParentAddIns;

    public AddIns(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAddIns == null) {
        _cacheParentAddIns = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentAddIns.add(_0.userRights);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAddIns.add(((asset.Windows) os).officeApplicationStartup);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAddIns) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.addIns");
    }
  }

  public class StealApplicationAccessToken extends AttackStepMax {
    private Set<AttackStep> _cacheParentStealApplicationAccessToken;

    public StealApplicationAccessToken(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentStealApplicationAccessToken == null) {
        _cacheParentStealApplicationAccessToken = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentStealApplicationAccessToken.add(_0.userRights);
          }
        }
        if (os != null) {
          for (UserAccount _1 : os.userAccount) {
            _cacheParentStealApplicationAccessToken.add(_1.userTraining.disable);
          }
        }
        if (os != null) {
          for (UserAccount _2 : os.userAccount) {
            _cacheParentStealApplicationAccessToken.add(_2.userAccountManagement.disable);
          }
        }
        for (Browser _3 : browser) {
          _cacheParentStealApplicationAccessToken.add(_3.malvertising);
        }
        for (Browser _4 : browser) {
          _cacheParentStealApplicationAccessToken.add(_4.crossSiteScripting);
        }
      }
      for (AttackStep attackStep : _cacheParentStealApplicationAccessToken) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.stealApplicationAccessToken");
    }
  }

  public class ApplicationDeploymentSoftware extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenApplicationDeploymentSoftware;

    private Set<AttackStep> _cacheParentApplicationDeploymentSoftware;

    public ApplicationDeploymentSoftware(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenApplicationDeploymentSoftware == null) {
        _cacheChildrenApplicationDeploymentSoftware = new HashSet<>();
        if (os != null) {
          _cacheChildrenApplicationDeploymentSoftware.add(os.executeCode);
        }
      }
      for (AttackStep attackStep : _cacheChildrenApplicationDeploymentSoftware) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationDeploymentSoftware == null) {
        _cacheParentApplicationDeploymentSoftware = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentApplicationDeploymentSoftware.add(_0.adminRights);
          }
        }
        if (os != null) {
          for (AdminAccount _1 : os.adminAccount) {
            _cacheParentApplicationDeploymentSoftware.add(_1.privilegedAccountManagement.disable);
          }
        }
        _cacheParentApplicationDeploymentSoftware.add(updateSoftware.disable);
        _cacheParentApplicationDeploymentSoftware.add(multiFactorAuthentication.disable);
        if (os != null) {
          _cacheParentApplicationDeploymentSoftware.add(os.codeSigning.disable);
        }
        if (os != null) {
          for (Computer _2 : os.computer) {
            for (Router _3 : _2.router) {
              for (InternalNetwork _4 : _3.internalNetwork) {
                _cacheParentApplicationDeploymentSoftware.add(_4.networkSegmentation.disable);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentApplicationDeploymentSoftware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.applicationDeploymentSoftware");
    }
  }

  public class ApplicationHighVulnerability extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenApplicationHighVulnerability;

    public ApplicationHighVulnerability(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenApplicationHighVulnerability == null) {
        _cacheChildrenApplicationHighVulnerability = new HashSet<>();
        _cacheChildrenApplicationHighVulnerability.add(exploitHighVulnerabilityPublicFacingApplication);
      }
      for (AttackStep attackStep : _cacheChildrenApplicationHighVulnerability) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.applicationHighVulnerability");
    }
  }

  public class ApplicationMediumVulnerability extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenApplicationMediumVulnerability;

    public ApplicationMediumVulnerability(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenApplicationMediumVulnerability == null) {
        _cacheChildrenApplicationMediumVulnerability = new HashSet<>();
        _cacheChildrenApplicationMediumVulnerability.add(exploitMediumVulnerabilityPublicFacingApplication);
      }
      for (AttackStep attackStep : _cacheChildrenApplicationMediumVulnerability) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.applicationMediumVulnerability");
    }
  }

  public class ApplicationLowVulnerability extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenApplicationLowVulnerability;

    public ApplicationLowVulnerability(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenApplicationLowVulnerability == null) {
        _cacheChildrenApplicationLowVulnerability = new HashSet<>();
        _cacheChildrenApplicationLowVulnerability.add(exploitLowVulnerabilityPublicFacingApplication);
      }
      for (AttackStep attackStep : _cacheChildrenApplicationLowVulnerability) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.applicationLowVulnerability");
    }
  }

  public class ExploitHighVulnerabilityPublicFacingApplication extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitHighVulnerabilityPublicFacingApplication;

    private Set<AttackStep> _cacheParentExploitHighVulnerabilityPublicFacingApplication;

    public ExploitHighVulnerabilityPublicFacingApplication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitHighVulnerabilityPublicFacingApplication == null) {
        _cacheChildrenExploitHighVulnerabilityPublicFacingApplication = new HashSet<>();
        _cacheChildrenExploitHighVulnerabilityPublicFacingApplication.add(attemptExploitationForDefenseEvasion);
        if (os != null) {
          _cacheChildrenExploitHighVulnerabilityPublicFacingApplication.add(os.systemAccess);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExploitHighVulnerabilityPublicFacingApplication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitHighVulnerabilityPublicFacingApplication == null) {
        _cacheParentExploitHighVulnerabilityPublicFacingApplication = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentExploitHighVulnerabilityPublicFacingApplication.add(_0.privilegedAccountManagement.disable);
          }
        }
        _cacheParentExploitHighVulnerabilityPublicFacingApplication.add(applicationHighVulnerability);
        _cacheParentExploitHighVulnerabilityPublicFacingApplication.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitHighVulnerabilityPublicFacingApplication.add(exploitProtection.disable);
        _cacheParentExploitHighVulnerabilityPublicFacingApplication.add(networkSegmentation.disable);
        _cacheParentExploitHighVulnerabilityPublicFacingApplication.add(updateSoftware.disable);
        _cacheParentExploitHighVulnerabilityPublicFacingApplication.add(vulnerabilityScanning.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitHighVulnerabilityPublicFacingApplication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitHighVulnerabilityPublicFacingApplication");
    }
  }

  public class ExploitMediumVulnerabilityPublicFacingApplication extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitMediumVulnerabilityPublicFacingApplication;

    private Set<AttackStep> _cacheParentExploitMediumVulnerabilityPublicFacingApplication;

    public ExploitMediumVulnerabilityPublicFacingApplication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitMediumVulnerabilityPublicFacingApplication == null) {
        _cacheChildrenExploitMediumVulnerabilityPublicFacingApplication = new HashSet<>();
        _cacheChildrenExploitMediumVulnerabilityPublicFacingApplication.add(attemptExploitationForDefenseEvasion);
        if (os != null) {
          _cacheChildrenExploitMediumVulnerabilityPublicFacingApplication.add(os.systemAccess);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExploitMediumVulnerabilityPublicFacingApplication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitMediumVulnerabilityPublicFacingApplication == null) {
        _cacheParentExploitMediumVulnerabilityPublicFacingApplication = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentExploitMediumVulnerabilityPublicFacingApplication.add(_0.privilegedAccountManagement.disable);
          }
        }
        _cacheParentExploitMediumVulnerabilityPublicFacingApplication.add(applicationMediumVulnerability);
        _cacheParentExploitMediumVulnerabilityPublicFacingApplication.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitMediumVulnerabilityPublicFacingApplication.add(exploitProtection.disable);
        _cacheParentExploitMediumVulnerabilityPublicFacingApplication.add(networkSegmentation.disable);
        _cacheParentExploitMediumVulnerabilityPublicFacingApplication.add(updateSoftware.disable);
        _cacheParentExploitMediumVulnerabilityPublicFacingApplication.add(vulnerabilityScanning.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitMediumVulnerabilityPublicFacingApplication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitMediumVulnerabilityPublicFacingApplication");
    }
  }

  public class ExploitLowVulnerabilityPublicFacingApplication extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitLowVulnerabilityPublicFacingApplication;

    private Set<AttackStep> _cacheParentExploitLowVulnerabilityPublicFacingApplication;

    public ExploitLowVulnerabilityPublicFacingApplication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitLowVulnerabilityPublicFacingApplication == null) {
        _cacheChildrenExploitLowVulnerabilityPublicFacingApplication = new HashSet<>();
        _cacheChildrenExploitLowVulnerabilityPublicFacingApplication.add(attemptExploitationForDefenseEvasion);
        if (os != null) {
          _cacheChildrenExploitLowVulnerabilityPublicFacingApplication.add(os.systemAccess);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExploitLowVulnerabilityPublicFacingApplication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitLowVulnerabilityPublicFacingApplication == null) {
        _cacheParentExploitLowVulnerabilityPublicFacingApplication = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheParentExploitLowVulnerabilityPublicFacingApplication.add(_0.privilegedAccountManagement.disable);
          }
        }
        _cacheParentExploitLowVulnerabilityPublicFacingApplication.add(applicationLowVulnerability);
        _cacheParentExploitLowVulnerabilityPublicFacingApplication.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitLowVulnerabilityPublicFacingApplication.add(exploitProtection.disable);
        _cacheParentExploitLowVulnerabilityPublicFacingApplication.add(networkSegmentation.disable);
        _cacheParentExploitLowVulnerabilityPublicFacingApplication.add(updateSoftware.disable);
        _cacheParentExploitLowVulnerabilityPublicFacingApplication.add(vulnerabilityScanning.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitLowVulnerabilityPublicFacingApplication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitLowVulnerabilityPublicFacingApplication");
    }
  }

  public class BlockUserAccess extends AttackStepMin {
    private Set<AttackStep> _cacheParentBlockUserAccess;

    public BlockUserAccess(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentBlockUserAccess == null) {
        _cacheParentBlockUserAccess = new HashSet<>();
        if (Service.this instanceof CloudService) {
          _cacheParentBlockUserAccess.add(((asset.CloudService) Service.this).applicationExhaustionFlood);
        }
        if (os != null) {
          _cacheParentBlockUserAccess.add(os.applicationExhaustionFlood);
        }
      }
      for (AttackStep attackStep : _cacheParentBlockUserAccess) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.blockUserAccess");
    }
  }

  public class ImplantContainerImage extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenImplantContainerImage;

    private Set<AttackStep> _cacheParentImplantContainerImage;

    public ImplantContainerImage(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenImplantContainerImage == null) {
        _cacheChildrenImplantContainerImage = new HashSet<>();
        if (os != null) {
          _cacheChildrenImplantContainerImage.add(os.persistence);
        }
      }
      for (AttackStep attackStep : _cacheChildrenImplantContainerImage) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentImplantContainerImage == null) {
        _cacheParentImplantContainerImage = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentImplantContainerImage.add(_0.userRights);
          }
        }
        _cacheParentImplantContainerImage.add(audit.disable);
        _cacheParentImplantContainerImage.add(privilegedAccountManagement.disable);
        if (os != null) {
          _cacheParentImplantContainerImage.add(os.codeSigning.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentImplantContainerImage) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.implantContainerImage");
    }
  }

  public class ServiceInformation extends AttackStepMin {
    private Set<AttackStep> _cacheParentServiceInformation;

    public ServiceInformation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentServiceInformation == null) {
        _cacheParentServiceInformation = new HashSet<>();
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentServiceInformation.add(((asset.Windows) os).systemServiceDiscovery);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentServiceInformation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.serviceInformation");
    }
  }

  public class RemoteServices extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenRemoteServices;

    private Set<AttackStep> _cacheParentRemoteServices;

    public RemoteServices(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRemoteServices == null) {
        _cacheChildrenRemoteServices = new HashSet<>();
        if (os != null) {
          _cacheChildrenRemoteServices.add(os.vNC);
        }
        if (os != null) {
          _cacheChildrenRemoteServices.add(os.attemptRemoteDesktopProtocol);
        }
        if (os != null) {
          _cacheChildrenRemoteServices.add(os.attemptWindowsAdminShares);
        }
        if (os != null) {
          _cacheChildrenRemoteServices.add(os.attemptDistributedComponentObjectModel);
        }
        if (os != null) {
          _cacheChildrenRemoteServices.add(os.attemptWindowsRemoteManagement);
        }
        if (os != null) {
          _cacheChildrenRemoteServices.add(os.sSH);
        }
      }
      for (AttackStep attackStep : _cacheChildrenRemoteServices) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteServices == null) {
        _cacheParentRemoteServices = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentRemoteServices.add(_0.userCredentials);
          }
        }
        if (os != null) {
          for (UserAccount _1 : os.userAccount) {
            _cacheParentRemoteServices.add(_1.userAccountManagement.disable);
          }
        }
        if (os != null) {
          for (AdminAccount _2 : os.adminAccount) {
            _cacheParentRemoteServices.add(_2.adminCredentials);
          }
        }
        _cacheParentRemoteServices.add(externalRemoteServices);
        _cacheParentRemoteServices.add(multiFactorAuthentication.disable);
        if (Service.this instanceof CloudService) {
          _cacheParentRemoteServices.add(((asset.CloudService) Service.this).cloudAccounts);
        }
        if (os != null) {
          _cacheParentRemoteServices.add(os.privateKeys);
        }
        if (os != null) {
          _cacheParentRemoteServices.add(os.privateKeysWithPassphrase);
        }
        if (os != null) {
          _cacheParentRemoteServices.add(os.defaultAccounts);
        }
        if (os != null) {
          _cacheParentRemoteServices.add(os.domainAccounts);
        }
        if (os != null) {
          _cacheParentRemoteServices.add(os.localAccounts);
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentRemoteServices.add(((asset.Windows) os).sIDHistoryInjection);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteServices) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.remoteServices");
    }
  }

  public class RemoteServiceSessionHijacking extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenRemoteServiceSessionHijacking;

    public RemoteServiceSessionHijacking(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRemoteServiceSessionHijacking == null) {
        _cacheChildrenRemoteServiceSessionHijacking = new HashSet<>();
        if (os != null) {
          _cacheChildrenRemoteServiceSessionHijacking.add(os.sSHHijacking);
        }
        if (os != null) {
          _cacheChildrenRemoteServiceSessionHijacking.add(os.rDPHijacking);
        }
      }
      for (AttackStep attackStep : _cacheChildrenRemoteServiceSessionHijacking) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.remoteServiceSessionHijacking");
    }
  }

  public class TransmittedDataManipulation extends AttackStepMax {
    private Set<AttackStep> _cacheParentTransmittedDataManipulation;

    public TransmittedDataManipulation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTransmittedDataManipulation == null) {
        _cacheParentTransmittedDataManipulation = new HashSet<>();
        _cacheParentTransmittedDataManipulation.add(encryptSensitiveInformation.disable);
        if (os != null) {
          _cacheParentTransmittedDataManipulation.add(os.dataManipulation);
        }
      }
      for (AttackStep attackStep : _cacheParentTransmittedDataManipulation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.transmittedDataManipulation");
    }
  }

  public class InformationRepositories extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenInformationRepositories;

    private Set<AttackStep> _cacheParentInformationRepositories;

    public InformationRepositories(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInformationRepositories == null) {
        _cacheChildrenInformationRepositories = new HashSet<>();
        if (os != null) {
          _cacheChildrenInformationRepositories.add(os.dataCollected);
        }
        if (os != null) {
          _cacheChildrenInformationRepositories.add(os.sensitiveDataCollected);
        }
      }
      for (AttackStep attackStep : _cacheChildrenInformationRepositories) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInformationRepositories == null) {
        _cacheParentInformationRepositories = new HashSet<>();
        if (os != null) {
          _cacheParentInformationRepositories.add(os.confluence);
        }
        if (os != null) {
          _cacheParentInformationRepositories.add(os.sharepoint);
        }
      }
      for (AttackStep attackStep : _cacheParentInformationRepositories) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.informationRepositories");
    }
  }

  public class RemoteAccessSoftware extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenRemoteAccessSoftware;

    private Set<AttackStep> _cacheParentRemoteAccessSoftware;

    public RemoteAccessSoftware(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenRemoteAccessSoftware == null) {
        _cacheChildrenRemoteAccessSoftware = new HashSet<>();
        if (os != null) {
          for (Computer _0 : os.computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenRemoteAccessSoftware.add(_2.c2Connexion);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenRemoteAccessSoftware) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteAccessSoftware == null) {
        _cacheParentRemoteAccessSoftware = new HashSet<>();
        if (os != null) {
          for (UserAccount _3 : os.userAccount) {
            _cacheParentRemoteAccessSoftware.add(_3.userRights);
          }
        }
        _cacheParentRemoteAccessSoftware.add(executionPrevention.disable);
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentRemoteAccessSoftware.add(((asset.Windows) os).registryRunKeysOrStartupFolder);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentRemoteAccessSoftware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.remoteAccessSoftware");
    }
  }

  public class AttemptSpearphishingViaService extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptSpearphishingViaService;

    private Set<AttackStep> _cacheParentAttemptSpearphishingViaService;

    public AttemptSpearphishingViaService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptSpearphishingViaService == null) {
        _cacheChildrenAttemptSpearphishingViaService = new HashSet<>();
        _cacheChildrenAttemptSpearphishingViaService.add(spearphishingViaService);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptSpearphishingViaService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptSpearphishingViaService == null) {
        _cacheParentAttemptSpearphishingViaService = new HashSet<>();
        for (Browser _0 : browser) {
          _cacheParentAttemptSpearphishingViaService.add(_0.phishing);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptSpearphishingViaService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptSpearphishingViaService");
    }
  }

  public class SpearphishingViaService extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenSpearphishingViaService;

    private Set<AttackStep> _cacheParentSpearphishingViaService;

    public SpearphishingViaService(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSpearphishingViaService == null) {
        _cacheChildrenSpearphishingViaService = new HashSet<>();
        _cacheChildrenSpearphishingViaService.add(spearphishingViaPersonalEmail);
        _cacheChildrenSpearphishingViaService.add(spearphishingViaSocialMedia);
      }
      for (AttackStep attackStep : _cacheChildrenSpearphishingViaService) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSpearphishingViaService == null) {
        _cacheParentSpearphishingViaService = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentSpearphishingViaService.add(_0.userTraining.disable);
          }
        }
        _cacheParentSpearphishingViaService.add(attemptSpearphishingViaService);
        for (Browser _1 : browser) {
          _cacheParentSpearphishingViaService.add(_1.restrictWebBasedContent.disable);
        }
        if (os != null) {
          _cacheParentSpearphishingViaService.add(os.antivirus.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentSpearphishingViaService) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.spearphishingViaService");
    }
  }

  public class SpearphishingViaPersonalEmail extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSpearphishingViaPersonalEmail;

    private Set<AttackStep> _cacheParentSpearphishingViaPersonalEmail;

    public SpearphishingViaPersonalEmail(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSpearphishingViaPersonalEmail == null) {
        _cacheChildrenSpearphishingViaPersonalEmail = new HashSet<>();
        for (Browser _0 : browser) {
          _cacheChildrenSpearphishingViaPersonalEmail.add(_0.attemptSpearphishingAttachment);
        }
        for (Browser _1 : browser) {
          _cacheChildrenSpearphishingViaPersonalEmail.add(_1.attemptSpearphishingLink);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSpearphishingViaPersonalEmail) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSpearphishingViaPersonalEmail == null) {
        _cacheParentSpearphishingViaPersonalEmail = new HashSet<>();
        _cacheParentSpearphishingViaPersonalEmail.add(spearphishingViaService);
      }
      for (AttackStep attackStep : _cacheParentSpearphishingViaPersonalEmail) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.spearphishingViaPersonalEmail");
    }
  }

  public class SpearphishingViaSocialMedia extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSpearphishingViaSocialMedia;

    private Set<AttackStep> _cacheParentSpearphishingViaSocialMedia;

    public SpearphishingViaSocialMedia(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSpearphishingViaSocialMedia == null) {
        _cacheChildrenSpearphishingViaSocialMedia = new HashSet<>();
        for (Browser _0 : browser) {
          _cacheChildrenSpearphishingViaSocialMedia.add(_0.attemptSpearphishingAttachment);
        }
        for (Browser _1 : browser) {
          _cacheChildrenSpearphishingViaSocialMedia.add(_1.attemptSpearphishingLink);
        }
        if (os != null) {
          _cacheChildrenSpearphishingViaSocialMedia.add(os.bruteForce);
        }
      }
      for (AttackStep attackStep : _cacheChildrenSpearphishingViaSocialMedia) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSpearphishingViaSocialMedia == null) {
        _cacheParentSpearphishingViaSocialMedia = new HashSet<>();
        _cacheParentSpearphishingViaSocialMedia.add(spearphishingViaService);
      }
      for (AttackStep attackStep : _cacheParentSpearphishingViaSocialMedia) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.spearphishingViaSocialMedia");
    }
  }

  public class SupplyChainCompromise extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenSupplyChainCompromise;

    public SupplyChainCompromise(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenSupplyChainCompromise == null) {
        _cacheChildrenSupplyChainCompromise = new HashSet<>();
        _cacheChildrenSupplyChainCompromise.add(compromiseSoftwareDependenciesAndDevelopmentTools);
        _cacheChildrenSupplyChainCompromise.add(compromiseSoftwareSupplyChain);
        _cacheChildrenSupplyChainCompromise.add(compromiseHardwareSupplyChain);
      }
      for (AttackStep attackStep : _cacheChildrenSupplyChainCompromise) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.supplyChainCompromise");
    }
  }

  public class CompromiseSoftwareDependenciesAndDevelopmentTools extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCompromiseSoftwareDependenciesAndDevelopmentTools;

    private Set<AttackStep> _cacheParentCompromiseSoftwareDependenciesAndDevelopmentTools;

    public CompromiseSoftwareDependenciesAndDevelopmentTools(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCompromiseSoftwareDependenciesAndDevelopmentTools == null) {
        _cacheChildrenCompromiseSoftwareDependenciesAndDevelopmentTools = new HashSet<>();
        if (os != null) {
          _cacheChildrenCompromiseSoftwareDependenciesAndDevelopmentTools.add(os.compromisedDataOrSystem);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCompromiseSoftwareDependenciesAndDevelopmentTools) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCompromiseSoftwareDependenciesAndDevelopmentTools == null) {
        _cacheParentCompromiseSoftwareDependenciesAndDevelopmentTools = new HashSet<>();
        _cacheParentCompromiseSoftwareDependenciesAndDevelopmentTools.add(supplyChainCompromise);
        _cacheParentCompromiseSoftwareDependenciesAndDevelopmentTools.add(updateSoftware.disable);
        _cacheParentCompromiseSoftwareDependenciesAndDevelopmentTools.add(vulnerabilityScanning.disable);
      }
      for (AttackStep attackStep : _cacheParentCompromiseSoftwareDependenciesAndDevelopmentTools) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.compromiseSoftwareDependenciesAndDevelopmentTools");
    }
  }

  public class CompromiseSoftwareSupplyChain extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCompromiseSoftwareSupplyChain;

    private Set<AttackStep> _cacheParentCompromiseSoftwareSupplyChain;

    public CompromiseSoftwareSupplyChain(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCompromiseSoftwareSupplyChain == null) {
        _cacheChildrenCompromiseSoftwareSupplyChain = new HashSet<>();
        if (os != null) {
          _cacheChildrenCompromiseSoftwareSupplyChain.add(os.compromisedDataOrSystem);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCompromiseSoftwareSupplyChain) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCompromiseSoftwareSupplyChain == null) {
        _cacheParentCompromiseSoftwareSupplyChain = new HashSet<>();
        _cacheParentCompromiseSoftwareSupplyChain.add(supplyChainCompromise);
        _cacheParentCompromiseSoftwareSupplyChain.add(updateSoftware.disable);
        _cacheParentCompromiseSoftwareSupplyChain.add(vulnerabilityScanning.disable);
      }
      for (AttackStep attackStep : _cacheParentCompromiseSoftwareSupplyChain) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.compromiseSoftwareSupplyChain");
    }
  }

  public class CompromiseHardwareSupplyChain extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCompromiseHardwareSupplyChain;

    private Set<AttackStep> _cacheParentCompromiseHardwareSupplyChain;

    public CompromiseHardwareSupplyChain(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCompromiseHardwareSupplyChain == null) {
        _cacheChildrenCompromiseHardwareSupplyChain = new HashSet<>();
        if (os != null) {
          _cacheChildrenCompromiseHardwareSupplyChain.add(os.compromisedDataOrSystem);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCompromiseHardwareSupplyChain) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCompromiseHardwareSupplyChain == null) {
        _cacheParentCompromiseHardwareSupplyChain = new HashSet<>();
        _cacheParentCompromiseHardwareSupplyChain.add(supplyChainCompromise);
        if (os != null) {
          _cacheParentCompromiseHardwareSupplyChain.add(os.bootIntegrity.disable);
        }
      }
      for (AttackStep attackStep : _cacheParentCompromiseHardwareSupplyChain) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.compromiseHardwareSupplyChain");
    }
  }

  public class AttemptExploitationForClientExecution extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExploitationForClientExecution;

    private Set<AttackStep> _cacheParentAttemptExploitationForClientExecution;

    public AttemptExploitationForClientExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExploitationForClientExecution == null) {
        _cacheChildrenAttemptExploitationForClientExecution = new HashSet<>();
        _cacheChildrenAttemptExploitationForClientExecution.add(exploitationForClientExecution);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExploitationForClientExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExploitationForClientExecution == null) {
        _cacheParentAttemptExploitationForClientExecution = new HashSet<>();
        if (os != null) {
          for (Computer _0 : os.computer) {
            for (User _1 : _0.user) {
              _cacheParentAttemptExploitationForClientExecution.add(_1.maliciousLink);
            }
          }
        }
        for (Browser _2 : browser) {
          _cacheParentAttemptExploitationForClientExecution.add(_2.driveByCompromise);
        }
        if (os != null) {
          _cacheParentAttemptExploitationForClientExecution.add(os.internalSpearphishing);
        }
        if (os != null) {
          _cacheParentAttemptExploitationForClientExecution.add(os.antivirusCheck);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExploitationForClientExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptExploitationForClientExecution");
    }
  }

  public class ExploitationForClientExecution extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitationForClientExecution;

    private Set<AttackStep> _cacheParentExploitationForClientExecution;

    public ExploitationForClientExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitationForClientExecution == null) {
        _cacheChildrenExploitationForClientExecution = new HashSet<>();
        if (os != null) {
          for (Computer _0 : os.computer) {
            for (User _1 : _0.user) {
              _cacheChildrenExploitationForClientExecution.add(_1.attemptUserExecution);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExploitationForClientExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitationForClientExecution == null) {
        _cacheParentExploitationForClientExecution = new HashSet<>();
        _cacheParentExploitationForClientExecution.add(attemptExploitationForClientExecution);
        _cacheParentExploitationForClientExecution.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitationForClientExecution.add(exploitProtection.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitationForClientExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitationForClientExecution");
    }
  }

  public class AttemptExploitationForCredentialAccess extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExploitationForCredentialAccess;

    private Set<AttackStep> _cacheParentAttemptExploitationForCredentialAccess;

    public AttemptExploitationForCredentialAccess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExploitationForCredentialAccess == null) {
        _cacheChildrenAttemptExploitationForCredentialAccess = new HashSet<>();
        _cacheChildrenAttemptExploitationForCredentialAccess.add(exploitationForCredentialAccess);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExploitationForCredentialAccess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExploitationForCredentialAccess == null) {
        _cacheParentAttemptExploitationForCredentialAccess = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentAttemptExploitationForCredentialAccess.add(_0.userRights);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExploitationForCredentialAccess) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptExploitationForCredentialAccess");
    }
  }

  public class ExploitationForCredentialAccess extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitationForCredentialAccess;

    private Set<AttackStep> _cacheParentExploitationForCredentialAccess;

    public ExploitationForCredentialAccess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitationForCredentialAccess == null) {
        _cacheChildrenExploitationForCredentialAccess = new HashSet<>();
        _cacheChildrenExploitationForCredentialAccess.add(exploitationOfSQLInjection);
        _cacheChildrenExploitationForCredentialAccess.add(exploitationOfNTLMAuthentication);
      }
      for (AttackStep attackStep : _cacheChildrenExploitationForCredentialAccess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitationForCredentialAccess == null) {
        _cacheParentExploitationForCredentialAccess = new HashSet<>();
        _cacheParentExploitationForCredentialAccess.add(attemptExploitationForCredentialAccess);
        _cacheParentExploitationForCredentialAccess.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitationForCredentialAccess.add(exploitProtection.disable);
        _cacheParentExploitationForCredentialAccess.add(threatIntelligenceProgram.disable);
        _cacheParentExploitationForCredentialAccess.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitationForCredentialAccess) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitationForCredentialAccess");
    }
  }

  public class ExploitationOfSQLInjection extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExploitationOfSQLInjection;

    private Set<AttackStep> _cacheParentExploitationOfSQLInjection;

    public ExploitationOfSQLInjection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitationOfSQLInjection == null) {
        _cacheChildrenExploitationOfSQLInjection = new HashSet<>();
        if (os != null) {
          _cacheChildrenExploitationOfSQLInjection.add(os.executeCode);
        }
        _cacheChildrenExploitationOfSQLInjection.add(attemptExploitationForPrivilegeEscalation);
      }
      for (AttackStep attackStep : _cacheChildrenExploitationOfSQLInjection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitationOfSQLInjection == null) {
        _cacheParentExploitationOfSQLInjection = new HashSet<>();
        _cacheParentExploitationOfSQLInjection.add(exploitationForCredentialAccess);
      }
      for (AttackStep attackStep : _cacheParentExploitationOfSQLInjection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitationOfSQLInjection");
    }
  }

  public class ExploitationOfNTLMAuthentication extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExploitationOfNTLMAuthentication;

    private Set<AttackStep> _cacheParentExploitationOfNTLMAuthentication;

    public ExploitationOfNTLMAuthentication(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitationOfNTLMAuthentication == null) {
        _cacheChildrenExploitationOfNTLMAuthentication = new HashSet<>();
        if (os != null) {
          _cacheChildrenExploitationOfNTLMAuthentication.add(os.executeCode);
        }
        _cacheChildrenExploitationOfNTLMAuthentication.add(attemptExploitationForPrivilegeEscalation);
      }
      for (AttackStep attackStep : _cacheChildrenExploitationOfNTLMAuthentication) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitationOfNTLMAuthentication == null) {
        _cacheParentExploitationOfNTLMAuthentication = new HashSet<>();
        _cacheParentExploitationOfNTLMAuthentication.add(exploitationForCredentialAccess);
      }
      for (AttackStep attackStep : _cacheParentExploitationOfNTLMAuthentication) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitationOfNTLMAuthentication");
    }
  }

  public class AttemptExploitationForDefenseEvasion extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExploitationForDefenseEvasion;

    private Set<AttackStep> _cacheParentAttemptExploitationForDefenseEvasion;

    public AttemptExploitationForDefenseEvasion(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExploitationForDefenseEvasion == null) {
        _cacheChildrenAttemptExploitationForDefenseEvasion = new HashSet<>();
        _cacheChildrenAttemptExploitationForDefenseEvasion.add(exploitationForDefenseEvasion);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExploitationForDefenseEvasion) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExploitationForDefenseEvasion == null) {
        _cacheParentAttemptExploitationForDefenseEvasion = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentAttemptExploitationForDefenseEvasion.add(_0.userRights);
          }
        }
        _cacheParentAttemptExploitationForDefenseEvasion.add(exploitHighVulnerabilityPublicFacingApplication);
        _cacheParentAttemptExploitationForDefenseEvasion.add(exploitMediumVulnerabilityPublicFacingApplication);
        _cacheParentAttemptExploitationForDefenseEvasion.add(exploitLowVulnerabilityPublicFacingApplication);
        if (os != null) {
          _cacheParentAttemptExploitationForDefenseEvasion.add(os.securitySoftwareDiscovery);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExploitationForDefenseEvasion) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptExploitationForDefenseEvasion");
    }
  }

  public class ExploitationForDefenseEvasion extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitationForDefenseEvasion;

    private Set<AttackStep> _cacheParentExploitationForDefenseEvasion;

    public ExploitationForDefenseEvasion(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitationForDefenseEvasion == null) {
        _cacheChildrenExploitationForDefenseEvasion = new HashSet<>();
        if (os != null) {
          _cacheChildrenExploitationForDefenseEvasion.add(os.bypassAntivirus);
        }
        if (os != null) {
          _cacheChildrenExploitationForDefenseEvasion.add(os.bypassSystemAccessControls);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExploitationForDefenseEvasion) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitationForDefenseEvasion == null) {
        _cacheParentExploitationForDefenseEvasion = new HashSet<>();
        _cacheParentExploitationForDefenseEvasion.add(attemptExploitationForDefenseEvasion);
        _cacheParentExploitationForDefenseEvasion.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitationForDefenseEvasion.add(exploitProtection.disable);
        _cacheParentExploitationForDefenseEvasion.add(threatIntelligenceProgram.disable);
        _cacheParentExploitationForDefenseEvasion.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitationForDefenseEvasion) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitationForDefenseEvasion");
    }
  }

  public class AttemptExploitationForPrivilegeEscalation extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExploitationForPrivilegeEscalation;

    private Set<AttackStep> _cacheParentAttemptExploitationForPrivilegeEscalation;

    public AttemptExploitationForPrivilegeEscalation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExploitationForPrivilegeEscalation == null) {
        _cacheChildrenAttemptExploitationForPrivilegeEscalation = new HashSet<>();
        _cacheChildrenAttemptExploitationForPrivilegeEscalation.add(exploitationForPrivilegeEscalation);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExploitationForPrivilegeEscalation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExploitationForPrivilegeEscalation == null) {
        _cacheParentAttemptExploitationForPrivilegeEscalation = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(_0.userRights);
          }
        }
        _cacheParentAttemptExploitationForPrivilegeEscalation.add(exploitationOfSQLInjection);
        _cacheParentAttemptExploitationForPrivilegeEscalation.add(exploitationOfNTLMAuthentication);
        _cacheParentAttemptExploitationForPrivilegeEscalation.add(exploitationOfRemoteServices);
        if (os != null) {
          _cacheParentAttemptExploitationForPrivilegeEscalation.add(os.softwareDiscovery);
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).dLLSearchOrderHijacking);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).executeCode);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).kerberoasting);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).windowsService);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).parentPIDSpoofing);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).servicesFilePermissionsWeakness);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).servicesRegistryPermissionsWeakness);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).powerShellAdminProfile);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).serviceRegistryPermissionsWeakness);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).scheduledTask);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).tokenImpersonationOrTheft);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).createProcessWithAToken);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).makeAndImpersonateToken);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).bypassUserAccessControl);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Windows) os).portMonitors);
          }
        }
        if (os != null) {
          if (os instanceof Linux) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Linux) os).lD_PRELOAD);
          }
        }
        if (os != null) {
          if (os instanceof Linux) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Linux) os).setuidAndSetgid);
          }
        }
        if (os != null) {
          if (os instanceof Linux) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.Linux) os).sudoAndSudoCaching);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).dylibHijacking);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).elevatedExecutionWithPrompt);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).emond);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).launchDaemon);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).plistModification);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).setuidAndSetgid);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).sudoAndSudoCaching);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentAttemptExploitationForPrivilegeEscalation.add(((asset.MacOS) os).startupItems);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExploitationForPrivilegeEscalation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptExploitationForPrivilegeEscalation");
    }
  }

  public class ExploitationForPrivilegeEscalation extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitationForPrivilegeEscalation;

    private Set<AttackStep> _cacheParentExploitationForPrivilegeEscalation;

    public ExploitationForPrivilegeEscalation(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitationForPrivilegeEscalation == null) {
        _cacheChildrenExploitationForPrivilegeEscalation = new HashSet<>();
        if (os != null) {
          for (AdminAccount _0 : os.adminAccount) {
            _cacheChildrenExploitationForPrivilegeEscalation.add(_0.adminRights);
          }
        }
        _cacheChildrenExploitationForPrivilegeEscalation.add(attemptUseThirdpartySoftware);
      }
      for (AttackStep attackStep : _cacheChildrenExploitationForPrivilegeEscalation) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitationForPrivilegeEscalation == null) {
        _cacheParentExploitationForPrivilegeEscalation = new HashSet<>();
        _cacheParentExploitationForPrivilegeEscalation.add(attemptExploitationForPrivilegeEscalation);
        _cacheParentExploitationForPrivilegeEscalation.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitationForPrivilegeEscalation.add(exploitProtection.disable);
        _cacheParentExploitationForPrivilegeEscalation.add(threatIntelligenceProgram.disable);
        _cacheParentExploitationForPrivilegeEscalation.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitationForPrivilegeEscalation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitationForPrivilegeEscalation");
    }
  }

  public class AttemptExploitationOfRemoteServices extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExploitationOfRemoteServices;

    private Set<AttackStep> _cacheParentAttemptExploitationOfRemoteServices;

    public AttemptExploitationOfRemoteServices(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExploitationOfRemoteServices == null) {
        _cacheChildrenAttemptExploitationOfRemoteServices = new HashSet<>();
        _cacheChildrenAttemptExploitationOfRemoteServices.add(exploitationOfRemoteServices);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExploitationOfRemoteServices) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExploitationOfRemoteServices == null) {
        _cacheParentAttemptExploitationOfRemoteServices = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentAttemptExploitationOfRemoteServices.add(_0.userRights);
          }
        }
        _cacheParentAttemptExploitationOfRemoteServices.add(externalRemoteServices);
        if (os != null) {
          _cacheParentAttemptExploitationOfRemoteServices.add(os.networkServiceScan);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExploitationOfRemoteServices) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptExploitationOfRemoteServices");
    }
  }

  public class ExploitationOfRemoteServices extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExploitationOfRemoteServices;

    private Set<AttackStep> _cacheParentExploitationOfRemoteServices;

    public ExploitationOfRemoteServices(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExploitationOfRemoteServices == null) {
        _cacheChildrenExploitationOfRemoteServices = new HashSet<>();
        _cacheChildrenExploitationOfRemoteServices.add(attemptExploitationForPrivilegeEscalation);
        if (os != null) {
          for (Computer _0 : os.computer) {
            _cacheChildrenExploitationOfRemoteServices.add(_0.infectedComputer);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExploitationOfRemoteServices) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExploitationOfRemoteServices == null) {
        _cacheParentExploitationOfRemoteServices = new HashSet<>();
        if (os != null) {
          for (AdminAccount _1 : os.adminAccount) {
            _cacheParentExploitationOfRemoteServices.add(_1.privilegedAccountManagement.disable);
          }
        }
        _cacheParentExploitationOfRemoteServices.add(attemptExploitationOfRemoteServices);
        _cacheParentExploitationOfRemoteServices.add(applicationIsolationAndSandboxing.disable);
        _cacheParentExploitationOfRemoteServices.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentExploitationOfRemoteServices.add(exploitProtection.disable);
        _cacheParentExploitationOfRemoteServices.add(networkSegmentation.disable);
        _cacheParentExploitationOfRemoteServices.add(threatIntelligenceProgram.disable);
        _cacheParentExploitationOfRemoteServices.add(updateSoftware.disable);
        _cacheParentExploitationOfRemoteServices.add(vulnerabilityScanning.disable);
      }
      for (AttackStep attackStep : _cacheParentExploitationOfRemoteServices) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.exploitationOfRemoteServices");
    }
  }

  public class AttemptExternalRemoteServices extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExternalRemoteServices;

    private Set<AttackStep> _cacheParentAttemptExternalRemoteServices;

    public AttemptExternalRemoteServices(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExternalRemoteServices == null) {
        _cacheChildrenAttemptExternalRemoteServices = new HashSet<>();
        _cacheChildrenAttemptExternalRemoteServices.add(externalRemoteServices);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExternalRemoteServices) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExternalRemoteServices == null) {
        _cacheParentAttemptExternalRemoteServices = new HashSet<>();
        if (os != null) {
          for (UserAccount _0 : os.userAccount) {
            _cacheParentAttemptExternalRemoteServices.add(_0.userRights);
          }
        }
        if (Service.this instanceof CloudService) {
          _cacheParentAttemptExternalRemoteServices.add(((asset.CloudService) Service.this).cloudAccounts);
        }
        if (os != null) {
          _cacheParentAttemptExternalRemoteServices.add(os.webPortalCapture);
        }
        if (os != null) {
          _cacheParentAttemptExternalRemoteServices.add(os.defaultAccounts);
        }
        if (os != null) {
          _cacheParentAttemptExternalRemoteServices.add(os.domainAccounts);
        }
        if (os != null) {
          _cacheParentAttemptExternalRemoteServices.add(os.localAccounts);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExternalRemoteServices) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.attemptExternalRemoteServices");
    }
  }

  public class ExternalRemoteServices extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExternalRemoteServices;

    private Set<AttackStep> _cacheParentExternalRemoteServices;

    public ExternalRemoteServices(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExternalRemoteServices == null) {
        _cacheChildrenExternalRemoteServices = new HashSet<>();
        if (os != null) {
          for (Computer _0 : os.computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenExternalRemoteServices.add(_2.persistence);
              }
            }
          }
        }
        if (os != null) {
          for (Computer _3 : os.computer) {
            for (Router _4 : _3.router) {
              for (InternalNetwork _5 : _4.internalNetwork) {
                _cacheChildrenExternalRemoteServices.add(_5.remoteAccess);
              }
            }
          }
        }
        if (os != null) {
          _cacheChildrenExternalRemoteServices.add(os.attemptSystemFirmware);
        }
        _cacheChildrenExternalRemoteServices.add(remoteServices);
        _cacheChildrenExternalRemoteServices.add(attemptExploitationOfRemoteServices);
      }
      for (AttackStep attackStep : _cacheChildrenExternalRemoteServices) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExternalRemoteServices == null) {
        _cacheParentExternalRemoteServices = new HashSet<>();
        _cacheParentExternalRemoteServices.add(attemptExternalRemoteServices);
        _cacheParentExternalRemoteServices.add(disableOrRemoveFeatureOrProgram.disable);
        _cacheParentExternalRemoteServices.add(networkSegmentation.disable);
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentExternalRemoteServices.add(((asset.Windows) os).windowsRemoteManagement);
          }
        }
        if (os != null) {
          for (Computer _6 : os.computer) {
            for (Router _7 : _6.router) {
              for (InternalNetwork _8 : _7.internalNetwork) {
                _cacheParentExternalRemoteServices.add(_8.limitAccessToResourceOverNetwork.disable);
              }
            }
          }
        }
        if (os != null) {
          for (Computer _9 : os.computer) {
            for (Router _a : _9.router) {
              if (_a.firewall != null) {
                _cacheParentExternalRemoteServices.add(_a.firewall.networkSegmentation.disable);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentExternalRemoteServices) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Service.externalRemoteServices");
    }
  }

  public class Audit extends Defense {
    public Audit(String name) {
      this(name, false);
    }

    public Audit(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenAudit;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenAudit == null) {
          _cacheChildrenAudit = new HashSet<>();
          _cacheChildrenAudit.add(implantContainerImage);
        }
        for (AttackStep attackStep : _cacheChildrenAudit) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.audit";
      }
    }
  }

  public class ApplicationIsolationAndSandboxing extends Defense {
    public ApplicationIsolationAndSandboxing(String name) {
      this(name, false);
    }

    public ApplicationIsolationAndSandboxing(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenApplicationIsolationAndSandboxing;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenApplicationIsolationAndSandboxing == null) {
          _cacheChildrenApplicationIsolationAndSandboxing = new HashSet<>();
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitationForClientExecution);
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitationForCredentialAccess);
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitationForDefenseEvasion);
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitationForPrivilegeEscalation);
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitationOfRemoteServices);
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitHighVulnerabilityPublicFacingApplication);
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitMediumVulnerabilityPublicFacingApplication);
          _cacheChildrenApplicationIsolationAndSandboxing.add(exploitLowVulnerabilityPublicFacingApplication);
        }
        for (AttackStep attackStep : _cacheChildrenApplicationIsolationAndSandboxing) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.applicationIsolationAndSandboxing";
      }
    }
  }

  public class PrivilegedAccountManagement extends Defense {
    public PrivilegedAccountManagement(String name) {
      this(name, false);
    }

    public PrivilegedAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenPrivilegedAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenPrivilegedAccountManagement == null) {
          _cacheChildrenPrivilegedAccountManagement = new HashSet<>();
          _cacheChildrenPrivilegedAccountManagement.add(implantContainerImage);
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.privilegedAccountManagement";
      }
    }
  }

  public class DisableOrRemoveFeatureOrProgram extends Defense {
    public DisableOrRemoveFeatureOrProgram(String name) {
      this(name, false);
    }

    public DisableOrRemoveFeatureOrProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenDisableOrRemoveFeatureOrProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenDisableOrRemoveFeatureOrProgram == null) {
          _cacheChildrenDisableOrRemoveFeatureOrProgram = new HashSet<>();
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(exploitationOfRemoteServices);
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(externalRemoteServices);
        }
        for (AttackStep attackStep : _cacheChildrenDisableOrRemoveFeatureOrProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.disableOrRemoveFeatureOrProgram";
      }
    }
  }

  public class EncryptSensitiveInformation extends Defense {
    public EncryptSensitiveInformation(String name) {
      this(name, false);
    }

    public EncryptSensitiveInformation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenEncryptSensitiveInformation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenEncryptSensitiveInformation == null) {
          _cacheChildrenEncryptSensitiveInformation = new HashSet<>();
          _cacheChildrenEncryptSensitiveInformation.add(transmittedDataManipulation);
        }
        for (AttackStep attackStep : _cacheChildrenEncryptSensitiveInformation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.encryptSensitiveInformation";
      }
    }
  }

  public class ExecutionPrevention extends Defense {
    public ExecutionPrevention(String name) {
      this(name, false);
    }

    public ExecutionPrevention(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenExecutionPrevention;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenExecutionPrevention == null) {
          _cacheChildrenExecutionPrevention = new HashSet<>();
          _cacheChildrenExecutionPrevention.add(remoteAccessSoftware);
        }
        for (AttackStep attackStep : _cacheChildrenExecutionPrevention) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.executionPrevention";
      }
    }
  }

  public class ExploitProtection extends Defense {
    public ExploitProtection(String name) {
      this(name, false);
    }

    public ExploitProtection(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenExploitProtection;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenExploitProtection == null) {
          _cacheChildrenExploitProtection = new HashSet<>();
          _cacheChildrenExploitProtection.add(exploitationForClientExecution);
          _cacheChildrenExploitProtection.add(exploitationForCredentialAccess);
          _cacheChildrenExploitProtection.add(exploitationForDefenseEvasion);
          _cacheChildrenExploitProtection.add(exploitationForPrivilegeEscalation);
          _cacheChildrenExploitProtection.add(exploitationOfRemoteServices);
          _cacheChildrenExploitProtection.add(exploitHighVulnerabilityPublicFacingApplication);
          _cacheChildrenExploitProtection.add(exploitMediumVulnerabilityPublicFacingApplication);
          _cacheChildrenExploitProtection.add(exploitLowVulnerabilityPublicFacingApplication);
        }
        for (AttackStep attackStep : _cacheChildrenExploitProtection) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.exploitProtection";
      }
    }
  }

  public class NetworkSegmentation extends Defense {
    public NetworkSegmentation(String name) {
      this(name, false);
    }

    public NetworkSegmentation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenNetworkSegmentation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenNetworkSegmentation == null) {
          _cacheChildrenNetworkSegmentation = new HashSet<>();
          _cacheChildrenNetworkSegmentation.add(exploitationOfRemoteServices);
          _cacheChildrenNetworkSegmentation.add(exploitHighVulnerabilityPublicFacingApplication);
          _cacheChildrenNetworkSegmentation.add(exploitMediumVulnerabilityPublicFacingApplication);
          _cacheChildrenNetworkSegmentation.add(exploitLowVulnerabilityPublicFacingApplication);
          _cacheChildrenNetworkSegmentation.add(externalRemoteServices);
        }
        for (AttackStep attackStep : _cacheChildrenNetworkSegmentation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.networkSegmentation";
      }
    }
  }

  public class ThreatIntelligenceProgram extends Defense {
    public ThreatIntelligenceProgram(String name) {
      this(name, false);
    }

    public ThreatIntelligenceProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenThreatIntelligenceProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenThreatIntelligenceProgram == null) {
          _cacheChildrenThreatIntelligenceProgram = new HashSet<>();
          _cacheChildrenThreatIntelligenceProgram.add(exploitationForCredentialAccess);
          _cacheChildrenThreatIntelligenceProgram.add(exploitationForPrivilegeEscalation);
          _cacheChildrenThreatIntelligenceProgram.add(exploitationForDefenseEvasion);
          _cacheChildrenThreatIntelligenceProgram.add(exploitationOfRemoteServices);
        }
        for (AttackStep attackStep : _cacheChildrenThreatIntelligenceProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.threatIntelligenceProgram";
      }
    }
  }

  public class PasswordPolicies extends Defense {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      public Disable(String name) {
        super(name);
      }

      @Override
      public String fullName() {
        return "Service.passwordPolicies";
      }
    }
  }

  public class UpdateSoftware extends Defense {
    public UpdateSoftware(String name) {
      this(name, false);
    }

    public UpdateSoftware(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenUpdateSoftware;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenUpdateSoftware == null) {
          _cacheChildrenUpdateSoftware = new HashSet<>();
          _cacheChildrenUpdateSoftware.add(applicationDeploymentSoftware);
          _cacheChildrenUpdateSoftware.add(compromiseSoftwareDependenciesAndDevelopmentTools);
          _cacheChildrenUpdateSoftware.add(compromiseSoftwareSupplyChain);
          _cacheChildrenUpdateSoftware.add(exploitationForCredentialAccess);
          _cacheChildrenUpdateSoftware.add(exploitationForDefenseEvasion);
          _cacheChildrenUpdateSoftware.add(exploitationForPrivilegeEscalation);
          _cacheChildrenUpdateSoftware.add(exploitationOfRemoteServices);
          _cacheChildrenUpdateSoftware.add(exploitHighVulnerabilityPublicFacingApplication);
          _cacheChildrenUpdateSoftware.add(exploitLowVulnerabilityPublicFacingApplication);
          _cacheChildrenUpdateSoftware.add(exploitMediumVulnerabilityPublicFacingApplication);
          if (os != null) {
            for (Computer _0 : os.computer) {
              for (Router _1 : _0.router) {
                for (InternalNetwork _2 : _1.internalNetwork) {
                  _cacheChildrenUpdateSoftware.add(_2.remoteAccess);
                }
              }
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenUpdateSoftware) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.updateSoftware";
      }
    }
  }

  public class SoftwareConfiguration extends Defense {
    public SoftwareConfiguration(String name) {
      this(name, false);
    }

    public SoftwareConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      public Disable(String name) {
        super(name);
      }

      @Override
      public String fullName() {
        return "Service.softwareConfiguration";
      }
    }
  }

  public class ActiveDirectoryConfiguration extends Defense {
    public ActiveDirectoryConfiguration(String name) {
      this(name, false);
    }

    public ActiveDirectoryConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      public Disable(String name) {
        super(name);
      }

      @Override
      public String fullName() {
        return "Service.activeDirectoryConfiguration";
      }
    }
  }

  public class VulnerabilityScanning extends Defense {
    public VulnerabilityScanning(String name) {
      this(name, false);
    }

    public VulnerabilityScanning(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenVulnerabilityScanning;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenVulnerabilityScanning == null) {
          _cacheChildrenVulnerabilityScanning = new HashSet<>();
          _cacheChildrenVulnerabilityScanning.add(compromiseSoftwareDependenciesAndDevelopmentTools);
          _cacheChildrenVulnerabilityScanning.add(compromiseSoftwareSupplyChain);
          _cacheChildrenVulnerabilityScanning.add(exploitHighVulnerabilityPublicFacingApplication);
          _cacheChildrenVulnerabilityScanning.add(exploitMediumVulnerabilityPublicFacingApplication);
          _cacheChildrenVulnerabilityScanning.add(exploitLowVulnerabilityPublicFacingApplication);
          _cacheChildrenVulnerabilityScanning.add(exploitationOfRemoteServices);
        }
        for (AttackStep attackStep : _cacheChildrenVulnerabilityScanning) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.vulnerabilityScanning";
      }
    }
  }

  public class MultiFactorAuthentication extends Defense {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(applicationDeploymentSoftware);
          _cacheChildrenMultiFactorAuthentication.add(remoteServices);
          _cacheChildrenMultiFactorAuthentication.add(cloudAccount);
          _cacheChildrenMultiFactorAuthentication.add(additionalAzureServicePrincipalCredentials);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Service.multiFactorAuthentication";
      }
    }
  }
}
