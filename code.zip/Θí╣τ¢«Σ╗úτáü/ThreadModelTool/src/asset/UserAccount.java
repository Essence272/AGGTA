package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class UserAccount extends Asset {
  public UserRights userRights;

  public UserCredentials userCredentials;

  public UserExecution userExecution;

  public UserInformation userInformation;

  public UserTraining userTraining;

  public UserAccountManagement userAccountManagement;

  public User user = null;

  public Set<AdminAccount> adminAccount = new HashSet<>();

  public OS os = null;

  public UserAccount(String name, boolean isUserTrainingEnabled,
      boolean isUserAccountManagementEnabled) {
    super(name);
    assetClassName = "UserAccount";
    AttackStep.allAttackSteps.remove(userRights);
    userRights = new UserRights(name);
    AttackStep.allAttackSteps.remove(userCredentials);
    userCredentials = new UserCredentials(name);
    AttackStep.allAttackSteps.remove(userExecution);
    userExecution = new UserExecution(name);
    AttackStep.allAttackSteps.remove(userInformation);
    userInformation = new UserInformation(name);
    if (userTraining != null) {
      AttackStep.allAttackSteps.remove(userTraining.disable);
    }
    Defense.allDefenses.remove(userTraining);
    userTraining = new UserTraining(name, isUserTrainingEnabled);
    if (userAccountManagement != null) {
      AttackStep.allAttackSteps.remove(userAccountManagement.disable);
    }
    Defense.allDefenses.remove(userAccountManagement);
    userAccountManagement = new UserAccountManagement(name, isUserAccountManagementEnabled);
  }

  public UserAccount(String name) {
    super(name);
    assetClassName = "UserAccount";
    AttackStep.allAttackSteps.remove(userRights);
    userRights = new UserRights(name);
    AttackStep.allAttackSteps.remove(userCredentials);
    userCredentials = new UserCredentials(name);
    AttackStep.allAttackSteps.remove(userExecution);
    userExecution = new UserExecution(name);
    AttackStep.allAttackSteps.remove(userInformation);
    userInformation = new UserInformation(name);
    if (userTraining != null) {
      AttackStep.allAttackSteps.remove(userTraining.disable);
    }
    Defense.allDefenses.remove(userTraining);
    userTraining = new UserTraining(name, false);
    if (userAccountManagement != null) {
      AttackStep.allAttackSteps.remove(userAccountManagement.disable);
    }
    Defense.allDefenses.remove(userAccountManagement);
    userAccountManagement = new UserAccountManagement(name, false);
  }

  public UserAccount(boolean isUserTrainingEnabled, boolean isUserAccountManagementEnabled) {
    this("Anonymous", isUserTrainingEnabled, isUserAccountManagementEnabled);
  }

  public UserAccount() {
    this("Anonymous");
  }

  public void addUser(User user) {
    this.user = user;
    user.userAccount.add(this);
  }

  public void addAdminAccount(AdminAccount adminAccount) {
    this.adminAccount.add(adminAccount);
    adminAccount.userAccount.add(this);
  }

  public void addOs(OS os) {
    this.os = os;
    os.userAccount.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("user")) {
      return User.class.getName();
    } else if (field.equals("adminAccount")) {
      return AdminAccount.class.getName();
    } else if (field.equals("os")) {
      return OS.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("user")) {
      if (user != null) {
        assets.add(user);
      }
    } else if (field.equals("adminAccount")) {
      assets.addAll(adminAccount);
    } else if (field.equals("os")) {
      if (os != null) {
        assets.add(os);
      }
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    if (user != null) {
      assets.add(user);
    }
    assets.addAll(adminAccount);
    if (os != null) {
      assets.add(os);
    }
    return assets;
  }

  public class UserRights extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenUserRights;

    private Set<AttackStep> _cacheParentUserRights;

    public UserRights(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUserRights == null) {
        _cacheChildrenUserRights = new HashSet<>();
        if (os != null) {
          _cacheChildrenUserRights.add(os.abuseElevationControlMechanism);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.accountAccessRemoval);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.accountDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.applicationWindowDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptAccessTokenManipulation);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptAutomatedCollection);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptBITSJobs);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptDataEncryptedForImpact);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptExecutionThroughAPI);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptLaunchAgent);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptLogonScripts);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptPlistModification);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptSetuidAndSetgid);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptShortcutModification);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptSSHAuthorizedKeys);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.attemptTaintSharedContent);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.bash_profileAndBashrc);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.bashHistory);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.bruteForce);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.bypassUserAccessControl);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.changeDefaultFileAssociation);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.clearCommandHistory);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.cmstp);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.commandAndScriptingInterpreter);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.compileAfterDelivery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.compiledHTMLFile);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.componentObjectModelHijacking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.controlPanel);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.cOR_PROFILER);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.credentialsInFiles);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.credentialsInRegistry);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.credentialStuffing);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.cron);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.dataDestruction);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.dataEncoding);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.dataFromInformationRepositories);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.dataManipulation);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.defaultAccounts);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.deobfuscateOrDecodeFilesOrInformation);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.disableOrModifyTools);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.diskWipe);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.dLLSearchOrderHijacking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.domainAccounts);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.domainDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.domainGroups);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.domainTrustDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.dynamicDataExchange);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.dynamicResolution);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.elevatedExecutionWithPrompt);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.emailCollection);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.executableInstallerFilePermissionsWeakness);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.executionGuardrails);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.executionThroughModuleLoad);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.fileAndDirectoryDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.fileAndDirectoryPermissionsModification);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.fileDeletion);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.forcedAuthentication);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.gatekeeperBypass);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.groupPolicyModification);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.groupPolicyPreferences);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.gUIInputCapture);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.hiddenFilesAndDirectories);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.hiddenFileSystem);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.hiddenWindow);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.hISTCONTROL);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.indicatorRemovalOnHost);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.indirectCommandExecution);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.inhibitSystemRecovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.installRootCertificate);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.installUtil);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.internalSpearphishing);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.lateralToolTransfer);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.launchctl);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.lC_LOAD_DYLIB_Addition);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.lLMNR_NBT_NS_PoisoningAndSMBRelay);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.localAccounts);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.localGroups);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.manInTheMiddle);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.masqueradeTaskOrService);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.modifyRegistry);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.mshta);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.msiexec);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.networkShareConnectionRemoval);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.networkShareDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.odbcconf);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.goldenTicket);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.parentPIDSpoofing);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.passwordCracking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.passwordGuessing);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.passwordPolicyDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.passwordSpraying);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.pathInterceptionBySearchOrderHijacking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.peripheralDeviceDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.portableExecutableInjection);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.portKnocking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.powerShellUserProfile);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.privateKeys);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.processDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.processDoppelganging);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.processHollowing);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.pubPrn);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.registryRunKeysOrStartupFolder);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.regsvcsOrRegasm);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.regsvr32);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.remoteDesktopProtocol);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.remoteFileCopy);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.remoteSystemDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.reopenedApplications);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.resourceHijacking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.rootkit);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.rundll32);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.runVirtualInstance);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.screensaver);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.securitySoftwareDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.servicesFilePermissionsWeakness);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.servicesRegistryPermissionsWeakness);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.serviceStop);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.signedScriptProxyExecution);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.silverTicket);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.sIPAndTrustProviderHijacking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.softwareDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.source);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.spaceAfterFileName);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.sudoAndSudoCaching);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.systemdService);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.systemInformationDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.systemNetworkConfigurationDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.systemNetworkConnectionsDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.systemOwnerOrUserDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.systemServiceDiscovery);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.systemShutdownOrReboot);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.templateInjection);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.threadExecutionHijacking);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.timestomp);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.trap);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.trustedDeveloperUtilities);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.videoCapture);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.windowsAdminShares);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.windowsManagementInstrumentation);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.windowsRemoteManagement);
        }
        if (os != null) {
          _cacheChildrenUserRights.add(os.xslScriptProcessing);
        }
        if (os != null) {
          for (Service _0 : os.service) {
            _cacheChildrenUserRights.add(_0.attemptExploitationForCredentialAccess);
          }
        }
        if (os != null) {
          for (Service _1 : os.service) {
            _cacheChildrenUserRights.add(_1.attemptExploitationForDefenseEvasion);
          }
        }
        if (os != null) {
          for (Service _2 : os.service) {
            _cacheChildrenUserRights.add(_2.attemptExploitationForPrivilegeEscalation);
          }
        }
        if (os != null) {
          for (Service _3 : os.service) {
            _cacheChildrenUserRights.add(_3.attemptExploitationOfRemoteServices);
          }
        }
        if (os != null) {
          for (Service _4 : os.service) {
            _cacheChildrenUserRights.add(_4.attemptExternalRemoteServices);
          }
        }
        if (os != null) {
          for (Service _5 : os.service) {
            _cacheChildrenUserRights.add(_5.implantContainerImage);
          }
        }
        if (os != null) {
          for (Service _6 : os.service) {
            _cacheChildrenUserRights.add(_6.remoteAccessSoftware);
          }
        }
        if (os != null) {
          for (Service _7 : os.service) {
            _cacheChildrenUserRights.add(_7.cloudAccounts);
          }
        }
        if (os != null) {
          for (Service _8 : os.service) {
            _cacheChildrenUserRights.add(_8.cloudGroups);
          }
        }
        if (os != null) {
          for (Service _9 : os.service) {
            _cacheChildrenUserRights.add(_9.cloudServiceDiscovery);
          }
        }
        if (os != null) {
          for (Service _a : os.service) {
            _cacheChildrenUserRights.add(_a.cloudServiceDashboard);
          }
        }
        if (os != null) {
          for (Service _b : os.service) {
            _cacheChildrenUserRights.add(_b.disableOrModifyCloudFirewall);
          }
        }
        if (os != null) {
          for (Service _c : os.service) {
            _cacheChildrenUserRights.add(_c.modifyCloudComputeInfrastructure);
          }
        }
        if (os != null) {
          for (Service _d : os.service) {
            _cacheChildrenUserRights.add(_d.officeTemplateMacros);
          }
        }
        if (os != null) {
          for (Service _e : os.service) {
            _cacheChildrenUserRights.add(_e.officeTest);
          }
        }
        if (os != null) {
          for (Service _f : os.service) {
            _cacheChildrenUserRights.add(_f.outlookForms);
          }
        }
        if (os != null) {
          for (Service _10 : os.service) {
            _cacheChildrenUserRights.add(_10.outlookHomePage);
          }
        }
        if (os != null) {
          for (Service _11 : os.service) {
            _cacheChildrenUserRights.add(_11.outlookRules);
          }
        }
        if (os != null) {
          for (Service _12 : os.service) {
            _cacheChildrenUserRights.add(_12.addIns);
          }
        }
        if (os != null) {
          for (Service _13 : os.service) {
            _cacheChildrenUserRights.add(_13.stealApplicationAccessToken);
          }
        }
        if (os != null) {
          for (Service _14 : os.service) {
            _cacheChildrenUserRights.add(_14.attemptUseThirdpartySoftware);
          }
        }
        if (os != null) {
          for (Service _15 : os.service) {
            for (Browser _16 : _15.browser) {
              _cacheChildrenUserRights.add(_16.browserBookmarkDiscovery);
            }
          }
        }
        if (os != null) {
          for (Service _17 : os.service) {
            for (Browser _18 : _17.browser) {
              _cacheChildrenUserRights.add(_18.driveByCompromise);
            }
          }
        }
        if (os != null) {
          for (Service _19 : os.service) {
            for (Browser _1a : _19.browser) {
              _cacheChildrenUserRights.add(_1a.installExtensions);
            }
          }
        }
        if (os != null) {
          for (Service _1b : os.service) {
            for (Browser _1c : _1b.browser) {
              _cacheChildrenUserRights.add(_1c.stealWebSessionCookie);
            }
          }
        }
        if (os != null) {
          for (Computer _1d : os.computer) {
            for (Router _1e : _1d.router) {
              for (InternalNetwork _1f : _1e.internalNetwork) {
                _cacheChildrenUserRights.add(_1f.transmittedDataManipulation);
              }
            }
          }
        }
        if (os != null) {
          for (Computer _20 : os.computer) {
            for (Router _21 : _20.router) {
              for (ExternalNetwork _22 : _21.externalNetwork) {
                _cacheChildrenUserRights.add(_22.bidirectionaCommunication);
              }
            }
          }
        }
        if (os != null) {
          for (Computer _23 : os.computer) {
            for (Router _24 : _23.router) {
              for (ExternalNetwork _25 : _24.externalNetwork) {
                _cacheChildrenUserRights.add(_25.dataFromCloudStorageObject);
              }
            }
          }
        }
        if (os != null) {
          for (Computer _26 : os.computer) {
            for (Router _27 : _26.router) {
              for (ExternalNetwork _28 : _27.externalNetwork) {
                _cacheChildrenUserRights.add(_28.deadDropResolver);
              }
            }
          }
        }
        if (os != null) {
          for (Computer _29 : os.computer) {
            for (Router _2a : _29.router) {
              for (ExternalNetwork _2b : _2a.externalNetwork) {
                _cacheChildrenUserRights.add(_2b.oneWayCommunication);
              }
            }
          }
        }
        if (os != null) {
          for (Computer _2c : os.computer) {
            for (Router _2d : _2c.router) {
              for (ExternalNetwork _2e : _2d.externalNetwork) {
                _cacheChildrenUserRights.add(_2e.transmittedDataManipulation);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenUserRights) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUserRights == null) {
        _cacheParentUserRights = new HashSet<>();
        _cacheParentUserRights.add(userCredentials);
        for (AdminAccount _2f : adminAccount) {
          _cacheParentUserRights.add(_2f.adminRights);
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserRights.add(((asset.Windows) os).dLLSearchOrderHijacking);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentUserRights) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("UserAccount.userRights");
    }
  }

  public class UserCredentials extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenUserCredentials;

    private Set<AttackStep> _cacheParentUserCredentials;

    public UserCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUserCredentials == null) {
        _cacheChildrenUserCredentials = new HashSet<>();
        _cacheChildrenUserCredentials.add(userRights);
        if (os != null) {
          _cacheChildrenUserCredentials.add(os.validAccounts);
        }
        if (os != null) {
          for (Computer _0 : os.computer) {
            for (Router _1 : _0.router) {
              for (InternalNetwork _2 : _1.internalNetwork) {
                _cacheChildrenUserCredentials.add(_2.exchangeServerCollection);
              }
            }
          }
        }
        if (os != null) {
          for (Service _3 : os.service) {
            _cacheChildrenUserCredentials.add(_3.remoteServices);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenUserCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUserCredentials == null) {
        _cacheParentUserCredentials = new HashSet<>();
        if (os != null) {
          for (Service _4 : os.service) {
            for (Browser _5 : _4.browser) {
              _cacheParentUserCredentials.add(_5.credentialsFromWebBrowsers);
            }
          }
        }
        if (os != null) {
          for (Service _6 : os.service) {
            for (Browser _7 : _6.browser) {
              _cacheParentUserCredentials.add(_7.browserExtensions);
            }
          }
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.accountManipulation);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.clipboardData);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.keylogging);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.networkSniffing);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.bruteForceWithPasswordPolicy);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.passwordGuessing);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.passwordCracking);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.passwordSpraying);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.credentialStuffing);
        }
        if (os != null) {
          _cacheParentUserCredentials.add(os.credentialsInFiles);
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserCredentials.add(((asset.Windows) os).credentialAPIHooking);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserCredentials.add(((asset.Windows) os).credentialsInRegistry);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserCredentials.add(((asset.Windows) os).lSASecrets);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserCredentials.add(((asset.Windows) os).groupPolicyPreferences);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserCredentials.add(((asset.Windows) os).gUIInputCapture);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserCredentials.add(((asset.Windows) os).rDPHijacking);
          }
        }
        if (os != null) {
          if (os instanceof Windows) {
            _cacheParentUserCredentials.add(((asset.Windows) os).captureAPICalls);
          }
        }
        if (os != null) {
          if (os instanceof Linux) {
            _cacheParentUserCredentials.add(((asset.Linux) os).bashHistory);
          }
        }
        if (os != null) {
          if (os instanceof Linux) {
            _cacheParentUserCredentials.add(((asset.Linux) os).securitydMemory);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentUserCredentials.add(((asset.MacOS) os).bashHistory);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentUserCredentials.add(((asset.MacOS) os).gUIInputCapture);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentUserCredentials.add(((asset.MacOS) os).securitydMemory);
          }
        }
        if (os != null) {
          if (os instanceof MacOS) {
            _cacheParentUserCredentials.add(((asset.MacOS) os).keychain);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentUserCredentials) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("UserAccount.userCredentials");
    }
  }

  public class UserExecution extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenUserExecution;

    private Set<AttackStep> _cacheParentUserExecution;

    public UserExecution(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenUserExecution == null) {
        _cacheChildrenUserExecution = new HashSet<>();
        if (user != null) {
          _cacheChildrenUserExecution.add(user.maliciousFile);
        }
        if (user != null) {
          _cacheChildrenUserExecution.add(user.maliciousLink);
        }
      }
      for (AttackStep attackStep : _cacheChildrenUserExecution) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUserExecution == null) {
        _cacheParentUserExecution = new HashSet<>();
        if (user != null) {
          _cacheParentUserExecution.add(user.attemptUserExecution);
        }
        if (user != null) {
          _cacheParentUserExecution.add(user.userTraining.disable);
        }
        if (os != null) {
          for (Service _0 : os.service) {
            for (Browser _1 : _0.browser) {
              _cacheParentUserExecution.add(_1.restrictWebBasedContent.disable);
            }
          }
        }
        if (os != null) {
          _cacheParentUserExecution.add(os.executionPrevention.disable);
        }
        if (os != null) {
          for (Computer _2 : os.computer) {
            for (Router _3 : _2.router) {
              for (InternalNetwork _4 : _3.internalNetwork) {
                _cacheParentUserExecution.add(_4.networkIntrusionPrevention.disable);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheParentUserExecution) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("UserAccount.userExecution");
    }
  }

  public class UserInformation extends AttackStepMin {
    private Set<AttackStep> _cacheParentUserInformation;

    public UserInformation(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUserInformation == null) {
        _cacheParentUserInformation = new HashSet<>();
        if (os != null) {
          for (Service _0 : os.service) {
            for (Browser _1 : _0.browser) {
              _cacheParentUserInformation.add(_1.browserBookmarkDiscovery);
            }
          }
        }
        if (os != null) {
          for (Service _2 : os.service) {
            for (Browser _3 : _2.browser) {
              _cacheParentUserInformation.add(_3.browserExtensions);
            }
          }
        }
        if (os != null) {
          _cacheParentUserInformation.add(os.domainAccount);
        }
        if (os != null) {
          _cacheParentUserInformation.add(os.localAccount);
        }
        if (os != null) {
          _cacheParentUserInformation.add(os.systemOwnerOrUserDiscovery);
        }
      }
      for (AttackStep attackStep : _cacheParentUserInformation) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("UserAccount.userInformation");
    }
  }

  public class UserTraining extends Defense {
    public UserTraining(String name) {
      this(name, false);
    }

    public UserTraining(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenUserTraining;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenUserTraining == null) {
          _cacheChildrenUserTraining = new HashSet<>();
          if (os != null) {
            _cacheChildrenUserTraining.add(os.cachedDomainCredentials);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.confluence);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.credentialsInFiles);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.gUIInputCapture);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.lSASecrets);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.lSASSMemory);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.manInTheBrowser);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.nTDS);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.plistModification);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.reopenedApplications);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.securityAccountManager);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.sharepoint);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.templateInjection);
          }
          if (os != null) {
            _cacheChildrenUserTraining.add(os.twoFactorAuthenticationInterception);
          }
          if (os != null) {
            for (Service _0 : os.service) {
              for (Browser _1 : _0.browser) {
                _cacheChildrenUserTraining.add(_1.browserExtensions);
              }
            }
          }
          if (os != null) {
            for (Service _2 : os.service) {
              for (Browser _3 : _2.browser) {
                _cacheChildrenUserTraining.add(_3.stealWebSessionCookie);
              }
            }
          }
          if (os != null) {
            for (Service _4 : os.service) {
              _cacheChildrenUserTraining.add(_4.stealApplicationAccessToken);
            }
          }
          if (os != null) {
            for (Service _5 : os.service) {
              _cacheChildrenUserTraining.add(_5.spearphishingViaService);
            }
          }
          if (os != null) {
            for (Service _6 : os.service) {
              _cacheChildrenUserTraining.add(_6.useThirdpartySoftware);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenUserTraining) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "UserAccount.userTraining";
      }
    }
  }

  public class UserAccountManagement extends Defense {
    public UserAccountManagement(String name) {
      this(name, false);
    }

    public UserAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenUserAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenUserAccountManagement == null) {
          _cacheChildrenUserAccountManagement = new HashSet<>();
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.accessTokenManipulation);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.at);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.attemptStartupItems);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.bITSJobs);
          }
          if (os != null) {
            for (Computer _0 : os.computer) {
              for (Router _1 : _0.router) {
                for (ExternalNetwork _2 : _1.externalNetwork) {
                  _cacheChildrenUserAccountManagement.add(_2.dataFromCloudStorageObject);
                }
              }
            }
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.confluence);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.cOR_PROFILER);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.credentialStuffing);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.cron);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.disableOrModifySystemFirewall);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.disableOrModifyTools);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.disableWindowsEventLogging);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.executableInstallerFilePermissionsWeakness);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.indicatorBlocking);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.launchAgent);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.launchctl);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.launchd);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.launchDaemon);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.manInTheBrowser);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.passTheHash);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.passTheTicket);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.rc_common);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.rDPHijacking);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.remoteDesktopProtocol);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.remoteScheduledTask);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.scheduledTask);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.servicesFilePermissionsWeakness);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.serviceStop);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.sharepoint);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.shortcutModification);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.systemdService);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.windowsManagementInstrumentation);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.windowsManagementInstrumentationEventSubscription);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.windowsService);
          }
          if (os != null) {
            _cacheChildrenUserAccountManagement.add(os.winlogonHelperDLL);
          }
          if (os != null) {
            for (Service _3 : os.service) {
              _cacheChildrenUserAccountManagement.add(_3.remoteServices);
            }
          }
          if (os != null) {
            for (Service _4 : os.service) {
              _cacheChildrenUserAccountManagement.add(_4.createSnapshot);
            }
          }
          if (os != null) {
            for (Service _5 : os.service) {
              _cacheChildrenUserAccountManagement.add(_5.cloudServiceDashboard);
            }
          }
          if (os != null) {
            for (Service _6 : os.service) {
              _cacheChildrenUserAccountManagement.add(_6.createCloudInstance);
            }
          }
          if (os != null) {
            for (Service _7 : os.service) {
              _cacheChildrenUserAccountManagement.add(_7.deleteCloudInstance);
            }
          }
          if (os != null) {
            for (Service _8 : os.service) {
              _cacheChildrenUserAccountManagement.add(_8.disableOrModifyCloudFirewall);
            }
          }
          if (os != null) {
            for (Service _9 : os.service) {
              _cacheChildrenUserAccountManagement.add(_9.stealApplicationAccessToken);
            }
          }
          if (os != null) {
            for (Service _a : os.service) {
              _cacheChildrenUserAccountManagement.add(_a.useThirdpartySoftware);
            }
          }
        }
        for (AttackStep attackStep : _cacheChildrenUserAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "UserAccount.userAccountManagement";
      }
    }
  }
}
