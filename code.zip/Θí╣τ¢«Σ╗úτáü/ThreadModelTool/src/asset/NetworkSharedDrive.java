package asset;

import core.AttackStep;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class NetworkSharedDrive extends InternalNetwork {
  public NetworkSharedDrive(String name, boolean isEncryptSensitiveInformationEnabled,
      boolean isExecutionPreventionEnabled, boolean isFilterNetworkTrafficEnabled,
      boolean isLimitAccessToResourceOverNetworkEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isNetworkIntrusionPreventionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isSSLOrTLSInspectionEnabled) {
    super(name, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isFilterNetworkTrafficEnabled, isLimitAccessToResourceOverNetworkEnabled, isMultiFactorAuthenticationEnabled, isNetworkIntrusionPreventionEnabled, isNetworkSegmentationEnabled, isSSLOrTLSInspectionEnabled);
    assetClassName = "NetworkSharedDrive";
    AttackStep.allAttackSteps.remove(taintSharedContent);
    taintSharedContent = new TaintSharedContent(name);
    AttackStep.allAttackSteps.remove(dataFromNetworkSharedDrive);
    dataFromNetworkSharedDrive = new DataFromNetworkSharedDrive(name);
  }

  public NetworkSharedDrive(String name) {
    super(name);
    assetClassName = "NetworkSharedDrive";
    AttackStep.allAttackSteps.remove(taintSharedContent);
    taintSharedContent = new TaintSharedContent(name);
    AttackStep.allAttackSteps.remove(dataFromNetworkSharedDrive);
    dataFromNetworkSharedDrive = new DataFromNetworkSharedDrive(name);
  }

  public NetworkSharedDrive(boolean isEncryptSensitiveInformationEnabled,
      boolean isExecutionPreventionEnabled, boolean isFilterNetworkTrafficEnabled,
      boolean isLimitAccessToResourceOverNetworkEnabled, boolean isMultiFactorAuthenticationEnabled,
      boolean isNetworkIntrusionPreventionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isSSLOrTLSInspectionEnabled) {
    this("Anonymous", isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isFilterNetworkTrafficEnabled, isLimitAccessToResourceOverNetworkEnabled, isMultiFactorAuthenticationEnabled, isNetworkIntrusionPreventionEnabled, isNetworkSegmentationEnabled, isSSLOrTLSInspectionEnabled);
  }

  public NetworkSharedDrive() {
    this("Anonymous");
  }

  public class TaintSharedContent extends InternalNetwork.TaintSharedContent {
    private Set<AttackStep> _cacheChildrenTaintSharedContent;

    public TaintSharedContent(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTaintSharedContent == null) {
        _cacheChildrenTaintSharedContent = new HashSet<>();
        if (NetworkSharedDrive.this instanceof NetworkSharedDrive) {
          for (Router _0 : ((asset.NetworkSharedDrive) NetworkSharedDrive.this).router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenTaintSharedContent.add(_2.executeCode);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenTaintSharedContent) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("NetworkSharedDrive.taintSharedContent");
    }
  }

  public class DataFromNetworkSharedDrive extends InternalNetwork.DataFromNetworkSharedDrive {
    private Set<AttackStep> _cacheChildrenDataFromNetworkSharedDrive;

    public DataFromNetworkSharedDrive(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDataFromNetworkSharedDrive == null) {
        _cacheChildrenDataFromNetworkSharedDrive = new HashSet<>();
        if (NetworkSharedDrive.this instanceof NetworkSharedDrive) {
          for (Router _0 : ((asset.NetworkSharedDrive) NetworkSharedDrive.this).router) {
            for (Computer _1 : _0.computer) {
              for (OS _2 : _1.os) {
                _cacheChildrenDataFromNetworkSharedDrive.add(_2.sensitiveDataCollected);
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDataFromNetworkSharedDrive) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("NetworkSharedDrive.dataFromNetworkSharedDrive");
    }
  }
}
