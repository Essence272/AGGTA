package asset;

import core.AttackStep;
import core.AttackStepMin;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class HardwareAddition extends Computer {
  public PhysicalAccess physicalAccess;

  public HardwareAddition(String name, boolean isDisableOrRemoveFeatureOrProgramEnabled) {
    super(name, isDisableOrRemoveFeatureOrProgramEnabled);
    assetClassName = "HardwareAddition";
    AttackStep.allAttackSteps.remove(physicalAccess);
    physicalAccess = new PhysicalAccess(name);
    AttackStep.allAttackSteps.remove(hardwareAdditions);
    hardwareAdditions = new HardwareAdditions(name);
  }

  public HardwareAddition(String name) {
    super(name);
    assetClassName = "HardwareAddition";
    AttackStep.allAttackSteps.remove(physicalAccess);
    physicalAccess = new PhysicalAccess(name);
    AttackStep.allAttackSteps.remove(hardwareAdditions);
    hardwareAdditions = new HardwareAdditions(name);
  }

  public HardwareAddition(boolean isDisableOrRemoveFeatureOrProgramEnabled) {
    this("Anonymous", isDisableOrRemoveFeatureOrProgramEnabled);
  }

  public HardwareAddition() {
    this("Anonymous");
  }

  public class PhysicalAccess extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenPhysicalAccess;

    public PhysicalAccess(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenPhysicalAccess == null) {
        _cacheChildrenPhysicalAccess = new HashSet<>();
        _cacheChildrenPhysicalAccess.add(hardwareAdditions);
        if (HardwareAddition.this instanceof HardwareAddition) {
          for (OS _0 : ((asset.HardwareAddition) HardwareAddition.this).os) {
            _cacheChildrenPhysicalAccess.add(_0.attemptAccessibilityFeatures);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenPhysicalAccess) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("HardwareAddition.physicalAccess");
    }
  }

  public class HardwareAdditions extends Computer.HardwareAdditions {
    private Set<AttackStep> _cacheChildrenHardwareAdditions;

    private Set<AttackStep> _cacheParentHardwareAdditions;

    public HardwareAdditions(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenHardwareAdditions == null) {
        _cacheChildrenHardwareAdditions = new HashSet<>();
        if (HardwareAddition.this instanceof HardwareAddition) {
          for (OS _0 : ((asset.HardwareAddition) HardwareAddition.this).os) {
            _cacheChildrenHardwareAdditions.add(_0.executeCode);
          }
        }
        if (HardwareAddition.this instanceof HardwareAddition) {
          for (OS _1 : ((asset.HardwareAddition) HardwareAddition.this).os) {
            _cacheChildrenHardwareAdditions.add(_1.attemptGatekeeperBypass);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenHardwareAdditions) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHardwareAdditions == null) {
        _cacheParentHardwareAdditions = new HashSet<>();
        _cacheParentHardwareAdditions.add(physicalAccess);
      }
      for (AttackStep attackStep : _cacheParentHardwareAdditions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("HardwareAddition.hardwareAdditions");
    }
  }
}
