package asset;

import core.AttackStep;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class CloudService extends Service {
  public CloudService(String name, boolean isAuditEnabled,
      boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    super(name, isAuditEnabled, isApplicationIsolationAndSandboxingEnabled, isPrivilegedAccountManagementEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isExploitProtectionEnabled, isNetworkSegmentationEnabled, isThreatIntelligenceProgramEnabled, isPasswordPoliciesEnabled, isUpdateSoftwareEnabled, isSoftwareConfigurationEnabled, isActiveDirectoryConfigurationEnabled, isVulnerabilityScanningEnabled, isMultiFactorAuthenticationEnabled);
    assetClassName = "CloudService";
    AttackStep.allAttackSteps.remove(applicationAccessToken);
    applicationAccessToken = new ApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(accessCloudBasedServiceResources);
    accessCloudBasedServiceResources = new AccessCloudBasedServiceResources(name);
    AttackStep.allAttackSteps.remove(stealApplicationAccessToken);
    stealApplicationAccessToken = new StealApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(sensitiveDataCollected);
    sensitiveDataCollected = new SensitiveDataCollected(name);
    AttackStep.allAttackSteps.remove(cloudServiceInformationCollected);
    cloudServiceInformationCollected = new CloudServiceInformationCollected(name);
    AttackStep.allAttackSteps.remove(cloudAccount);
    cloudAccount = new CloudAccount(name);
    AttackStep.allAttackSteps.remove(cloudAccounts);
    cloudAccounts = new CloudAccounts(name);
    AttackStep.allAttackSteps.remove(cloudGroups);
    cloudGroups = new CloudGroups(name);
    AttackStep.allAttackSteps.remove(cloudInstanceMetadataAPI);
    cloudInstanceMetadataAPI = new CloudInstanceMetadataAPI(name);
    AttackStep.allAttackSteps.remove(cloudServiceDiscovery);
    cloudServiceDiscovery = new CloudServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(cloudServiceDashboard);
    cloudServiceDashboard = new CloudServiceDashboard(name);
    AttackStep.allAttackSteps.remove(disableOrModifyCloudFirewall);
    disableOrModifyCloudFirewall = new DisableOrModifyCloudFirewall(name);
    AttackStep.allAttackSteps.remove(emailAccount);
    emailAccount = new EmailAccount(name);
    AttackStep.allAttackSteps.remove(emailAddressCollected);
    emailAddressCollected = new EmailAddressCollected(name);
    AttackStep.allAttackSteps.remove(additionalAzureServicePrincipalCredentials);
    additionalAzureServicePrincipalCredentials = new AdditionalAzureServicePrincipalCredentials(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(addOffice365GlobalAdministratorRole);
    addOffice365GlobalAdministratorRole = new AddOffice365GlobalAdministratorRole(name);
    AttackStep.allAttackSteps.remove(modifyCloudComputeInfrastructure);
    modifyCloudComputeInfrastructure = new ModifyCloudComputeInfrastructure(name);
    AttackStep.allAttackSteps.remove(createSnapshot);
    createSnapshot = new CreateSnapshot(name);
    AttackStep.allAttackSteps.remove(createCloudInstance);
    createCloudInstance = new CreateCloudInstance(name);
    AttackStep.allAttackSteps.remove(deleteCloudInstance);
    deleteCloudInstance = new DeleteCloudInstance(name);
    AttackStep.allAttackSteps.remove(revertCloudInstance);
    revertCloudInstance = new RevertCloudInstance(name);
    AttackStep.allAttackSteps.remove(remoteEmailCollection);
    remoteEmailCollection = new RemoteEmailCollection(name);
    AttackStep.allAttackSteps.remove(emailForwardingRule);
    emailForwardingRule = new EmailForwardingRule(name);
    AttackStep.allAttackSteps.remove(applicationExhaustionFlood);
    applicationExhaustionFlood = new ApplicationExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(applicationOrSystemExploitation);
    applicationOrSystemExploitation = new ApplicationOrSystemExploitation(name);
    AttackStep.allAttackSteps.remove(officeTemplateMacros);
    officeTemplateMacros = new OfficeTemplateMacros(name);
    AttackStep.allAttackSteps.remove(officeTest);
    officeTest = new OfficeTest(name);
    AttackStep.allAttackSteps.remove(outlookForms);
    outlookForms = new OutlookForms(name);
    AttackStep.allAttackSteps.remove(outlookHomePage);
    outlookHomePage = new OutlookHomePage(name);
    AttackStep.allAttackSteps.remove(outlookRules);
    outlookRules = new OutlookRules(name);
    AttackStep.allAttackSteps.remove(addIns);
    addIns = new AddIns(name);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, isDisableOrRemoveFeatureOrProgramEnabled);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, isSoftwareConfigurationEnabled);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, isUpdateSoftwareEnabled);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, isPrivilegedAccountManagementEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, isNetworkSegmentationEnabled);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, isAuditEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
  }

  public CloudService(String name) {
    super(name);
    assetClassName = "CloudService";
    AttackStep.allAttackSteps.remove(applicationAccessToken);
    applicationAccessToken = new ApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(accessCloudBasedServiceResources);
    accessCloudBasedServiceResources = new AccessCloudBasedServiceResources(name);
    AttackStep.allAttackSteps.remove(stealApplicationAccessToken);
    stealApplicationAccessToken = new StealApplicationAccessToken(name);
    AttackStep.allAttackSteps.remove(persistence);
    persistence = new Persistence(name);
    AttackStep.allAttackSteps.remove(sensitiveDataCollected);
    sensitiveDataCollected = new SensitiveDataCollected(name);
    AttackStep.allAttackSteps.remove(cloudServiceInformationCollected);
    cloudServiceInformationCollected = new CloudServiceInformationCollected(name);
    AttackStep.allAttackSteps.remove(cloudAccount);
    cloudAccount = new CloudAccount(name);
    AttackStep.allAttackSteps.remove(cloudAccounts);
    cloudAccounts = new CloudAccounts(name);
    AttackStep.allAttackSteps.remove(cloudGroups);
    cloudGroups = new CloudGroups(name);
    AttackStep.allAttackSteps.remove(cloudInstanceMetadataAPI);
    cloudInstanceMetadataAPI = new CloudInstanceMetadataAPI(name);
    AttackStep.allAttackSteps.remove(cloudServiceDiscovery);
    cloudServiceDiscovery = new CloudServiceDiscovery(name);
    AttackStep.allAttackSteps.remove(cloudServiceDashboard);
    cloudServiceDashboard = new CloudServiceDashboard(name);
    AttackStep.allAttackSteps.remove(disableOrModifyCloudFirewall);
    disableOrModifyCloudFirewall = new DisableOrModifyCloudFirewall(name);
    AttackStep.allAttackSteps.remove(emailAccount);
    emailAccount = new EmailAccount(name);
    AttackStep.allAttackSteps.remove(emailAddressCollected);
    emailAddressCollected = new EmailAddressCollected(name);
    AttackStep.allAttackSteps.remove(additionalAzureServicePrincipalCredentials);
    additionalAzureServicePrincipalCredentials = new AdditionalAzureServicePrincipalCredentials(name);
    AttackStep.allAttackSteps.remove(exchangeEmailDelegatePermissions);
    exchangeEmailDelegatePermissions = new ExchangeEmailDelegatePermissions(name);
    AttackStep.allAttackSteps.remove(addOffice365GlobalAdministratorRole);
    addOffice365GlobalAdministratorRole = new AddOffice365GlobalAdministratorRole(name);
    AttackStep.allAttackSteps.remove(modifyCloudComputeInfrastructure);
    modifyCloudComputeInfrastructure = new ModifyCloudComputeInfrastructure(name);
    AttackStep.allAttackSteps.remove(createSnapshot);
    createSnapshot = new CreateSnapshot(name);
    AttackStep.allAttackSteps.remove(createCloudInstance);
    createCloudInstance = new CreateCloudInstance(name);
    AttackStep.allAttackSteps.remove(deleteCloudInstance);
    deleteCloudInstance = new DeleteCloudInstance(name);
    AttackStep.allAttackSteps.remove(revertCloudInstance);
    revertCloudInstance = new RevertCloudInstance(name);
    AttackStep.allAttackSteps.remove(remoteEmailCollection);
    remoteEmailCollection = new RemoteEmailCollection(name);
    AttackStep.allAttackSteps.remove(emailForwardingRule);
    emailForwardingRule = new EmailForwardingRule(name);
    AttackStep.allAttackSteps.remove(applicationExhaustionFlood);
    applicationExhaustionFlood = new ApplicationExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(serviceExhaustionFlood);
    serviceExhaustionFlood = new ServiceExhaustionFlood(name);
    AttackStep.allAttackSteps.remove(applicationOrSystemExploitation);
    applicationOrSystemExploitation = new ApplicationOrSystemExploitation(name);
    AttackStep.allAttackSteps.remove(officeTemplateMacros);
    officeTemplateMacros = new OfficeTemplateMacros(name);
    AttackStep.allAttackSteps.remove(officeTest);
    officeTest = new OfficeTest(name);
    AttackStep.allAttackSteps.remove(outlookForms);
    outlookForms = new OutlookForms(name);
    AttackStep.allAttackSteps.remove(outlookHomePage);
    outlookHomePage = new OutlookHomePage(name);
    AttackStep.allAttackSteps.remove(outlookRules);
    outlookRules = new OutlookRules(name);
    AttackStep.allAttackSteps.remove(addIns);
    addIns = new AddIns(name);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, false);
    if (softwareConfiguration != null) {
      AttackStep.allAttackSteps.remove(softwareConfiguration.disable);
    }
    Defense.allDefenses.remove(softwareConfiguration);
    softwareConfiguration = new SoftwareConfiguration(name, false);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, false);
    if (privilegedAccountManagement != null) {
      AttackStep.allAttackSteps.remove(privilegedAccountManagement.disable);
    }
    Defense.allDefenses.remove(privilegedAccountManagement);
    privilegedAccountManagement = new PrivilegedAccountManagement(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, false);
    if (audit != null) {
      AttackStep.allAttackSteps.remove(audit.disable);
    }
    Defense.allDefenses.remove(audit);
    audit = new Audit(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
  }

  public CloudService(boolean isAuditEnabled, boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    this("Anonymous", isAuditEnabled, isApplicationIsolationAndSandboxingEnabled, isPrivilegedAccountManagementEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isExploitProtectionEnabled, isNetworkSegmentationEnabled, isThreatIntelligenceProgramEnabled, isPasswordPoliciesEnabled, isUpdateSoftwareEnabled, isSoftwareConfigurationEnabled, isActiveDirectoryConfigurationEnabled, isVulnerabilityScanningEnabled, isMultiFactorAuthenticationEnabled);
  }

  public CloudService() {
    this("Anonymous");
  }

  public class ApplicationAccessToken extends Service.ApplicationAccessToken {
    private Set<AttackStep> _cacheChildrenApplicationAccessToken;

    private Set<AttackStep> _cacheParentApplicationAccessToken;

    public ApplicationAccessToken(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenApplicationAccessToken == null) {
        _cacheChildrenApplicationAccessToken = new HashSet<>();
        _cacheChildrenApplicationAccessToken.add(accessCloudBasedServiceResources);
      }
      for (AttackStep attackStep : _cacheChildrenApplicationAccessToken) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentApplicationAccessToken == null) {
        _cacheParentApplicationAccessToken = new HashSet<>();
        _cacheParentApplicationAccessToken.add(stealApplicationAccessToken);
      }
      for (AttackStep attackStep : _cacheParentApplicationAccessToken) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.applicationAccessToken");
    }
  }

  public class AccessCloudBasedServiceResources extends Service.AccessCloudBasedServiceResources {
    private Set<AttackStep> _cacheParentAccessCloudBasedServiceResources;

    public AccessCloudBasedServiceResources(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAccessCloudBasedServiceResources == null) {
        _cacheParentAccessCloudBasedServiceResources = new HashSet<>();
        _cacheParentAccessCloudBasedServiceResources.add(applicationAccessToken);
      }
      for (AttackStep attackStep : _cacheParentAccessCloudBasedServiceResources) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.accessCloudBasedServiceResources");
    }
  }

  public class StealApplicationAccessToken extends Service.StealApplicationAccessToken {
    private Set<AttackStep> _cacheChildrenStealApplicationAccessToken;

    private Set<AttackStep> _cacheParentStealApplicationAccessToken;

    public StealApplicationAccessToken(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenStealApplicationAccessToken == null) {
        _cacheChildrenStealApplicationAccessToken = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          for (Browser _0 : ((asset.CloudService) CloudService.this).browser) {
            _cacheChildrenStealApplicationAccessToken.add(_0.spearphishingLink);
          }
        }
        _cacheChildrenStealApplicationAccessToken.add(applicationAccessToken);
      }
      for (AttackStep attackStep : _cacheChildrenStealApplicationAccessToken) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentStealApplicationAccessToken == null) {
        _cacheParentStealApplicationAccessToken = new HashSet<>();
        _cacheParentStealApplicationAccessToken.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentStealApplicationAccessToken) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.stealApplicationAccessToken");
    }
  }

  public class Persistence extends Service.Persistence {
    private Set<AttackStep> _cacheParentPersistence;

    public Persistence(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPersistence == null) {
        _cacheParentPersistence = new HashSet<>();
        _cacheParentPersistence.add(additionalAzureServicePrincipalCredentials);
      }
      for (AttackStep attackStep : _cacheParentPersistence) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.persistence");
    }
  }

  public class SensitiveDataCollected extends Service.SensitiveDataCollected {
    private Set<AttackStep> _cacheParentSensitiveDataCollected;

    public SensitiveDataCollected(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentSensitiveDataCollected == null) {
        _cacheParentSensitiveDataCollected = new HashSet<>();
        _cacheParentSensitiveDataCollected.add(cloudInstanceMetadataAPI);
        _cacheParentSensitiveDataCollected.add(remoteEmailCollection);
        _cacheParentSensitiveDataCollected.add(emailForwardingRule);
      }
      for (AttackStep attackStep : _cacheParentSensitiveDataCollected) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.sensitiveDataCollected");
    }
  }

  public class CloudServiceInformationCollected extends Service.CloudServiceInformationCollected {
    private Set<AttackStep> _cacheParentCloudServiceInformationCollected;

    public CloudServiceInformationCollected(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudServiceInformationCollected == null) {
        _cacheParentCloudServiceInformationCollected = new HashSet<>();
        _cacheParentCloudServiceInformationCollected.add(cloudServiceDiscovery);
        _cacheParentCloudServiceInformationCollected.add(cloudServiceDashboard);
      }
      for (AttackStep attackStep : _cacheParentCloudServiceInformationCollected) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.cloudServiceInformationCollected");
    }
  }

  public class CloudAccount extends Service.CloudAccount {
    private Set<AttackStep> _cacheChildrenCloudAccount;

    private Set<AttackStep> _cacheParentCloudAccount;

    public CloudAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCloudAccount == null) {
        _cacheChildrenCloudAccount = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenCloudAccount.add(((asset.CloudService) CloudService.this).os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCloudAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudAccount == null) {
        _cacheParentCloudAccount = new HashSet<>();
        _cacheParentCloudAccount.add(networkSegmentation.disable);
      }
      for (AttackStep attackStep : _cacheParentCloudAccount) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.cloudAccount");
    }
  }

  public class CloudAccounts extends Service.CloudAccounts {
    private Set<AttackStep> _cacheChildrenCloudAccounts;

    private Set<AttackStep> _cacheParentCloudAccounts;

    public CloudAccounts(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCloudAccounts == null) {
        _cacheChildrenCloudAccounts = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          _cacheChildrenCloudAccounts.add(((asset.CloudService) CloudService.this).attemptTrustedRelationship);
        }
        if (CloudService.this instanceof CloudService) {
          _cacheChildrenCloudAccounts.add(((asset.CloudService) CloudService.this).remoteServices);
        }
        if (CloudService.this instanceof CloudService) {
          _cacheChildrenCloudAccounts.add(((asset.CloudService) CloudService.this).attemptExternalRemoteServices);
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _0 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _1 : _0.router) {
                for (InternalNetwork _2 : _1.internalNetwork) {
                  _cacheChildrenCloudAccounts.add(_2.bypassNetworkIntrusionDetection);
                }
              }
            }
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _3 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _4 : _3.router) {
                if (_4.firewall != null) {
                  _cacheChildrenCloudAccounts.add(_4.firewall.bypassFirewall);
                }
              }
            }
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenCloudAccounts.add(((asset.CloudService) CloudService.this).os.bypassHostIntrusionPrevention);
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenCloudAccounts.add(((asset.CloudService) CloudService.this).os.bypassApplicationControl);
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenCloudAccounts.add(((asset.CloudService) CloudService.this).os.bypassSystemAccessControls);
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenCloudAccounts.add(((asset.CloudService) CloudService.this).os.bypassAntivirus);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCloudAccounts) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCloudAccounts == null) {
        _cacheParentCloudAccounts = new HashSet<>();
        _cacheParentCloudAccounts.add(privilegedAccountManagement.disable);
        _cacheParentCloudAccounts.add(passwordPolicies.disable);
      }
      for (AttackStep attackStep : _cacheParentCloudAccounts) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.cloudAccounts");
    }
  }

  public class CloudGroups extends Service.CloudGroups {
    public CloudGroups(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.cloudGroups");
    }
  }

  public class CloudInstanceMetadataAPI extends Service.CloudInstanceMetadataAPI {
    private Set<AttackStep> _cacheChildrenCloudInstanceMetadataAPI;

    public CloudInstanceMetadataAPI(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCloudInstanceMetadataAPI == null) {
        _cacheChildrenCloudInstanceMetadataAPI = new HashSet<>();
        _cacheChildrenCloudInstanceMetadataAPI.add(sensitiveDataCollected);
      }
      for (AttackStep attackStep : _cacheChildrenCloudInstanceMetadataAPI) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.cloudInstanceMetadataAPI");
    }
  }

  public class CloudServiceDiscovery extends Service.CloudServiceDiscovery {
    private Set<AttackStep> _cacheChildrenCloudServiceDiscovery;

    public CloudServiceDiscovery(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCloudServiceDiscovery == null) {
        _cacheChildrenCloudServiceDiscovery = new HashSet<>();
        _cacheChildrenCloudServiceDiscovery.add(cloudServiceInformationCollected);
      }
      for (AttackStep attackStep : _cacheChildrenCloudServiceDiscovery) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.cloudServiceDiscovery");
    }
  }

  public class CloudServiceDashboard extends Service.CloudServiceDashboard {
    private Set<AttackStep> _cacheChildrenCloudServiceDashboard;

    public CloudServiceDashboard(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCloudServiceDashboard == null) {
        _cacheChildrenCloudServiceDashboard = new HashSet<>();
        _cacheChildrenCloudServiceDashboard.add(cloudServiceInformationCollected);
      }
      for (AttackStep attackStep : _cacheChildrenCloudServiceDashboard) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.cloudServiceDashboard");
    }
  }

  public class DisableOrModifyCloudFirewall extends Service.DisableOrModifyCloudFirewall {
    private Set<AttackStep> _cacheChildrenDisableOrModifyCloudFirewall;

    private Set<AttackStep> _cacheParentDisableOrModifyCloudFirewall;

    public DisableOrModifyCloudFirewall(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDisableOrModifyCloudFirewall == null) {
        _cacheChildrenDisableOrModifyCloudFirewall = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _0 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _1 : _0.router) {
                for (InternalNetwork _2 : _1.internalNetwork) {
                  _cacheChildrenDisableOrModifyCloudFirewall.add(_2.c2Connected);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDisableOrModifyCloudFirewall) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDisableOrModifyCloudFirewall == null) {
        _cacheParentDisableOrModifyCloudFirewall = new HashSet<>();
        _cacheParentDisableOrModifyCloudFirewall.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentDisableOrModifyCloudFirewall) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.disableOrModifyCloudFirewall");
    }
  }

  public class EmailAccount extends Service.EmailAccount {
    private Set<AttackStep> _cacheChildrenEmailAccount;

    public EmailAccount(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenEmailAccount == null) {
        _cacheChildrenEmailAccount = new HashSet<>();
        _cacheChildrenEmailAccount.add(emailAddressCollected);
      }
      for (AttackStep attackStep : _cacheChildrenEmailAccount) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.emailAccount");
    }
  }

  public class EmailAddressCollected extends Service.EmailAddressCollected {
    private Set<AttackStep> _cacheParentEmailAddressCollected;

    public EmailAddressCollected(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentEmailAddressCollected == null) {
        _cacheParentEmailAddressCollected = new HashSet<>();
        _cacheParentEmailAddressCollected.add(emailAccount);
      }
      for (AttackStep attackStep : _cacheParentEmailAddressCollected) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.emailAddressCollected");
    }
  }

  public class AdditionalAzureServicePrincipalCredentials extends Service.AdditionalAzureServicePrincipalCredentials {
    private Set<AttackStep> _cacheChildrenAdditionalAzureServicePrincipalCredentials;

    private Set<AttackStep> _cacheParentAdditionalAzureServicePrincipalCredentials;

    public AdditionalAzureServicePrincipalCredentials(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAdditionalAzureServicePrincipalCredentials == null) {
        _cacheChildrenAdditionalAzureServicePrincipalCredentials = new HashSet<>();
        _cacheChildrenAdditionalAzureServicePrincipalCredentials.add(persistence);
      }
      for (AttackStep attackStep : _cacheChildrenAdditionalAzureServicePrincipalCredentials) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAdditionalAzureServicePrincipalCredentials == null) {
        _cacheParentAdditionalAzureServicePrincipalCredentials = new HashSet<>();
        _cacheParentAdditionalAzureServicePrincipalCredentials.add(privilegedAccountManagement.disable);
        _cacheParentAdditionalAzureServicePrincipalCredentials.add(networkSegmentation.disable);
      }
      for (AttackStep attackStep : _cacheParentAdditionalAzureServicePrincipalCredentials) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.additionalAzureServicePrincipalCredentials");
    }
  }

  public class ExchangeEmailDelegatePermissions extends Service.ExchangeEmailDelegatePermissions {
    private Set<AttackStep> _cacheChildrenExchangeEmailDelegatePermissions;

    private Set<AttackStep> _cacheParentExchangeEmailDelegatePermissions;

    public ExchangeEmailDelegatePermissions(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenExchangeEmailDelegatePermissions == null) {
        _cacheChildrenExchangeEmailDelegatePermissions = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenExchangeEmailDelegatePermissions.add(((asset.CloudService) CloudService.this).os.internalSpearphishing);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenExchangeEmailDelegatePermissions) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExchangeEmailDelegatePermissions == null) {
        _cacheParentExchangeEmailDelegatePermissions = new HashSet<>();
        _cacheParentExchangeEmailDelegatePermissions.add(privilegedAccountManagement.disable);
        _cacheParentExchangeEmailDelegatePermissions.add(multiFactorAuthentication.disable);
      }
      for (AttackStep attackStep : _cacheParentExchangeEmailDelegatePermissions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.exchangeEmailDelegatePermissions");
    }
  }

  public class AddOffice365GlobalAdministratorRole extends Service.AddOffice365GlobalAdministratorRole {
    private Set<AttackStep> _cacheChildrenAddOffice365GlobalAdministratorRole;

    private Set<AttackStep> _cacheParentAddOffice365GlobalAdministratorRole;

    public AddOffice365GlobalAdministratorRole(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAddOffice365GlobalAdministratorRole == null) {
        _cacheChildrenAddOffice365GlobalAdministratorRole = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (AdminAccount _0 : ((asset.CloudService) CloudService.this).os.adminAccount) {
              _cacheChildrenAddOffice365GlobalAdministratorRole.add(_0.attemptCreateAccount);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenAddOffice365GlobalAdministratorRole) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAddOffice365GlobalAdministratorRole == null) {
        _cacheParentAddOffice365GlobalAdministratorRole = new HashSet<>();
        _cacheParentAddOffice365GlobalAdministratorRole.add(privilegedAccountManagement.disable);
        _cacheParentAddOffice365GlobalAdministratorRole.add(multiFactorAuthentication.disable);
      }
      for (AttackStep attackStep : _cacheParentAddOffice365GlobalAdministratorRole) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.addOffice365GlobalAdministratorRole");
    }
  }

  public class ModifyCloudComputeInfrastructure extends Service.ModifyCloudComputeInfrastructure {
    private Set<AttackStep> _cacheChildrenModifyCloudComputeInfrastructure;

    public ModifyCloudComputeInfrastructure(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenModifyCloudComputeInfrastructure == null) {
        _cacheChildrenModifyCloudComputeInfrastructure = new HashSet<>();
        _cacheChildrenModifyCloudComputeInfrastructure.add(createSnapshot);
        _cacheChildrenModifyCloudComputeInfrastructure.add(createCloudInstance);
        _cacheChildrenModifyCloudComputeInfrastructure.add(deleteCloudInstance);
        _cacheChildrenModifyCloudComputeInfrastructure.add(revertCloudInstance);
      }
      for (AttackStep attackStep : _cacheChildrenModifyCloudComputeInfrastructure) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.modifyCloudComputeInfrastructure");
    }
  }

  public class CreateSnapshot extends Service.CreateSnapshot {
    private Set<AttackStep> _cacheChildrenCreateSnapshot;

    private Set<AttackStep> _cacheParentCreateSnapshot;

    public CreateSnapshot(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCreateSnapshot == null) {
        _cacheChildrenCreateSnapshot = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _0 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _1 : _0.router) {
                for (ExternalNetwork _2 : _1.externalNetwork) {
                  _cacheChildrenCreateSnapshot.add(_2.bypassNetworkIntrusionDetection);
                }
              }
            }
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _3 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _4 : _3.router) {
                for (InternalNetwork _5 : _4.internalNetwork) {
                  _cacheChildrenCreateSnapshot.add(_5.bypassNetworkIntrusionDetection);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCreateSnapshot) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCreateSnapshot == null) {
        _cacheParentCreateSnapshot = new HashSet<>();
        _cacheParentCreateSnapshot.add(modifyCloudComputeInfrastructure);
        _cacheParentCreateSnapshot.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentCreateSnapshot) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.createSnapshot");
    }
  }

  public class CreateCloudInstance extends Service.CreateCloudInstance {
    private Set<AttackStep> _cacheChildrenCreateCloudInstance;

    private Set<AttackStep> _cacheParentCreateCloudInstance;

    public CreateCloudInstance(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCreateCloudInstance == null) {
        _cacheChildrenCreateCloudInstance = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenCreateCloudInstance.add(((asset.CloudService) CloudService.this).os.dataFromLocalSystem);
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenCreateCloudInstance.add(((asset.CloudService) CloudService.this).os.remoteDataStaging);
          }
        }
        _cacheChildrenCreateCloudInstance.add(deleteCloudInstance);
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _0 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _1 : _0.router) {
                if (_1.firewall != null) {
                  _cacheChildrenCreateCloudInstance.add(_1.firewall.bypassFirewall);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCreateCloudInstance) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCreateCloudInstance == null) {
        _cacheParentCreateCloudInstance = new HashSet<>();
        _cacheParentCreateCloudInstance.add(modifyCloudComputeInfrastructure);
        _cacheParentCreateCloudInstance.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentCreateCloudInstance) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.createCloudInstance");
    }
  }

  public class DeleteCloudInstance extends Service.DeleteCloudInstance {
    private Set<AttackStep> _cacheChildrenDeleteCloudInstance;

    private Set<AttackStep> _cacheParentDeleteCloudInstance;

    public DeleteCloudInstance(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenDeleteCloudInstance == null) {
        _cacheChildrenDeleteCloudInstance = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _0 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _1 : _0.router) {
                for (ExternalNetwork _2 : _1.externalNetwork) {
                  _cacheChildrenDeleteCloudInstance.add(_2.bypassNetworkIntrusionDetection);
                }
              }
            }
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _3 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _4 : _3.router) {
                for (InternalNetwork _5 : _4.internalNetwork) {
                  _cacheChildrenDeleteCloudInstance.add(_5.bypassNetworkIntrusionDetection);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenDeleteCloudInstance) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDeleteCloudInstance == null) {
        _cacheParentDeleteCloudInstance = new HashSet<>();
        _cacheParentDeleteCloudInstance.add(modifyCloudComputeInfrastructure);
        _cacheParentDeleteCloudInstance.add(createCloudInstance);
        _cacheParentDeleteCloudInstance.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentDeleteCloudInstance) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.deleteCloudInstance");
    }
  }

  public class RevertCloudInstance extends Service.RevertCloudInstance {
    private Set<AttackStep> _cacheChildrenRevertCloudInstance;

    private Set<AttackStep> _cacheParentRevertCloudInstance;

    public RevertCloudInstance(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRevertCloudInstance == null) {
        _cacheChildrenRevertCloudInstance = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _0 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _1 : _0.router) {
                for (ExternalNetwork _2 : _1.externalNetwork) {
                  _cacheChildrenRevertCloudInstance.add(_2.bypassNetworkIntrusionDetection);
                }
              }
            }
          }
        }
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            for (Computer _3 : ((asset.CloudService) CloudService.this).os.computer) {
              for (Router _4 : _3.router) {
                for (InternalNetwork _5 : _4.internalNetwork) {
                  _cacheChildrenRevertCloudInstance.add(_5.bypassNetworkIntrusionDetection);
                }
              }
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenRevertCloudInstance) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRevertCloudInstance == null) {
        _cacheParentRevertCloudInstance = new HashSet<>();
        _cacheParentRevertCloudInstance.add(modifyCloudComputeInfrastructure);
      }
      for (AttackStep attackStep : _cacheParentRevertCloudInstance) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.revertCloudInstance");
    }
  }

  public class RemoteEmailCollection extends Service.RemoteEmailCollection {
    private Set<AttackStep> _cacheChildrenRemoteEmailCollection;

    private Set<AttackStep> _cacheParentRemoteEmailCollection;

    public RemoteEmailCollection(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenRemoteEmailCollection == null) {
        _cacheChildrenRemoteEmailCollection = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenRemoteEmailCollection.add(((asset.CloudService) CloudService.this).os.attemptRemoteDesktopProtocol);
          }
        }
        _cacheChildrenRemoteEmailCollection.add(sensitiveDataCollected);
      }
      for (AttackStep attackStep : _cacheChildrenRemoteEmailCollection) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentRemoteEmailCollection == null) {
        _cacheParentRemoteEmailCollection = new HashSet<>();
        _cacheParentRemoteEmailCollection.add(multiFactorAuthentication.disable);
        _cacheParentRemoteEmailCollection.add(audit.disable);
      }
      for (AttackStep attackStep : _cacheParentRemoteEmailCollection) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.remoteEmailCollection");
    }
  }

  public class EmailForwardingRule extends Service.EmailForwardingRule {
    private Set<AttackStep> _cacheChildrenEmailForwardingRule;

    public EmailForwardingRule(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenEmailForwardingRule == null) {
        _cacheChildrenEmailForwardingRule = new HashSet<>();
        _cacheChildrenEmailForwardingRule.add(sensitiveDataCollected);
      }
      for (AttackStep attackStep : _cacheChildrenEmailForwardingRule) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.emailForwardingRule");
    }
  }

  public class ApplicationExhaustionFlood extends Service.ApplicationExhaustionFlood {
    private Set<AttackStep> _cacheChildrenApplicationExhaustionFlood;

    public ApplicationExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenApplicationExhaustionFlood == null) {
        _cacheChildrenApplicationExhaustionFlood = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          _cacheChildrenApplicationExhaustionFlood.add(((asset.CloudService) CloudService.this).blockUserAccess);
        }
      }
      for (AttackStep attackStep : _cacheChildrenApplicationExhaustionFlood) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.applicationExhaustionFlood");
    }
  }

  public class ServiceExhaustionFlood extends Service.ServiceExhaustionFlood {
    private Set<AttackStep> _cacheChildrenServiceExhaustionFlood;

    public ServiceExhaustionFlood(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenServiceExhaustionFlood == null) {
        _cacheChildrenServiceExhaustionFlood = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenServiceExhaustionFlood.add(((asset.CloudService) CloudService.this).os.attemptServiceStop);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenServiceExhaustionFlood) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.serviceExhaustionFlood");
    }
  }

  public class ApplicationOrSystemExploitation extends Service.ApplicationOrSystemExploitation {
    public ApplicationOrSystemExploitation(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.applicationOrSystemExploitation");
    }
  }

  public class OfficeTemplateMacros extends Service.OfficeTemplateMacros {
    private Set<AttackStep> _cacheChildrenOfficeTemplateMacros;

    private Set<AttackStep> _cacheParentOfficeTemplateMacros;

    public OfficeTemplateMacros(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOfficeTemplateMacros == null) {
        _cacheChildrenOfficeTemplateMacros = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenOfficeTemplateMacros.add(((asset.CloudService) CloudService.this).os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenOfficeTemplateMacros) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOfficeTemplateMacros == null) {
        _cacheParentOfficeTemplateMacros = new HashSet<>();
        _cacheParentOfficeTemplateMacros.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentOfficeTemplateMacros) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.officeTemplateMacros");
    }
  }

  public class OfficeTest extends Service.OfficeTest {
    private Set<AttackStep> _cacheChildrenOfficeTest;

    private Set<AttackStep> _cacheParentOfficeTest;

    public OfficeTest(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOfficeTest == null) {
        _cacheChildrenOfficeTest = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenOfficeTest.add(((asset.CloudService) CloudService.this).os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenOfficeTest) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOfficeTest == null) {
        _cacheParentOfficeTest = new HashSet<>();
        _cacheParentOfficeTest.add(softwareConfiguration.disable);
      }
      for (AttackStep attackStep : _cacheParentOfficeTest) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.officeTest");
    }
  }

  public class OutlookForms extends Service.OutlookForms {
    private Set<AttackStep> _cacheChildrenOutlookForms;

    private Set<AttackStep> _cacheParentOutlookForms;

    public OutlookForms(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOutlookForms == null) {
        _cacheChildrenOutlookForms = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenOutlookForms.add(((asset.CloudService) CloudService.this).os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenOutlookForms) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOutlookForms == null) {
        _cacheParentOutlookForms = new HashSet<>();
        _cacheParentOutlookForms.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentOutlookForms) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.outlookForms");
    }
  }

  public class OutlookHomePage extends Service.OutlookHomePage {
    private Set<AttackStep> _cacheChildrenOutlookHomePage;

    private Set<AttackStep> _cacheParentOutlookHomePage;

    public OutlookHomePage(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOutlookHomePage == null) {
        _cacheChildrenOutlookHomePage = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenOutlookHomePage.add(((asset.CloudService) CloudService.this).os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenOutlookHomePage) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOutlookHomePage == null) {
        _cacheParentOutlookHomePage = new HashSet<>();
        _cacheParentOutlookHomePage.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentOutlookHomePage) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.outlookHomePage");
    }
  }

  public class OutlookRules extends Service.OutlookRules {
    private Set<AttackStep> _cacheChildrenOutlookRules;

    private Set<AttackStep> _cacheParentOutlookRules;

    public OutlookRules(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenOutlookRules == null) {
        _cacheChildrenOutlookRules = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenOutlookRules.add(((asset.CloudService) CloudService.this).os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenOutlookRules) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentOutlookRules == null) {
        _cacheParentOutlookRules = new HashSet<>();
        _cacheParentOutlookRules.add(updateSoftware.disable);
      }
      for (AttackStep attackStep : _cacheParentOutlookRules) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.outlookRules");
    }
  }

  public class AddIns extends Service.AddIns {
    private Set<AttackStep> _cacheChildrenAddIns;

    public AddIns(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAddIns == null) {
        _cacheChildrenAddIns = new HashSet<>();
        if (CloudService.this instanceof CloudService) {
          if (((asset.CloudService) CloudService.this).os != null) {
            _cacheChildrenAddIns.add(((asset.CloudService) CloudService.this).os.persistence);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenAddIns) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("CloudService.addIns");
    }
  }

  public class DisableOrRemoveFeatureOrProgram extends Service.DisableOrRemoveFeatureOrProgram {
    public DisableOrRemoveFeatureOrProgram(String name) {
      this(name, false);
    }

    public DisableOrRemoveFeatureOrProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.DisableOrRemoveFeatureOrProgram.Disable {
      private Set<AttackStep> _cacheChildrenDisableOrRemoveFeatureOrProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenDisableOrRemoveFeatureOrProgram == null) {
          _cacheChildrenDisableOrRemoveFeatureOrProgram = new HashSet<>();
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(officeTemplateMacros);
        }
        for (AttackStep attackStep : _cacheChildrenDisableOrRemoveFeatureOrProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.disableOrRemoveFeatureOrProgram";
      }
    }
  }

  public class SoftwareConfiguration extends Service.SoftwareConfiguration {
    public SoftwareConfiguration(String name) {
      this(name, false);
    }

    public SoftwareConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.SoftwareConfiguration.Disable {
      private Set<AttackStep> _cacheChildrenSoftwareConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenSoftwareConfiguration == null) {
          _cacheChildrenSoftwareConfiguration = new HashSet<>();
          _cacheChildrenSoftwareConfiguration.add(officeTest);
        }
        for (AttackStep attackStep : _cacheChildrenSoftwareConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.softwareConfiguration";
      }
    }
  }

  public class UpdateSoftware extends Service.UpdateSoftware {
    public UpdateSoftware(String name) {
      this(name, false);
    }

    public UpdateSoftware(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.UpdateSoftware.Disable {
      private Set<AttackStep> _cacheChildrenUpdateSoftware;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenUpdateSoftware == null) {
          _cacheChildrenUpdateSoftware = new HashSet<>();
          _cacheChildrenUpdateSoftware.add(outlookForms);
          _cacheChildrenUpdateSoftware.add(outlookHomePage);
          _cacheChildrenUpdateSoftware.add(outlookRules);
        }
        for (AttackStep attackStep : _cacheChildrenUpdateSoftware) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.updateSoftware";
      }
    }
  }

  public class PrivilegedAccountManagement extends Service.PrivilegedAccountManagement {
    public PrivilegedAccountManagement(String name) {
      this(name, false);
    }

    public PrivilegedAccountManagement(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.PrivilegedAccountManagement.Disable {
      private Set<AttackStep> _cacheChildrenPrivilegedAccountManagement;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPrivilegedAccountManagement == null) {
          _cacheChildrenPrivilegedAccountManagement = new HashSet<>();
          _cacheChildrenPrivilegedAccountManagement.add(additionalAzureServicePrincipalCredentials);
          _cacheChildrenPrivilegedAccountManagement.add(cloudAccounts);
          _cacheChildrenPrivilegedAccountManagement.add(exchangeEmailDelegatePermissions);
          _cacheChildrenPrivilegedAccountManagement.add(addOffice365GlobalAdministratorRole);
        }
        for (AttackStep attackStep : _cacheChildrenPrivilegedAccountManagement) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.privilegedAccountManagement";
      }
    }
  }

  public class MultiFactorAuthentication extends Service.MultiFactorAuthentication {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.MultiFactorAuthentication.Disable {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(remoteEmailCollection);
          _cacheChildrenMultiFactorAuthentication.add(exchangeEmailDelegatePermissions);
          _cacheChildrenMultiFactorAuthentication.add(addOffice365GlobalAdministratorRole);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.multiFactorAuthentication";
      }
    }
  }

  public class NetworkSegmentation extends Service.NetworkSegmentation {
    public NetworkSegmentation(String name) {
      this(name, false);
    }

    public NetworkSegmentation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.NetworkSegmentation.Disable {
      private Set<AttackStep> _cacheChildrenNetworkSegmentation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenNetworkSegmentation == null) {
          _cacheChildrenNetworkSegmentation = new HashSet<>();
          _cacheChildrenNetworkSegmentation.add(cloudAccount);
          _cacheChildrenNetworkSegmentation.add(additionalAzureServicePrincipalCredentials);
        }
        for (AttackStep attackStep : _cacheChildrenNetworkSegmentation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.networkSegmentation";
      }
    }
  }

  public class Audit extends Service.Audit {
    public Audit(String name) {
      this(name, false);
    }

    public Audit(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.Audit.Disable {
      private Set<AttackStep> _cacheChildrenAudit;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenAudit == null) {
          _cacheChildrenAudit = new HashSet<>();
          _cacheChildrenAudit.add(remoteEmailCollection);
          _cacheChildrenAudit.add(createSnapshot);
          _cacheChildrenAudit.add(createCloudInstance);
          _cacheChildrenAudit.add(deleteCloudInstance);
          _cacheChildrenAudit.add(disableOrModifyCloudFirewall);
          _cacheChildrenAudit.add(stealApplicationAccessToken);
        }
        for (AttackStep attackStep : _cacheChildrenAudit) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.audit";
      }
    }
  }

  public class PasswordPolicies extends Service.PasswordPolicies {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.PasswordPolicies.Disable {
      private Set<AttackStep> _cacheChildrenPasswordPolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPasswordPolicies == null) {
          _cacheChildrenPasswordPolicies = new HashSet<>();
          _cacheChildrenPasswordPolicies.add(cloudAccounts);
        }
        for (AttackStep attackStep : _cacheChildrenPasswordPolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "CloudService.passwordPolicies";
      }
    }
  }
}
