package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMin;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class PeripheralDevice extends Asset {
  public CollectVideo collectVideo;

  public CollectAudio collectAudio;

  public DataExfiltration dataExfiltration;

  public InfectedMedia infectedMedia;

  public DataFromRemovableMedia dataFromRemovableMedia;

  public Set<Computer> computer = new HashSet<>();

  public PeripheralDevice(String name) {
    super(name);
    assetClassName = "PeripheralDevice";
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
    AttackStep.allAttackSteps.remove(collectAudio);
    collectAudio = new CollectAudio(name);
    AttackStep.allAttackSteps.remove(dataExfiltration);
    dataExfiltration = new DataExfiltration(name);
    AttackStep.allAttackSteps.remove(infectedMedia);
    infectedMedia = new InfectedMedia(name);
    AttackStep.allAttackSteps.remove(dataFromRemovableMedia);
    dataFromRemovableMedia = new DataFromRemovableMedia(name);
  }

  public PeripheralDevice() {
    this("Anonymous");
  }

  public void addComputer(Computer computer) {
    this.computer.add(computer);
    computer.peripheralDevice.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("computer")) {
      return Computer.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("computer")) {
      assets.addAll(computer);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(computer);
    return assets;
  }

  public class CollectVideo extends AttackStepMin {
    public CollectVideo(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("PeripheralDevice.collectVideo");
    }
  }

  public class CollectAudio extends AttackStepMin {
    public CollectAudio(String name) {
      super(name);
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("PeripheralDevice.collectAudio");
    }
  }

  public class DataExfiltration extends AttackStepMin {
    private Set<AttackStep> _cacheParentDataExfiltration;

    public DataExfiltration(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataExfiltration == null) {
        _cacheParentDataExfiltration = new HashSet<>();
        for (Computer _0 : computer) {
          for (User _1 : _0.user) {
            _cacheParentDataExfiltration.add(_1.mediaInserted);
          }
        }
        for (Computer _2 : computer) {
          _cacheParentDataExfiltration.add(_2.exfiltrationOverPhysicalMedium);
        }
        for (Computer _3 : computer) {
          _cacheParentDataExfiltration.add(_3.exfiltrationOverUSB);
        }
      }
      for (AttackStep attackStep : _cacheParentDataExfiltration) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("PeripheralDevice.dataExfiltration");
    }
  }

  public class InfectedMedia extends AttackStepMin {
    private Set<AttackStep> _cacheParentInfectedMedia;

    public InfectedMedia(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInfectedMedia == null) {
        _cacheParentInfectedMedia = new HashSet<>();
        for (Computer _0 : computer) {
          for (OS _1 : _0.os) {
            _cacheParentInfectedMedia.add(_1.compromisedDataOrSystem);
          }
        }
        for (Computer _2 : computer) {
          for (OS _3 : _2.os) {
            if (_3 instanceof Windows) {
              _cacheParentInfectedMedia.add(((asset.Windows) _3).replicationThroughRemovableMedia);
            }
          }
        }
        for (Computer _4 : computer) {
          _cacheParentInfectedMedia.add(_4.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentInfectedMedia) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("PeripheralDevice.infectedMedia");
    }
  }

  public class DataFromRemovableMedia extends AttackStepMin {
    private Set<AttackStep> _cacheParentDataFromRemovableMedia;

    public DataFromRemovableMedia(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentDataFromRemovableMedia == null) {
        _cacheParentDataFromRemovableMedia = new HashSet<>();
        for (Computer _0 : computer) {
          _cacheParentDataFromRemovableMedia.add(_0.infectedComputer);
        }
      }
      for (AttackStep attackStep : _cacheParentDataFromRemovableMedia) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("PeripheralDevice.dataFromRemovableMedia");
    }
  }
}
