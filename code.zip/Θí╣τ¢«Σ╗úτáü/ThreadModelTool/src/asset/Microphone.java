package asset;

import core.AttackStep;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Microphone extends PeripheralDevice {
  public Microphone(String name) {
    super(name);
    assetClassName = "Microphone";
    AttackStep.allAttackSteps.remove(collectAudio);
    collectAudio = new CollectAudio(name);
  }

  public Microphone() {
    this("Anonymous");
  }

  public class CollectAudio extends PeripheralDevice.CollectAudio {
    private Set<AttackStep> _cacheChildrenCollectAudio;

    public CollectAudio(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCollectAudio == null) {
        _cacheChildrenCollectAudio = new HashSet<>();
        if (Microphone.this instanceof Microphone) {
          for (Computer _0 : ((asset.Microphone) Microphone.this).computer) {
            _cacheChildrenCollectAudio.add(_0.collectAudio);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCollectAudio) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Microphone.collectAudio");
    }
  }
}
