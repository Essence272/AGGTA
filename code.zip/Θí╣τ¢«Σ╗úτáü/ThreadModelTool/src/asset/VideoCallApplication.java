package asset;

import core.AttackStep;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class VideoCallApplication extends Service {
  public VideoCallApplication(String name, boolean isAuditEnabled,
      boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    super(name, isAuditEnabled, isApplicationIsolationAndSandboxingEnabled, isPrivilegedAccountManagementEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isExploitProtectionEnabled, isNetworkSegmentationEnabled, isThreatIntelligenceProgramEnabled, isPasswordPoliciesEnabled, isUpdateSoftwareEnabled, isSoftwareConfigurationEnabled, isActiveDirectoryConfigurationEnabled, isVulnerabilityScanningEnabled, isMultiFactorAuthenticationEnabled);
    assetClassName = "VideoCallApplication";
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
  }

  public VideoCallApplication(String name) {
    super(name);
    assetClassName = "VideoCallApplication";
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
  }

  public VideoCallApplication(boolean isAuditEnabled,
      boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    this("Anonymous", isAuditEnabled, isApplicationIsolationAndSandboxingEnabled, isPrivilegedAccountManagementEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isExploitProtectionEnabled, isNetworkSegmentationEnabled, isThreatIntelligenceProgramEnabled, isPasswordPoliciesEnabled, isUpdateSoftwareEnabled, isSoftwareConfigurationEnabled, isActiveDirectoryConfigurationEnabled, isVulnerabilityScanningEnabled, isMultiFactorAuthenticationEnabled);
  }

  public VideoCallApplication() {
    this("Anonymous");
  }

  public class CollectVideo extends Service.CollectVideo {
    private Set<AttackStep> _cacheChildrenCollectVideo;

    public CollectVideo(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenCollectVideo == null) {
        _cacheChildrenCollectVideo = new HashSet<>();
        if (VideoCallApplication.this instanceof VideoCallApplication) {
          if (((asset.VideoCallApplication) VideoCallApplication.this).os != null) {
            for (Computer _0 : ((asset.VideoCallApplication) VideoCallApplication.this).os.computer) {
              _cacheChildrenCollectVideo.add(_0.collectVideo);
            }
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenCollectVideo) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("VideoCallApplication.collectVideo");
    }
  }
}
