package asset;

import core.Asset;
import core.AttackStep;
import core.AttackStepMax;
import core.AttackStepMin;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class Computer extends Asset {
  public InfectedComputer infectedComputer;

  public InfectedWindowsComputer infectedWindowsComputer;

  public InfectedLinuxComputer infectedLinuxComputer;

  public InfectedMacOSComputer infectedMacOSComputer;

  public Unresponsive unresponsive;

  public HardwareAdditions hardwareAdditions;

  public AttemptExfiltrationOverPhysicalMedium attemptExfiltrationOverPhysicalMedium;

  public ExfiltrationOverPhysicalMedium exfiltrationOverPhysicalMedium;

  public ExfiltrationOverUSB exfiltrationOverUSB;

  public CollectAudio collectAudio;

  public PeripheralDeviceDiscovery peripheralDeviceDiscovery;

  public CollectVideo collectVideo;

  public DisableOrRemoveFeatureOrProgram disableOrRemoveFeatureOrProgram;

  public Set<User> user = new HashSet<>();

  public Set<OS> os = new HashSet<>();

  public Set<Router> router = new HashSet<>();

  public Set<PeripheralDevice> peripheralDevice = new HashSet<>();

  public Computer(String name, boolean isDisableOrRemoveFeatureOrProgramEnabled) {
    super(name);
    assetClassName = "Computer";
    AttackStep.allAttackSteps.remove(infectedComputer);
    infectedComputer = new InfectedComputer(name);
    AttackStep.allAttackSteps.remove(infectedWindowsComputer);
    infectedWindowsComputer = new InfectedWindowsComputer(name);
    AttackStep.allAttackSteps.remove(infectedLinuxComputer);
    infectedLinuxComputer = new InfectedLinuxComputer(name);
    AttackStep.allAttackSteps.remove(infectedMacOSComputer);
    infectedMacOSComputer = new InfectedMacOSComputer(name);
    AttackStep.allAttackSteps.remove(unresponsive);
    unresponsive = new Unresponsive(name);
    AttackStep.allAttackSteps.remove(hardwareAdditions);
    hardwareAdditions = new HardwareAdditions(name);
    AttackStep.allAttackSteps.remove(attemptExfiltrationOverPhysicalMedium);
    attemptExfiltrationOverPhysicalMedium = new AttemptExfiltrationOverPhysicalMedium(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverPhysicalMedium);
    exfiltrationOverPhysicalMedium = new ExfiltrationOverPhysicalMedium(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverUSB);
    exfiltrationOverUSB = new ExfiltrationOverUSB(name);
    AttackStep.allAttackSteps.remove(collectAudio);
    collectAudio = new CollectAudio(name);
    AttackStep.allAttackSteps.remove(peripheralDeviceDiscovery);
    peripheralDeviceDiscovery = new PeripheralDeviceDiscovery(name);
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, isDisableOrRemoveFeatureOrProgramEnabled);
  }

  public Computer(String name) {
    super(name);
    assetClassName = "Computer";
    AttackStep.allAttackSteps.remove(infectedComputer);
    infectedComputer = new InfectedComputer(name);
    AttackStep.allAttackSteps.remove(infectedWindowsComputer);
    infectedWindowsComputer = new InfectedWindowsComputer(name);
    AttackStep.allAttackSteps.remove(infectedLinuxComputer);
    infectedLinuxComputer = new InfectedLinuxComputer(name);
    AttackStep.allAttackSteps.remove(infectedMacOSComputer);
    infectedMacOSComputer = new InfectedMacOSComputer(name);
    AttackStep.allAttackSteps.remove(unresponsive);
    unresponsive = new Unresponsive(name);
    AttackStep.allAttackSteps.remove(hardwareAdditions);
    hardwareAdditions = new HardwareAdditions(name);
    AttackStep.allAttackSteps.remove(attemptExfiltrationOverPhysicalMedium);
    attemptExfiltrationOverPhysicalMedium = new AttemptExfiltrationOverPhysicalMedium(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverPhysicalMedium);
    exfiltrationOverPhysicalMedium = new ExfiltrationOverPhysicalMedium(name);
    AttackStep.allAttackSteps.remove(exfiltrationOverUSB);
    exfiltrationOverUSB = new ExfiltrationOverUSB(name);
    AttackStep.allAttackSteps.remove(collectAudio);
    collectAudio = new CollectAudio(name);
    AttackStep.allAttackSteps.remove(peripheralDeviceDiscovery);
    peripheralDeviceDiscovery = new PeripheralDeviceDiscovery(name);
    AttackStep.allAttackSteps.remove(collectVideo);
    collectVideo = new CollectVideo(name);
    if (disableOrRemoveFeatureOrProgram != null) {
      AttackStep.allAttackSteps.remove(disableOrRemoveFeatureOrProgram.disable);
    }
    Defense.allDefenses.remove(disableOrRemoveFeatureOrProgram);
    disableOrRemoveFeatureOrProgram = new DisableOrRemoveFeatureOrProgram(name, false);
  }

  public Computer(boolean isDisableOrRemoveFeatureOrProgramEnabled) {
    this("Anonymous", isDisableOrRemoveFeatureOrProgramEnabled);
  }

  public Computer() {
    this("Anonymous");
  }

  public void addUser(User user) {
    this.user.add(user);
    user.computer.add(this);
  }

  public void addOs(OS os) {
    this.os.add(os);
    os.computer.add(this);
  }

  public void addRouter(Router router) {
    this.router.add(router);
    router.computer.add(this);
  }

  public void addPeripheralDevice(PeripheralDevice peripheralDevice) {
    this.peripheralDevice.add(peripheralDevice);
    peripheralDevice.computer.add(this);
  }

  @Override
  public String getAssociatedAssetClassName(String field) {
    if (field.equals("user")) {
      return User.class.getName();
    } else if (field.equals("os")) {
      return OS.class.getName();
    } else if (field.equals("router")) {
      return Router.class.getName();
    } else if (field.equals("peripheralDevice")) {
      return PeripheralDevice.class.getName();
    }
    return "";
  }

  @Override
  public Set<Asset> getAssociatedAssets(String field) {
    Set<Asset> assets = new HashSet<>();
    if (field.equals("user")) {
      assets.addAll(user);
    } else if (field.equals("os")) {
      assets.addAll(os);
    } else if (field.equals("router")) {
      assets.addAll(router);
    } else if (field.equals("peripheralDevice")) {
      assets.addAll(peripheralDevice);
    }
    return assets;
  }

  @Override
  public Set<Asset> getAllAssociatedAssets() {
    Set<Asset> assets = new HashSet<>();
    assets.addAll(user);
    assets.addAll(os);
    assets.addAll(router);
    assets.addAll(peripheralDevice);
    return assets;
  }

  public class InfectedComputer extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenInfectedComputer;

    private Set<AttackStep> _cacheParentInfectedComputer;

    public InfectedComputer(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenInfectedComputer == null) {
        _cacheChildrenInfectedComputer = new HashSet<>();
        for (Router _0 : router) {
          for (InternalNetwork _1 : _0.internalNetwork) {
            _cacheChildrenInfectedComputer.add(_1.applicationLayerConnexion);
          }
        }
        for (Router _2 : router) {
          for (InternalNetwork _3 : _2.internalNetwork) {
            _cacheChildrenInfectedComputer.add(_3.attemptDataEncryptedForImpact);
          }
        }
        for (Router _4 : router) {
          for (ExternalNetwork _5 : _4.externalNetwork) {
            _cacheChildrenInfectedComputer.add(_5.attemptDataEncryptedForImpact);
          }
        }
        for (OS _6 : os) {
          _cacheChildrenInfectedComputer.add(_6.nonStandardPort);
        }
        for (OS _7 : os) {
          _cacheChildrenInfectedComputer.add(_7.fileDeletion);
        }
        for (OS _8 : os) {
          _cacheChildrenInfectedComputer.add(_8.attemptPowerShell);
        }
        for (OS _9 : os) {
          _cacheChildrenInfectedComputer.add(_9.accountManipulation);
        }
        for (OS _a : os) {
          _cacheChildrenInfectedComputer.add(_a.screenCapture);
        }
        for (OS _b : os) {
          _cacheChildrenInfectedComputer.add(_b.validAccounts);
        }
        for (PeripheralDevice _c : peripheralDevice) {
          _cacheChildrenInfectedComputer.add(_c.infectedMedia);
        }
        for (PeripheralDevice _d : peripheralDevice) {
          _cacheChildrenInfectedComputer.add(_d.dataFromRemovableMedia);
        }
      }
      for (AttackStep attackStep : _cacheChildrenInfectedComputer) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInfectedComputer == null) {
        _cacheParentInfectedComputer = new HashSet<>();
        for (OS _e : os) {
          for (Service _f : _e.service) {
            _cacheParentInfectedComputer.add(_f.exploitationOfRemoteServices);
          }
        }
        for (OS _10 : os) {
          _cacheParentInfectedComputer.add(_10.infectedOS);
        }
        for (OS _11 : os) {
          _cacheParentInfectedComputer.add(_11.executeCode);
        }
      }
      for (AttackStep attackStep : _cacheParentInfectedComputer) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.infectedComputer");
    }
  }

  public class InfectedWindowsComputer extends AttackStepMin {
    private Set<AttackStep> _cacheParentInfectedWindowsComputer;

    public InfectedWindowsComputer(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInfectedWindowsComputer == null) {
        _cacheParentInfectedWindowsComputer = new HashSet<>();
        for (OS _0 : os) {
          if (_0 instanceof Windows) {
            _cacheParentInfectedWindowsComputer.add(((asset.Windows) _0).executeCode);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentInfectedWindowsComputer) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.infectedWindowsComputer");
    }
  }

  public class InfectedLinuxComputer extends AttackStepMin {
    private Set<AttackStep> _cacheParentInfectedLinuxComputer;

    public InfectedLinuxComputer(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInfectedLinuxComputer == null) {
        _cacheParentInfectedLinuxComputer = new HashSet<>();
        for (OS _0 : os) {
          if (_0 instanceof Linux) {
            _cacheParentInfectedLinuxComputer.add(((asset.Linux) _0).executeCode);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentInfectedLinuxComputer) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.infectedLinuxComputer");
    }
  }

  public class InfectedMacOSComputer extends AttackStepMin {
    private Set<AttackStep> _cacheParentInfectedMacOSComputer;

    public InfectedMacOSComputer(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentInfectedMacOSComputer == null) {
        _cacheParentInfectedMacOSComputer = new HashSet<>();
        for (OS _0 : os) {
          if (_0 instanceof MacOS) {
            _cacheParentInfectedMacOSComputer.add(((asset.MacOS) _0).executeCode);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentInfectedMacOSComputer) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.infectedMacOSComputer");
    }
  }

  public class Unresponsive extends AttackStepMin {
    private Set<AttackStep> _cacheParentUnresponsive;

    public Unresponsive(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUnresponsive == null) {
        _cacheParentUnresponsive = new HashSet<>();
        for (OS _0 : os) {
          _cacheParentUnresponsive.add(_0.resourceHijacking);
        }
      }
      for (AttackStep attackStep : _cacheParentUnresponsive) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.unresponsive");
    }
  }

  public class HardwareAdditions extends AttackStepMax {
    private Set<AttackStep> _cacheParentHardwareAdditions;

    public HardwareAdditions(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentHardwareAdditions == null) {
        _cacheParentHardwareAdditions = new HashSet<>();
        for (OS _0 : os) {
          _cacheParentHardwareAdditions.add(_0.limitHardwareInstallation.disable);
        }
        for (Router _1 : router) {
          for (InternalNetwork _2 : _1.internalNetwork) {
            _cacheParentHardwareAdditions.add(_2.limitAccessToResourceOverNetwork.disable);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentHardwareAdditions) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.hardwareAdditions");
    }
  }

  public class AttemptExfiltrationOverPhysicalMedium extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenAttemptExfiltrationOverPhysicalMedium;

    private Set<AttackStep> _cacheParentAttemptExfiltrationOverPhysicalMedium;

    public AttemptExfiltrationOverPhysicalMedium(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenAttemptExfiltrationOverPhysicalMedium == null) {
        _cacheChildrenAttemptExfiltrationOverPhysicalMedium = new HashSet<>();
        _cacheChildrenAttemptExfiltrationOverPhysicalMedium.add(exfiltrationOverPhysicalMedium);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptExfiltrationOverPhysicalMedium) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentAttemptExfiltrationOverPhysicalMedium == null) {
        _cacheParentAttemptExfiltrationOverPhysicalMedium = new HashSet<>();
        for (OS _0 : os) {
          _cacheParentAttemptExfiltrationOverPhysicalMedium.add(_0.sensitiveDataCollected);
        }
        for (OS _1 : os) {
          _cacheParentAttemptExfiltrationOverPhysicalMedium.add(_1.dataCollected);
        }
        for (OS _2 : os) {
          _cacheParentAttemptExfiltrationOverPhysicalMedium.add(_2.dataEncrypted);
        }
        for (OS _3 : os) {
          _cacheParentAttemptExfiltrationOverPhysicalMedium.add(_3.localDataStaging);
        }
        for (OS _4 : os) {
          _cacheParentAttemptExfiltrationOverPhysicalMedium.add(_4.remoteDataStaging);
        }
        for (OS _5 : os) {
          _cacheParentAttemptExfiltrationOverPhysicalMedium.add(_5.dataCompressed);
        }
      }
      for (AttackStep attackStep : _cacheParentAttemptExfiltrationOverPhysicalMedium) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.attemptExfiltrationOverPhysicalMedium");
    }
  }

  public class ExfiltrationOverPhysicalMedium extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenExfiltrationOverPhysicalMedium;

    private Set<AttackStep> _cacheParentExfiltrationOverPhysicalMedium;

    public ExfiltrationOverPhysicalMedium(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverPhysicalMedium == null) {
        _cacheChildrenExfiltrationOverPhysicalMedium = new HashSet<>();
        _cacheChildrenExfiltrationOverPhysicalMedium.add(exfiltrationOverUSB);
        for (PeripheralDevice _0 : peripheralDevice) {
          _cacheChildrenExfiltrationOverPhysicalMedium.add(_0.dataExfiltration);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverPhysicalMedium) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverPhysicalMedium == null) {
        _cacheParentExfiltrationOverPhysicalMedium = new HashSet<>();
        for (OS _1 : os) {
          _cacheParentExfiltrationOverPhysicalMedium.add(_1.limitHardwareInstallation.disable);
        }
        _cacheParentExfiltrationOverPhysicalMedium.add(attemptExfiltrationOverPhysicalMedium);
        _cacheParentExfiltrationOverPhysicalMedium.add(disableOrRemoveFeatureOrProgram.disable);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverPhysicalMedium) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.exfiltrationOverPhysicalMedium");
    }
  }

  public class ExfiltrationOverUSB extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenExfiltrationOverUSB;

    private Set<AttackStep> _cacheParentExfiltrationOverUSB;

    public ExfiltrationOverUSB(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenExfiltrationOverUSB == null) {
        _cacheChildrenExfiltrationOverUSB = new HashSet<>();
        for (PeripheralDevice _0 : peripheralDevice) {
          _cacheChildrenExfiltrationOverUSB.add(_0.dataExfiltration);
        }
      }
      for (AttackStep attackStep : _cacheChildrenExfiltrationOverUSB) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentExfiltrationOverUSB == null) {
        _cacheParentExfiltrationOverUSB = new HashSet<>();
        _cacheParentExfiltrationOverUSB.add(exfiltrationOverPhysicalMedium);
      }
      for (AttackStep attackStep : _cacheParentExfiltrationOverUSB) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.exfiltrationOverUSB");
    }
  }

  public class CollectAudio extends AttackStepMax {
    private Set<AttackStep> _cacheChildrenCollectAudio;

    private Set<AttackStep> _cacheParentCollectAudio;

    public CollectAudio(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCollectAudio == null) {
        _cacheChildrenCollectAudio = new HashSet<>();
        for (OS _0 : os) {
          _cacheChildrenCollectAudio.add(_0.dataCollected);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCollectAudio) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCollectAudio == null) {
        _cacheParentCollectAudio = new HashSet<>();
        for (OS _1 : os) {
          _cacheParentCollectAudio.add(_1.executionPrevention.disable);
        }
        for (PeripheralDevice _2 : peripheralDevice) {
          if (_2 instanceof Microphone) {
            _cacheParentCollectAudio.add(((asset.Microphone) _2).collectAudio);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCollectAudio) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.collectAudio");
    }
  }

  public class PeripheralDeviceDiscovery extends AttackStepMin {
    private Set<AttackStep> _cacheParentPeripheralDeviceDiscovery;

    public PeripheralDeviceDiscovery(String name) {
      super(name);
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentPeripheralDeviceDiscovery == null) {
        _cacheParentPeripheralDeviceDiscovery = new HashSet<>();
        for (OS _0 : os) {
          if (_0 instanceof Windows) {
            _cacheParentPeripheralDeviceDiscovery.add(((asset.Windows) _0).peripheralDeviceDiscovery);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentPeripheralDeviceDiscovery) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.peripheralDeviceDiscovery");
    }
  }

  public class CollectVideo extends AttackStepMin {
    private Set<AttackStep> _cacheChildrenCollectVideo;

    private Set<AttackStep> _cacheParentCollectVideo;

    public CollectVideo(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      if (_cacheChildrenCollectVideo == null) {
        _cacheChildrenCollectVideo = new HashSet<>();
        for (OS _0 : os) {
          _cacheChildrenCollectVideo.add(_0.dataCollected);
        }
      }
      for (AttackStep attackStep : _cacheChildrenCollectVideo) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentCollectVideo == null) {
        _cacheParentCollectVideo = new HashSet<>();
        for (OS _1 : os) {
          for (Service _2 : _1.service) {
            if (_2 instanceof VideoCallApplication) {
              _cacheParentCollectVideo.add(((asset.VideoCallApplication) _2).collectVideo);
            }
          }
        }
        for (OS _3 : os) {
          if (_3 instanceof Windows) {
            _cacheParentCollectVideo.add(((asset.Windows) _3).videoCapture);
          }
        }
        for (OS _4 : os) {
          if (_4 instanceof MacOS) {
            _cacheParentCollectVideo.add(((asset.MacOS) _4).videoCapture);
          }
        }
        for (PeripheralDevice _5 : peripheralDevice) {
          if (_5 instanceof Webcam) {
            _cacheParentCollectVideo.add(((asset.Webcam) _5).collectVideo);
          }
        }
      }
      for (AttackStep attackStep : _cacheParentCollectVideo) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("Computer.collectVideo");
    }
  }

  public class DisableOrRemoveFeatureOrProgram extends Defense {
    public DisableOrRemoveFeatureOrProgram(String name) {
      this(name, false);
    }

    public DisableOrRemoveFeatureOrProgram(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends AttackStepMin {
      private Set<AttackStep> _cacheChildrenDisableOrRemoveFeatureOrProgram;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        if (_cacheChildrenDisableOrRemoveFeatureOrProgram == null) {
          _cacheChildrenDisableOrRemoveFeatureOrProgram = new HashSet<>();
          _cacheChildrenDisableOrRemoveFeatureOrProgram.add(exfiltrationOverPhysicalMedium);
        }
        for (AttackStep attackStep : _cacheChildrenDisableOrRemoveFeatureOrProgram) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "Computer.disableOrRemoveFeatureOrProgram";
      }
    }
  }
}
