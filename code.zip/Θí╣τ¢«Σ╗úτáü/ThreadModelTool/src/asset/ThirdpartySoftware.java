package asset;

import core.AttackStep;
import core.Defense;
import java.lang.Boolean;
import java.lang.Override;
import java.lang.String;
import java.util.HashSet;
import java.util.Set;

public class ThirdpartySoftware extends Service {
  public ThirdpartySoftware(String name, boolean isAuditEnabled,
      boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    super(name, isAuditEnabled, isApplicationIsolationAndSandboxingEnabled, isPrivilegedAccountManagementEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isExploitProtectionEnabled, isNetworkSegmentationEnabled, isThreatIntelligenceProgramEnabled, isPasswordPoliciesEnabled, isUpdateSoftwareEnabled, isSoftwareConfigurationEnabled, isActiveDirectoryConfigurationEnabled, isVulnerabilityScanningEnabled, isMultiFactorAuthenticationEnabled);
    assetClassName = "ThirdpartySoftware";
    AttackStep.allAttackSteps.remove(attemptTrustedRelationship);
    attemptTrustedRelationship = new AttemptTrustedRelationship(name);
    AttackStep.allAttackSteps.remove(trustedRelationship);
    trustedRelationship = new TrustedRelationship(name);
    AttackStep.allAttackSteps.remove(attemptUseThirdpartySoftware);
    attemptUseThirdpartySoftware = new AttemptUseThirdpartySoftware(name);
    AttackStep.allAttackSteps.remove(useThirdpartySoftware);
    useThirdpartySoftware = new UseThirdpartySoftware(name);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, isUpdateSoftwareEnabled);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, isMultiFactorAuthenticationEnabled);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, isPasswordPoliciesEnabled);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, isActiveDirectoryConfigurationEnabled);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, isNetworkSegmentationEnabled);
  }

  public ThirdpartySoftware(String name) {
    super(name);
    assetClassName = "ThirdpartySoftware";
    AttackStep.allAttackSteps.remove(attemptTrustedRelationship);
    attemptTrustedRelationship = new AttemptTrustedRelationship(name);
    AttackStep.allAttackSteps.remove(trustedRelationship);
    trustedRelationship = new TrustedRelationship(name);
    AttackStep.allAttackSteps.remove(attemptUseThirdpartySoftware);
    attemptUseThirdpartySoftware = new AttemptUseThirdpartySoftware(name);
    AttackStep.allAttackSteps.remove(useThirdpartySoftware);
    useThirdpartySoftware = new UseThirdpartySoftware(name);
    if (updateSoftware != null) {
      AttackStep.allAttackSteps.remove(updateSoftware.disable);
    }
    Defense.allDefenses.remove(updateSoftware);
    updateSoftware = new UpdateSoftware(name, false);
    if (multiFactorAuthentication != null) {
      AttackStep.allAttackSteps.remove(multiFactorAuthentication.disable);
    }
    Defense.allDefenses.remove(multiFactorAuthentication);
    multiFactorAuthentication = new MultiFactorAuthentication(name, false);
    if (passwordPolicies != null) {
      AttackStep.allAttackSteps.remove(passwordPolicies.disable);
    }
    Defense.allDefenses.remove(passwordPolicies);
    passwordPolicies = new PasswordPolicies(name, false);
    if (activeDirectoryConfiguration != null) {
      AttackStep.allAttackSteps.remove(activeDirectoryConfiguration.disable);
    }
    Defense.allDefenses.remove(activeDirectoryConfiguration);
    activeDirectoryConfiguration = new ActiveDirectoryConfiguration(name, false);
    if (networkSegmentation != null) {
      AttackStep.allAttackSteps.remove(networkSegmentation.disable);
    }
    Defense.allDefenses.remove(networkSegmentation);
    networkSegmentation = new NetworkSegmentation(name, false);
  }

  public ThirdpartySoftware(boolean isAuditEnabled,
      boolean isApplicationIsolationAndSandboxingEnabled,
      boolean isPrivilegedAccountManagementEnabled,
      boolean isDisableOrRemoveFeatureOrProgramEnabled,
      boolean isEncryptSensitiveInformationEnabled, boolean isExecutionPreventionEnabled,
      boolean isExploitProtectionEnabled, boolean isNetworkSegmentationEnabled,
      boolean isThreatIntelligenceProgramEnabled, boolean isPasswordPoliciesEnabled,
      boolean isUpdateSoftwareEnabled, boolean isSoftwareConfigurationEnabled,
      boolean isActiveDirectoryConfigurationEnabled, boolean isVulnerabilityScanningEnabled,
      boolean isMultiFactorAuthenticationEnabled) {
    this("Anonymous", isAuditEnabled, isApplicationIsolationAndSandboxingEnabled, isPrivilegedAccountManagementEnabled, isDisableOrRemoveFeatureOrProgramEnabled, isEncryptSensitiveInformationEnabled, isExecutionPreventionEnabled, isExploitProtectionEnabled, isNetworkSegmentationEnabled, isThreatIntelligenceProgramEnabled, isPasswordPoliciesEnabled, isUpdateSoftwareEnabled, isSoftwareConfigurationEnabled, isActiveDirectoryConfigurationEnabled, isVulnerabilityScanningEnabled, isMultiFactorAuthenticationEnabled);
  }

  public ThirdpartySoftware() {
    this("Anonymous");
  }

  public class AttemptTrustedRelationship extends Service.AttemptTrustedRelationship {
    private Set<AttackStep> _cacheChildrenAttemptTrustedRelationship;

    public AttemptTrustedRelationship(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptTrustedRelationship == null) {
        _cacheChildrenAttemptTrustedRelationship = new HashSet<>();
        _cacheChildrenAttemptTrustedRelationship.add(trustedRelationship);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptTrustedRelationship) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ThirdpartySoftware.attemptTrustedRelationship");
    }
  }

  public class TrustedRelationship extends Service.TrustedRelationship {
    private Set<AttackStep> _cacheChildrenTrustedRelationship;

    private Set<AttackStep> _cacheParentTrustedRelationship;

    public TrustedRelationship(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenTrustedRelationship == null) {
        _cacheChildrenTrustedRelationship = new HashSet<>();
        if (ThirdpartySoftware.this instanceof ThirdpartySoftware) {
          if (((asset.ThirdpartySoftware) ThirdpartySoftware.this).os != null) {
            _cacheChildrenTrustedRelationship.add(((asset.ThirdpartySoftware) ThirdpartySoftware.this).os.validAccounts);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenTrustedRelationship) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentTrustedRelationship == null) {
        _cacheParentTrustedRelationship = new HashSet<>();
        _cacheParentTrustedRelationship.add(attemptTrustedRelationship);
        _cacheParentTrustedRelationship.add(networkSegmentation.disable);
      }
      for (AttackStep attackStep : _cacheParentTrustedRelationship) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ThirdpartySoftware.trustedRelationship");
    }
  }

  public class AttemptUseThirdpartySoftware extends Service.AttemptUseThirdpartySoftware {
    private Set<AttackStep> _cacheChildrenAttemptUseThirdpartySoftware;

    public AttemptUseThirdpartySoftware(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenAttemptUseThirdpartySoftware == null) {
        _cacheChildrenAttemptUseThirdpartySoftware = new HashSet<>();
        _cacheChildrenAttemptUseThirdpartySoftware.add(useThirdpartySoftware);
      }
      for (AttackStep attackStep : _cacheChildrenAttemptUseThirdpartySoftware) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ThirdpartySoftware.attemptUseThirdpartySoftware");
    }
  }

  public class UseThirdpartySoftware extends Service.UseThirdpartySoftware {
    private Set<AttackStep> _cacheChildrenUseThirdpartySoftware;

    private Set<AttackStep> _cacheParentUseThirdpartySoftware;

    public UseThirdpartySoftware(String name) {
      super(name);
    }

    @Override
    public void updateChildren(Set<AttackStep> attackSteps) {
      super.updateChildren(attackSteps);
      if (_cacheChildrenUseThirdpartySoftware == null) {
        _cacheChildrenUseThirdpartySoftware = new HashSet<>();
        if (ThirdpartySoftware.this instanceof ThirdpartySoftware) {
          if (((asset.ThirdpartySoftware) ThirdpartySoftware.this).os != null) {
            _cacheChildrenUseThirdpartySoftware.add(((asset.ThirdpartySoftware) ThirdpartySoftware.this).os.executeCode);
          }
        }
      }
      for (AttackStep attackStep : _cacheChildrenUseThirdpartySoftware) {
        attackStep.updateTtc(this, ttc, attackSteps);
      }
    }

    @Override
    public void setExpectedParents() {
      super.setExpectedParents();
      if (_cacheParentUseThirdpartySoftware == null) {
        _cacheParentUseThirdpartySoftware = new HashSet<>();
        _cacheParentUseThirdpartySoftware.add(attemptUseThirdpartySoftware);
        _cacheParentUseThirdpartySoftware.add(updateSoftware.disable);
        _cacheParentUseThirdpartySoftware.add(multiFactorAuthentication.disable);
        _cacheParentUseThirdpartySoftware.add(passwordPolicies.disable);
        _cacheParentUseThirdpartySoftware.add(activeDirectoryConfiguration.disable);
        _cacheParentUseThirdpartySoftware.add(networkSegmentation.disable);
      }
      for (AttackStep attackStep : _cacheParentUseThirdpartySoftware) {
        addExpectedParent(attackStep);
      }
    }

    @Override
    public double localTtc() {
      return ttcHashMap.get("ThirdpartySoftware.useThirdpartySoftware");
    }
  }

  public class UpdateSoftware extends Service.UpdateSoftware {
    public UpdateSoftware(String name) {
      this(name, false);
    }

    public UpdateSoftware(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.UpdateSoftware.Disable {
      private Set<AttackStep> _cacheChildrenUpdateSoftware;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenUpdateSoftware == null) {
          _cacheChildrenUpdateSoftware = new HashSet<>();
          _cacheChildrenUpdateSoftware.add(useThirdpartySoftware);
        }
        for (AttackStep attackStep : _cacheChildrenUpdateSoftware) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ThirdpartySoftware.updateSoftware";
      }
    }
  }

  public class MultiFactorAuthentication extends Service.MultiFactorAuthentication {
    public MultiFactorAuthentication(String name) {
      this(name, false);
    }

    public MultiFactorAuthentication(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.MultiFactorAuthentication.Disable {
      private Set<AttackStep> _cacheChildrenMultiFactorAuthentication;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenMultiFactorAuthentication == null) {
          _cacheChildrenMultiFactorAuthentication = new HashSet<>();
          _cacheChildrenMultiFactorAuthentication.add(useThirdpartySoftware);
        }
        for (AttackStep attackStep : _cacheChildrenMultiFactorAuthentication) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ThirdpartySoftware.multiFactorAuthentication";
      }
    }
  }

  public class PasswordPolicies extends Service.PasswordPolicies {
    public PasswordPolicies(String name) {
      this(name, false);
    }

    public PasswordPolicies(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.PasswordPolicies.Disable {
      private Set<AttackStep> _cacheChildrenPasswordPolicies;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenPasswordPolicies == null) {
          _cacheChildrenPasswordPolicies = new HashSet<>();
          _cacheChildrenPasswordPolicies.add(useThirdpartySoftware);
        }
        for (AttackStep attackStep : _cacheChildrenPasswordPolicies) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ThirdpartySoftware.passwordPolicies";
      }
    }
  }

  public class ActiveDirectoryConfiguration extends Service.ActiveDirectoryConfiguration {
    public ActiveDirectoryConfiguration(String name) {
      this(name, false);
    }

    public ActiveDirectoryConfiguration(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.ActiveDirectoryConfiguration.Disable {
      private Set<AttackStep> _cacheChildrenActiveDirectoryConfiguration;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenActiveDirectoryConfiguration == null) {
          _cacheChildrenActiveDirectoryConfiguration = new HashSet<>();
          _cacheChildrenActiveDirectoryConfiguration.add(useThirdpartySoftware);
        }
        for (AttackStep attackStep : _cacheChildrenActiveDirectoryConfiguration) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ThirdpartySoftware.activeDirectoryConfiguration";
      }
    }
  }

  public class NetworkSegmentation extends Service.NetworkSegmentation {
    public NetworkSegmentation(String name) {
      this(name, false);
    }

    public NetworkSegmentation(String name, Boolean isEnabled) {
      super(name);
      defaultValue = isEnabled;
      disable = new Disable(name);
    }

    public class Disable extends Service.NetworkSegmentation.Disable {
      private Set<AttackStep> _cacheChildrenNetworkSegmentation;

      public Disable(String name) {
        super(name);
      }

      @Override
      public void updateChildren(Set<AttackStep> attackSteps) {
        super.updateChildren(attackSteps);
        if (_cacheChildrenNetworkSegmentation == null) {
          _cacheChildrenNetworkSegmentation = new HashSet<>();
          _cacheChildrenNetworkSegmentation.add(trustedRelationship);
          _cacheChildrenNetworkSegmentation.add(useThirdpartySoftware);
        }
        for (AttackStep attackStep : _cacheChildrenNetworkSegmentation) {
          attackStep.updateTtc(this, ttc, attackSteps);
        }
      }

      @Override
      public String fullName() {
        return "ThirdpartySoftware.networkSegmentation";
      }
    }
  }
}
