package test;

import core.Attacker;
import examplelang.Host;
import examplelang.Network;
import examplelang.Password;

public class TestCore extends CoreTest {
  private static class ExampleLangModel {
    public final Network internet = new Network("internet");
    public final Host server = new Host("server");
    public final Password password123 = new Password("password123");

    public ExampleLangModel() {
      internet.addHosts(server);
      server.addPasswords(password123);
    }
  }

  public void testAccess() {
    var model = new ExampleLangModel();

    var attacker = new Attacker();
    attacker.addAttackPoint(model.internet.access);
    attacker.addAttackPoint(model.password123.obtain);
    attacker.attack();

    model.server.access.assertCompromisedInstantaneously();
  }

  public void testNoPassword() {
    var model = new ExampleLangModel();

    var attacker = new Attacker();
    attacker.addAttackPoint(model.internet.access);
    attacker.attack();

    model.server.access.assertUncompromised();
  }

  public void testNoNetwork() {
    var model = new ExampleLangModel();

    var attacker = new Attacker();
    attacker.addAttackPoint(model.password123.obtain);
    attacker.attack();

    model.server.access.assertUncompromised();
  }
}
