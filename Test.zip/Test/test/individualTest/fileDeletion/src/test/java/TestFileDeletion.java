package test.individualTest.fileDeletion.src.test.java;

import asset.*;
import core.*;
import test.CoreTest;

public class  TestFileDeletion extends CoreTest{ /*
                              OS -----   UserAccount

        Attacker's entry point: userAccount.userRights
    */

    //  https://unit42.paloaltonetworks.com/unit42-new-wine-old-bottle-new-azorult-variant-found-findmyname-campaign-using-fallout-exploit-kit/
    //  rootkit no defens aktiv.
    private static class fileDeletion{
        public final UserAccount userAccount = new UserAccount("userAccount");
        public final OS os = new OS("os");
        public final Computer computer = new Computer("computer");

        public fileDeletion() {
            userAccount.addOs(os);
            computer.addOs(os);
        }

    }

    public void userRights(){
        var model = new fileDeletion();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.userAccount.userRights);
        attacker.attack();

        model.os.fileDeletion.assertCompromisedInstantaneously();
        model.os.bypassHostForensicAnalysis.assertCompromisedInstantaneously();
    }


    public void infectedComputer(){
        var model = new fileDeletion();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.computer.infectedComputer);
        attacker.attack();

        model.os.fileDeletion.assertCompromisedInstantaneously();
        model.os.bypassHostForensicAnalysis.assertCompromisedInstantaneously();
    }

    public void indicatorRemovalOnHost(){
        var model = new fileDeletion();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.os.indicatorRemovalOnHost);
        attacker.attack();

        model.os.fileDeletion.assertCompromisedInstantaneously();
        model.os.bypassHostForensicAnalysis.assertCompromisedInstantaneously();
    }
}


