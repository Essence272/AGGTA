package test.individualTest.accountDiscovery.src.test.java;

import asset.*;
import core.*;
import test.CoreTest;

public class  TestAccountManipulation extends CoreTest {
    /*

		Windows ---- Computer
		  |
		  |
		  |----- UserAccunt
		  |
		WindowsAdmin


        Attacker's entry point: computer.infectedComputer
    */
    // https://attack.mitre.org/techniques/T1098/
    // https://www.cisa.gov/news-events/alerts/2018/03/15/russian-government-cyber-activity-targeting-energy-and-other-critical
    // trunsted relationship no defens aktiv.
    private static class trustedRelationshipNoDefens{
        public final UserAccount userAccount = new UserAccount("userAccount");
        public final Computer computer = new Computer("computer");
        public final Windows win = new Windows("win");
        public final OS os = new OS("internalSystems");

        public trustedRelationshipNoDefens() {
            win.addUserAccount(userAccount);
            win.addComputer(computer);
            computer.addOs(os);
        }

    }

    public void runNoDefensInfectedComputer(){
        var model = new trustedRelationshipNoDefens();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.computer.infectedComputer);
        attacker.attack();


        model.win.accountManipulation.assertCompromisedInstantaneously();
        model.win.persistence.assertCompromisedInstantaneously();
        model.userAccount.userCredentials.assertCompromisedInstantaneously();
    }
    public void runNoDefensUserRights(){
        var model = new trustedRelationshipNoDefens();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.userAccount.userRights);
        attacker.attack();


        model.win.accountManipulation.assertCompromisedInstantaneously();
        model.win.persistence.assertCompromisedInstantaneouslyFrom(model.win.accountManipulation);
        model.userAccount.userCredentials.assertCompromisedInstantaneouslyFrom(model.win.accountManipulation);
    }



    // trunsted relationship with defens aktiv.
    private static class trustedRelationshipDefens{

        public final UserAccount userAccount = new UserAccount("userAccount");
        public final AdminAccount adminAccount = new AdminAccount("adminAccount");
        public final Computer computer = new Computer("computer");
        public final Windows win = new Windows("win");
        public final OS os = new OS("internalSystems");

        public trustedRelationshipDefens() {
            //win.addAdminAccount(winAdmin);
            win.addAdminAccount(adminAccount);
            win.addUserAccount(userAccount);
            win.addComputer(computer);
            computer.addOs(os);
        }

    }
    //trustedRelationship -> _validAccounts -> service.userRemoteServicesLogin,
    public void runWithDefens(){
        var model = new trustedRelationshipDefens();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.userAccount.userRights);
        attacker.attack();

        //model.win.persistence.assertUncompromisedFrom(model.win.accountManipulation);
        //model.userAccount.userCredentials.assertUncompromisedFrom(model.win.accountManipulation);
        model.win.accountManipulation.assertCompromisedInstantaneously();
        //model.win.accountManipulation.assertUncompromised();
    }


}