package test.individualTest.spearphishingAttachment.src.test.java;

import asset.*;
import core.*;
import test.CoreTest;


import core.Attacker;

public class TestSpearphishing extends CoreTest {

    private static class SpearphishingViaServiceModel {

        /*
                           Service
                              |
                              |
                              OS -----   UserAccount
                              |               |
                              |               |
                            Computer ------  User

        Attacker's entry point: Service.attemptSpearphishingViaService
        */

        public final User user = new User("user");
        public final UserAccount userAccount = new UserAccount("userAccount");
        public final Browser browser = new Browser("browser");
        public final Computer computer = new Computer("computer");
        public final Service service = new Service("service");
        public final OS os = new OS("os");

        public SpearphishingViaServiceModel() {
            browser.addService(service);
            os.addService(service);
            os.addComputer(computer);
            os.addUserAccount(userAccount);
            computer.addUser(user);
        }
    }

    // Test an adversary can compromise a computer by spearphishingViaService.
    public void testwithSpearphishingViaService() {
        var model = new SpearphishingViaServiceModel();

        Attacker attacker = new Attacker();
        attacker.addAttackPoint(model.service.spearphishingViaService);
        attacker.attack();

        model.service.spearphishingViaPersonalEmail.assertCompromisedInstantaneously();
        model.service.spearphishingViaSocialMedia.assertCompromisedInstantaneously();
        model.browser.attemptSpearphishingAttachment.assertCompromisedInstantaneously();
        model.browser.attemptSpearphishingLink.assertCompromisedInstantaneously();
        model.user.maliciousFile.assertCompromisedInstantaneously();
        model.user.maliciousLink.assertCompromisedInstantaneously();
        model.os.executeCode.assertCompromisedInstantaneously();
        model.computer.infectedComputer.assertCompromisedInstantaneously();
    }

}
