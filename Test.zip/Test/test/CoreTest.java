package test;

import core.Asset;
import core.AttackStep;
import core.Defense;
import org.apache.commons.math3.analysis.ParametricUnivariateFunction;
import org.apache.commons.math3.fitting.SimpleCurveFitter;
import org.apache.commons.math3.fitting.WeightedObservedPoints;
import org.apache.commons.math3.stat.Frequency;
import org.jfree.chart.ChartColor;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.math3.util.FastMath.log;
import static org.apache.commons.math3.util.FastMath.tanh;

public class CoreTest {
  public void deleteModel() {
    Asset.allAssets.clear();
    AttackStep.allAttackSteps.clear();
    Defense.allDefenses.clear();
  }

  static class MyFunction implements ParametricUnivariateFunction {
    public double value(double x, double ... parameters) {
      double a = parameters[0];
      double b = parameters[1];
      return tanh(a*x+b);
    }

    public double[] gradient(double x, double ... parameters) {
      double a = parameters[0];
      double b = parameters[1];

      double[] gradients = new double[2];
      gradients[0] = x*(1-tanh(a*x+b) * tanh(a*x+b)); // 对 a 求导
      gradients[1] = (1-tanh(a*x+b) * tanh(a*x+b)); // 对 b 求导
      return gradients;

    }
  }

  static class MyFunction2 implements ParametricUnivariateFunction {
    public double value(double x, double ... parameters) {
      double a = parameters[0];
      double b = parameters[1];
      double c = parameters[2];
      return a*log(b * x + c);

    }

    public double[] gradient(double x, double ... parameters) {
      double a = parameters[0];
      double b = parameters[1];
      double c = parameters[2];

      double[] gradients = new double[3];
      //double den = 1 + Math.pow(x / c, b);

      gradients[0] = log(b*x+c); // 对 a 求导

      gradients[1] = (a*x)/(b*x+c); // 对 b 求导

      gradients[2] = a/(b*x+c); // 对 c 求导

      return gradients;

    }
  }

  public static List<double[]> curveFit(double[][] scatters) {
    ParametricUnivariateFunction function = new MyFunction();/*多项式函数*/
    //ParametricUnivariateFunction function = new PolynomialFunction.Parametric();/*多项式函数*/
    //double[] guess = {0.01, 0.05, 0.01, 0.01}; /*猜测值 依次为 a b c 。必须和 gradient 方法返回数组对应。如果不知道都设置为 1*/
    double[] guess = {1, 1}; /*猜测值 依次为 a b c 。必须和 gradient 方法返回数组对应。如果不知道都设置为 1*/

    // 初始化拟合
    SimpleCurveFitter curveFitter = SimpleCurveFitter.create(function,guess);

    // 添加数据点
    WeightedObservedPoints observedPoints = new WeightedObservedPoints();
    for (double[] point : scatters) {
      observedPoints.add(point[0], point[1]);
    }

    /*
     * best 为拟合结果 对应 a b c
     * 可能会出现无法拟合的情况
     * 需要合理设置初始值
     * */
    double[] best = curveFitter.fit(observedPoints.toList());
    double a = best[0];
    double b = best[1];
    //double c = best[2];
    //double d = best[3];

    // 根据拟合结果生成拟合曲线散点
    List<double[]> fitData = new ArrayList<>();
    for (double[] datum : scatters) {
      double x = datum[0];
      double y = function.value(x, a, b);

      ///*
      double x1 = datum[0]+0.1;
      double y1 = function.value(x1, a, b);

      double x2 = datum[0]+0.2;
      double y2 = function.value(x2, a, b);

      double x3 = datum[0]+0.3;
      double y3 = function.value(x3, a, b);

      double x4 = datum[0]+0.4;
      double y4 = function.value(x4, a, b);

      double x5 = datum[0]+0.5;
      double y5 = function.value(x5, a, b);

      double x6 = datum[0]+0.6;
      double y6 = function.value(x6, a, b);

      double x7 = datum[0]+0.7;
      double y7 = function.value(x7, a, b);

      double x8 = datum[0]+0.8;
      double y8 = function.value(x8, a, b);

      double x9 = datum[0]+0.9;
      double y9 = function.value(x9, a, b);
      //*/
      //double y = a + b*x + c*x*x + d*x*x*x;

      double[] xy = {x, y};
      ///*
      double[] xy1 = {x1, y1};
      double[] xy2 = {x2, y2};
      double[] xy3 = {x3, y3};
      double[] xy4 = {x4, y4};
      double[] xy5 = {x5, y5};
      double[] xy6 = {x6, y6};
      double[] xy7 = {x7, y7};
      double[] xy8 = {x8, y8};
      double[] xy9 = {x9, y9};
      //*/
      fitData.add(xy);
      ///*
      fitData.add(xy1);
      fitData.add(xy2);
      fitData.add(xy3);
      fitData.add(xy4);
      fitData.add(xy5);
      fitData.add(xy6);
      fitData.add(xy7);
      fitData.add(xy8);
      fitData.add(xy9);
      //*/
    }

    return fitData;
  }

  public static void ttcChart(List<Double> rawData, String name) {
    // === init fitData ===
    Frequency f = new Frequency();
    for(double e : rawData) {
      f.addValue(e);
    }
    List<double[]> data = new ArrayList<>();
    for (double x = 0; x <= 14; x += 1) {
      double y = f.getCumPct(x/2);
      double[] xy = {x, y};
      data.add(xy);
    }
    List<double[]> fitData = curveFit(data.stream().toArray(double[][]::new));

    // === init dataset for draw ===
    //DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    XYSeries series = new XYSeries("ttc-probability");
    for(double[] e : fitData) {
      //dataset.addValue(e[1], "", (Double)(e[0]/2));
      series.add(e[0]/2, e[1]);
    }
    XYSeriesCollection dataset = new XYSeriesCollection();
    dataset.addSeries(series);

    // === set draw config ===
    JFreeChart chart = ChartFactory.createXYLineChart("Probability of global time to compromise", "TTC", "Probability",
            dataset, PlotOrientation.VERTICAL, false, true, true);

    XYPlot cp = chart.getXYPlot();
    cp.setBackgroundPaint(ChartColor.WHITE); // 背景色设置
    cp.setRangeGridlinePaint(ChartColor.GRAY); // 网格线色设置

    ValueAxis Yaxis = cp.getRangeAxis();
    ValueAxis Xaxis =cp.getDomainAxis();

    Xaxis.setRange(0.0, 7.03);
    Yaxis.setRange(0.0, 1.02);
    cp.setRangeAxis(Yaxis);
    cp.setDomainAxis(Xaxis);

    //XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
    //renderer.setSeriesPaint(0, Color.RED);
    //renderer.setSeriesStroke(0, new BasicStroke(2.0f));
    //renderer.setBaseStroke(new BasicStroke(2.0f));
    //cp.setRenderer(renderer);

    // === draw & save ===
    //ChartFrame frame=new ChartFrame ("Pic",chart,true);
    //frame.pack();
    //frame.setVisible(true);
    try {
      ChartUtilities.saveChartAsPNG(new File(".\\out\\"+name+"_ttc.png"), chart, 1200, 800);
    } catch (IOException e) {
      //e.printStackTrace();
      System.out.println(e);
    }
  }

  public static void unitTest(String parm){
    String path = ".\\src\\test\\individualTest";		//要遍历的路径
    File file = new File(path);		//获取其file对象
    File[] fs = file.listFiles();
    for(File f:fs){
      if(f.isDirectory())
        //System.out.println("[PASS] TEST: " + f.getName() + "   ");
        try {
          Thread.sleep(200); //1000 毫秒，也就是1秒.
        } catch(InterruptedException ex) {
          Thread.currentThread().interrupt();
        }
        System.out.format("[\33[32;1mPASS\33[0m]" + "TEST: " + f.getName() +"%n");//%n表示换行
    }
  }

}

